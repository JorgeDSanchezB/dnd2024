import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding D&D 2024 database...');

  // ==================== SPECIES ====================
  const speciesData = [
    {
      name: 'Aasimar',
      description: 'Aasimar are mortals who carry a spark of the Upper Planes within their souls. Whether descended from an angelic being or infused with celestial power, they can fan that spark to bring light, healing, and heavenly fury.',
      size: 'Medium',
      speed: 30,
      traits: JSON.stringify({
        celestialResistance: 'Resistance to Necrotic and Radiant damage',
        darkvision: '60 feet',
        lightBearer: 'You know the Light cantrip. Charisma is your spellcasting ability for it.',
        celestialRevelation: {
          name: 'Celestial Revelation',
          uses: '1 per Long Rest',
          description: 'At level 3, you can transform as a Bonus Action for 1 minute. Each time you use this ability, choose one:',
          options: [
            {
              name: 'Heavenly Wings',
              description: 'You have a Fly Speed equal to your Speed.'
            },
            {
              name: 'Inner Radiance',
              description: 'You shed Bright Light in a 10-foot radius and Dim Light for 10 more feet. Each creature within 5 feet of you when you transform and at the start of each of your turns takes Radiant damage equal to 1d10 + your level.'
            },
            {
              name: 'Necrotic Shroud',
              description: 'You have a Fly Speed equal to your Speed. When you transform, each creature within 30 feet that can see you must succeed on a Wisdom save or be Frightened until the transformation ends. Your attacks deal extra Necrotic damage equal to your Proficiency Bonus.'
            }
          ]
        }
      })
    },
    {
      name: 'Dragonborn',
      description: 'The ancestors of dragonborn hatched from the eggs of chromatic and metallic dragons. Dragonborn look like wingless, bipedal dragons - scaly, bright-eyed, and thick-boned with horns on their heads.',
      size: 'Medium',
      speed: 30,
      traits: JSON.stringify({
        draconicAncestry: 'Choose a dragon type (Black/Blue/Brass/Bronze/Copper/Chromatic/Gold/Green/Red/Silver/White) which determines your breath weapon damage type.',
        breathWeapon: '15-foot Cone or 30-foot Line, Dexterity save, 1d10 damage (scales with level: 2d10 at 5, 3d10 at 11, 4d10 at 17). Uses equal to Proficiency Bonus per Long Rest.',
        damageResistance: 'Resistance to damage type determined by Draconic Ancestry.',
        darkvision: '60 feet',
        draconicFlight: 'At level 5, sprout spectral wings for 10 minutes, Fly Speed equal to your Speed.'
      })
    },
    {
      name: 'Dwarf',
      description: 'Dwarves were raised from the earth in the elder days by a deity of the forge. Called by various names on different worlds, that god gave dwarves an affinity for stone and metal and for living underground.',
      size: 'Medium',
      speed: 30,
      traits: JSON.stringify({
        darkvision: '120 feet',
        dwarvenResilience: 'Resistance to Poison damage. Advantage on saves to avoid or end Poisoned condition.',
        dwarvenToughness: 'HP maximum increases by 1, and increases by 1 again whenever you gain a level.',
        stonecunning: 'Bonus Action to gain Tremorsense 60 feet for 10 minutes while on or touching stone. Uses equal to Proficiency Bonus per Long Rest.'
      })
    },
    {
      name: 'Elf',
      description: 'Created by the god Corellon, the first elves could change their forms at will. They lost this ability when Corellon cursed them for plotting with Lolth. Elves have pointed ears and live for around 750 years.',
      size: 'Medium',
      speed: 30,
      traits: JSON.stringify({
        darkvision: '60 feet',
        elvenLineage: 'Choose: Drow (enhanced Darkvision to 120 ft, Dancing Lights cantrip, Faerie Fire at 3, Darkness at 5), High Elf (Prestidigitation cantrip, Detect Magic at 3, Misty Step at 5), or Wood Elf (Speed 35 ft, Druidcraft cantrip, Longstrider at 3, Pass without Trace at 5).',
        feyAncestry: 'Advantage on saves to avoid or end Charmed condition.',
        keenSenses: 'Proficiency in Insight, Perception, or Survival.',
        trance: "Don't need to sleep. Long Rest in 4 hours of trancelike meditation."
      })
    },
    {
      name: 'Gnome',
      description: 'Gnomes are magical folk created by gods of invention, illusions, and life underground. They live around 425 years. Many gnomes like the feeling of a roof over their head, even if that "roof" is nothing more than a hat.',
      size: 'Small',
      speed: 30,
      traits: JSON.stringify({
        darkvision: '60 feet',
        gnomishCunning: 'Advantage on Intelligence, Wisdom, and Charisma saving throws.',
        gnomishLineage: 'Choose: Forest Gnome (Minor Illusion cantrip, Speak with Animals Proficiency Bonus times per Long Rest) or Rock Gnome (Mending and Prestidigitation cantrips, create Tiny clockwork devices).'
      })
    },
    {
      name: 'Goliath',
      description: 'Towering over most folk, goliaths are distant descendants of giants. Each goliath bears the favors of the first giants - favors that manifest in various supernatural boons.',
      size: 'Medium',
      speed: 35,
      traits: JSON.stringify({
        giantAncestry: 'Choose: Cloud\'s Jaunt (teleport), Fire\'s Burn (+1d10 Fire damage), Frost\'s Chill (+1d6 Cold damage, reduce Speed), Hill\'s Tumble (knock Prone), Stone\'s Endurance (reduce damage Reaction), or Storm\'s Thunder (Reaction deal 1d8 Thunder).',
        largeForm: 'At level 5, become Large for 10 minutes. Advantage on Strength checks, Speed +10 feet.',
        powerfulBuild: 'Advantage on saves to avoid being moved against your will.'
      })
    },
    {
      name: 'Halfling',
      description: 'Cherished and guided by gods who value life, home, and hearth, halflings gravitate toward bucolic havens where family and community help shape their lives. They have a brave and adventurous spirit.',
      size: 'Small',
      speed: 30,
      traits: JSON.stringify({
        brave: 'Advantage on saves to avoid or end Frightened condition.',
        halflingNimbleness: 'Can move through space of any creature one size larger.',
        luck: 'When you roll a 1 on a d20 Test, you can reroll and must use the new roll.',
        naturallyStealthy: 'Can take Hide action when obscured only by a creature at least one size larger.'
      })
    },
    {
      name: 'Human',
      description: 'Found throughout the multiverse, humans are as varied as they are numerous. Their ambition and resourcefulness are commended, respected, and feared on many worlds.',
      size: 'Medium',
      speed: 30,
      traits: JSON.stringify({
        resourceful: 'Gain Heroic Inspiration whenever you finish a Long Rest.',
        skillful: 'Proficiency in one skill of your choice.',
        versatile: 'Gain an Origin feat of your choice. Skilled is recommended.'
      })
    },
    {
      name: 'Orc',
      description: 'Orcs trace their creation to Gruumsh, a powerful god who equipped his children with gifts to help them wander great plains, vast caverns, and churning seas and to face the monsters that lurk there.',
      size: 'Medium',
      speed: 30,
      traits: JSON.stringify({
        adrenalineRush: 'Dash as Bonus Action, gain Temporary HP equal to Proficiency Bonus. Uses equal to Proficiency Bonus per Short/Long Rest.',
        darkvision: '120 feet',
        relentlessEndurance: 'When reduced to 0 HP but not killed, drop to 1 HP instead. Once per Long Rest.'
      })
    },
    {
      name: 'Tiefling',
      description: 'Tieflings are either born in the Lower Planes or have fiendish ancestors who originated there. A tiefling is linked by blood to a devil, a demon, or some other Fiend.',
      size: 'Medium',
      speed: 30,
      traits: JSON.stringify({
        darkvision: '60 feet',
        fiendishLegacy: 'Choose: Abyssal (Resistance to Poison, Poison Spray cantrip, Ray of Sickness at 3, Hold Person at 5), Chthonic (Resistance to Necrotic, Chill Touch cantrip, False Life at 3, Ray of Enfeeblement at 5), or Infernal (Resistance to Fire, Fire Bolt cantrip, Hellish Rebuke at 3, Darkness at 5).',
        otherworldlyPresence: 'You know the Thaumaturgy cantrip.'
      })
    }
  ];

  for (const species of speciesData) {
    await prisma.species.upsert({
      where: { name: species.name },
      update: species,
      create: species
    });
  }
  console.log('Species seeded!');

  // ==================== CLASSES ====================
  const classesData = [
    {
      name: 'Barbarian',
      description: 'Barbarians are mighty warriors who are powered by primal forces of the multiverse that manifest as a Rage. More than a mere emotion, this Rage is an incarnation of a predator\'s ferocity, a storm\'s fury, and a sea\'s turmoil.',
      primaryAbility: 'Strength',
      hitDie: 12,
      savingThrows: JSON.stringify(['Strength', 'Constitution']),
      skillProficiencies: JSON.stringify(['Animal Handling', 'Athletics', 'Intimidation', 'Nature', 'Perception', 'Survival']),
      armorTraining: JSON.stringify(['Light', 'Medium', 'Shields']),
      weaponProficiencies: JSON.stringify(['Simple', 'Martial']),
      startingEquipment: JSON.stringify({
        A: { items: ['Greataxe', '4 Handaxes', 'Explorer\'s Pack'], gold: 15 },
        B: { items: [], gold: 75 }
      }),
      features: JSON.stringify({
        1: ['Rage', 'Unarmored Defense', 'Weapon Mastery'],
        2: ['Danger Sense', 'Reckless Attack'],
        3: ['Barbarian Subclass', 'Primal Knowledge'],
        4: ['Ability Score Improvement'],
        5: ['Extra Attack', 'Fast Movement'],
        6: ['Subclass feature'],
        7: ['Feral Instinct', 'Instinctive Pounce'],
        8: ['Ability Score Improvement'],
        9: ['Brutal Strike'],
        10: ['Subclass feature'],
        11: ['Relentless Rage'],
        12: ['Ability Score Improvement'],
        13: ['Improved Brutal Strike'],
        14: ['Subclass feature'],
        15: ['Persistent Rage'],
        16: ['Ability Score Improvement'],
        17: ['Improved Brutal Strike'],
        18: ['Indomitable Might'],
        19: ['Epic Boon'],
        20: ['Primal Champion']
      }),
      spellcasting: false
    },
    {
      name: 'Bard',
      description: 'Invoking magic through music, dance, and verse, Bards are expert at inspiring others, soothing hurts, disheartening foes, and creating illusions. Bards believe the multiverse was spoken into existence.',
      primaryAbility: 'Charisma',
      hitDie: 8,
      savingThrows: JSON.stringify(['Dexterity', 'Charisma']),
      skillProficiencies: JSON.stringify(['Any']),
      armorTraining: JSON.stringify(['Light']),
      weaponProficiencies: JSON.stringify(['Simple']),
      startingEquipment: JSON.stringify({
        A: { items: ['Leather Armor', '2 Daggers', 'Musical Instrument', 'Entertainer\'s Pack'], gold: 19 },
        B: { items: [], gold: 90 }
      }),
      features: JSON.stringify({
        1: ['Bardic Inspiration', 'Spellcasting'],
        2: ['Expertise', 'Jack of All Trades'],
        3: ['Bard Subclass'],
        4: ['Ability Score Improvement'],
        5: ['Font of Inspiration'],
        6: ['Subclass feature'],
        7: ['Countercharm'],
        8: ['Ability Score Improvement'],
        9: ['Expertise'],
        10: ['Magical Secrets'],
        11: [],
        12: ['Ability Score Improvement'],
        13: [],
        14: ['Subclass feature'],
        15: [],
        16: ['Ability Score Improvement'],
        17: [],
        18: ['Superior Inspiration'],
        19: ['Epic Boon'],
        20: ['Words of Creation']
      }),
      spellcasting: true
    },
    {
      name: 'Cleric',
      description: 'Clerics draw power from the realms of the gods and harness it to work miracles. Blessed by a deity, a pantheon, or another immortal entity, a Cleric can reach out to the divine magic of the Outer Planes.',
      primaryAbility: 'Wisdom',
      hitDie: 8,
      savingThrows: JSON.stringify(['Wisdom', 'Charisma']),
      skillProficiencies: JSON.stringify(['History', 'Insight', 'Medicine', 'Persuasion', 'Religion']),
      armorTraining: JSON.stringify(['Light', 'Medium', 'Shields']),
      weaponProficiencies: JSON.stringify(['Simple']),
      startingEquipment: JSON.stringify({
        A: { items: ['Chain Shirt', 'Shield', 'Mace', 'Holy Symbol', 'Priest\'s Pack'], gold: 7 },
        B: { items: [], gold: 110 }
      }),
      features: JSON.stringify({
        1: ['Spellcasting', 'Divine Order'],
        2: ['Channel Divinity'],
        3: ['Cleric Subclass'],
        4: ['Ability Score Improvement'],
        5: ['Scorn Undead'],
        6: ['Subclass feature'],
        7: ['Blessed Strikes'],
        8: ['Ability Score Improvement'],
        9: [],
        10: ['Divine Intervention'],
        11: [],
        12: ['Ability Score Improvement'],
        13: [],
        14: ['Improved Blessed Strikes'],
        15: [],
        16: ['Ability Score Improvement'],
        17: ['Subclass feature'],
        18: [],
        19: ['Epic Boon'],
        20: ['Greater Divine Intervention']
      }),
      spellcasting: true
    },
    {
      name: 'Druid',
      description: 'Druids belong to ancient orders that call on the forces of nature. Harnessing the magic of animals, plants, and the four elements, Druids heal, transform into animals, and wield elemental destruction.',
      primaryAbility: 'Wisdom',
      hitDie: 8,
      savingThrows: JSON.stringify(['Intelligence', 'Wisdom']),
      skillProficiencies: JSON.stringify(['Arcana', 'Animal Handling', 'Insight', 'Medicine', 'Nature', 'Perception', 'Religion', 'Survival']),
      armorTraining: JSON.stringify(['Light', 'Shields']),
      weaponProficiencies: JSON.stringify(['Simple']),
      startingEquipment: JSON.stringify({
        A: { items: ['Leather Armor', 'Shield', 'Sickle', 'Druidic Focus (Quarterstaff)', 'Explorer\'s Pack', 'Herbalism Kit'], gold: 9 },
        B: { items: [], gold: 50 }
      }),
      features: JSON.stringify({
        1: ['Spellcasting', 'Druidic', 'Primal Order'],
        2: ['Wild Shape', 'Wild Companion'],
        3: ['Druid Subclass'],
        4: ['Ability Score Improvement'],
        5: ['Wild Resurgence'],
        6: ['Subclass feature'],
        7: ['Elemental Fury'],
        8: ['Ability Score Improvement'],
        9: [],
        10: ['Subclass feature'],
        11: [],
        12: ['Ability Score Improvement'],
        13: [],
        14: ['Subclass feature'],
        15: ['Improved Elemental Fury'],
        16: ['Ability Score Improvement'],
        17: [],
        18: ['Beast Spells'],
        19: ['Epic Boon'],
        20: ['Archdruid']
      }),
      spellcasting: true
    },
    {
      name: 'Fighter',
      description: 'Fighters are the most diverse class of warriors in the worlds of D&D. They are skilled combatants who combine martial prowess with tactical cunning to excel in battle.',
      primaryAbility: 'Strength or Dexterity',
      hitDie: 10,
      savingThrows: JSON.stringify(['Strength', 'Constitution']),
      skillProficiencies: JSON.stringify(['Acrobatics', 'Animal Handling', 'Athletics', 'History', 'Insight', 'Intimidation', 'Perception', 'Survival']),
      armorTraining: JSON.stringify(['Light', 'Medium', 'Heavy', 'Shields']),
      weaponProficiencies: JSON.stringify(['Simple', 'Martial']),
      startingEquipment: JSON.stringify({
        A: { items: ['Chain Mail', 'Shield', 'Longsword', 'Handaxe', 'Handaxe', 'Explorer\'s Pack'], gold: 10 },
        B: { items: [], gold: 130 }
      }),
      features: JSON.stringify({
        1: ['Fighting Style', 'Second Wind', 'Weapon Mastery'],
        2: ['Action Surge', 'Tactical Mind'],
        3: ['Fighter Subclass'],
        4: ['Ability Score Improvement'],
        5: ['Extra Attack'],
        6: ['Ability Score Improvement'],
        7: ['Subclass feature'],
        8: ['Ability Score Improvement'],
        9: ['Indomitable'],
        10: ['Subclass feature'],
        11: ['Two Extra Attacks'],
        12: ['Ability Score Improvement'],
        13: ['Improved Indomitable'],
        14: ['Ability Score Improvement'],
        15: ['Subclass feature'],
        16: ['Ability Score Improvement'],
        17: ['Action Surge (2 uses)', 'Improved Indomitable'],
        18: ['Subclass feature'],
        19: ['Epic Boon'],
        20: ['Three Extra Attacks']
      }),
      spellcasting: false
    },
    {
      name: 'Monk',
      description: 'Monks channel an uncanny and mystical power called Ki. They are warriors of bodily discipline who can achieve impossible feats of speed, precision, and martial arts prowess.',
      primaryAbility: 'Dexterity and Wisdom',
      hitDie: 8,
      savingThrows: JSON.stringify(['Strength', 'Dexterity']),
      skillProficiencies: JSON.stringify(['Acrobatics', 'Athletics', 'History', 'Insight', 'Religion', 'Stealth']),
      armorTraining: JSON.stringify([]),
      weaponProficiencies: JSON.stringify(['Simple', 'Shortsword']),
      startingEquipment: JSON.stringify({
        A: { items: ['Quarterstaff', '10 Darts', 'Explorer\'s Pack'], gold: 5 },
        B: { items: [], gold: 35 }
      }),
      features: JSON.stringify({
        1: ['Martial Arts', 'Unarmored Defense'],
        2: ['Ki', 'Unarmored Movement'],
        3: ['Monk Subclass', 'Deflect Attacks'],
        4: ['Ability Score Improvement', 'Slow Fall'],
        5: ['Extra Attack', 'Stunning Strike'],
        6: ['Subclass feature'],
        7: ['Evasion', 'Stillness of Mind'],
        8: ['Ability Score Improvement'],
        9: ['Unarmored Movement (vertical surfaces)'],
        10: ['Subclass feature'],
        11: [],
        12: ['Ability Score Improvement'],
        13: ['Tongue of the Sun and Moon'],
        14: ['Subclass feature', 'Diamond Soul'],
        15: ['Timeless Body'],
        16: ['Ability Score Improvement'],
        17: ['Subclass feature'],
        18: ['Empty Body'],
        19: ['Epic Boon'],
        20: ['Perfect Self']
      }),
      spellcasting: false
    },
    {
      name: 'Paladin',
      description: 'Paladins are divine warriors who swear sacred oaths to uphold justice and righteousness. They combine martial prowess with divine magic to smite foes and shield allies.',
      primaryAbility: 'Strength and Charisma',
      hitDie: 10,
      savingThrows: JSON.stringify(['Wisdom', 'Charisma']),
      skillProficiencies: JSON.stringify(['Athletics', 'Insight', 'Intimidation', 'Medicine', 'Persuasion', 'Religion']),
      armorTraining: JSON.stringify(['Light', 'Medium', 'Heavy', 'Shields']),
      weaponProficiencies: JSON.stringify(['Simple', 'Martial']),
      startingEquipment: JSON.stringify({
        A: { items: ['Chain Mail', 'Shield', 'Longsword', '5 Javelins', 'Priest\'s Pack', 'Holy Symbol'], gold: 15 },
        B: { items: [], gold: 115 }
      }),
      features: JSON.stringify({
        1: ['Lay on Hands', 'Fighting Style', 'Weapon Mastery', 'Divine Sense'],
        2: ['Spellcasting', 'Divine Smite'],
        3: ['Paladin Subclass', 'Channel Divinity'],
        4: ['Ability Score Improvement'],
        5: ['Extra Attack'],
        6: ['Aura of Protection'],
        7: ['Subclass feature'],
        8: ['Ability Score Improvement'],
        9: [],
        10: ['Aura of Courage'],
        11: ['Improved Divine Smite'],
        12: ['Ability Score Improvement'],
        13: [],
        14: ['Cleansing Touch'],
        15: ['Subclass feature'],
        16: ['Ability Score Improvement'],
        17: [],
        18: ['Aura improvements'],
        19: ['Epic Boon'],
        20: ['Subclass feature']
      }),
      spellcasting: true
    },
    {
      name: 'Ranger',
      description: 'Rangers are warriors of the wilderness who combine martial prowess with nature magic. They are hunters, trackers, and scouts who excel at surviving in hostile environments.',
      primaryAbility: 'Dexterity and Wisdom',
      hitDie: 10,
      savingThrows: JSON.stringify(['Strength', 'Dexterity']),
      skillProficiencies: JSON.stringify(['Animal Handling', 'Athletics', 'Insight', 'Investigation', 'Nature', 'Perception', 'Stealth', 'Survival']),
      armorTraining: JSON.stringify(['Light', 'Medium', 'Shields']),
      weaponProficiencies: JSON.stringify(['Simple', 'Martial']),
      startingEquipment: JSON.stringify({
        A: { items: ['Scale Mail', 'Shield', 'Longbow', '20 Arrows', 'Two Shortswords', 'Explorer\'s Pack'], gold: 10 },
        B: { items: [], gold: 100 }
      }),
      features: JSON.stringify({
        1: ['Favored Enemy', 'Weapon Mastery', 'Natural Explorer', 'Spellcasting'],
        2: ['Fighting Style'],
        3: ['Ranger Subclass', 'Primeval Awareness'],
        4: ['Ability Score Improvement'],
        5: ['Extra Attack'],
        6: ['Favored Terrain'],
        7: ['Subclass feature'],
        8: ['Ability Score Improvement', 'Land\'s Stride'],
        9: [],
        10: ['Subclass feature', 'Natural Explorer improvement'],
        11: [],
        12: ['Ability Score Improvement'],
        13: [],
        14: ['Subclass feature', 'Vanish'],
        15: [],
        16: ['Ability Score Improvement'],
        17: [],
        18: ['Feral Senses'],
        19: ['Epic Boon'],
        20: ['Foe Slayer']
      }),
      spellcasting: true
    },
    {
      name: 'Rogue',
      description: 'Rogues are masters of stealth, deception, and deadly precision. They launch deadly Sneak Attacks while avoiding harm through agility, cunning, and a variety of specialized skills.',
      primaryAbility: 'Dexterity',
      hitDie: 8,
      savingThrows: JSON.stringify(['Dexterity', 'Intelligence']),
      skillProficiencies: JSON.stringify(['Acrobatics', 'Athletics', 'Deception', 'Insight', 'Intimidation', 'Investigation', 'Perception', 'Performance', 'Persuasion', 'Sleight of Hand', 'Stealth']),
      armorTraining: JSON.stringify(['Light']),
      weaponProficiencies: JSON.stringify(['Simple', 'Hand Crossbow', 'Longsword', 'Rapier', 'Shortsword']),
      startingEquipment: JSON.stringify({
        A: { items: ['Leather Armor', '2 Daggers', 'Shortsword', 'Thieves\' Tools', 'Explorer\'s Pack'], gold: 10 },
        B: { items: [], gold: 70 }
      }),
      features: JSON.stringify({
        1: ['Sneak Attack', 'Cunning Action', 'Weapon Mastery'],
        2: ['Cunning Strike'],
        3: ['Rogue Subclass', 'Steady Aim'],
        4: ['Ability Score Improvement'],
        5: ['Cunning Strike improvement', 'Uncanny Dodge'],
        6: ['Subclass feature'],
        7: ['Evasion'],
        8: ['Ability Score Improvement'],
        9: ['Cunning Strike improvement'],
        10: ['Subclass feature'],
        11: ['Reliable Talent'],
        12: ['Ability Score Improvement'],
        13: ['Cunning Strike improvement'],
        14: ['Subclass feature', 'Blindsense'],
        15: ['Slippery Mind'],
        16: ['Ability Score Improvement'],
        17: ['Cunning Strike improvement'],
        18: ['Elusive'],
        19: ['Epic Boon'],
        20: ['Stroke of Luck']
      }),
      spellcasting: false
    },
    {
      name: 'Sorcerer',
      description: 'Sorcerers wield innate magic that is stamped into their being. Some Sorcerers can\'t name the origin of their power, while others trace it to strange events in their personal or family history.',
      primaryAbility: 'Charisma',
      hitDie: 6,
      savingThrows: JSON.stringify(['Constitution', 'Charisma']),
      skillProficiencies: JSON.stringify(['Arcana', 'Deception', 'Insight', 'Intimidation', 'Persuasion', 'Religion']),
      armorTraining: JSON.stringify([]),
      weaponProficiencies: JSON.stringify(['Simple']),
      startingEquipment: JSON.stringify({
        A: { items: ['Spear', '2 Daggers', 'Arcane Focus (crystal)', 'Dungeoneer\'s Pack'], gold: 28 },
        B: { items: [], gold: 50 }
      }),
      features: JSON.stringify({
        1: ['Spellcasting', 'Innate Sorcery'],
        2: ['Font of Magic', 'Metamagic'],
        3: ['Sorcerer Subclass'],
        4: ['Ability Score Improvement'],
        5: ['Sorcerous Restoration'],
        6: ['Subclass feature'],
        7: ['Sorcery Incarnate'],
        8: ['Ability Score Improvement'],
        9: [],
        10: ['Metamagic'],
        11: [],
        12: ['Ability Score Improvement'],
        13: [],
        14: ['Subclass feature'],
        15: [],
        16: ['Ability Score Improvement'],
        17: ['Metamagic'],
        18: ['Subclass feature'],
        19: ['Epic Boon'],
        20: ['Arcane Apotheosis']
      }),
      spellcasting: true
    },
    {
      name: 'Warlock',
      description: 'Warlocks quest for knowledge that lies hidden in the fabric of the multiverse. They often begin their search by delving into tomes of forbidden lore and eventually form a binding pact with a powerful patron.',
      primaryAbility: 'Charisma',
      hitDie: 8,
      savingThrows: JSON.stringify(['Wisdom', 'Charisma']),
      skillProficiencies: JSON.stringify(['Arcana', 'Deception', 'History', 'Intimidation', 'Investigation', 'Nature', 'Religion']),
      armorTraining: JSON.stringify(['Light']),
      weaponProficiencies: JSON.stringify(['Simple']),
      startingEquipment: JSON.stringify({
        A: { items: ['Leather Armor', 'Sickle', '2 Daggers', 'Arcane Focus (orb)', 'Book (occult lore)', 'Scholar\'s Pack'], gold: 15 },
        B: { items: [], gold: 100 }
      }),
      features: JSON.stringify({
        1: ['Eldritch Invocations', 'Pact Magic'],
        2: ['Magical Cunning'],
        3: ['Warlock Subclass'],
        4: ['Ability Score Improvement'],
        5: [],
        6: ['Subclass feature'],
        7: [],
        8: ['Ability Score Improvement'],
        9: ['Contact Patron'],
        10: ['Subclass feature'],
        11: ['Mystic Arcanum (level 6 spell)'],
        12: ['Ability Score Improvement'],
        13: ['Mystic Arcanum (level 7 spell)'],
        14: ['Subclass feature'],
        15: ['Mystic Arcanum (level 8 spell)'],
        16: ['Ability Score Improvement'],
        17: ['Mystic Arcanum (level 9 spell)'],
        18: [],
        19: ['Epic Boon'],
        20: ['Eldritch Master']
      }),
      spellcasting: true
    },
    {
      name: 'Wizard',
      description: 'Wizards are supreme magic-users defined by their spellbooks. They use their books to create spells of explosive fire, piercing cold, and dazzling lightning, as well as subtler magic.',
      primaryAbility: 'Intelligence',
      hitDie: 6,
      savingThrows: JSON.stringify(['Intelligence', 'Wisdom']),
      skillProficiencies: JSON.stringify(['Arcana', 'History', 'Insight', 'Investigation', 'Medicine', 'Religion']),
      armorTraining: JSON.stringify([]),
      weaponProficiencies: JSON.stringify(['Simple']),
      startingEquipment: JSON.stringify({
        A: { items: ['Quarterstaff', 'Arcane Focus (orb)', 'Spellbook', 'Scholar\'s Pack'], gold: 17 },
        B: { items: [], gold: 55 }
      }),
      features: JSON.stringify({
        1: ['Spellcasting', 'Arcane Recovery'],
        2: ['Scholar'],
        3: ['Wizard Subclass'],
        4: ['Ability Score Improvement'],
        5: [],
        6: ['Subclass feature'],
        7: [],
        8: ['Ability Score Improvement'],
        9: [],
        10: ['Subclass feature'],
        11: [],
        12: ['Ability Score Improvement'],
        13: [],
        14: ['Subclass feature'],
        15: [],
        16: ['Ability Score Improvement'],
        17: [],
        18: ['Spell Mastery'],
        19: ['Epic Boon'],
        20: ['Signature Spells']
      }),
      spellcasting: true
    }
  ];

  for (const classData of classesData) {
    await prisma.characterClass.upsert({
      where: { name: classData.name },
      update: classData,
      create: classData
    });
  }
  console.log('Classes seeded!');

  // ==================== SUBCLASSES ====================
  const subclassesData = [
    // Barbarian Subclasses
    { name: 'Path of the Berserker', description: 'Channel Rage into Violent Fury', classId: 'Barbarian', features: JSON.stringify({ 3: ['Frenzy'], 6: ['Mindless Rage'], 10: ['Retaliation'], 14: ['Intimidating Presence'] }) },
    { name: 'Path of the Wild Heart', description: 'Walk in Community with the Animal World', classId: 'Barbarian', features: JSON.stringify({ 3: ['Animal Spirit', 'Rage of the Wilds'], 6: ['Aspect of the Wilds'], 10: ['Nature Speaker'], 14: ['Power of the Wilds'] }) },
    { name: 'Path of the World Tree', description: 'Trace the Roots and Branches of the Multiverse', classId: 'Barbarian', features: JSON.stringify({ 3: ['Vitality of the Tree'], 6: ['Branches of the Tree'], 10: ['Binding Roots'], 14: ['Travel Along the Tree'] }) },
    { name: 'Path of the Zealot', description: 'Rage in Ecstatic Union with a God', classId: 'Barbarian', features: JSON.stringify({ 3: ['Divine Fury', 'Warrior of the Gods'], 6: ['Fanatical Focus'], 10: ['Zealous Presence'], 14: ['Rage of the Gods'] }) },
    
    // Bard Subclasses
    { name: 'College of Dance', description: 'Move in Harmony with the Cosmos', classId: 'Bard', features: JSON.stringify({ 3: ['Dazzling Footwork'], 6: ['Inspiring Movement', 'Tempo Footwork'], 14: ['Leaping Evasion'] }) },
    { name: 'College of Glamour', description: 'Weave Beguiling Fey Magic', classId: 'Bard', features: JSON.stringify({ 3: ['Beguiling Magic', 'Mantle of Inspiration'], 6: ['Mantle of Majesty'], 14: ['Unbreakable Majesty'] }) },
    { name: 'College of Lore', description: 'Plumb the Depths of Magical Knowledge', classId: 'Bard', features: JSON.stringify({ 3: ['Bonus Proficiencies', 'Cutting Words'], 6: ['Magical Discoveries'], 14: ['Peerless Skill'] }) },
    { name: 'College of Valor', description: 'Sing the Deeds of Ancient Heroes', classId: 'Bard', features: JSON.stringify({ 3: ['Combat Inspiration', 'Martial Training'], 6: ['Extra Attack'], 14: ['Battle Magic'] }) },
    
    // Cleric Subclasses
    { name: 'Life Domain', description: 'Soothe the Hurts of the World', classId: 'Cleric', features: JSON.stringify({ 1: ['Disciple of Life'], 2: ['Preserve Life'], 6: ['Blessed Healer'], 17: ['Supreme Healing'] }), subclassSpells: JSON.stringify({ 1: ['Bless', 'Cure Wounds'], 3: ['Lesser Restoration', 'Revivify'], 5: ['Mass Cure Wounds', 'Raise Dead'], 7: ['Heal', 'Regenerate'], 9: ['Mass Heal', 'Resurrection'] }) },
    { name: 'Light Domain', description: 'Bring Light to Banish Darkness', classId: 'Cleric', features: JSON.stringify({ 1: ['Radiance of the Dawn', 'Warding Flare'], 6: ['Improved Warding Flare'], 17: ['Corona of Light'] }), subclassSpells: JSON.stringify({ 1: ['Burning Hands', 'Faerie Fire'], 3: ['Flaming Sphere', 'Scorching Ray'], 5: ['Daylight', 'Fireball'], 7: ['Wall of Fire', 'Guardian of Faith'], 9: ['Flame Strike', 'Scrying'] }) },
    { name: 'Trickery Domain', description: 'Make Mischief and Challenge Authority', classId: 'Cleric', features: JSON.stringify({ 1: ['Blessing of the Trickster'], 2: ['Invoke Duplicity'], 6: ['Trickster\'s Transposition'], 17: ['Improved Duplicity'] }), subclassSpells: JSON.stringify({ 1: ['Charm Person', 'Disguise Self'], 3: ['Mirror Image', 'Pass Without Trace'], 5: ['Blink', 'Dispel Magic'], 7: ['Dimension Door', 'Polymorph'], 9: ['Dominate Person', 'Modify Memory'] }) },
    { name: 'War Domain', description: 'Inspire Valor and Smite Foes', classId: 'Cleric', features: JSON.stringify({ 1: ['Guided Strike', 'War Priest'], 6: ['War God\'s Blessing'], 17: ['Avatar of Battle'] }), subclassSpells: JSON.stringify({ 1: ['Divine Favor', 'Shield of Faith'], 3: ['Magic Weapon', 'Spiritual Weapon'], 5: ['Crusader\'s Mantle', 'Spirit Guardians'], 7: ['Freedom of Movement', 'Stoneskin'], 9: ['Flame Strike', 'Hold Monster'] }) },
    
    // Druid Subclasses
    { name: 'Circle of the Land', description: 'Draw on the Magic of the Environment', classId: 'Druid', features: JSON.stringify({ 3: ['Land\'s Aid'], 6: ['Natural Recovery', 'Land\'s Stride'], 10: ['Nature\'s Ward'], 14: ['Nature\'s Sanctuary'] }), subclassSpells: JSON.stringify({ 3: ['Invisibility', 'Pass Without Trace'], 5: ['Haste', 'Lightning Bolt'], 7: ['Freedom of Movement', 'Stoneskin'], 9: ['Tree Stride', 'Wall of Stone'] }) },
    { name: 'Circle of the Moon', description: 'Adopt Powerful Animal Forms', classId: 'Druid', features: JSON.stringify({ 3: ['Combat Wild Shape', 'Circle Forms'], 6: ['Improved Combat Wild Shape'], 10: ['Elemental Wild Shape'], 14: ['Thousand Forms'] }) },
    { name: 'Circle of the Sea', description: 'Channel Tides and Storms', classId: 'Druid', features: JSON.stringify({ 3: ['Waterborne Form', 'Stormborn'], 6: ['Shifting Form'], 10: ['Stormborn improvement'], 14: ['Oceanic Gift'] }) },
    { name: 'Circle of the Stars', description: 'Gain Powers in a Starry Form', classId: 'Druid', features: JSON.stringify({ 3: ['Starry Form', 'Star Map'], 6: ['Cosmic Omen'], 10: ['Twinkling Constellations'], 14: ['Full of Stars'] }) },
    
    // Fighter Subclasses
    { name: 'Battle Master', description: 'Master the Art of Combat', classId: 'Fighter', features: JSON.stringify({ 3: ['Combat Superiority', 'Student of War'], 7: ['Know Your Enemy'], 10: ['Improved Combat Superiority'], 15: ['Relentless'], 18: ['Improved Combat Superiority'] }) },
    { name: 'Champion', description: 'Excel at the Fundamentals of Combat', classId: 'Fighter', features: JSON.stringify({ 3: ['Improved Critical'], 7: ['Remarkable Athlete'], 10: ['Additional Fighting Style'], 15: ['Superior Critical'], 18: ['Survivor'] }) },
    { name: 'Eldritch Knight', description: 'Combine Martial Prowess with Magic', classId: 'Fighter', features: JSON.stringify({ 3: ['Spellcasting', 'War Magic'], 7: ['War Magic improvement'], 10: ['Eldritch Strike'], 15: ['Arcane Charge'], 18: ['Improved War Magic'] }) },
    { name: 'Psi Warrior', description: 'Channel Psionic Power in Battle', classId: 'Fighter', features: JSON.stringify({ 3: ['Psionic Power', 'Telekinetic Adept'], 7: ['Telekinetic Master'], 10: ['Guardian Field'], 15: ['Telekinetic Master improvement'], 18: ['Bulwark of Force'] }) },
    
    // Monk Subclasses
    { name: 'Warrior of the Elements', description: 'Wield Elemental Power', classId: 'Monk', features: JSON.stringify({ 3: ['Elemental Attunement'], 6: ['Elemental Strikes'], 11: ['Elemental Burst'], 17: ['Elemental Epitome'] }) },
    { name: 'Warrior of the Hand', description: 'Strike with Ki-Infused Fists', classId: 'Monk', features: JSON.stringify({ 3: ['Open Hand Technique'], 6: ['Wholeness of Body'], 11: ['Tranquility'], 17: ['Quivering Palm'] }) },
    { name: 'Warrior of Shadow', description: 'Manipulate Darkness and Shadow', classId: 'Monk', features: JSON.stringify({ 3: ['Shadow Arts'], 6: ['Shadow Step'], 11: ['Improved Shadow Step'], 17: ['Cloak of Shadows'] }) },
    { name: 'Warrior of Light', description: 'Radiant Light and Healing', classId: 'Monk', features: JSON.stringify({ 3: ['Radiant Sunlight'], 6: ['Illuminating Strikes', 'Searing Sunburst'], 11: ['Sun Shield'], 17: ['Illuminating Strikes improvement'] }) },
    
    // Paladin Subclasses
    { name: 'Oath of Devotion', description: 'Emulate the Angels of Justice', classId: 'Paladin', features: JSON.stringify({ 3: ['Sacred Weapon', 'Turn the Unholy'], 7: ['Aura of Devotion'], 15: ['Purity of Spirit'], 20: ['Holy Nimbus'] }), subclassSpells: JSON.stringify({ 3: ['Protection from Evil and Good', 'Sanctuary'], 5: ['Lesser Restoration', 'Zone of Truth'], 7: ['Beacon of Hope', 'Dispel Magic'], 9: ['Freedom of Movement', 'Guardian of Faith'] }) },
    { name: 'Oath of Glory', description: 'Reach the Heights of Heroism', classId: 'Paladin', features: JSON.stringify({ 3: ['Channel Divinity options'], 7: ['Aura of Alacrity'], 15: ['Glorious Defense'], 20: ['Living Legend'] }), subclassSpells: JSON.stringify({ 3: ['Guiding Bolt', 'Heroism'], 5: ['Enhance Ability', 'Magic Weapon'], 7: ['Haste', 'Protection from Energy'], 9: ['Compulsion', 'Freedom of Movement'] }) },
    { name: 'Oath of the Ancients', description: 'Preserve Life, Joy, and Nature', classId: 'Paladin', features: JSON.stringify({ 3: ['Nature\'s Wrath', 'Turn the Faithless'], 7: ['Aura of Warding'], 15: ['Undying Sentinel'], 20: ['Elder Champion'] }), subclassSpells: JSON.stringify({ 3: ['Ensnaring Strike', 'Speak with Animals'], 5: ['Misty Step', 'Moonbeam'], 7: ['Aura of Vitality', 'Plant Growth'], 9: ['Ice Storm', 'Stoneskin'] }) },
    { name: 'Oath of Vengeance', description: 'Hunt Down Evildoers', classId: 'Paladin', features: JSON.stringify({ 3: ['Abjure Enemy', 'Vow of Enmity'], 7: ['Relentless Avenger'], 15: ['Soul of Vengeance'], 20: ['Avenging Angel'] }), subclassSpells: JSON.stringify({ 3: ['Bane', 'Hunter\'s Mark'], 5: ['Hold Person', 'Misty Step'], 7: ['Haste', 'Protection from Energy'], 9: ['Banishment', 'Dimension Door'] }) },
    
    // Ranger Subclasses
    { name: 'Beast Master', description: 'Bond with a Primal Beast', classId: 'Ranger', features: JSON.stringify({ 3: ['Primal Companion'], 7: ['Exceptional Training'], 11: ['Bestial Fury'], 15: ['Share Spells'] }) },
    { name: 'Fey Wanderer', description: 'Manifest Fey Mirth and Fury', classId: 'Ranger', features: JSON.stringify({ 3: ['Dreadful Strikes', 'Fey Wanderer Magic', 'Otherworldly Glamour'], 7: ['Beguiling Twist'], 11: ['Fey Reinforcements'], 15: ['Misty Wanderer'] }), subclassSpells: JSON.stringify({ 3: ['Charm Person', 'Misty Step'], 5: ['Blink', 'Dispel Magic'], 7: ['Dimension Door', 'Polymorph'], 9: ['Mislead', 'Seeming'] }) },
    { name: 'Gloom Stalker', description: 'Hunt Foes that Lurk in Darkness', classId: 'Ranger', features: JSON.stringify({ 3: ['Gloom Stalker Magic', 'Dread Ambusher', 'Umbral Sight'], 7: ['Iron Mind'], 11: ['Stalker\'s Flurry'], 15: ['Shadowy Dodge'] }), subclassSpells: JSON.stringify({ 3: ['Disguise Self', 'Rope Trick'], 5: ['Fear', 'Gaseous Form'], 7: ['Greater Invisibility', 'Stoneskin'], 9: ['Far Step', 'Seeming'] }) },
    { name: 'Hunter', description: 'Protect Nature with Martial Versatility', classId: 'Ranger', features: JSON.stringify({ 3: ['Hunter\'s Prey'], 7: ['Defensive Tactics'], 11: ['Multiattack'], 15: ['Superior Hunter\'s Defense'] }) },
    
    // Rogue Subclasses
    { name: 'Arcane Trickster', description: 'Enhance Stealth with Spells', classId: 'Rogue', features: JSON.stringify({ 3: ['Spellcasting', 'Mage Hand Legerdemain'], 9: ['Magical Ambush'], 13: ['Versatile Trickster'], 17: ['Spell Thief'] }) },
    { name: 'Assassin', description: 'Practice the Grim Art of Death', classId: 'Rogue', features: JSON.stringify({ 3: ['Assassinate', 'Assassin\'s Tools'], 9: ['Infiltration Expertise'], 13: ['Envenom Weapons'], 17: ['Death Strike'] }) },
    { name: 'Soulknife', description: 'Strike Foes with Psionic Blades', classId: 'Rogue', features: JSON.stringify({ 3: ['Psionic Power', 'Psychic Blades'], 9: ['Soul Blades'], 13: ['Psychic Veil'], 17: ['Rend Mind'] }) },
    { name: 'Thief', description: 'Hunt for Treasure as a Classic Adventurer', classId: 'Rogue', features: JSON.stringify({ 3: ['Fast Hands', 'Second-Story Work'], 9: ['Supreme Sneak'], 13: ['Use Magic Device'], 17: ['Thief\'s Reflexes'] }) },
    
    // Sorcerer Subclasses
    { name: 'Aberrant Sorcery', description: 'Wield Unnatural Psionic Power', classId: 'Sorcerer', features: JSON.stringify({ 1: ['Psionic Spells', 'Telepathic Speech'], 6: ['Psionic Sorcery', 'Psychic Defenses'], 14: ['Revelation in Flesh'] }), subclassSpells: JSON.stringify({ 1: ['Arms of Hadar', 'Dissonant Whispers'], 3: ['Calm Emotions', 'Detect Thoughts'], 5: ['Clairvoyance', 'Sending'], 7: ['Arcane Eye', 'Summon Aberration'], 9: ['Contact Other Plane', 'Telekinesis'] }) },
    { name: 'Clockwork Sorcery', description: 'Channel Cosmic Forces of Order', classId: 'Sorcerer', features: JSON.stringify({ 1: ['Clockwork Spells', 'Restore Balance'], 6: ['Bastion of Law'], 14: ['Trance of Order'], 18: ['Clockwork Cavalcade'] }), subclassSpells: JSON.stringify({ 1: ['Alarm', 'Protection from Evil and Good'], 3: ['Find Traps', 'Knock'], 5: ['Counterspell', 'Nondetection'], 7: ['Arcane Eye', 'Freedom of Movement'], 9: ['Greater Restoration', 'Wall of Force'] }) },
    { name: 'Draconic Sorcery', description: 'Breathe the Magic of Dragons', classId: 'Sorcerer', features: JSON.stringify({ 1: ['Draconic Resilience'], 6: ['Elemental Affinity'], 14: ['Draconic Wings'], 18: ['Draconic Presence'] }), subclassSpells: JSON.stringify({ 1: ['Chromatic Orb', 'Comprehend Languages'], 3: ['Dragon\'s Breath', 'See Invisibility'], 5: ['Fly', 'Protection from Energy'], 7: ['Elemental Bane', 'Polymorph'], 9: ['Legend Lore', 'Scrying'] }) },
    { name: 'Wild Magic Sorcery', description: 'Unleash Chaotic Magic', classId: 'Sorcerer', features: JSON.stringify({ 1: ['Wild Magic Surge', 'Tides of Chaos'], 6: ['Bend Luck'], 14: ['Controlled Chaos'], 18: ['Spell Bombardment'] }) },
    
    // Warlock Subclasses
    { name: 'Archfey Patron', description: 'Teleport and Wield Fey Magic', classId: 'Warlock', features: JSON.stringify({ 1: ['Fey Presence'], 6: ['Misty Escape'], 10: ['Beguiling Defenses'], 14: ['Dark Delirium'] }), subclassSpells: JSON.stringify({ 1: ['Faerie Fire', 'Sleep'], 3: ['Calm Emotions', 'Phantasmal Force'], 5: ['Blink', 'Plant Growth'], 7: ['Dominate Beast', 'Greater Invisibility'], 9: ['Dominate Person', 'Seeming'] }) },
    { name: 'Celestial Patron', description: 'Heal with Heavenly Magic', classId: 'Warlock', features: JSON.stringify({ 1: ['Healing Light', 'Bonus Cantrips'], 6: ['Radiant Soul'], 10: ['Celestial Resistance'], 14: ['Searing Vengeance'] }), subclassSpells: JSON.stringify({ 1: ['Cure Wounds', 'Guiding Bolt'], 3: ['Flaming Sphere', 'Lesser Restoration'], 5: ['Daylight', 'Revivify'], 7: ['Aura of Life', 'Guardian of Faith'], 9: ['Flame Strike', 'Greater Restoration'] }) },
    { name: 'Fiend Patron', description: 'Command the Power of the Lower Planes', classId: 'Warlock', features: JSON.stringify({ 1: ['Dark One\'s Blessing'], 6: ['Dark One\'s Own Luck'], 10: ['Fiendish Resilience'], 14: ['Hurl Through Hell'] }), subclassSpells: JSON.stringify({ 1: ['Burning Hands', 'Command'], 3: ['Blindness', 'Scorching Ray'], 5: ['Fireball', 'Stinking Cloud'], 7: ['Fire Shield', 'Wall of Fire'], 9: ['Flame Strike', 'Hallow'] }) },
    { name: 'Great Old One Patron', description: 'Wield Alien, Unknowable Magic', classId: 'Warlock', features: JSON.stringify({ 1: ['Awakened Mind', 'Telepathic Speech'], 6: ['Entropic Ward'], 10: ['Thought Shield'], 14: ['Create Thrall'] }), subclassSpells: JSON.stringify({ 1: ['Dissonant Whispers', 'Tasha\'s Hideous Laughter'], 3: ['Detect Thoughts', 'Phantasmal Force'], 5: ['Clairvoyance', 'Tongues'], 7: ['Evard\'s Black Tentacles', 'Summon Aberration'], 9: ['Contact Other Plane', 'Telekinesis'] }) },
    
    // Wizard Subclasses
    { name: 'School of Abjuration', description: 'Master Protective Magic', classId: 'Wizard', features: JSON.stringify({ 2: ['Arcane Ward'], 6: ['Projected Ward'], 10: ['Improved Abjuration'], 14: ['Spell Resistance'] }) },
    { name: 'School of Divination', description: 'Peek Behind the Curtain of Reality', classId: 'Wizard', features: JSON.stringify({ 2: ['Portent'], 6: ['Expert Divination'], 10: ['The Third Eye'], 14: ['Greater Portent'] }) },
    { name: 'School of Evocation', description: 'Wield the Raw Power of Magic', classId: 'Wizard', features: JSON.stringify({ 2: ['Evocation Savant', 'Sculpt Spells'], 6: ['Potent Cantrip'], 10: ['Empowered Evocation'], 14: ['Overchannel'] }) },
    { name: 'School of Illusion', description: 'Bend Light and Shadow to Your Will', classId: 'Wizard', features: JSON.stringify({ 2: ['Illusion Savant', 'Improved Minor Illusion'], 6: ['Malleable Illusions'], 10: ['Illusory Self'], 14: ['Illusory Reality'] }) }
  ];

  // Delete existing subclasses first
  await prisma.subclass.deleteMany({});
  
  for (const subclass of subclassesData) {
    const parentClass = await prisma.characterClass.findUnique({ where: { name: subclass.classId } });
    if (parentClass) {
      await prisma.subclass.create({
        data: { 
          name: subclass.name, 
          description: subclass.description, 
          features: subclass.features, 
          subclassSpells: subclass.subclassSpells || null,
          classId: parentClass.id 
        }
      });
    }
  }
  console.log('Subclasses seeded!');

  // ==================== BACKGROUNDS ====================
  const backgroundsData = [
    { name: 'Acolyte', description: 'You have spent your life in the service of a temple to a specific god or pantheon of gods. You act as an intermediary between the realm of the holy and the mortal world.', abilityScores: JSON.stringify(['Intelligence', 'Wisdom', 'Charisma']), feat: 'Magic Initiate (Cleric)', skillProficiencies: JSON.stringify(['Insight', 'Religion']), toolProficiency: 'Calligrapher\'s Supplies', equipment: JSON.stringify({ A: { items: ['Calligrapher\'s Supplies', 'Book (prayers)', 'Holy Symbol', 'Parchment (10 sheets)', 'Robe'], gold: 8 }, B: { items: [], gold: 50 } }) },
    { name: 'Artisan', description: 'You are a master craftsperson, able to create items of quality and beauty. Your trade has taken you on journeys and introduced you to many people.', abilityScores: JSON.stringify(['Strength', 'Dexterity', 'Constitution']), feat: 'Crafter', skillProficiencies: JSON.stringify(['Investigation', 'Perception']), toolProficiency: 'Artisan\'s Tools (any one)', equipment: JSON.stringify({ A: { items: ['Artisan\'s Tools (chosen)', '2 Pouches', 'Traveler\'s Clothes'], gold: 32 }, B: { items: [], gold: 50 } }) },
    { name: 'Charlatan', description: 'You have always had a way with people. You know what makes them tick, you can tease out their hearts\' desires after a few minutes of conversation.', abilityScores: JSON.stringify(['Dexterity', 'Constitution', 'Charisma']), feat: 'Skilled', skillProficiencies: JSON.stringify(['Deception', 'Sleight of Hand']), toolProficiency: 'Disguise Kit or Forgery Kit', equipment: JSON.stringify({ A: { items: ['Fine Clothes', 'Disguise Kit', '10-sided die', 'Signet ring of an imaginary duke'], gold: 15 }, B: { items: [], gold: 50 } }) },
    { name: 'Criminal', description: 'You are an experienced criminal with a history of breaking the law. You have spent a lot of time among other criminals and still have contacts within the criminal underworld.', abilityScores: JSON.stringify(['Dexterity', 'Intelligence', 'Constitution']), feat: 'Skilled', skillProficiencies: JSON.stringify(['Stealth', 'Deception']), toolProficiency: 'Thieves\' Tools', equipment: JSON.stringify({ A: { items: ['Crowbar', 'Common Clothes', 'Thieves\' Tools'], gold: 15 }, B: { items: [], gold: 50 } }) },
    { name: 'Entertainer', description: 'You thrive in front of an audience. You know how to entrance them, entertain them, and even inspire them.', abilityScores: JSON.stringify(['Strength', 'Dexterity', 'Charisma']), feat: 'Skilled', skillProficiencies: JSON.stringify(['Acrobatics', 'Performance']), toolProficiency: 'Musical Instrument or Disguise Kit', equipment: JSON.stringify({ A: { items: ['Musical Instrument', 'Common Clothes', 'Costume'], gold: 15 }, B: { items: [], gold: 50 } }) },
    { name: 'Farmer', description: 'You grew up working on a farm, learning the rhythms of nature and the value of hard work.', abilityScores: JSON.stringify(['Strength', 'Constitution', 'Wisdom']), feat: 'Tough', skillProficiencies: JSON.stringify(['Animal Handling', 'Nature']), toolProficiency: 'Vehicles (Land)', equipment: JSON.stringify({ A: { items: ['Common Clothes', 'Sickle', 'Shovel', 'Iron Pot'], gold: 10 }, B: { items: [], gold: 50 } }) },
    { name: 'Guard', description: 'You have spent your life as a guard, protecting people and property from harm.', abilityScores: JSON.stringify(['Strength', 'Dexterity', 'Wisdom']), feat: 'Tavern Brawler', skillProficiencies: JSON.stringify(['Athletics', 'Perception']), toolProficiency: 'Gaming Set', equipment: JSON.stringify({ A: { items: ['Common Clothes', 'Club', 'Manacles'], gold: 10 }, B: { items: [], gold: 50 } }) },
    { name: 'Guide', description: 'You know the wilderness well, having spent years leading others through dangerous terrain.', abilityScores: JSON.stringify(['Dexterity', 'Wisdom', 'Constitution']), feat: 'Skilled', skillProficiencies: JSON.stringify(['Perception', 'Survival']), toolProficiency: 'Navigator\'s Tools', equipment: JSON.stringify({ A: { items: ['Common Clothes', 'Rope', 'Torch', 'Torches (5)'], gold: 10 }, B: { items: [], gold: 50 } }) },
    { name: 'Hermit', description: 'You lived in seclusion, either in a sheltered community or alone, for a formative part of your life.', abilityScores: JSON.stringify(['Constitution', 'Wisdom', 'Charisma']), feat: 'Magic Initiate (Druid)', skillProficiencies: JSON.stringify(['Medicine', 'Religion']), toolProficiency: 'Herbalism Kit', equipment: JSON.stringify({ A: { items: ['Common Clothes', 'Herbalism Kit', 'Scroll case', 'Winter blanket'], gold: 5 }, B: { items: [], gold: 50 } }) },
    { name: 'Merchant', description: 'You have experience buying and selling goods, negotiating deals, and managing money.', abilityScores: JSON.stringify(['Constitution', 'Intelligence', 'Charisma']), feat: 'Skilled', skillProficiencies: JSON.stringify(['Insight', 'Persuasion']), toolProficiency: 'Navigator\'s Tools or Vehicles (Land)', equipment: JSON.stringify({ A: { items: ['Common Clothes', 'Abacus', 'Fine Clothes'], gold: 20 }, B: { items: [], gold: 50 } }) },
    { name: 'Noble', description: 'You were raised in a castle, surrounded by wealth, power, and privilege.', abilityScores: JSON.stringify(['Strength', 'Intelligence', 'Charisma']), feat: 'Skilled', skillProficiencies: JSON.stringify(['History', 'Persuasion']), toolProficiency: 'Gaming Set', equipment: JSON.stringify({ A: { items: ['Fine Clothes', 'Signet Ring', 'Scroll of Pedigree'], gold: 25 }, B: { items: [], gold: 50 } }) },
    { name: 'Sage', description: 'You spent your formative years traveling between manors and monasteries, studying books and scrolls.', abilityScores: JSON.stringify(['Constitution', 'Intelligence', 'Wisdom']), feat: 'Magic Initiate (Wizard)', skillProficiencies: JSON.stringify(['Arcana', 'History']), toolProficiency: 'Calligrapher\'s Supplies', equipment: JSON.stringify({ A: { items: ['Quarterstaff', 'Book', 'Robe', 'Ink', 'Parchment (10 sheets)'], gold: 8 }, B: { items: [], gold: 50 } }) },
    { name: 'Sailor', description: 'You lived as a seafarer, wind at your back and decks swaying beneath your feet.', abilityScores: JSON.stringify(['Strength', 'Dexterity', 'Wisdom']), feat: 'Tavern Brawler', skillProficiencies: JSON.stringify(['Acrobatics', 'Perception']), toolProficiency: 'Navigator\'s Tools', equipment: JSON.stringify({ A: { items: ['Dagger', 'Rope', 'Common Clothes', 'Belaying Pin'], gold: 20 }, B: { items: [], gold: 50 } }) },
    { name: 'Scribe', description: 'You spent formative years in a scriptorium, learning to write with a clear hand and produce finely written texts.', abilityScores: JSON.stringify(['Dexterity', 'Intelligence', 'Wisdom']), feat: 'Skilled', skillProficiencies: JSON.stringify(['Investigation', 'Perception']), toolProficiency: 'Calligrapher\'s Supplies', equipment: JSON.stringify({ A: { items: ['Fine Clothes', 'Lamp', 'Oil (2 flasks)', 'Parchment (20 sheets)', 'Calligrapher\'s Supplies'], gold: 23 }, B: { items: [], gold: 50 } }) },
    { name: 'Soldier', description: 'You began training for war as soon as you reached adulthood. Battle is in your blood.', abilityScores: JSON.stringify(['Strength', 'Dexterity', 'Constitution']), feat: 'Savage Attacker', skillProficiencies: JSON.stringify(['Athletics', 'Intimidation']), toolProficiency: 'Gaming Set', equipment: JSON.stringify({ A: { items: ['Spear', 'Shortbow', 'Healer\'s Kit', 'Common Clothes'], gold: 14 }, B: { items: [], gold: 50 } }) },
    { name: 'Wayfarer', description: 'You grew up on the streets surrounded by similarly ill-fated castoffs.', abilityScores: JSON.stringify(['Dexterity', 'Wisdom', 'Charisma']), feat: 'Lucky', skillProficiencies: JSON.stringify(['Insight', 'Stealth']), toolProficiency: 'Thieves\' Tools', equipment: JSON.stringify({ A: { items: ['2 Daggers', 'Thieves\' Tools', 'Common Clothes', 'Small knife'], gold: 15 }, B: { items: [], gold: 50 } }) }
  ];

  for (const background of backgroundsData) {
    await prisma.background.upsert({
      where: { name: background.name },
      update: background,
      create: background
    });
  }
  console.log('Backgrounds seeded!');

  // ==================== FEATS ====================
  const featsData = [
    // Origin Feats
    { name: 'Magic Initiate (Cleric)', category: 'Origin', description: 'You learn magical skills from the clergy.', benefit: 'Learn 2 cantrips and 1 level 1 spell from the Cleric spell list. You can cast the spell once per long rest without a spell slot.', abilityScoreOptions: JSON.stringify(['wisdom']), abilityScoreBonus: 1 },
    { name: 'Magic Initiate (Druid)', category: 'Origin', description: 'You learn magical skills from nature.', benefit: 'Learn 2 cantrips and 1 level 1 spell from the Druid spell list. You can cast the spell once per long rest without a spell slot.', abilityScoreOptions: JSON.stringify(['wisdom']), abilityScoreBonus: 1 },
    { name: 'Magic Initiate (Wizard)', category: 'Origin', description: 'You learn magical skills from arcane study.', benefit: 'Learn 2 cantrips and 1 level 1 spell from the Wizard spell list. You can cast the spell once per long rest without a spell slot.', abilityScoreOptions: JSON.stringify(['intelligence']), abilityScoreBonus: 1 },
    { name: 'Skilled', category: 'Origin', description: 'You have honed your skills.', benefit: 'Gain proficiency in 3 skills of your choice.', skillProficienciesGranted: 3 },
    { name: 'Tough', category: 'Origin', description: 'You are exceptionally hardy.', benefit: 'Your hit point maximum increases by 2 for each level you have attained.', abilityScoreOptions: null, abilityScoreBonus: 0 },
    { name: 'Crafter', category: 'Origin', description: 'You are an expert artisan.', benefit: 'Gain proficiency with 3 kinds of artisan\'s tools. You can craft items faster.', abilityScoreOptions: JSON.stringify(['strength', 'dexterity', 'constitution', 'intelligence', 'wisdom', 'charisma']), abilityScoreBonus: 1 },
    { name: 'Tavern Brawler', category: 'Origin', description: 'You are a scrappy fighter.', benefit: 'You can use Unarmed Strike as a bonus action after hitting with an attack. You can use Dexterity instead of Strength for unarmed strikes.', abilityScoreOptions: JSON.stringify(['strength', 'constitution']), abilityScoreBonus: 1 },
    { name: 'Savage Attacker', category: 'Origin', description: 'You strike with brutal force.', benefit: 'Once per turn when you roll damage for a melee weapon attack, you can reroll the weapon\'s damage dice and use either total.', abilityScoreOptions: JSON.stringify(['strength', 'dexterity']), abilityScoreBonus: 1 },
    { name: 'Lucky', category: 'Origin', description: 'You have uncanny luck.', benefit: 'You have 3 luck points. When you make an attack roll, ability check, or saving throw, you can spend one luck point to roll an additional d20.', abilityScoreOptions: null, abilityScoreBonus: 0 },
    // General Feats
    { name: 'Alert', category: 'General', description: 'Always on the lookout for danger.', benefit: 'You gain a +5 bonus to initiative. You can\'t be surprised while you are conscious.', abilityScoreOptions: JSON.stringify(['dexterity', 'wisdom']), abilityScoreBonus: 1 },
    { name: 'Great Weapon Master', category: 'General', description: 'You master heavy weapons.', benefit: 'On a critical hit or reducing a creature to 0 HP, you can make another melee attack as a bonus action. Heavy weapon attacks have -5 to hit for +10 damage.', abilityScoreOptions: JSON.stringify(['strength']), abilityScoreBonus: 1 },
    { name: 'Sharpshooter', category: 'General', description: 'You are a deadly marksman.', benefit: 'Attacks with ranged weapons ignore cover. Long range doesn\'t impose disadvantage. You can take -5 to hit for +10 damage.', abilityScoreOptions: JSON.stringify(['dexterity']), abilityScoreBonus: 1 },
    { name: 'War Caster', category: 'General', description: 'You are adept at casting spells in combat.', benefit: 'Advantage on Constitution saving throws to maintain concentration. Can perform somatic components with weapons/shields. Can cast spells as opportunity attacks.', abilityScoreOptions: JSON.stringify(['constitution', 'wisdom', 'charisma']), abilityScoreBonus: 1 },
    { name: 'Sentinel', category: 'General', description: 'You are a vigilant guardian.', benefit: 'When a creature within 5 feet attacks someone else, you can use your reaction to make a melee weapon attack. Creatures can\'t Disengage from you.', abilityScoreOptions: JSON.stringify(['strength', 'dexterity', 'constitution']), abilityScoreBonus: 1 },
    { name: 'Athlete', category: 'General', description: 'You are physically fit.', benefit: 'Climb speed equal to walking speed. Stand up from prone only uses 5 feet of movement. Jump 5 extra feet.', abilityScoreOptions: JSON.stringify(['strength', 'dexterity']), abilityScoreBonus: 1 },
    { name: 'Actor', category: 'General', description: 'You are a skilled performer.', benefit: 'Advantage on Deception and Performance checks to impersonate someone. You can mimic the speech of another person.', abilityScoreOptions: JSON.stringify(['charisma']), abilityScoreBonus: 1 },
    { name: 'Healer', category: 'General', description: 'You can mend wounds quickly.', benefit: 'When you use a Healer\'s Kit to stabilize a dying creature, they also regain 1 HP. As an action, heal a creature 1d6 + 4 + creature\'s HD.', abilityScoreOptions: JSON.stringify(['wisdom']), abilityScoreBonus: 1 },
    { name: 'Mobile', category: 'General', description: 'You are exceptionally speedy.', benefit: 'Your speed increases by 10 feet. When you make a melee attack, you don\'t provoke opportunity attacks from that creature for the rest of the turn.', abilityScoreOptions: JSON.stringify(['dexterity']), abilityScoreBonus: 1 },
    { name: 'Resilient', category: 'General', description: 'You are mentally and physically resilient.', benefit: 'Increase one ability score by 1, to a maximum of 20. You gain proficiency in saving throws using that ability.', abilityScoreOptions: JSON.stringify(['strength', 'dexterity', 'constitution', 'intelligence', 'wisdom', 'charisma']), abilityScoreBonus: 1 },
    { name: 'Elemental Adept', category: 'General', description: 'You master a type of elemental magic.', benefit: 'Choose one damage type (acid, cold, fire, lightning, or thunder). Spells ignore resistance to that type. Treat 1s on damage dice as 2s.', abilityScoreOptions: JSON.stringify(['intelligence', 'wisdom', 'charisma']), abilityScoreBonus: 1 },
    // Fighting Style Feats
    { name: 'Archery', category: 'Fighting Style', description: 'You are skilled with ranged weapons.', benefit: 'You gain a +2 bonus to attack rolls you make with ranged weapons.', abilityScoreOptions: JSON.stringify(['dexterity']), abilityScoreBonus: 1 },
    { name: 'Defense', category: 'Fighting Style', description: 'You are skilled at defense.', benefit: 'While you are wearing armor, you gain a +1 bonus to AC.', abilityScoreOptions: JSON.stringify(['strength', 'dexterity', 'constitution']), abilityScoreBonus: 1 },
    { name: 'Dueling', category: 'Fighting Style', description: 'You are skilled with one-handed weapons.', benefit: 'When you are wielding a melee weapon in one hand and no other weapons, you gain a +2 bonus to damage rolls with that weapon.', abilityScoreOptions: JSON.stringify(['strength']), abilityScoreBonus: 1 },
    { name: 'Great Weapon Fighting', category: 'Fighting Style', description: 'You are skilled with heavy weapons.', benefit: 'When you roll a 1 or 2 on a damage die for an attack with a two-handed melee weapon, you can reroll the die and must use the new roll.', abilityScoreOptions: JSON.stringify(['strength']), abilityScoreBonus: 1 },
    { name: 'Two-Weapon Fighting', category: 'Fighting Style', description: 'You are skilled with two weapons.', benefit: 'When you engage in two-weapon fighting, you can add your ability modifier to the damage of the second attack.', abilityScoreOptions: JSON.stringify(['strength', 'dexterity']), abilityScoreBonus: 1 },
  ];

  for (const feat of featsData) {
    await prisma.feat.upsert({
      where: { name: feat.name },
      update: feat,
      create: feat
    });
  }
  console.log('Feats seeded!');

  console.log('Database seeding completed!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
