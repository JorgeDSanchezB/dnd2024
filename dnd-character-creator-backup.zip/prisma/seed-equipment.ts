import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding equipment...');

  // ==================== WEAPONS ====================
  const weaponsData = [
    // Simple Melee Weapons
    { name: 'Club', category: 'Simple Melee', damage: '1d4', damageType: 'Bludgeoning', weight: 2, cost: 1, properties: JSON.stringify(['Light']), mastery: 'Topple' },
    { name: 'Dagger', category: 'Simple Melee', damage: '1d4', damageType: 'Piercing', weight: 1, cost: 2, properties: JSON.stringify(['Finesse', 'Light', 'Thrown (20/60)']), mastery: 'Nick' },
    { name: 'Greatclub', category: 'Simple Melee', damage: '1d8', damageType: 'Bludgeoning', weight: 10, cost: 2, properties: JSON.stringify(['Two-Handed']), mastery: 'Topple' },
    { name: 'Handaxe', category: 'Simple Melee', damage: '1d6', damageType: 'Slashing', weight: 2, cost: 5, properties: JSON.stringify(['Light', 'Thrown (20/60)']), mastery: 'Vex' },
    { name: 'Javelin', category: 'Simple Melee', damage: '1d6', damageType: 'Piercing', weight: 2, cost: 5, properties: JSON.stringify(['Thrown (30/120)']), mastery: 'Slow' },
    { name: 'Light Hammer', category: 'Simple Melee', damage: '1d4', damageType: 'Bludgeoning', weight: 2, cost: 2, properties: JSON.stringify(['Light', 'Thrown (20/60)']), mastery: 'Topple' },
    { name: 'Mace', category: 'Simple Melee', damage: '1d6', damageType: 'Bludgeoning', weight: 4, cost: 5, properties: JSON.stringify([]), mastery: 'Sap' },
    { name: 'Quarterstaff', category: 'Simple Melee', damage: '1d6', damageType: 'Bludgeoning', weight: 4, cost: 2, properties: JSON.stringify(['Versatile (1d8)']), mastery: 'Topple' },
    { name: 'Sickle', category: 'Simple Melee', damage: '1d6', damageType: 'Slashing', weight: 2, cost: 1, properties: JSON.stringify(['Light']), mastery: 'Nick' },
    { name: 'Spear', category: 'Simple Melee', damage: '1d6', damageType: 'Piercing', weight: 3, cost: 1, properties: JSON.stringify(['Thrown (20/60)', 'Versatile (1d8)']), mastery: 'Sap' },
    
    // Simple Ranged Weapons
    { name: 'Crossbow, Light', category: 'Simple Ranged', damage: '1d8', damageType: 'Piercing', weight: 5, cost: 25, properties: JSON.stringify(['Ammunition (80/320)', 'Light', 'Loading', 'Two-Handed']), mastery: 'Slow', range: '80/320' },
    { name: 'Dart', category: 'Simple Ranged', damage: '1d4', damageType: 'Piercing', weight: 0.25, cost: 0.05, properties: JSON.stringify(['Finesse', 'Thrown (20/60)']), mastery: 'Vex', range: '20/60' },
    { name: 'Shortbow', category: 'Simple Ranged', damage: '1d6', damageType: 'Piercing', weight: 2, cost: 25, properties: JSON.stringify(['Ammunition (80/320)', 'Two-Handed']), mastery: 'Vex', range: '80/320' },
    { name: 'Sling', category: 'Simple Ranged', damage: '1d4', damageType: 'Bludgeoning', weight: 0, cost: 0.1, properties: JSON.stringify(['Ammunition (30/120)']), mastery: 'Topple', range: '30/120' },
    
    // Martial Melee Weapons
    { name: 'Battleaxe', category: 'Martial Melee', damage: '1d8', damageType: 'Slashing', weight: 4, cost: 10, properties: JSON.stringify(['Versatile (1d10)']), mastery: 'Topple' },
    { name: 'Flail', category: 'Martial Melee', damage: '1d8', damageType: 'Bludgeoning', weight: 2, cost: 10, properties: JSON.stringify([]), mastery: 'Sap' },
    { name: 'Glaive', category: 'Martial Melee', damage: '1d10', damageType: 'Slashing', weight: 6, cost: 20, properties: JSON.stringify(['Heavy', 'Reach', 'Two-Handed']), mastery: 'Graze' },
    { name: 'Greataxe', category: 'Martial Melee', damage: '1d12', damageType: 'Slashing', weight: 7, cost: 30, properties: JSON.stringify(['Heavy', 'Two-Handed']), mastery: 'Cleave' },
    { name: 'Greatsword', category: 'Martial Melee', damage: '2d6', damageType: 'Slashing', weight: 6, cost: 50, properties: JSON.stringify(['Heavy', 'Two-Handed']), mastery: 'Graze' },
    { name: 'Halberd', category: 'Martial Melee', damage: '1d10', damageType: 'Slashing', weight: 6, cost: 20, properties: JSON.stringify(['Heavy', 'Reach', 'Two-Handed']), mastery: 'Cleave' },
    { name: 'Handaxe', category: 'Martial Melee', damage: '1d6', damageType: 'Slashing', weight: 2, cost: 5, properties: JSON.stringify(['Light', 'Thrown (20/60)']), mastery: 'Vex' },
    { name: 'Lance', category: 'Martial Melee', damage: '1d12', damageType: 'Piercing', weight: 6, cost: 10, properties: JSON.stringify(['Reach', 'Two-Handed']), mastery: 'Topple' },
    { name: 'Longsword', category: 'Martial Melee', damage: '1d8', damageType: 'Slashing', weight: 3, cost: 15, properties: JSON.stringify(['Versatile (1d10)']), mastery: 'Sap' },
    { name: 'Maul', category: 'Martial Melee', damage: '2d6', damageType: 'Bludgeoning', weight: 10, cost: 10, properties: JSON.stringify(['Heavy', 'Two-Handed']), mastery: 'Topple' },
    { name: 'Morningstar', category: 'Martial Melee', damage: '1d8', damageType: 'Piercing', weight: 4, cost: 15, properties: JSON.stringify([]), mastery: 'Pierce' },
    { name: 'Pike', category: 'Martial Melee', damage: '1d10', damageType: 'Piercing', weight: 18, cost: 5, properties: JSON.stringify(['Heavy', 'Reach', 'Two-Handed']), mastery: 'Push' },
    { name: 'Rapier', category: 'Martial Melee', damage: '1d8', damageType: 'Piercing', weight: 2, cost: 25, properties: JSON.stringify(['Finesse']), mastery: 'Pierce' },
    { name: 'Scimitar', category: 'Martial Melee', damage: '1d6', damageType: 'Slashing', weight: 3, cost: 25, properties: JSON.stringify(['Finesse', 'Light']), mastery: 'Nick' },
    { name: 'Shortsword', category: 'Martial Melee', damage: '1d6', damageType: 'Piercing', weight: 2, cost: 10, properties: JSON.stringify(['Finesse', 'Light']), mastery: 'Vex' },
    { name: 'Trident', category: 'Martial Melee', damage: '1d6', damageType: 'Piercing', weight: 4, cost: 5, properties: JSON.stringify(['Thrown (20/60)', 'Versatile (1d8)']), mastery: 'Topple' },
    { name: 'War Pick', category: 'Martial Melee', damage: '1d8', damageType: 'Piercing', weight: 2, cost: 5, properties: JSON.stringify([]), mastery: 'Pierce' },
    { name: 'Warhammer', category: 'Martial Melee', damage: '1d8', damageType: 'Bludgeoning', weight: 2, cost: 15, properties: JSON.stringify(['Versatile (1d10)']), mastery: 'Push' },
    { name: 'Whip', category: 'Martial Melee', damage: '1d4', damageType: 'Slashing', weight: 3, cost: 2, properties: JSON.stringify(['Finesse', 'Reach']), mastery: 'Slow' },
    
    // Martial Ranged Weapons
    { name: 'Blowgun', category: 'Martial Ranged', damage: '1', damageType: 'Piercing', weight: 1, cost: 10, properties: JSON.stringify(['Ammunition (25/100)', 'Loading']), mastery: 'Vex', range: '25/100' },
    { name: 'Crossbow, Hand', category: 'Martial Ranged', damage: '1d6', damageType: 'Piercing', weight: 3, cost: 75, properties: JSON.stringify(['Ammunition (30/120)', 'Light', 'Loading']), mastery: 'Vex', range: '30/120' },
    { name: 'Crossbow, Heavy', category: 'Martial Ranged', damage: '1d10', damageType: 'Piercing', weight: 18, cost: 50, properties: JSON.stringify(['Ammunition (100/400)', 'Heavy', 'Loading', 'Two-Handed']), mastery: 'Pierce', range: '100/400' },
    { name: 'Longbow', category: 'Martial Ranged', damage: '1d8', damageType: 'Piercing', weight: 2, cost: 50, properties: JSON.stringify(['Ammunition (150/600)', 'Heavy', 'Two-Handed']), mastery: 'Slow', range: '150/600' },
    { name: 'Net', category: 'Martial Ranged', damage: '-', damageType: '-', weight: 3, cost: 1, properties: JSON.stringify(['Thrown (5/15)']), mastery: 'Slow', range: '5/15' }
  ];

  for (const weapon of weaponsData) {
    await prisma.weapon.upsert({
      where: { name: weapon.name },
      update: weapon,
      create: weapon
    });
  }
  console.log('Weapons seeded!');

  // ==================== ARMOR ====================
  const armorData = [
    // Light Armor
    { name: 'Padded', category: 'Light', baseAC: 11, dexBonus: true, maxDexBonus: null, strRequired: null, stealthDisadv: true, weight: 8, cost: 5, donTime: 1, doffTime: 1 },
    { name: 'Leather', category: 'Light', baseAC: 11, dexBonus: true, maxDexBonus: null, strRequired: null, stealthDisadv: false, weight: 10, cost: 10, donTime: 1, doffTime: 1 },
    { name: 'Studded Leather', category: 'Light', baseAC: 12, dexBonus: true, maxDexBonus: null, strRequired: null, stealthDisadv: false, weight: 13, cost: 45, donTime: 1, doffTime: 1 },
    
    // Medium Armor
    { name: 'Hide', category: 'Medium', baseAC: 12, dexBonus: true, maxDexBonus: 2, strRequired: null, stealthDisadv: false, weight: 12, cost: 10, donTime: 5, doffTime: 1 },
    { name: 'Chain Shirt', category: 'Medium', baseAC: 13, dexBonus: true, maxDexBonus: 2, strRequired: null, stealthDisadv: false, weight: 20, cost: 50, donTime: 5, doffTime: 1 },
    { name: 'Scale Mail', category: 'Medium', baseAC: 14, dexBonus: true, maxDexBonus: 2, strRequired: null, stealthDisadv: true, weight: 45, cost: 50, donTime: 5, doffTime: 1 },
    { name: 'Breastplate', category: 'Medium', baseAC: 14, dexBonus: true, maxDexBonus: 2, strRequired: null, stealthDisadv: false, weight: 20, cost: 400, donTime: 5, doffTime: 1 },
    { name: 'Half Plate', category: 'Medium', baseAC: 15, dexBonus: true, maxDexBonus: 2, strRequired: null, stealthDisadv: true, weight: 40, cost: 750, donTime: 5, doffTime: 1 },
    
    // Heavy Armor
    { name: 'Ring Mail', category: 'Heavy', baseAC: 14, dexBonus: false, maxDexBonus: null, strRequired: null, stealthDisadv: true, weight: 40, cost: 30, donTime: 10, doffTime: 5 },
    { name: 'Chain Mail', category: 'Heavy', baseAC: 16, dexBonus: false, maxDexBonus: null, strRequired: 13, stealthDisadv: true, weight: 55, cost: 75, donTime: 10, doffTime: 5 },
    { name: 'Splint', category: 'Heavy', baseAC: 17, dexBonus: false, maxDexBonus: null, strRequired: 15, stealthDisadv: true, weight: 60, cost: 200, donTime: 10, doffTime: 5 },
    { name: 'Plate', category: 'Heavy', baseAC: 18, dexBonus: false, maxDexBonus: null, strRequired: 15, stealthDisadv: true, weight: 65, cost: 1500, donTime: 10, doffTime: 5 },
    
    // Shields
    { name: 'Shield', category: 'Shield', baseAC: 2, dexBonus: false, maxDexBonus: null, strRequired: null, stealthDisadv: false, weight: 6, cost: 10, donTime: 1, doffTime: 1 }
  ];

  for (const armor of armorData) {
    await prisma.armor.upsert({
      where: { name: armor.name },
      update: armor,
      create: armor
    });
  }
  console.log('Armor seeded!');

  // ==================== COMMON ITEMS ====================
  const itemsData = [
    // Adventuring Gear
    { name: 'Abacus', category: 'Adventuring Gear', subcategory: 'Tools', description: 'A calculation tool', weight: 2, cost: 200 },
    { name: 'Acid (vial)', category: 'Adventuring Gear', subcategory: 'Consumable', description: 'Deals 2d6 Acid damage on contact', weight: 1, cost: 25 },
    { name: 'Alchemist\'s Fire (flask)', category: 'Adventuring Gear', subcategory: 'Consumable', description: 'Deals 1d4 Fire damage at start of each turn until doused', weight: 1, cost: 50 },
    { name: 'Alchemist\'s Supplies', category: 'Adventuring Gear', subcategory: 'Tools', description: 'Tools for crafting alchemical items', weight: 8, cost: 50 },
    { name: 'Antitoxin (vial)', category: 'Adventuring Gear', subcategory: 'Consumable', description: 'Advantage on saves against poison for 1 hour', weight: 0, cost: 50 },
    { name: 'Backpack', category: 'Adventuring Gear', subcategory: 'Container', description: 'A leather pack for carrying gear', weight: 5, cost: 2 },
    { name: 'Ball Bearings (bag of 1000)', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'Creatures moving through must succeed DC 10 Dexterity save or fall Prone', weight: 2, cost: 1 },
    { name: 'Barrel', category: 'Adventuring Gear', subcategory: 'Container', description: 'Holds 40 gallons liquid or 4 cubic feet solid', weight: 70, cost: 2 },
    { name: 'Basket', category: 'Adventuring Gear', subcategory: 'Container', description: 'Holds 2 cubic feet or 40 pounds', weight: 2, cost: 0.4 },
    { name: 'Bedroll', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'Bedding for sleeping in the wild', weight: 7, cost: 1 },
    { name: 'Bell', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'A small brass bell', weight: 0, cost: 1 },
    { name: 'Blanket', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'A warm blanket', weight: 3, cost: 0.5 },
    { name: 'Block and Tackle', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'Doubles lifting capacity', weight: 5, cost: 1 },
    { name: 'Book', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'A scholarly tome', weight: 5, cost: 25 },
    { name: 'Bottle, glass', category: 'Adventuring Gear', subcategory: 'Container', description: 'Holds 1.5 pints liquid', weight: 2, cost: 2 },
    { name: 'Bucket', category: 'Adventuring Gear', subcategory: 'Container', description: 'Holds 3 gallons liquid', weight: 2, cost: 0.5 },
    { name: 'Caltrops (bag of 20)', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'Creatures take 1 damage and reduce speed by 10 feet until healed', weight: 2, cost: 1 },
    { name: 'Candle', category: 'Adventuring Gear', subcategory: 'Light', description: 'Sheds dim light in 5-foot radius for 1 hour', weight: 0, cost: 0.01 },
    { name: 'Case, Crossbow Bolt', category: 'Adventuring Gear', subcategory: 'Container', description: 'Holds 20 crossbow bolts', weight: 1, cost: 1 },
    { name: 'Case, Map or Scroll', category: 'Adventuring Gear', subcategory: 'Container', description: 'A leather tube for holding documents', weight: 1, cost: 1 },
    { name: 'Chain (10 feet)', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'Has 13 HP', weight: 10, cost: 5 },
    { name: 'Chalk (1 piece)', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'A stick of chalk', weight: 0, cost: 0.01 },
    { name: 'Chest', category: 'Adventuring Gear', subcategory: 'Container', description: 'Holds 12 cubic feet or 300 pounds', weight: 25, cost: 5 },
    { name: 'Climber\'s Kit', category: 'Adventuring Gear', subcategory: 'Tools', description: 'Includes pitons, boot tips, and harness', weight: 12, cost: 25 },
    { name: 'Clothes, Common', category: 'Adventuring Gear', subcategory: 'Clothing', description: 'Simple everyday clothes', weight: 3, cost: 0.5 },
    { name: 'Clothes, Costume', category: 'Adventuring Gear', subcategory: 'Clothing', description: 'Outfit for performances', weight: 4, cost: 5 },
    { name: 'Clothes, Fine', category: 'Adventuring Gear', subcategory: 'Clothing', description: 'High-quality noble attire', weight: 6, cost: 15 },
    { name: 'Clothes, Traveler\'s', category: 'Adventuring Gear', subcategory: 'Clothing', description: 'Sturdy clothes for travel', weight: 4, cost: 2 },
    { name: 'Component Pouch', category: 'Adventuring Gear', subcategory: 'Spellcasting', description: 'Holds spell components', weight: 2, cost: 25 },
    { name: 'Crowbar', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'Advantage on Strength checks to pry', weight: 5, cost: 2 },
    { name: 'Disguise Kit', category: 'Adventuring Gear', subcategory: 'Tools', description: 'Cosmetics for creating disguises', weight: 3, cost: 25 },
    { name: 'Druidic Focus', category: 'Adventuring Gear', subcategory: 'Spellcasting', description: 'Mistletoe, totem, or wooden staff', weight: 0, cost: 0 },
    { name: 'Emblem, Holy', category: 'Adventuring Gear', subcategory: 'Spellcasting', description: 'Holy Symbol for clerics and paladins', weight: 0, cost: 5 },
    { name: 'Fishing Tackle', category: 'Adventuring Gear', subcategory: 'Tools', description: 'Equipment for fishing', weight: 4, cost: 1 },
    { name: 'Flask or Tankard', category: 'Adventuring Gear', subcategory: 'Container', description: 'Holds 1 pint liquid', weight: 1, cost: 0.02 },
    { name: 'Grappling Hook', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'For climbing ropes', weight: 4, cost: 2 },
    { name: 'Hammer', category: 'Adventuring Gear', subcategory: 'Tools', description: 'A light hammer', weight: 3, cost: 2 },
    { name: 'Hammer, Sledge', category: 'Adventuring Gear', subcategory: 'Tools', description: 'A heavy sledgehammer', weight: 10, cost: 2 },
    { name: 'Healer\'s Kit', category: 'Adventuring Gear', subcategory: 'Medical', description: '10 uses to stabilize dying creatures', weight: 3, cost: 5 },
    { name: 'Herbalism Kit', category: 'Adventuring Gear', subcategory: 'Tools', description: 'Tools for identifying and using herbs', weight: 3, cost: 5 },
    { name: 'Holy Water (flask)', category: 'Adventuring Gear', subcategory: 'Consumable', description: 'Deals 2d6 Radiant damage to Fiends and Undead', weight: 1, cost: 25 },
    { name: 'Hourglass', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'Measures 1 hour', weight: 1, cost: 25 },
    { name: 'Hunting Trap', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'DC 13 Dexterity save or Restrained', weight: 25, cost: 5 },
    { name: 'Ink (1 ounce bottle)', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'Black ink for writing', weight: 0, cost: 10 },
    { name: 'Ink Pen', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'A writing instrument', weight: 0, cost: 0.02 },
    { name: 'Jug or Pitcher', category: 'Adventuring Gear', subcategory: 'Container', description: 'Holds 1 gallon liquid', weight: 4, cost: 0.02 },
    { name: 'Ladder (10-foot)', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'A wooden ladder', weight: 25, cost: 0.1 },
    { name: 'Lamp', category: 'Adventuring Gear', subcategory: 'Light', description: 'Sheds bright light in 15-foot radius, dim for another 30 feet', weight: 1, cost: 0.5 },
    { name: 'Lantern, Bullseye', category: 'Adventuring Gear', subcategory: 'Light', description: 'Sheds bright light in 60-foot cone, dim for another 60 feet', weight: 2, cost: 10 },
    { name: 'Lantern, Hooded', category: 'Adventuring Gear', subcategory: 'Light', description: 'Sheds bright light in 30-foot radius, dim for another 30 feet', weight: 2, cost: 5 },
    { name: 'Lock', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'A simple lock, DC 15 to pick', weight: 1, cost: 10 },
    { name: 'Magnifying Glass', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'For examining small details', weight: 0, cost: 100 },
    { name: 'Manacles', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'DC 20 Dexterity check to escape', weight: 6, cost: 2 },
    { name: 'Mess Kit', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'Tin cup and plate with utensils', weight: 1, cost: 0.2 },
    { name: 'Mirror, Steel', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'A small steel mirror', weight: 0.5, cost: 5 },
    { name: 'Oil (flask)', category: 'Adventuring Gear', subcategory: 'Consumable', description: 'Burns for 6 hours in lantern, deals 5 fire damage when ignited', weight: 1, cost: 0.1 },
    { name: 'Paper (one sheet)', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'A sheet of paper', weight: 0, cost: 0.2 },
    { name: 'Parchment (one sheet)', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'A sheet of parchment', weight: 0, cost: 0.1 },
    { name: 'Perfume (vial)', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'Scented perfume', weight: 0, cost: 5 },
    { name: 'Pick, Miner\'s', category: 'Adventuring Gear', subcategory: 'Tools', description: 'For mining ore', weight: 10, cost: 2 },
    { name: 'Piton', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'A metal spike for climbing', weight: 0.25, cost: 0.05 },
    { name: 'Poison, Basic (vial)', category: 'Adventuring Gear', subcategory: 'Consumable', description: 'DC 10 Constitution save or take 1d4 poison damage', weight: 0, cost: 100 },
    { name: 'Pole (10-foot)', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'A long wooden pole', weight: 7, cost: 0.05 },
    { name: 'Pot, Iron', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'Holds 1 gallon', weight: 10, cost: 2 },
    { name: 'Potion of Healing', category: 'Adventuring Gear', subcategory: 'Consumable', description: 'Regain 2d4 + 2 Hit Points', weight: 0.5, cost: 50 },
    { name: 'Pouch', category: 'Adventuring Gear', subcategory: 'Container', description: 'A leather pouch', weight: 1, cost: 0.5 },
    { name: 'Quiver', category: 'Adventuring Gear', subcategory: 'Container', description: 'Holds 20 arrows', weight: 1, cost: 1 },
    { name: 'Ram, Portable', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'For breaking down doors', weight: 35, cost: 4 },
    { name: 'Rations (1 day)', category: 'Adventuring Gear', subcategory: 'Food', description: 'Dried meat and fruit', weight: 2, cost: 0.5 },
    { name: 'Robes', category: 'Adventuring Gear', subcategory: 'Clothing', description: 'Simple robes', weight: 4, cost: 1 },
    { name: 'Rope, Hemp (50 feet)', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'Has 2 HP', weight: 10, cost: 1 },
    { name: 'Rope, Silk (50 feet)', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'Has 4 HP', weight: 5, cost: 10 },
    { name: 'Sack', category: 'Adventuring Gear', subcategory: 'Container', description: 'Holds 1 cubic foot or 30 pounds', weight: 0.5, cost: 0.01 },
    { name: 'Scale, Merchant\'s', category: 'Adventuring Gear', subcategory: 'Tools', description: 'For weighing items', weight: 3, cost: 5 },
    { name: 'Sealing Wax', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'For sealing documents', weight: 0, cost: 0.5 },
    { name: 'Shovel', category: 'Adventuring Gear', subcategory: 'Tools', description: 'For digging', weight: 5, cost: 2 },
    { name: 'Signal Whistle', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'A loud whistle', weight: 0, cost: 0.05 },
    { name: 'Signet Ring', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'For marking documents', weight: 0, cost: 5 },
    { name: 'Soap', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'A bar of soap', weight: 0, cost: 0.02 },
    { name: 'Spellbook', category: 'Adventuring Gear', subcategory: 'Spellcasting', description: 'Holds 100 pages of spells', weight: 3, cost: 50 },
    { name: 'Spyglass', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'Magnifies distant objects', weight: 1, cost: 1000 },
    { name: 'Tent, Two-Person', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'Canvas tent for two', weight: 20, cost: 2 },
    { name: 'Tinderbox', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'For starting fires', weight: 1, cost: 0.5 },
    { name: 'Torch', category: 'Adventuring Gear', subcategory: 'Light', description: 'Sheds bright light in 20-foot radius, dim for another 20 feet. Burns 1 hour', weight: 1, cost: 0.01 },
    { name: 'Vial', category: 'Adventuring Gear', subcategory: 'Container', description: 'Holds 4 ounces liquid', weight: 0, cost: 1 },
    { name: 'Waterskin', category: 'Adventuring Gear', subcategory: 'Container', description: 'Holds 4 pints liquid', weight: 5, cost: 0.2 },
    { name: 'Whetstone', category: 'Adventuring Gear', subcategory: 'Equipment', description: 'For sharpening blades', weight: 1, cost: 0.01 },
    
    // Tools
    { name: 'Brewer\'s Supplies', category: 'Tools', subcategory: 'Artisan Tools', description: 'Tools for brewing beverages', weight: 6, cost: 20 },
    { name: 'Calligrapher\'s Supplies', category: 'Tools', subcategory: 'Artisan Tools', description: 'Tools for decorative writing', weight: 5, cost: 10 },
    { name: 'Carpenter\'s Tools', category: 'Tools', subcategory: 'Artisan Tools', description: 'Tools for woodworking', weight: 6, cost: 8 },
    { name: 'Cobbler\'s Tools', category: 'Tools', subcategory: 'Artisan Tools', description: 'Tools for making shoes', weight: 5, cost: 5 },
    { name: 'Cook\'s Utensils', category: 'Tools', subcategory: 'Artisan Tools', description: 'Tools for cooking', weight: 8, cost: 1 },
    { name: 'Glassblower\'s Tools', category: 'Tools', subcategory: 'Artisan Tools', description: 'Tools for working glass', weight: 5, cost: 30 },
    { name: 'Jeweler\'s Tools', category: 'Tools', subcategory: 'Artisan Tools', description: 'Tools for crafting jewelry', weight: 2, cost: 25 },
    { name: 'Leatherworker\'s Tools', category: 'Tools', subcategory: 'Artisan Tools', description: 'Tools for working leather', weight: 5, cost: 5 },
    { name: 'Mason\'s Tools', category: 'Tools', subcategory: 'Artisan Tools', description: 'Tools for stonework', weight: 8, cost: 10 },
    { name: 'Navigator\'s Tools', category: 'Tools', subcategory: 'Specialty', description: 'Tools for navigation', weight: 2, cost: 25 },
    { name: 'Painter\'s Supplies', category: 'Tools', subcategory: 'Artisan Tools', description: 'Tools for painting', weight: 5, cost: 10 },
    { name: 'Potter\'s Tools', category: 'Tools', subcategory: 'Artisan Tools', description: 'Tools for pottery', weight: 3, cost: 10 },
    { name: 'Smith\'s Tools', category: 'Tools', subcategory: 'Artisan Tools', description: 'Tools for metalworking', weight: 8, cost: 20 },
    { name: 'Tinker\'s Tools', category: 'Tools', subcategory: 'Artisan Tools', description: 'Tools for mechanical repair', weight: 10, cost: 50 },
    { name: 'Weaver\'s Tools', category: 'Tools', subcategory: 'Artisan Tools', description: 'Tools for weaving cloth', weight: 5, cost: 1 },
    { name: 'Woodcarver\'s Tools', category: 'Tools', subcategory: 'Artisan Tools', description: 'Tools for carving wood', weight: 5, cost: 1 },
    { name: 'Thieves\' Tools', category: 'Tools', subcategory: 'Specialty', description: 'Tools for picking locks and disarming traps', weight: 1, cost: 25 },
    { name: 'Forgery Kit', category: 'Tools', subcategory: 'Specialty', description: 'Tools for forging documents', weight: 5, cost: 15 },
    { name: 'Dice Set', category: 'Tools', subcategory: 'Gaming Set', description: 'A set of dice', weight: 0, cost: 0.1 },
    { name: 'Playing Card Set', category: 'Tools', subcategory: 'Gaming Set', description: 'A deck of playing cards', weight: 0, cost: 0.5 },
    { name: 'Dragonchess Set', category: 'Tools', subcategory: 'Gaming Set', description: 'A three-dimensional chess set', weight: 0, cost: 1 },
    { name: 'Three-Dragon Ante Set', category: 'Tools', subcategory: 'Gaming Set', description: 'A card game set', weight: 0, cost: 1 },
    
    // Musical Instruments
    { name: 'Bagpipes', category: 'Musical Instruments', subcategory: null, description: 'Wind instrument with bag', weight: 6, cost: 30 },
    { name: 'Drum', category: 'Musical Instruments', subcategory: null, description: 'Percussion instrument', weight: 3, cost: 6 },
    { name: 'Dulcimer', category: 'Musical Instruments', subcategory: null, description: 'String instrument', weight: 10, cost: 25 },
    { name: 'Flute', category: 'Musical Instruments', subcategory: null, description: 'Wind instrument', weight: 1, cost: 2 },
    { name: 'Horn', category: 'Musical Instruments', subcategory: null, description: 'Brass wind instrument', weight: 2, cost: 3 },
    { name: 'Lute', category: 'Musical Instruments', subcategory: null, description: 'String instrument', weight: 2, cost: 35 },
    { name: 'Lyre', category: 'Musical Instruments', subcategory: null, description: 'Small harp-like instrument', weight: 2, cost: 30 },
    { name: 'Pan Flute', category: 'Musical Instruments', subcategory: null, description: 'Multiple pipes bound together', weight: 2, cost: 12 },
    { name: 'Shawm', category: 'Musical Instruments', subcategory: null, description: 'Double-reed wind instrument', weight: 1, cost: 2 },
    { name: 'Viol', category: 'Musical Instruments', subcategory: null, description: 'String instrument like a cello', weight: 1, cost: 30 },
    
    // Ammunition
    { name: 'Arrows (20)', category: 'Ammunition', subcategory: null, description: 'Arrows for bows', weight: 1, cost: 1 },
    { name: 'Crossbow Bolts (20)', category: 'Ammunition', subcategory: null, description: 'Bolts for crossbows', weight: 1.5, cost: 1 },
    { name: 'Blowgun Needles (50)', category: 'Ammunition', subcategory: null, description: 'Needles for blowguns', weight: 1, cost: 1 },
    { name: 'Sling Bullets (20)', category: 'Ammunition', subcategory: null, description: 'Lead bullets for slings', weight: 1.5, cost: 0.04 }
  ];

  for (const item of itemsData) {
    await prisma.item.upsert({
      where: { name: item.name },
      update: item,
      create: item
    });
  }
  console.log('Items seeded!');

  // ==================== MAGIC ITEMS (Sample) ====================
  const magicItemsData = [
    { name: 'Potion of Healing (Greater)', rarity: 'Uncommon', type: 'Potion', attunement: false, description: 'Regain 4d4 + 4 Hit Points when drunk', effects: JSON.stringify(['Heal 4d4+4 HP']), weight: 0.5, cost: 100 },
    { name: 'Potion of Healing (Superior)', rarity: 'Rare', type: 'Potion', attunement: false, description: 'Regain 8d4 + 8 Hit Points when drunk', effects: JSON.stringify(['Heal 8d4+8 HP']), weight: 0.5, cost: 500 },
    { name: 'Potion of Healing (Supreme)', rarity: 'Very Rare', type: 'Potion', attunement: false, description: 'Regain 10d4 + 20 Hit Points when drunk', effects: JSON.stringify(['Heal 10d4+20 HP']), weight: 0.5, cost: 2500 },
    { name: 'Potion of Speed', rarity: 'Very Rare', type: 'Potion', attunement: false, description: 'Gain Haste effect for 1 minute', effects: JSON.stringify(['Haste for 1 minute']), weight: 0.5, cost: 5000 },
    { name: 'Potion of Flying', rarity: 'Very Rare', type: 'Potion', attunement: false, description: 'Gain flying speed of 60 feet for 1 hour', effects: JSON.stringify(['Fly speed 60 ft for 1 hour']), weight: 0.5, cost: 5000 },
    { name: 'Potion of Invisibility', rarity: 'Rare', type: 'Potion', attunement: false, description: 'Become invisible for 1 hour', effects: JSON.stringify(['Invisibility for 1 hour']), weight: 0.5, cost: 5000 },
    { name: '+1 Weapon', rarity: 'Uncommon', type: 'Weapon', attunement: true, description: 'You have a +1 bonus to attack and damage rolls with this magic weapon', effects: JSON.stringify(['+1 attack and damage']), weight: null, cost: 500 },
    { name: '+2 Weapon', rarity: 'Rare', type: 'Weapon', attunement: true, description: 'You have a +2 bonus to attack and damage rolls with this magic weapon', effects: JSON.stringify(['+2 attack and damage']), weight: null, cost: 4000 },
    { name: '+3 Weapon', rarity: 'Very Rare', type: 'Weapon', attunement: true, description: 'You have a +3 bonus to attack and damage rolls with this magic weapon', effects: JSON.stringify(['+3 attack and damage']), weight: null, cost: 16000 },
    { name: '+1 Armor', rarity: 'Uncommon', type: 'Armor', attunement: true, description: 'You have a +1 bonus to AC while wearing this armor', effects: JSON.stringify(['+1 AC']), weight: null, cost: 500 },
    { name: '+2 Armor', rarity: 'Rare', type: 'Armor', attunement: true, description: 'You have a +2 bonus to AC while wearing this armor', effects: JSON.stringify(['+2 AC']), weight: null, cost: 4000 },
    { name: '+3 Armor', rarity: 'Very Rare', type: 'Armor', attunement: true, description: 'You have a +3 bonus to AC while wearing this armor', effects: JSON.stringify(['+3 AC']), weight: null, cost: 16000 },
    { name: 'Ring of Protection', rarity: 'Rare', type: 'Ring', attunement: true, description: 'You gain +1 bonus to AC and saving throws', effects: JSON.stringify(['+1 AC', '+1 saving throws']), weight: 0, cost: 4000 },
    { name: 'Amulet of Proof Against Detection and Location', rarity: 'Uncommon', type: 'Wondrous Item', attunement: true, description: 'While wearing this amulet, you are hidden from divination magic', effects: JSON.stringify(['Immunity to divination magic']), weight: 0.1, cost: 20000 },
    { name: 'Bag of Holding', rarity: 'Uncommon', type: 'Wondrous Item', attunement: false, description: 'This bag has an interior space considerably larger than its outside dimensions. The bag can hold up to 500 pounds', effects: JSON.stringify(['Hold 500 lbs in extradimensional space']), weight: 15, cost: 4000 },
    { name: 'Broom of Flying', rarity: 'Uncommon', type: 'Wondrous Item', attunement: true, description: 'This broom can fly, carrying up to 400 pounds at 50 feet per minute', effects: JSON.stringify(['Fly 50 ft/round, carry 400 lbs']), weight: 3, cost: 5000 },
    { name: 'Cloak of Elvenkind', rarity: 'Uncommon', type: 'Wondrous Item', attunement: true, description: 'Advantage on Stealth checks, Disadvantage on Perception checks against you', effects: JSON.stringify(['Advantage Stealth', 'Disadvantage to be perceived']), weight: 1, cost: 5000 },
    { name: 'Cloak of Invisibility', rarity: 'Legendary', type: 'Wondrous Item', attunement: true, description: 'Become invisible for up to 2 hours per day', effects: JSON.stringify(['Invisibility 2 hours/day']), weight: 1, cost: 50000 },
    { name: 'Wand of Magic Missiles', rarity: 'Uncommon', type: 'Wand', attunement: true, description: 'Cast Magic Missile using charges (7 charges)', effects: JSON.stringify(['Cast Magic Missile (7 charges)']), weight: 1, cost: 5000 },
    { name: 'Wand of Fireballs', rarity: 'Rare', type: 'Wand', attunement: true, description: 'Cast Fireball using charges (7 charges)', effects: JSON.stringify(['Cast Fireball (7 charges)']), weight: 1, cost: 10000 },
    { name: 'Boots of Speed', rarity: 'Rare', type: 'Wondrous Item', attunement: true, description: 'Double your walking speed, use Bonus Action to Dash or Dodge', effects: JSON.stringify(['Double speed', 'Bonus Action Dash/Dodge']), weight: 1, cost: 4000 },
    { name: 'Gloves of Thievery', rarity: 'Uncommon', type: 'Wondrous Item', attunement: true, description: '+5 bonus to Dexterity (Sleight of Hand) checks', effects: JSON.stringify(['+5 Sleight of Hand']), weight: 0, cost: 4000 },
    { name: 'Goggles of Night', rarity: 'Uncommon', type: 'Wondrous Item', attunement: false, description: 'Darkvision out to 60 feet', effects: JSON.stringify(['Darkvision 60 ft']), weight: 0, cost: 4000 },
    { name: 'Sending Stones', rarity: 'Uncommon', type: 'Wondrous Item', attunement: false, description: 'Pair of stones that allow Sending spell once per day between holders', effects: JSON.stringify(['Sending 1/day between stones']), weight: 0.5, cost: 5000 },
    { name: 'Spell Scroll (Cantrip)', rarity: 'Common', type: 'Scroll', attunement: false, description: 'A scroll containing a cantrip', effects: JSON.stringify(['Cast cantrip once']), weight: 0, cost: 50 },
    { name: 'Spell Scroll (Level 1)', rarity: 'Common', type: 'Scroll', attunement: false, description: 'A scroll containing a level 1 spell', effects: JSON.stringify(['Cast level 1 spell once']), weight: 0, cost: 100 },
    { name: 'Spell Scroll (Level 2)', rarity: 'Uncommon', type: 'Scroll', attunement: false, description: 'A scroll containing a level 2 spell', effects: JSON.stringify(['Cast level 2 spell once']), weight: 0, cost: 200 },
    { name: 'Spell Scroll (Level 3)', rarity: 'Uncommon', type: 'Scroll', attunement: false, description: 'A scroll containing a level 3 spell', effects: JSON.stringify(['Cast level 3 spell once']), weight: 0, cost: 500 },
    { name: 'Sword of Sharpness', rarity: 'Very Rare', type: 'Weapon', attunement: true, description: '+3 bonus, extra 14 slashing damage on 20, can cut objects', effects: JSON.stringify(['+3 weapon', 'Extra 14 damage on crit', 'Cut objects']), weight: 3, cost: 20000 },
    { name: 'Sun Blade', rarity: 'Rare', type: 'Weapon', attunement: true, description: '+2 bonus, deals radiant damage, sheds light, bonus vs undead', effects: JSON.stringify(['+2 weapon', 'Radiant damage', 'Light', 'Bonus vs undead']), weight: 3, cost: 8000 }
  ];

  for (const magicItem of magicItemsData) {
    await prisma.magicItem.upsert({
      where: { name: magicItem.name },
      update: magicItem,
      create: magicItem
    });
  }
  console.log('Magic Items seeded!');

  console.log('Equipment seeding completed!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
