import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

const actions = [
  // ========== COMBAT ACTIONS ==========
  {
    name: 'Attack',
    nameEs: 'Atacar',
    description: 'With this action, you make a melee attack, a ranged attack, or a spell attack. You can attack with a weapon you are holding, or you can attack with an unarmed strike. When you make an attack, your attack roll determines whether the attack hits or misses. To make an attack roll, roll a d20 and add the appropriate modifiers. If the total of the roll plus modifiers equals or exceeds the target\'s Armor Class (AC), the attack hits.',
    type: 'Action',
    category: 'Combat',
    icon: 'sword',
    color: 'red',
    details: JSON.stringify({
      subtypes: ['Melee Attack', 'Ranged Attack', 'Unarmed Strike', 'Grapple', 'Shove'],
      modifiers: 'Attack roll = d20 + Ability Modifier + Proficiency Bonus (if proficient)',
      criticalHit: 'Natural 20 hits automatically and doubles damage dice',
      criticalMiss: 'Natural 1 misses automatically'
    })
  },
  {
    name: 'Cast a Spell',
    nameEs: 'Lanzar un Hechizo',
    description: 'Spellcasters (such as wizards or clerics) use this action to cast a spell. Each spell has a casting time, which is the time needed to cast it. A spell\'s casting time is noted in its description. Most spells have a casting time of 1 action, but some have longer casting times, and some can be cast as a bonus action or reaction.',
    type: 'Action',
    category: 'Combat',
    icon: 'sparkles',
    color: 'purple',
    details: JSON.stringify({
      components: ['Verbal (V)', 'Somatic (S)', 'Material (M)'],
      concentration: 'Some spells require concentration to maintain',
      spellSlots: 'Most spells consume a spell slot when cast',
      ritualCasting: 'Some spells can be cast as rituals without using a slot'
    })
  },
  {
    name: 'Dash',
    nameEs: 'Carrera',
    description: 'When you take the Dash action, you gain extra movement for the current turn. The increase equals your speed, after applying any modifiers. With a speed of 30 feet, for example, you can move up to 60 feet on your turn if you Dash. Any speed increase or decrease applies to this extra movement as well.',
    type: 'Action',
    category: 'Movement',
    icon: 'zap',
    color: 'blue',
    details: JSON.stringify({
      movementIncrease: 'Double your speed for the turn',
      terrainModifiers: 'Difficult terrain still affects movement',
      stacking: 'Multiple Dash actions stack (triple speed with 2 Dashes, etc.)'
    })
  },
  {
    name: 'Disengage',
    nameEs: 'Desengancharse',
    description: 'If you take the Disengage action, your movement doesn\'t provoke opportunity attacks for the rest of the turn. This allows you to safely move away from enemies without risking free attacks against you.',
    type: 'Action',
    category: 'Movement',
    icon: 'move',
    color: 'green',
    details: JSON.stringify({
      effect: 'Movement does not provoke opportunity attacks',
      duration: 'Until the end of your turn',
      comparison: 'Rogues can do this as a bonus action (Cunning Action)'
    })
  },
  {
    name: 'Dodge',
    nameEs: 'Esquivar',
    description: 'When you take the Dodge action, you focus entirely on avoiding attacks. Until the start of your next turn, any attack roll made against you has disadvantage if you can see the attacker, and you make Dexterity saving throws with advantage. You lose this benefit if you are incapacitated or if your speed drops to 0.',
    type: 'Action',
    category: 'Combat',
    icon: 'shield',
    color: 'yellow',
    details: JSON.stringify({
      attackEffect: 'Disadvantage on attacks against you',
      saveEffect: 'Advantage on Dexterity saving throws',
      requirements: 'Must be able to see the attacker, must not be incapacitated',
      duration: 'Until start of your next turn'
    })
  },
  {
    name: 'Help',
    nameEs: 'Ayudar',
    description: 'You can lend your aid to another creature in the completion of a task. When you take the Help action, the creature you aid gains advantage on the next ability check it makes to perform the task you are helping with, provided that it makes the check before the start of your next turn. Alternatively, you can aid a friendly creature in attacking a creature within 5 feet of you. You feint, distract the target, or in some other way team up to make your ally\'s attack more effective. If your ally attacks the target before your next turn, the first attack roll is made with advantage.',
    type: 'Action',
    category: 'Combat',
    icon: 'users',
    color: 'cyan',
    details: JSON.stringify({
      abilityCheck: 'Grant advantage on next ability check',
      combatHelp: 'Grant advantage on next attack against target within 5 feet',
      range: 'Target must be within 5 feet of you for combat help',
      duration: 'Must be used before start of your next turn'
    })
  },
  {
    name: 'Hide',
    nameEs: 'Ocultarse',
    description: 'When you take the Hide action, you make a Dexterity (Stealth) check in an attempt to hide, following the rules for hiding. If you succeed, you gain certain benefits, as described in the "Unseen Attackers and Targets" section. Until you are discovered or you stop hiding, that check\'s total is contested by the Wisdom (Perception) check of any creature that actively searches for signs of your presence.',
    type: 'Action',
    category: 'Exploration',
    icon: 'eye-off',
    color: 'gray',
    details: JSON.stringify({
      check: 'Dexterity (Stealth) check',
      opposedBy: 'Wisdom (Perception) check of searching creatures',
      benefits: 'Advantage on attacks, attacks against you have disadvantage',
      requirements: 'Must be heavily obscured or have cover',
      breaking: 'Making noise, attacking, or casting spells breaks hiding'
    })
  },
  {
    name: 'Ready',
    nameEs: 'Preparar',
    description: 'Sometimes you want to get the jump on a foe or wait for a particular circumstance before you act. To do so, you can take the Ready action on your turn, which lets you act using your reaction before the start of your next turn. First, you decide what perceivable circumstance will trigger your reaction. Then, you choose the action you will take in response to that trigger, or you choose to move up to your speed in response to it.',
    type: 'Action',
    category: 'Combat',
    icon: 'clock',
    color: 'orange',
    details: JSON.stringify({
      trigger: 'Must be a perceivable circumstance',
      response: 'Action or movement up to your speed',
      cost: 'Uses your reaction when triggered',
      spellcasting: 'Ready action can be used to cast a spell (spell\'s casting time must be 1 action)',
      spellHold: 'If trigger doesn\'t occur, spell slot is lost'
    })
  },
  {
    name: 'Search',
    nameEs: 'Buscar',
    description: 'When you take the Search action, you devote your attention to finding something. Depending on the nature of your search, the DM might have you make a Wisdom (Perception) check or an Intelligence (Investigation) check. The search encompasses an area around you, and the DM might rule that finding certain things requires a specific amount of time.',
    type: 'Action',
    category: 'Exploration',
    icon: 'search',
    color: 'teal',
    details: JSON.stringify({
      checks: ['Wisdom (Perception)', 'Intelligence (Investigation)'],
      uses: 'Finding hidden objects, secret doors, traps, creatures',
      passive: 'Passive Perception is used when not actively searching'
    })
  },
  {
    name: 'Use an Object',
    nameEs: 'Usar un Objeto',
    description: 'When an object requires your action for its use, you take the Use an Object action. This action is also used when you want to interact with more than one object on your turn. Normally, you can interact with one object for free during your turn (such as drawing a weapon or opening a door). If you want to interact with a second object, use this action.',
    type: 'Action',
    category: 'Exploration',
    icon: 'package',
    color: 'amber',
    details: JSON.stringify({
      freeInteraction: 'Draw/sheathe weapon, open door, pick up item, etc.',
      actionRequired: 'Second object interaction, use magic item, administer potion',
      magicItems: 'Most magic items require this action to activate',
      examples: ['Drink a potion', 'Light a torch', 'Apply poison', 'Use a magic item']
    })
  },
  {
    name: 'Grapple',
    nameEs: 'Agarrar',
    description: 'When you want to grab a creature or wrestle with it, you can use the Attack action to make a special melee attack, a grapple. If you\'re able to make multiple attacks with the Attack action, this attack replaces one of them. The target of your grapple must be no more than one size larger than you, and it must be within your reach. Using at least one free hand, you try to seize the target by making a grapple check: a Strength (Athletics) check contested by the target\'s Strength (Athletics) or Dexterity (Acrobatics) check.',
    type: 'Action',
    category: 'Combat',
    icon: 'hand',
    color: 'red',
    requirements: 'Target must be no more than one size larger, within reach, free hand required',
    details: JSON.stringify({
      contest: 'Strength (Athletics) vs. target\'s Athletics or Acrobatics',
      sizeLimit: 'Target must be no more than one size larger',
      requirements: 'At least one free hand',
      effect: 'Target has Grappled condition, speed becomes 0',
      escape: 'Target can use action to escape with Athletics or Acrobatics contest',
      replaceAttack: 'Replaces one attack from Attack action'
    })
  },
  {
    name: 'Shove',
    nameEs: 'Empujar',
    description: 'Using the Attack action, you can make a special melee attack to shove a creature, either to knock it prone or push it away from you. If you\'re able to make multiple attacks with the Attack action, this attack replaces one of them. The target of your shove must be no more than one size larger than you, and it must be within your reach. You make a Strength (Athletics) check contested by the target\'s Strength (Athletics) or Dexterity (Acrobatics) check.',
    type: 'Action',
    category: 'Combat',
    icon: 'wind',
    color: 'red',
    requirements: 'Target must be no more than one size larger, within reach',
    details: JSON.stringify({
      options: ['Knock prone', 'Push 5 feet away'],
      contest: 'Strength (Athletics) vs. target\'s Athletics or Acrobatics',
      sizeLimit: 'Target must be no more than one size larger',
      proneBenefit: 'Attacks within 5 feet have advantage, target has disadvantage on attacks',
      replaceAttack: 'Replaces one attack from Attack action'
    })
  },
  {
    name: 'Two-Weapon Fighting',
    nameEs: 'Combate con Dos Armas',
    description: 'When you take the Attack action with a light melee weapon that you\'re holding in one hand, you can use a bonus action to attack with a different light melee weapon that you\'re holding in the other hand. You don\'t add your ability modifier to the damage of the bonus attack, unless that modifier is negative. If either weapon has the thrown property, you can throw the weapon instead of making a melee attack with it.',
    type: 'Bonus Action',
    category: 'Combat',
    icon: 'swords',
    color: 'red',
    requirements: 'Two light melee weapons',
    details: JSON.stringify({
      requirement: 'Both weapons must have the Light property',
      bonusAction: 'Uses bonus action for second attack',
      damage: 'No ability modifier on bonus attack damage (unless negative)',
      fightingStyle: 'Two-Weapon Fighting style adds ability modifier to damage',
      thrown: 'Thrown weapons can be used'
    })
  },
  {
    name: 'Opportunity Attack',
    nameEs: 'Ataque de Oportunidad',
    description: 'In a fight, everyone is constantly watching for enemies to drop their guard. You can rarely move heedlessly past your foes without putting yourself in danger; doing so provokes an opportunity attack. To make the opportunity attack, you use your reaction to make one melee attack against the provoking creature. The attack occurs right before the creature leaves your reach.',
    type: 'Reaction',
    category: 'Combat',
    icon: 'target',
    color: 'red',
    requirements: 'Triggered when creature moves out of your reach',
    details: JSON.stringify({
      trigger: 'Creature leaves your reach',
      cost: 'Uses your reaction',
      attack: 'One melee attack against the provoking creature',
      timing: 'Occurs right before creature leaves reach',
      disengage: 'Disengage action prevents opportunity attacks',
      teleport: 'Teleportation doesn\'t provoke opportunity attacks'
    })
  },
  {
    name: 'Unarmed Strike',
    nameEs: 'Golpe Desarmado',
    description: 'Instead of using a weapon to make a melee weapon attack, you can use an unarmed strike: a punch, kick, head-butt, or similar forceful blow (none of which count as weapons). On a hit, an unarmed strike deals bludgeoning damage equal to 1 + your Strength modifier. You are proficient with your unarmed strikes. A Monk\'s unarmed strike deals more damage based on their level.',
    type: 'Action',
    category: 'Combat',
    icon: 'hand',
    color: 'red',
    details: JSON.stringify({
      damage: '1 + Strength modifier (bludgeoning)',
      proficient: 'Always proficient',
      monk: 'Monks deal 1d4+ at higher levels',
      grapple: 'Can be used for grappling',
      shove: 'Can be used for shoving'
    })
  },

  // ========== EXPLORATION ACTIONS ==========
  {
    name: 'Climb',
    nameEs: 'Trepar',
    description: 'While climbing or swimming, each foot of movement costs 1 extra foot (2 extra feet in difficult terrain), unless a creature has a climbing or swimming speed. At the DM\'s option, climbing a slippery vertical surface or one with few handholds requires a successful Strength (Athletics) check.',
    type: 'Movement',
    category: 'Exploration',
    icon: 'arrow-up',
    color: 'green',
    details: JSON.stringify({
      movementCost: 'Each foot costs 1 extra foot (2 in difficult terrain)',
      check: 'Strength (Athletics) for difficult surfaces',
      climbingSpeed: 'Creatures with climbing speed don\'t pay extra movement cost'
    })
  },
  {
    name: 'Swim',
    nameEs: 'Nadar',
    description: 'While swimming, each foot of movement costs 1 extra foot (2 extra feet in difficult terrain), unless a creature has a swimming speed. At the DM\'s option, swimming through rough water might require a successful Strength (Athletics) check.',
    type: 'Movement',
    category: 'Exploration',
    icon: 'droplet',
    color: 'blue',
    details: JSON.stringify({
      movementCost: 'Each foot costs 1 extra foot (2 in difficult terrain)',
      check: 'Strength (Athletics) for rough water',
      swimmingSpeed: 'Creatures with swimming speed don\'t pay extra movement cost',
      drowning: 'Can hold breath for minutes equal to CON modifier (min 1)'
    })
  },
  {
    name: 'Jump',
    nameEs: 'Saltar',
    description: 'Your jump distance is determined by your Strength score. Long jump: You cover a number of feet up to your Strength score if you move at least 10 feet on foot immediately before the jump. High jump: You leap into the air a number of feet equal to 3 + your Strength modifier if you move at least 10 feet on foot immediately before the jump.',
    type: 'Movement',
    category: 'Exploration',
    icon: 'arrow-up-circle',
    color: 'green',
    details: JSON.stringify({
      longJump: 'Feet equal to Strength score (with 10 ft run)',
      highJump: '3 + Strength modifier feet (with 10 ft run)',
      standingJump: 'Half distance without running start',
      reach: 'Can extend reach by jumping and reaching'
    })
  },
  {
    name: 'Squeeze',
    nameEs: 'Apretarse',
    description: 'A creature can squeeze through a space that is large enough for a creature one size smaller than itself. Thus, a Large creature can squeeze through a passage that\'s only 5 feet wide. While squeezing through a space, a creature must spend 1 extra foot for every foot it moves there, and it has disadvantage on attack rolls and Dexterity saving throws. Attack rolls against the creature have advantage while it\'s in the smaller space.',
    type: 'Movement',
    category: 'Exploration',
    icon: 'minimize-2',
    color: 'gray',
    details: JSON.stringify({
      space: 'Can fit through space for creature one size smaller',
      movementCost: '1 extra foot per foot moved',
      attackPenalty: 'Disadvantage on attack rolls',
      savePenalty: 'Disadvantage on Dexterity saving throws',
      defensePenalty: 'Attacks against you have advantage'
    })
  },
  {
    name: 'Crawl',
    nameEs: 'Arrastrarse',
    description: 'While prone, you can crawl. Crawling 1 foot in difficult terrain costs 3 feet of movement. If you would end your movement prone in the same space as another creature, you can move into a space within 5 feet of that creature instead. You can end your move in another creature\'s space only if that creature is at least two sizes larger or smaller than you.',
    type: 'Movement',
    category: 'Exploration',
    icon: 'footprints',
    color: 'gray',
    details: JSON.stringify({
      movementCost: 'Each foot costs 1 extra foot (2 in difficult terrain)',
      prone: 'Must be prone to crawl',
      standingUp: 'Costs half your movement speed to stand up',
      creatureSpace: 'Can\'t end move in another creature\'s space normally'
    })
  },

  // ========== SOCIAL ACTIONS ==========
  {
    name: 'Influence',
    nameEs: 'Influir',
    description: 'You can use your action to attempt to influence a creature through persuasion, deception, or intimidation. Make a Charisma check contested by the target\'s Wisdom (Insight) check. The DM may apply advantage or disadvantage based on circumstances, the creature\'s attitude, and your approach.',
    type: 'Action',
    category: 'Social',
    icon: 'message-circle',
    color: 'pink',
    details: JSON.stringify({
      skills: ['Persuasion', 'Deception', 'Intimidation'],
      opposedBy: 'Wisdom (Insight)',
      attitudes: ['Hostile', 'Unfriendly', 'Indifferent', 'Friendly', 'Helpful'],
      time: 'Usually takes at least 1 minute of interaction'
    })
  },
  {
    name: 'Insight',
    nameEs: 'Perspicacia',
    description: 'Your Wisdom (Insight) check decides whether you can determine the true intentions of a creature, such as when searching out a lie or predicting someone\'s next move. Doing so involves gleaning clues from body language, speech habits, and changes in mannerisms.',
    type: 'Action',
    category: 'Social',
    icon: 'eye',
    color: 'purple',
    details: JSON.stringify({
      check: 'Wisdom (Insight)',
      opposedBy: 'Charisma (Deception)',
      uses: ['Detect lies', 'Read body language', 'Predict behavior', 'Assess honesty'],
      passive: 'Passive Insight is always active'
    })
  },

  // ========== OBJECT INTERACTIONS ==========
  {
    name: 'Disarm',
    nameEs: 'Desarmar',
    description: 'A creature can use a weapon attack to knock a weapon or another item from a target\'s grasp. The attacker makes an attack roll contested by the target\'s Strength (Athletics) check or Dexterity (Acrobatics) check. If the attacker wins the contest, the attack causes no damage or other ill effect, but the target drops the item. The DM decides if this option is available.',
    type: 'Action',
    category: 'Combat',
    icon: 'shield-off',
    color: 'orange',
    details: JSON.stringify({
      contest: 'Attack roll vs. Athletics or Acrobatics',
      effect: 'Target drops held item',
      dmOption: 'DM may allow or disallow this action',
      replaceAttack: 'Replaces one attack from Attack action'
    })
  },
  {
    name: 'Mark',
    nameEs: 'Marcar',
    description: 'When a creature makes a melee attack, it can designate a creature within 5 feet of it as a mark. The marked creature has disadvantage on any attack roll that doesn\'t target the marking creature. This effect lasts until the marking creature makes an attack that doesn\'t target the marked creature, or until the marked creature moves more than 5 feet away from the marking creature.',
    type: 'Action',
    category: 'Combat',
    icon: 'crosshair',
    color: 'red',
    details: JSON.stringify({
      requirement: 'Target within 5 feet',
      effect: 'Disadvantage on attacks that don\'t target you',
      duration: 'Until you attack another target or marked creature moves away',
      dmOption: 'DM may allow or disallow this action'
    })
  },
  {
    name: 'Overrun',
    nameEs: 'Arrollar',
    description: 'A creature can use its action to attempt to move through a hostile creature\'s space. The creature makes a Strength (Athletics) check contested by the hostile creature\'s Strength (Athletics) check. The creature attempting to overrun has advantage on its check if it is larger than the hostile creature, or disadvantage if it is smaller.',
    type: 'Action',
    category: 'Movement',
    icon: 'chevrons-right',
    color: 'green',
    details: JSON.stringify({
      contest: 'Strength (Athletics) vs. Athletics',
      sizeModifier: 'Advantage if larger, disadvantage if smaller',
      effect: 'Move through hostile creature\'s space',
      dmOption: 'DM may allow or disallow this action'
    })
  },
  {
    name: 'Tumble',
    nameEs: 'Voltereta',
    description: 'A creature can use its action to tumble through a hostile creature\'s space. The creature makes a Dexterity (Acrobatics) check contested by the hostile creature\'s Dexterity (Acrobatics) check. If the tumbler wins the contest, it can move through the hostile creature\'s space without provoking opportunity attacks.',
    type: 'Action',
    category: 'Movement',
    icon: 'rotate-ccw',
    color: 'green',
    details: JSON.stringify({
      contest: 'Dexterity (Acrobatics) vs. Acrobatics',
      effect: 'Move through hostile space without opportunity attacks',
      dmOption: 'DM may allow or disallow this action'
    })
  },

  // ========== REST AND RECOVERY ==========
  {
    name: 'Short Rest',
    nameEs: 'Descanso Corto',
    description: 'A short rest is a period of downtime, at least 1 hour long, during which a character does nothing more strenuous than eating, drinking, reading, and tending to wounds. A character can spend one or more Hit Dice at the end of a short rest, up to the character\'s maximum number of Hit Dice. For each Hit Die spent, the player rolls the die and adds the character\'s Constitution modifier. The character regains hit points equal to the total.',
    type: 'Other',
    category: 'Exploration',
    icon: 'sun',
    color: 'yellow',
    details: JSON.stringify({
      duration: 'At least 1 hour',
      hitDice: 'Spend Hit Dice to recover HP',
      activities: 'Eat, drink, read, tend wounds',
      features: 'Some class features recover on short rest',
      warlock: 'Warlock spell slots recover on short rest'
    })
  },
  {
    name: 'Long Rest',
    nameEs: 'Descanso Largo',
    description: 'A long rest is a period of extended downtime, at least 8 hours long, during which a character sleeps for at least 6 hours and performs no more than 2 hours of light activity. If the rest is interrupted by a period of strenuous activity—at least 1 hour of walking, fighting, casting spells, or similar adventuring activity—the characters must begin the rest again to gain any benefit from it.',
    type: 'Other',
    category: 'Exploration',
    icon: 'moon',
    color: 'indigo',
    details: JSON.stringify({
      duration: 'At least 8 hours (6 hours sleep, 2 hours light activity)',
      hpRecovery: 'All hit points recovered',
      hitDiceRecovery: 'Recover half your total Hit Dice (minimum 1)',
      spellSlots: 'All spell slots recovered',
      resources: 'Most class resources recovered',
      interruption: '1+ hour of strenuous activity restarts the rest',
      frequency: 'Benefit only once per 24 hours'
    })
  },

  // ========== EQUIPMENT INTERACTIONS ==========
  {
    name: 'Don Armor',
    nameEs: 'Poner Armadura',
    description: 'The time required to don armor depends on its type. Light armor: 1 minute. Medium armor: 5 minutes. Heavy armor: 10 minutes. Padded, Leather, Studded Leather: 1 minute. Hide, Chain Shirt, Scale Mail, Breastplate, Half Plate: 5 minutes. Ring Mail, Chain Mail, Splint, Plate: 10 minutes.',
    type: 'Other',
    category: 'Exploration',
    icon: 'shield',
    color: 'gray',
    details: JSON.stringify({
      lightArmor: '1 minute',
      mediumArmor: '5 minutes',
      heavyArmor: '10 minutes',
      shield: '1 action',
      help: 'With help, heavy armor takes 5 minutes'
    })
  },
  {
    name: 'Doff Armor',
    nameEs: 'Quitarse Armadura',
    description: 'The time required to doff armor depends on its type. Light armor: 1 minute. Medium armor: 1 minute. Heavy armor: 5 minutes. Padded, Leather, Studded Leather: 1 minute. Hide, Chain Shirt, Scale Mail, Breastplate, Half Plate: 1 minute. Ring Mail, Chain Mail, Splint, Plate: 5 minutes.',
    type: 'Other',
    category: 'Exploration',
    icon: 'shield-off',
    color: 'gray',
    details: JSON.stringify({
      lightArmor: '1 minute',
      mediumArmor: '1 minute',
      heavyArmor: '5 minutes',
      shield: '1 action',
      help: 'With help, heavy armor takes 1 minute'
    })
  },

  // ========== SPECIAL COMBAT ==========
  {
    name: 'Aid Another',
    nameEs: 'Asistir a Otro',
    description: 'When a creature takes the Help action, the creature they aid gains advantage on the next ability check it makes to perform the task they are helping with. This ability check must be made before the start of the helper\'s next turn. Alternatively, the helper can aid a friendly creature in attacking a creature within 5 feet of them.',
    type: 'Action',
    category: 'Combat',
    icon: 'heart',
    color: 'cyan',
    details: JSON.stringify({
      abilityCheck: 'Advantage on next ability check',
      attack: 'Advantage on next attack against target within 5 ft',
      duration: 'Before start of helper\'s next turn',
      range: 'Must be within 5 feet for combat assistance'
    })
  },
  {
    name: 'Totem Attack',
    nameEs: 'Ataque Tótem',
    description: 'Some characters can make multiple attacks as part of the Attack action. Beginning at 5th level, you can attack twice, instead of once, whenever you take the Attack action on your turn. The number of attacks increases to three when you reach 11th level in this class (for Fighters) and to four at 20th level.',
    type: 'Action',
    category: 'Combat',
    icon: 'swords',
    color: 'red',
    details: JSON.stringify({
      level5: 'Two attacks',
      level11: 'Three attacks (Fighter)',
      level20: 'Four attacks (Fighter)',
      stacking: 'Multiattack doesn\'t stack between classes'
    })
  }
]

async function main() {
  console.log('Seeding actions...')
  
  for (const action of actions) {
    const existing = await prisma.action.findUnique({
      where: { name: action.name }
    })
    
    if (!existing) {
      await prisma.action.create({ data: action })
      console.log(`Created action: ${action.name}`)
    } else {
      await prisma.action.update({
        where: { name: action.name },
        data: action
      })
      console.log(`Updated action: ${action.name}`)
    }
  }
  
  console.log('Actions seeded successfully!')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
