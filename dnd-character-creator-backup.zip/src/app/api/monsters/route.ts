import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const monsters = await db.monster.findMany({
      orderBy: [
        { cr: 'asc' },
        { name: 'asc' }
      ]
    })
    
    return NextResponse.json(monsters)
  } catch (error) {
    console.error('Error fetching monsters:', error)
    return NextResponse.json({ error: 'Failed to fetch monsters' }, { status: 500 })
  }
}
