import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// API to add expert columns to the database
export async function GET() {
  try {
    // Try to add each expert column
    const columns = [
      'expertAcrobatics', 'expertAnimalHandling', 'expertArcana', 'expertAthletics',
      'expertDeception', 'expertHistory', 'expertInsight', 'expertIntimidation',
      'expertInvestigation', 'expertMedicine', 'expertNature', 'expertPerception',
      'expertPerformance', 'expertPersuasion', 'expertReligion', 'expertSleightOfHand',
      'expertStealth', 'expertSurvival'
    ];

    const results = [];

    for (const col of columns) {
      try {
        await db.$executeRawUnsafe(`ALTER TABLE Character ADD COLUMN ${col} BOOLEAN DEFAULT 0`);
        results.push({ column: col, status: 'added' });
      } catch (e: any) {
        if (e.message?.includes('duplicate column')) {
          results.push({ column: col, status: 'already_exists' });
        } else {
          results.push({ column: col, status: 'error', message: e.message });
        }
      }
    }

    return NextResponse.json({
      message: 'Migration attempt complete',
      results
    });
  } catch (error) {
    console.error('Migration error:', error);
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
