import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const search = searchParams.get('search');
    
    let where: any = {};
    if (category) {
      where.category = category;
    }
    
    // SQLite doesn't support mode: 'insensitive', so we use contains without it
    // and filter case-insensitively in the query
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { name: { contains: search.charAt(0).toUpperCase() + search.slice(1).toLowerCase() } },
        { name: { contains: search.toUpperCase() } },
        { name: { contains: search.toLowerCase() } }
      ];
    }
    
    const weapons = await db.weapon.findMany({
      where,
      orderBy: [{ category: 'asc' }, { name: 'asc' }]
    });
    
    return NextResponse.json(weapons);
  } catch (error) {
    console.error('Error fetching weapons:', error);
    return NextResponse.json({ error: 'Failed to fetch weapons' }, { status: 500 });
  }
}
