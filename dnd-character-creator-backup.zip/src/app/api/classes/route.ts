import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET() {
  try {
    const classes = await db.characterClass.findMany({
      orderBy: { name: 'asc' },
      include: {
        subclasses: {
          orderBy: { name: 'asc' }
        }
      }
    });
    return NextResponse.json(classes);
  } catch (error) {
    console.error('Error fetching classes:', error);
    return NextResponse.json({ error: 'Failed to fetch classes' }, { status: 500 });
  }
}
