import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { Prisma } from '@prisma/client'

// GET - Get single magic item by ID
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    
    const item = await db.magicItem.findUnique({ where: { id } })
    
    if (!item) {
      return NextResponse.json({ error: 'Magic item not found' }, { status: 404 })
    }
    
    return NextResponse.json(item)
  } catch (error) {
    console.error('Error fetching magic item:', error)
    return NextResponse.json({ error: 'Failed to fetch magic item' }, { status: 500 })
  }
}

// PATCH - Update magic item (mainly for price editing)
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { cost, name, rarity, type, attunement, attunementReq, description, effects, weight } = body
    
    const updateData: any = {}
    if (cost !== undefined) updateData.cost = cost
    if (name !== undefined) updateData.name = name
    if (rarity !== undefined) updateData.rarity = rarity
    if (type !== undefined) updateData.type = type
    if (attunement !== undefined) updateData.attunement = attunement
    if (attunementReq !== undefined) updateData.attunementReq = attunementReq
    if (description !== undefined) updateData.description = description
    if (effects !== undefined) updateData.effects = effects
    if (weight !== undefined) updateData.weight = weight
    
    const updatedItem = await db.magicItem.update({
      where: { id },
      data: updateData
    })
    
    return NextResponse.json(updatedItem)
  } catch (error) {
    console.error('Error updating magic item:', error)
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      if (error.code === 'P2025') {
        return NextResponse.json({ error: 'Magic item not found' }, { status: 404 })
      }
    }
    return NextResponse.json({ error: 'Failed to update magic item' }, { status: 500 })
  }
}

// DELETE - Delete a magic item
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    
    await db.magicItem.delete({ where: { id } })
    
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting magic item:', error)
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      if (error.code === 'P2025') {
        return NextResponse.json({ error: 'Magic item not found' }, { status: 404 })
      }
    }
    return NextResponse.json({ error: 'Failed to delete magic item' }, { status: 500 })
  }
}
