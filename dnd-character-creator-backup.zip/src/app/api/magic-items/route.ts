import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const rarity = searchParams.get('rarity');
    const type = searchParams.get('type');
    
    let where: any = {};
    if (rarity) {
      where.rarity = rarity;
    }
    if (type) {
      where.type = type;
    }
    
    const magicItems = await db.magicItem.findMany({
      where,
      orderBy: [{ rarity: 'asc' }, { name: 'asc' }]
    });
    
    return NextResponse.json(magicItems);
  } catch (error) {
    console.error('Error fetching magic items:', error);
    return NextResponse.json({ error: 'Failed to fetch magic items' }, { status: 500 });
  }
}
