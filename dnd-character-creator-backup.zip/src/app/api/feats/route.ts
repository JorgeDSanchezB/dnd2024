import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// D&D 2024 Feats data - Updated schema with abilityScoreOptions and spellOptions
const DND_2024_FEATS = [
  // Origin Feats
  {
    name: "Alert",
    category: "Origin",
    description: "Always on your toes, you react quickly to danger.",
    benefit: "You gain Initiative Proficiency and can swap Initiative with an ally.",
    repeatable: false,
    abilityScoreOptions: null,
    abilityScoreBonus: 0,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Crafter",
    category: "Origin",
    description: "You are adept at crafting items quickly and efficiently.",
    benefit: "Tool Proficiency with 3 Artisan's Tools, 20% discount on nonmagical items, Fast Crafting ability.",
    repeatable: false,
    abilityScoreOptions: null,
    abilityScoreBonus: 0,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Healer",
    category: "Origin",
    description: "You have training in stabilizing wounds and healing.",
    benefit: "Battle Medic ability, Healing Rerolls when restoring HP.",
    repeatable: false,
    abilityScoreOptions: null,
    abilityScoreBonus: 0,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Lucky",
    category: "Origin",
    description: "Fortune favors you.",
    benefit: "Luck Points equal to Proficiency Bonus. Spend for Advantage on d20 tests or Disadvantage on enemy attacks.",
    repeatable: false,
    abilityScoreOptions: null,
    abilityScoreBonus: 0,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Magic Initiate",
    category: "Origin",
    description: "You have learned the rudiments of magic.",
    benefit: "2 cantrips and 1 level 1 spell from a spell list. Cast the spell once without a slot.",
    repeatable: true,
    abilityScoreOptions: null,
    abilityScoreBonus: 0,
    spellOptions: JSON.stringify({ chooseFromClass: true, cantrips: 2, level1Spells: 1 }),
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Musician",
    category: "Origin",
    description: "You are a skilled performer.",
    benefit: "Proficiency with 3 Musical Instruments. Encouraging Song gives Heroic Inspiration to allies after rests.",
    repeatable: false,
    abilityScoreOptions: null,
    abilityScoreBonus: 0,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Savage Attacker",
    category: "Origin",
    description: "You've trained to deal particularly damaging strikes.",
    benefit: "Once per turn, reroll one damage die from a melee attack and use the higher roll.",
    repeatable: false,
    abilityScoreOptions: null,
    abilityScoreBonus: 0,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Skilled",
    category: "Origin",
    description: "You have acquired specialized training.",
    benefit: "Gain proficiency in 3 skills or tools of your choice.",
    repeatable: true,
    abilityScoreOptions: null,
    abilityScoreBonus: 0,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Tavern Brawler",
    category: "Origin",
    description: "You have experience in unarmed combat.",
    benefit: "Enhanced Unarmed Strike (1d4), Damage Rerolls, Improvised Weapon proficiency, Push ability.",
    repeatable: false,
    abilityScoreOptions: null,
    abilityScoreBonus: 0,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Tough",
    category: "Origin",
    description: "You are exceptionally resilient.",
    benefit: "HP maximum increases by 2 per character level.",
    repeatable: false,
    abilityScoreOptions: null,
    abilityScoreBonus: 0,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  // General Feats with Ability Score improvements
  {
    name: "Ability Score Improvement",
    category: "General",
    description: "Increase one ability score by 2, or two ability scores by 1.",
    benefit: "Increase one ability score by 2, or two ability scores by 1. Maximum 20.",
    repeatable: true,
    abilityScoreOptions: JSON.stringify(["strength", "dexterity", "constitution", "intelligence", "wisdom", "charisma"]),
    abilityScoreBonus: 2,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Actor",
    category: "General",
    prerequisite: "Level 4+, Charisma 13+",
    description: "You are skilled at mimicry and dramatic performance.",
    benefit: "Charisma +1. Advantage on Deception and Performance checks. Mimic speech and sounds.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["charisma"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Athlete",
    category: "General",
    prerequisite: "Level 4+, Strength or Dexterity 13+",
    description: "You have trained to be at the peak of physical performance.",
    benefit: "Strength or Dexterity +1. Climb Speed, Hop Up, improved Jumping, Push ability.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["strength", "dexterity"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Charger",
    category: "General",
    prerequisite: "Level 4+, Strength or Dexterity 13+",
    description: "You charge into battle with powerful momentum.",
    benefit: "Strength or Dexterity +1. Improved Dash, Charge Attack bonus damage or push.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["strength", "dexterity"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Chef",
    category: "General",
    prerequisite: "Level 4+, Strength or Dexterity 13+",
    description: "You can create meals that provide temporary hit points and buffs.",
    benefit: "Strength or Dexterity +1. Cook's Utensils proficiency. Create treats that give temp HP.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["strength", "dexterity"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Crossbow Expert",
    category: "General",
    prerequisite: "Level 4+, Dexterity 13+",
    description: "You are skilled with crossbows.",
    benefit: "Dexterity +1. Ignore Loading, fire in melee without disadvantage, dual wield crossbows.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["dexterity"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Crusher",
    category: "General",
    prerequisite: "Level 4+",
    description: "You are skilled at dealing bludgeoning damage.",
    benefit: "Strength or Constitution +1. Push on bludgeoning hit, Enhanced Critical vs affected targets.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["strength", "constitution"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Defensive Duelist",
    category: "General",
    prerequisite: "Level 4+, Strength or Dexterity 13+",
    description: "You use your weapon to parry attacks.",
    benefit: "Strength or Dexterity +1. Use Reaction to add proficiency bonus to AC against one attack.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["strength", "dexterity"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Dual Wielder",
    category: "General",
    prerequisite: "Level 4+, Strength or Dexterity 13+",
    description: "You are skilled at fighting with two weapons.",
    benefit: "Strength or Dexterity +1. Enhanced Dual Wielding, Quick Draw.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["strength", "dexterity"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Durable",
    category: "General",
    prerequisite: "Level 4+",
    description: "You are exceptionally resilient.",
    benefit: "Constitution +1. Advantage on Death Saves, heal with Hit Point Dice as Bonus Action.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["constitution"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Fey-Touched",
    category: "General",
    prerequisite: "Level 4+",
    description: "Your exposure to the Feywild's magic has changed you.",
    benefit: "Intelligence, Wisdom, or Charisma +1. Misty Step and one Divination/Enchantment spell.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["intelligence", "wisdom", "charisma"]),
    abilityScoreBonus: 1,
    spellOptions: JSON.stringify({ schools: ["Divination", "Enchantment"], level1Spell: true, bonusSpell: "Misty Step" }),
    spellSchoolFilter: "Divination, Enchantment",
    spellsGranted: JSON.stringify(["Misty Step"])
  },
  {
    name: "Grappler",
    category: "General",
    prerequisite: "Level 4+, Strength or Dexterity 13+",
    description: "You are skilled at grappling.",
    benefit: "Strength or Dexterity +1. Punch and Grab, Attack Advantage vs Grappled, Fast Wrestler.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["strength", "dexterity"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Great Weapon Master",
    category: "General",
    prerequisite: "Level 4+, Strength 13+",
    description: "You are skilled at using heavy weapons.",
    benefit: "Strength +1. Heavy Weapon Mastery, Bonus Action attack on critical or kill.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["strength"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Heavily Armored",
    category: "General",
    prerequisite: "Level 4+, Medium Armor Training",
    description: "You have trained in heavy armor.",
    benefit: "Constitution or Strength +1. Heavy Armor Training.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["constitution", "strength"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Heavy Armor Master",
    category: "General",
    prerequisite: "Level 4+, Heavy Armor Training",
    description: "You are exceptionally skilled in heavy armor.",
    benefit: "Constitution or Strength +1. Reduce physical damage by Proficiency Bonus while in heavy armor.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["constitution", "strength"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Inspiring Leader",
    category: "General",
    prerequisite: "Level 4+, Wisdom or Charisma 13+",
    description: "You can inspire your companions with words of encouragement.",
    benefit: "Wisdom or Charisma +1. Grant temp HP equal to level + ability modifier after a rest.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["wisdom", "charisma"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Keen Mind",
    category: "General",
    prerequisite: "Level 4+, Intelligence 13+",
    description: "You have a keen mind for details.",
    benefit: "Intelligence +1. Lore Knowledge proficiency, Quick Study as Bonus Action.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["intelligence"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Lightly Armored",
    category: "General",
    prerequisite: "Level 4+",
    description: "You have trained in light armor.",
    benefit: "Strength or Dexterity +1. Light Armor and Shield Training.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["strength", "dexterity"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Mage Slayer",
    category: "General",
    prerequisite: "Level 4+",
    description: "You are adept at fighting spellcasters.",
    benefit: "Strength or Dexterity +1. Concentration Breaker, Guarded Mind once per long rest.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["strength", "dexterity"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Medium Armor Master",
    category: "General",
    prerequisite: "Level 4+, Medium Armor Training",
    description: "You are exceptionally skilled in medium armor.",
    benefit: "Constitution or Strength +1. Add +3 to AC with medium armor if Dex 16+.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["constitution", "strength"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Moderately Armored",
    category: "General",
    prerequisite: "Level 4+, Light Armor Training",
    description: "You have trained in medium armor.",
    benefit: "Strength or Dexterity +1. Medium Armor Training.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["strength", "dexterity"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Observant",
    category: "General",
    prerequisite: "Level 4+, Intelligence 13+",
    description: "You are highly observant and perceptive.",
    benefit: "Intelligence +1. Read Lips, Quick Search as Bonus Action.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["intelligence"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Piercer",
    category: "General",
    prerequisite: "Level 4+",
    description: "You are skilled at dealing piercing damage.",
    benefit: "Strength or Dexterity +1. Puncture reroll, Enhanced Critical with piercing.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["strength", "dexterity"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Poisoner",
    category: "General",
    prerequisite: "Level 4+",
    description: "You are skilled at using poisons.",
    benefit: "Dexterity or Intelligence +1. Potent Poison, Brew Poison with Poisoner's Kit.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["dexterity", "intelligence"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Polearm Master",
    category: "General",
    prerequisite: "Level 4+, Strength or Dexterity 13+",
    description: "You are skilled with polearms.",
    benefit: "Dexterity or Strength +1. Pole Strike, Reactive Strike when enemies enter reach.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["dexterity", "strength"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Resilient",
    category: "General",
    prerequisite: "Level 4+",
    description: "You are exceptionally resilient in one ability.",
    benefit: "Choose one ability. +1 to that ability, gain saving throw proficiency.",
    repeatable: true,
    abilityScoreOptions: JSON.stringify(["strength", "dexterity", "constitution", "intelligence", "wisdom", "charisma"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Ritual Caster",
    category: "General",
    prerequisite: "Level 4+, Intelligence, Wisdom, or Charisma 13+",
    description: "You can cast ritual spells.",
    benefit: "Intelligence, Wisdom, or Charisma +1. Ritual spells prepared, Quick Ritual once per long rest.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["intelligence", "wisdom", "charisma"]),
    abilityScoreBonus: 1,
    spellOptions: JSON.stringify({ ritualOnly: true }),
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Sentinel",
    category: "General",
    prerequisite: "Level 4+, Strength or Dexterity 13+",
    description: "You are skilled at controlling the battlefield.",
    benefit: "Strength or Dexterity +1. Guardian, reduce speed to 0 on opportunity attack, Reactive Strike.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["strength", "dexterity"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Shadow-Touched",
    category: "General",
    prerequisite: "Level 4+",
    description: "Your exposure to the Shadowfell's magic has changed you.",
    benefit: "Intelligence, Wisdom, or Charisma +1. Invisibility and one Illusion/Necromancy spell.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["intelligence", "wisdom", "charisma"]),
    abilityScoreBonus: 1,
    spellOptions: JSON.stringify({ schools: ["Illusion", "Necromancy"], level1Spell: true, bonusSpell: "Invisibility" }),
    spellSchoolFilter: "Illusion, Necromancy",
    spellsGranted: JSON.stringify(["Invisibility"])
  },
  {
    name: "Sharpshooter",
    category: "General",
    prerequisite: "Level 4+, Strength or Dexterity 13+",
    description: "You are skilled with ranged weapons.",
    benefit: "Strength or Dexterity +1. Firing in Melee, Long Shots, Covering Shot.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["strength", "dexterity"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Shield Master",
    category: "General",
    prerequisite: "Level 4+, Strength or Dexterity 13+",
    description: "You are skilled at using shields.",
    benefit: "Strength or Dexterity +1. Shield Shove, Shield Defense.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["strength", "dexterity"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Skill Expert",
    category: "General",
    prerequisite: "Level 4+",
    description: "You have expertise in a skill.",
    benefit: "Choose one ability. +1 to that ability, gain skill proficiency and expertise.",
    repeatable: true,
    abilityScoreOptions: JSON.stringify(["strength", "dexterity", "constitution", "intelligence", "wisdom", "charisma"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Skulker",
    category: "General",
    prerequisite: "Level 4+, Dexterity 13+",
    description: "You are skilled at stealth.",
    benefit: "Dexterity +1. Fire in Shadows, Hidden Step, Snipers Shroud.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["dexterity"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Slasher",
    category: "General",
    prerequisite: "Level 4+",
    description: "You are skilled at dealing slashing damage.",
    benefit: "Strength or Dexterity +1. Slashing Speed reduction, Enhanced Critical with slashing.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["strength", "dexterity"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Speedy",
    category: "General",
    prerequisite: "Level 4+",
    description: "You are exceptionally fast.",
    benefit: "Dexterity +1. Speed +10, Dash Over, Fast Climber.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["dexterity"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Spell Sniper",
    category: "General",
    prerequisite: "Level 4+, Spellcasting or Pact Magic",
    description: "You are skilled at hitting with spell attacks.",
    benefit: "Intelligence, Wisdom, or Charisma +1. Spell range doubled, ignore cover, learn attack cantrip.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["intelligence", "wisdom", "charisma"]),
    abilityScoreBonus: 1,
    spellOptions: JSON.stringify({ attackCantrip: true }),
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Telekinetic",
    category: "General",
    prerequisite: "Level 4+",
    description: "You have telekinetic abilities.",
    benefit: "Intelligence, Wisdom, or Charisma +1. Telekinetic shove, invisible mage hand.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["intelligence", "wisdom", "charisma"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Telepathic",
    category: "General",
    prerequisite: "Level 4+",
    description: "You have telepathic abilities.",
    benefit: "Intelligence, Wisdom, or Charisma +1. Telepathic communication up to 1 mile.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["intelligence", "wisdom", "charisma"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "War Caster",
    category: "General",
    prerequisite: "Level 4+, Spellcasting or Pact Magic",
    description: "You are skilled at casting spells in combat.",
    benefit: "Constitution, Intelligence, Wisdom, or Charisma +1. Spellcasting in melee, Somatic components free, Reaction spells.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["constitution", "intelligence", "wisdom", "charisma"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Weapon Master",
    category: "General",
    prerequisite: "Level 4+, Strength 13+",
    description: "You are skilled with all weapons.",
    benefit: "Strength +1. All Simple and Martial weapon proficiency, +1 to weapon attacks.",
    repeatable: false,
    abilityScoreOptions: JSON.stringify(["strength"]),
    abilityScoreBonus: 1,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  // Fighting Style Feats
  {
    name: "Archery",
    category: "Fighting Style",
    prerequisite: "Fighting Style feature",
    description: "You are skilled with ranged weapons.",
    benefit: "+2 bonus to attack rolls with ranged weapons.",
    repeatable: false,
    abilityScoreOptions: null,
    abilityScoreBonus: 0,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Defense",
    category: "Fighting Style",
    prerequisite: "Fighting Style feature",
    description: "You are skilled at defense.",
    benefit: "+1 bonus to AC while wearing armor.",
    repeatable: false,
    abilityScoreOptions: null,
    abilityScoreBonus: 0,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Dueling",
    category: "Fighting Style",
    prerequisite: "Fighting Style feature",
    description: "You are skilled at one-on-one combat.",
    benefit: "+2 bonus to damage rolls with one-handed melee weapons.",
    repeatable: false,
    abilityScoreOptions: null,
    abilityScoreBonus: 0,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Two-Weapon Fighting",
    category: "Fighting Style",
    prerequisite: "Fighting Style feature",
    description: "You are skilled at fighting with two weapons.",
    benefit: "Add ability modifier to off-hand weapon damage.",
    repeatable: false,
    abilityScoreOptions: null,
    abilityScoreBonus: 0,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  // Epic Boon Feats
  {
    name: "Boon of Combat Prowess",
    category: "Epic Boon",
    prerequisite: "Level 19+",
    description: "You have achieved legendary combat prowess.",
    benefit: "Once per turn, replace a missed attack with a hit, or force an enemy to reroll a hit.",
    repeatable: false,
    abilityScoreOptions: null,
    abilityScoreBonus: 0,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Boon of Fortitude",
    category: "Epic Boon",
    prerequisite: "Level 19+",
    description: "You are exceptionally resilient.",
    benefit: "Hit Point maximum increases by 40. Regain 2d6 HP at the start of each turn.",
    repeatable: false,
    abilityScoreOptions: null,
    abilityScoreBonus: 0,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  },
  {
    name: "Boon of Speed",
    category: "Epic Boon",
    prerequisite: "Level 19+",
    description: "You are incredibly fast.",
    benefit: "Speed increases by 30 feet. Dash as Bonus Action. Dash doesn't provoke opportunity attacks.",
    repeatable: false,
    abilityScoreOptions: null,
    abilityScoreBonus: 0,
    spellOptions: null,
    spellSchoolFilter: null,
    spellsGranted: null
  }
]

// GET - Get all feats (seeds database if empty, updates existing feats if missing fields)
export async function GET() {
  try {
    let feats = await db.feat.findMany({
      orderBy: [
        { category: 'asc' },
        { name: 'asc' }
      ]
    })
    
    // Seed feats if database is empty
    if (feats.length === 0) {
      console.log('Seeding feats database...')
      await db.feat.createMany({
        data: DND_2024_FEATS
      })
      feats = await db.feat.findMany({
        orderBy: [
          { category: 'asc' },
          { name: 'asc' }
        ]
      })
      console.log(`Seeded ${feats.length} feats`)
    } else {
      // Check if any feats are missing important fields (abilityScoreOptions, spellOptions, etc.)
      const needsUpdate = feats.some(f => 
        f.abilityScoreOptions === null && DND_2024_FEATS.find(d => d.name === f.name)?.abilityScoreOptions
      )
      
      if (needsUpdate) {
        console.log('Updating feats with missing fields...')
        // Update existing feats with new field data
        for (const featData of DND_2024_FEATS) {
          const existingFeat = feats.find(f => f.name === featData.name)
          if (existingFeat) {
            await db.feat.update({
              where: { id: existingFeat.id },
              data: {
                abilityScoreOptions: featData.abilityScoreOptions,
                spellOptions: featData.spellOptions,
                spellSchoolFilter: featData.spellSchoolFilter,
                spellsGranted: featData.spellsGranted,
                skillProficienciesGranted: featData.skillProficienciesGranted ?? null,
                expertiseGranted: featData.expertiseGranted ?? false
              }
            })
          }
        }
        // Refetch updated feats
        feats = await db.feat.findMany({
          orderBy: [
            { category: 'asc' },
            { name: 'asc' }
          ]
        })
        console.log('Feats updated successfully')
      }
    }
    
    return NextResponse.json(feats)
  } catch (error) {
    console.error('Error fetching feats:', error)
    return NextResponse.json([])  // Return empty array on error
  }
}
