import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Debug endpoint to check character fields
export async function GET() {
  try {
    const characters = await db.character.findMany({
      take: 1
    });
    
    if (characters.length === 0) {
      return NextResponse.json({ message: 'No characters found' });
    }
    
    const char = characters[0];
    
    // Check if expert fields exist
    const hasExpertFields = {
      expertAcrobatics: 'expertAcrobatics' in char,
      expertPerception: 'expertPerception' in char,
      expertStealth: 'expertStealth' in char,
    };
    
    return NextResponse.json({
      characterId: char.id,
      characterName: char.name,
      hasExpertFields,
      expertAcrobaticsValue: (char as any).expertAcrobatics ?? 'field not found',
      expertPerceptionValue: (char as any).expertPerception ?? 'field not found',
      allFields: Object.keys(char)
    });
  } catch (error) {
    console.error('Debug error:', error);
    return NextResponse.json({ error: String(error) }, { status: 500 });
  }
}
