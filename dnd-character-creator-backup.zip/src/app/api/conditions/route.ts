import { NextResponse } from 'next/server'
import { db } from '@/lib/db'

// D&D 2024 Conditions data
const DND_2024_CONDITIONS = [
  {
    name: "Blinded",
    nameEs: "Cegado",
    description: "Un personaje cegado no puede ver y falla automáticamente cualquier prueba de habilidad que requiera vista. Los ataques contra el personaje tienen ventaja, y los ataques del personaje tienen desventaja.",
    effects: JSON.stringify([
      "No puedes ver y fallas automáticamente cualquier prueba de habilidad que requiera vista",
      "Los ataques contra ti tienen ventaja",
      "Tus ataques tienen desventaja"
    ]),
    endsOn: null,
    saveType: null,
    saveDC: null,
    icon: "eye-off",
    color: "gray"
  },
  {
    name: "Charmed",
    nameEs: "Encantado",
    description: "Un personaje encantado no puede atacar al encantador ni tomar como objetivo al encantador con habilidades o efectos mágicos dañinos. El encantador tiene ventaja en cualquier prueba de habilidad para interactuar socialmente con el personaje.",
    effects: JSON.stringify([
      "No puedes atacar al encantador",
      "No puedes tomar como objetivo al encantador con habilidades o efectos mágicos dañinos",
      "El encantador tiene ventaja en pruebas de habilidad para interactuar socialmente contigo"
    ]),
    endsOn: null,
    saveType: null,
    saveDC: null,
    icon: "heart",
    color: "pink"
  },
  {
    name: "Deafened",
    nameEs: "Sordo",
    description: "Un personaje sordo no puede oír y falla automáticamente cualquier prueba de habilidad que requiera oído.",
    effects: JSON.stringify([
      "No puedes oír",
      "Fallas automáticamente cualquier prueba de habilidad que requiera oído"
    ]),
    endsOn: null,
    saveType: null,
    saveDC: null,
    icon: "ear-off",
    color: "slate"
  },
  {
    name: "Exhaustion",
    nameEs: "Agotamiento",
    description: "El agotamiento se mide en seis niveles. Los efectos se acumulan. Un personaje sufre el efecto de su nivel actual de agotamiento así como todos los niveles inferiores. Finalizar un descanso largo reduce el nivel de agotamiento en 1, siempre que el personaje haya ingerido comida y bebida.",
    effects: JSON.stringify([
      "Nivel 1: Desventaja en pruebas de característica",
      "Nivel 2: Velocidad reducida a la mitad",
      "Nivel 3: Desventaja en tiradas de ataque y salvaciones",
      "Nivel 4: Puntos de golpe máximos reducidos a la mitad",
      "Nivel 5: Velocidad 0",
      "Nivel 6: Muerte"
    ]),
    endsOn: "Descanso largo (reduce 1 nivel)",
    saveType: null,
    saveDC: null,
    icon: "battery-low",
    color: "amber"
  },
  {
    name: "Frightened",
    nameEs: "Asustado",
    description: "Un personaje asustado tiene desventaja en pruebas de característica y tiradas de ataque mientras la fuente de su miedo esté dentro de su línea de visión. El personaje no puede acercarse voluntariamente a la fuente de su miedo.",
    effects: JSON.stringify([
      "Tienes desventaja en pruebas de característica mientras la fuente del miedo esté en tu línea de visión",
      "Tienes desventaja en tiradas de ataque mientras la fuente del miedo esté en tu línea de visión",
      "No puedes acercarte voluntariamente a la fuente de tu miedo"
    ]),
    endsOn: null,
    saveType: null,
    saveDC: null,
    icon: "ghost",
    color: "purple"
  },
  {
    name: "Grappled",
    nameEs: "Agarrado",
    description: "Un personaje agarrado tiene velocidad 0 y no puede beneficiarse de ningún bono a su velocidad. La condición termina si el agarrador queda incapacitado o si un efecto saca al agarrado fuera del alcance del agarrador.",
    effects: JSON.stringify([
      "Tu velocidad es 0 y no puedes beneficiarte de bonos a tu velocidad",
      "La condición termina si el agarrador queda incapacitado",
      "La condición termina si un efecto te saca fuera del alcance del agarrador"
    ]),
    endsOn: null,
    saveType: null,
    saveDC: null,
    icon: "hand",
    color: "orange"
  },
  {
    name: "Incapacitated",
    nameEs: "Incapacitado",
    description: "Un personaje incapacitado no puede realizar acciones ni reacciones.",
    effects: JSON.stringify([
      "No puedes realizar acciones",
      "No puedes realizar reacciones"
    ]),
    endsOn: null,
    saveType: null,
    saveDC: null,
    icon: "x-circle",
    color: "red"
  },
  {
    name: "Invisible",
    nameEs: "Invisible",
    description: "Un personaje invisible es imposible de ver para el ojo desnudo. El personaje tiene ventaja en tiradas de ataque y los ataques contra él tienen desventaja.",
    effects: JSON.stringify([
      "Eres imposible de ver para el ojo desnudo",
      "Tienes ventaja en tiradas de ataque",
      "Los ataques contra ti tienen desventaja"
    ]),
    endsOn: null,
    saveType: null,
    saveDC: null,
    icon: "eye-closed",
    color: "cyan"
  },
  {
    name: "Paralyzed",
    nameEs: "Paralizado",
    description: "Un personaje paralizado está incapacitado y no puede moverse ni hablar. El personaje falla automáticamente las salvaciones de Fuerza y Destreza. Los ataques contra el personaje tienen ventaja y son golpes críticos si el atacante está a menos de 5 pies.",
    effects: JSON.stringify([
      "Estás incapacitado",
      "No puedes moverte ni hablar",
      "Fallas automáticamente las salvaciones de Fuerza y Destreza",
      "Los ataques contra ti tienen ventaja",
      "Los ataques cuerpo a cuerpo contra ti son golpes críticos si el atacante está a menos de 5 pies"
    ]),
    endsOn: null,
    saveType: null,
    saveDC: null,
    icon: "lock",
    color: "red"
  },
  {
    name: "Petrified",
    nameEs: "Petrificado",
    description: "Un personaje petrificado está transformado en una sustancia inanimada junto con cualquier objeto no mágico que lleve. Su peso aumenta diez veces y deja de envejecer. El personaje está incapacitado y no puede moverse ni hablar, y no sabe lo que ocurre a su alrededor.",
    effects: JSON.stringify([
      "Estás transformado en sustancia inanimada junto con objetos no mágicos",
      "Tu peso aumenta diez veces",
      "Dejas de envejecer",
      "Estás incapacitado y no puedes moverte ni hablar",
      "No sabes lo que ocurre a tu alrededor",
      "Fallas automáticamente las salvaciones de Fuerza y Destreza",
      "Los ataques contra ti tienen ventaja",
      "Tienes resistencia a todo el daño",
      "Eres inmune a veneno y enfermedad"
    ]),
    endsOn: null,
    saveType: null,
    saveDC: null,
    icon: "box",
    color: "stone"
  },
  {
    name: "Poisoned",
    nameEs: "Envenenado",
    description: "Un personaje envenenado tiene desventaja en tiradas de ataque y pruebas de característica.",
    effects: JSON.stringify([
      "Tienes desventaja en tiradas de ataque",
      "Tienes desventaja en pruebas de característica"
    ]),
    endsOn: null,
    saveType: null,
    saveDC: null,
    icon: "droplet",
    color: "green"
  },
  {
    name: "Prone",
    nameEs: "Derribado",
    description: "Un personaje derribado puede arrastrarse pero no puede levantarse ni moverse normalmente. El personaje tiene desventaja en tiradas de ataque y no puede realizar ataques a distancia.",
    effects: JSON.stringify([
      "Puedes arrastrarte pero no puedes levantarte ni moverte normalmente",
      "Tienes desventaja en tiradas de ataque",
      "No puedes realizar ataques a distancia",
      "Los ataques cuerpo a cuerpo contra ti tienen ventaja si el atacante está a menos de 5 pies",
      "Los ataques a distancia contra ti tienen desventaja"
    ]),
    endsOn: "Levantarse (gasta la mitad de tu movimiento)",
    saveType: null,
    saveDC: null,
    icon: "arrow-down",
    color: "yellow"
  },
  {
    name: "Restrained",
    nameEs: "Retenido",
    description: "Un personaje retenido tiene velocidad 0 y no puede beneficiarse de ningún bono a su velocidad. Los ataques contra él tienen ventaja, y el personaje tiene desventaja en tiradas de ataque y salvaciones de Destreza.",
    effects: JSON.stringify([
      "Tu velocidad es 0 y no puedes beneficiarte de bonos a tu velocidad",
      "Los ataques contra ti tienen ventaja",
      "Tienes desventaja en tiradas de ataque",
      "Tienes desventaja en salvaciones de Destreza"
    ]),
    endsOn: null,
    saveType: null,
    saveDC: null,
    icon: "rope",
    color: "brown"
  },
  {
    name: "Stunned",
    nameEs: "Aturdido",
    description: "Un personaje aturdido está incapacitado, no puede moverse y habla con dificultad. El personaje falla automáticamente las salvaciones de Fuerza y Destreza, y los ataques contra él tienen ventaja.",
    effects: JSON.stringify([
      "Estás incapacitado",
      "No puedes moverte",
      "Hablas con dificultad",
      "Fallas automáticamente las salvaciones de Fuerza y Destreza",
      "Los ataques contra ti tienen ventaja"
    ]),
    endsOn: null,
    saveType: null,
    saveDC: null,
    icon: "zap",
    color: "yellow"
  },
  {
    name: "Unconscious",
    nameEs: "Inconsciente",
    description: "Un personaje inconsciente está incapacitado, no puede moverse ni hablar, y no sabe lo que ocurre a su alrededor. El personaje suelta lo que sostiene y cae derribado.",
    effects: JSON.stringify([
      "Estás incapacitado",
      "No puedes moverte ni hablar",
      "No sabes lo que ocurre a tu alrededor",
      "Sueltes lo que sostienes y caes derribado",
      "Fallas automáticamente las salvaciones de Fuerza y Destreza",
      "Los ataques contra ti tienen ventaja",
      "Los ataques cuerpo a cuerpo contra ti son golpes críticos si el atacante está a menos de 5 pies"
    ]),
    endsOn: null,
    saveType: null,
    saveDC: null,
    icon: "moon",
    color: "indigo"
  }
]

// GET - Get all conditions (seeds database if empty)
export async function GET() {
  try {
    let conditions = await db.condition.findMany({
      orderBy: { name: 'asc' }
    })
    
    // Seed conditions if database is empty
    if (conditions.length === 0) {
      console.log('Seeding conditions database...')
      await db.condition.createMany({
        data: DND_2024_CONDITIONS
      })
      conditions = await db.condition.findMany({
        orderBy: { name: 'asc' }
      })
      console.log(`Seeded ${conditions.length} conditions`)
    }
    
    return NextResponse.json(conditions)
  } catch (error) {
    console.error('Error fetching conditions:', error)
    return NextResponse.json([])
  }
}
