import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET all Metamagic options
export async function GET() {
  try {
    const options = await db.metamagicOption.findMany({
      orderBy: { name: 'asc' }
    });
    return NextResponse.json(options);
  } catch (error) {
    console.error('Error fetching Metamagic options:', error);
    return NextResponse.json({ error: 'Failed to fetch Metamagic options' }, { status: 500 });
  }
}
