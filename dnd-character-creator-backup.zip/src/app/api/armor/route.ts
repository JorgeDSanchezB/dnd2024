import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const search = searchParams.get('search');
    
    let where: any = {};
    if (category) {
      where.category = category;
    }
    
    // SQLite doesn't support mode: 'insensitive', so we use contains without it
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { name: { contains: search.charAt(0).toUpperCase() + search.slice(1).toLowerCase() } },
        { name: { contains: search.toUpperCase() } },
        { name: { contains: search.toLowerCase() } }
      ];
    }
    
    const armor = await db.armor.findMany({
      where,
      orderBy: [{ category: 'asc' }, { name: 'asc' }]
    });
    
    return NextResponse.json(armor);
  } catch (error) {
    console.error('Error fetching armor:', error);
    return NextResponse.json({ error: 'Failed to fetch armor' }, { status: 500 });
  }
}
