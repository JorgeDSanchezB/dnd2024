import { NextResponse } from 'next/server'
import { PrismaClient } from '@prisma/client'

// Create a fresh PrismaClient for actions to ensure model is available
const prisma = new PrismaClient()

// GET - Get all actions
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const search = searchParams.get('search')
    const category = searchParams.get('category')
    const type = searchParams.get('type')
    
    const whereClause: any = {}
    
    if (search) {
      whereClause.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { nameEs: { contains: search, mode: 'insensitive' } },
        { description: { contains: search, mode: 'insensitive' } }
      ]
    }
    
    if (category) {
      whereClause.category = category
    }
    
    if (type) {
      whereClause.type = type
    }
    
    const actions = await prisma.action.findMany({
      where: whereClause,
      orderBy: [
        { category: 'asc' },
        { name: 'asc' }
      ]
    })
    
    return NextResponse.json(actions)
  } catch (error) {
    console.error('Error fetching actions:', error)
    return NextResponse.json([])
  }
}
