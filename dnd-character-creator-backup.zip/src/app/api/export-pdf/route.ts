import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { exec } from 'child_process'
import { promisify } from 'util'
import { readFile, unlink } from 'fs/promises'
import path from 'path'

const execAsync = promisify(exec)

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const characterId = searchParams.get('id')
    
    if (!characterId) {
      return NextResponse.json({ error: 'Character ID is required' }, { status: 400 })
    }
    
    // Fetch character with all related data
    const character = await db.character.findUnique({
      where: { id: characterId },
      include: {
        species: true,
        characterClass: true,
        subclass: true,
        background: true,
        inventoryItems: {
          include: {
            weapon: true,
            armor: true,
            item: true,
            magicItem: true
          }
        },
        characterSpells: {
          include: {
            spell: true
          }
        },
        characterFeats: {
          include: {
            feat: true
          }
        }
      }
    })
    
    if (!character) {
      return NextResponse.json({ error: 'Character not found' }, { status: 404 })
    }
    
    // Prepare character data for PDF
    const characterData = {
      name: character.name,
      level: character.level,
      xp: character.xp,
      
      // Ability Scores
      strength: character.strength,
      dexterity: character.dexterity,
      constitution: character.constitution,
      intelligence: character.intelligence,
      wisdom: character.wisdom,
      charisma: character.charisma,
      
      // Combat Stats
      currentHp: character.currentHp,
      maxHp: character.maxHp,
      tempHp: character.tempHp,
      armorClass: character.armorClass,
      speed: character.speed,
      hitDiceCurrent: character.hitDiceCurrent,
      hitDiceMax: character.hitDiceMax,
      hitDiceType: character.hitDiceType,
      
      // Proficiency
      proficiencyBonus: character.proficiencyBonus,
      
      // Death Saves
      deathSaveSuccesses: character.deathSaveSuccesses,
      deathSaveFailures: character.deathSaveFailures,
      
      // Saving Throws
      saveStr: character.saveStr,
      saveDex: character.saveDex,
      saveCon: character.saveCon,
      saveInt: character.saveInt,
      saveWis: character.saveWis,
      saveCha: character.saveCha,
      
      // Skills
      skillAcrobatics: character.skillAcrobatics,
      skillAnimalHandling: character.skillAnimalHandling,
      skillArcana: character.skillArcana,
      skillAthletics: character.skillAthletics,
      skillDeception: character.skillDeception,
      skillHistory: character.skillHistory,
      skillInsight: character.skillInsight,
      skillIntimidation: character.skillIntimidation,
      skillInvestigation: character.skillInvestigation,
      skillMedicine: character.skillMedicine,
      skillNature: character.skillNature,
      skillPerception: character.skillPerception,
      skillPerformance: character.skillPerformance,
      skillPersuasion: character.skillPersuasion,
      skillReligion: character.skillReligion,
      skillSleightOfHand: character.skillSleightOfHand,
      skillStealth: character.skillStealth,
      skillSurvival: character.skillSurvival,
      
      // Expertise
      expertAcrobatics: character.expertAcrobatics,
      expertAnimalHandling: character.expertAnimalHandling,
      expertArcana: character.expertArcana,
      expertAthletics: character.expertAthletics,
      expertDeception: character.expertDeception,
      expertHistory: character.expertHistory,
      expertInsight: character.expertInsight,
      expertIntimidation: character.expertIntimidation,
      expertInvestigation: character.expertInvestigation,
      expertMedicine: character.expertMedicine,
      expertNature: character.expertNature,
      expertPerception: character.expertPerception,
      expertPerformance: character.expertPerformance,
      expertPersuasion: character.expertPersuasion,
      expertReligion: character.expertReligion,
      expertSleightOfHand: character.expertSleightOfHand,
      expertStealth: character.expertStealth,
      expertSurvival: character.expertSurvival,
      
      // Character Details
      alignment: character.alignment,
      appearance: character.appearance,
      backgroundStory: character.backgroundStory,
      languages: character.languages,
      toolProficiencies: character.toolProficiencies,
      armorProficiencies: character.armorProficiencies,
      weaponProficiencies: character.weaponProficiencies,
      
      // Currency
      cp: character.cp,
      sp: character.sp,
      ep: character.ep,
      gp: character.gp,
      pp: character.pp,
      
      // Relationships
      species: character.species,
      characterClass: character.characterClass,
      subclass: character.subclass,
      background: character.background,
      
      // Inventory
      inventoryItems: character.inventoryItems,
      
      // Spells
      characterSpells: character.characterSpells,
      
      // Feats
      characterFeats: character.characterFeats
    }
    
    // Create output directory if it doesn't exist
    const outputDir = '/home/z/my-project/public/exports'
    await execAsync(`mkdir -p ${outputDir}`)
    
    // Generate unique filename
    const safeName = character.name.replace(/[^a-zA-Z0-9]/g, '_')
    const filename = `${safeName}_character_sheet.pdf`
    const outputPath = `${outputDir}/${filename}`
    
    // Escape the JSON for command line
    const jsonStr = JSON.stringify(characterData).replace(/'/g, "'\\''")
    
    // Execute Python script
    const { stdout, stderr } = await execAsync(
      `python3 /home/z/my-project/scripts/fill_character_sheet.py '${jsonStr}' '${outputPath}'`
    )
    
    if (stderr && !stderr.includes('PDF created')) {
      console.error('Python stderr:', stderr)
    }
    
    // Read the generated PDF
    const pdfBuffer = await readFile(outputPath)
    
    // Clean up the file after reading
    await unlink(outputPath).catch(() => {})
    
    // Return the PDF
    return new NextResponse(pdfBuffer, {
      status: 200,
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="${filename}"`,
        'Content-Length': pdfBuffer.length.toString()
      }
    })
    
  } catch (error) {
    console.error('Error generating PDF:', error)
    return NextResponse.json({ 
      error: 'Failed to generate PDF',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 })
  }
}
