import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const level = searchParams.get('level');
    const className = searchParams.get('class');
    const search = searchParams.get('search');
    
    let where: any = {};
    
    if (level) {
      where.level = parseInt(level);
    }
    
    // If searching for a specific spell name, use contains for better matching
    if (search) {
      where.name = {
        contains: search,
        mode: 'insensitive'
      };
    }
    
    const spells = await db.spell.findMany({
      where,
      orderBy: [{ level: 'asc' }, { name: 'asc' }]
    });
    
    // Filter by class if specified
    let filteredSpells = spells;
    if (className) {
      filteredSpells = spells.filter(spell => {
        try {
          const classes = JSON.parse(spell.classes);
          return classes.includes(className);
        } catch {
          return false;
        }
      });
    }
    
    return NextResponse.json(filteredSpells);
  } catch (error) {
    console.error('Error fetching spells:', error);
    return NextResponse.json({ error: 'Failed to fetch spells' }, { status: 500 });
  }
}
