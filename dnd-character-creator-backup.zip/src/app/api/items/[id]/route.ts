import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { Prisma } from '@prisma/client'

// GET - Get single item by ID
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    
    // Try to find in Weapons
    let item = await db.weapon.findUnique({ where: { id } })
    if (item) {
      return NextResponse.json({ ...item, itemType: 'weapon' })
    }
    
    // Try to find in Armor
    item = await db.armor.findUnique({ where: { id } })
    if (item) {
      return NextResponse.json({ ...item, itemType: 'armor' })
    }
    
    // Try to find in Items
    item = await db.item.findUnique({ where: { id } })
    if (item) {
      return NextResponse.json({ ...item, itemType: 'item' })
    }
    
    return NextResponse.json({ error: 'Item not found' }, { status: 404 })
  } catch (error) {
    console.error('Error fetching item:', error)
    return NextResponse.json({ error: 'Failed to fetch item' }, { status: 500 })
  }
}

// PATCH - Update item (mainly for price editing)
export async function PATCH(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { cost, itemType, ...otherFields } = body
    
    let updatedItem
    
    if (itemType === 'weapon') {
      updatedItem = await db.weapon.update({
        where: { id },
        data: { cost, ...otherFields }
      })
    } else if (itemType === 'armor') {
      updatedItem = await db.armor.update({
        where: { id },
        data: { cost, ...otherFields }
      })
    } else if (itemType === 'item') {
      updatedItem = await db.item.update({
        where: { id },
        data: { cost, ...otherFields }
      })
    } else {
      // Try to find and update in any table
      let found = false
      
      try {
        updatedItem = await db.weapon.update({
          where: { id },
          data: { cost }
        })
        found = true
        updatedItem = { ...updatedItem, itemType: 'weapon' }
      } catch {}
      
      if (!found) {
        try {
          updatedItem = await db.armor.update({
            where: { id },
            data: { cost }
          })
          found = true
          updatedItem = { ...updatedItem, itemType: 'armor' }
        } catch {}
      }
      
      if (!found) {
        try {
          updatedItem = await db.item.update({
            where: { id },
            data: { cost }
          })
          found = true
          updatedItem = { ...updatedItem, itemType: 'item' }
        } catch {}
      }
      
      if (!found) {
        return NextResponse.json({ error: 'Item not found' }, { status: 404 })
      }
    }
    
    return NextResponse.json(updatedItem)
  } catch (error) {
    console.error('Error updating item:', error)
    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      if (error.code === 'P2025') {
        return NextResponse.json({ error: 'Item not found' }, { status: 404 })
      }
    }
    return NextResponse.json({ error: 'Failed to update item' }, { status: 500 })
  }
}
