import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const category = searchParams.get('category');
    const search = searchParams.get('search');
    
    let where: any = {};
    if (category) {
      where.category = category;
    }
    
    // SQLite doesn't support mode: 'insensitive', so we use contains without it
    if (search) {
      where.OR = [
        { name: { contains: search } },
        { name: { contains: search.charAt(0).toUpperCase() + search.slice(1).toLowerCase() } },
        { name: { contains: search.toUpperCase() } },
        { name: { contains: search.toLowerCase() } }
      ];
    }
    
    const items = await db.item.findMany({
      where,
      orderBy: [{ category: 'asc' }, { name: 'asc' }]
    });
    
    return NextResponse.json(items);
  } catch (error) {
    console.error('Error fetching items:', error);
    return NextResponse.json({ error: 'Failed to fetch items' }, { status: 500 });
  }
}
