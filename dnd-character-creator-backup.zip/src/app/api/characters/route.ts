import { NextResponse } from 'next/server';
import { database } from '@/lib/database';

// Use the database instance with updated Prisma schema

// Species Subtype Configuration for spell grants
interface SpeciesSubtypeOption {
  id: string
  name: string
  cantrip?: string
  spells?: { level: number; spellName: string }[]
}

interface SpeciesSubtypeConfig {
  requiresSelection: boolean
  selectionName: string
  options: SpeciesSubtypeOption[]
}

const SPECIES_SUBTYPES: Record<string, SpeciesSubtypeConfig> = {
  'Dragonborn': {
    requiresSelection: true,
    selectionName: 'Ancestro Dracónico',
    options: [
      { id: 'black', name: 'Dragón Negro' },
      { id: 'blue', name: 'Dragón Azul' },
      { id: 'brass', name: 'Dragón Latón' },
      { id: 'bronze', name: 'Dragón Bronce' },
      { id: 'copper', name: 'Dragón Cobre' },
      { id: 'gold', name: 'Dragón Oro' },
      { id: 'green', name: 'Dragón Verde' },
      { id: 'red', name: 'Dragón Rojo' },
      { id: 'silver', name: 'Dragón Plata' },
      { id: 'white', name: 'Dragón Blanco' }
    ]
  },
  'Elf': {
    requiresSelection: true,
    selectionName: 'Linaje Élfico',
    options: [
      { id: 'drow', name: 'Drow', cantrip: 'Dancing Lights', spells: [{ level: 3, spellName: 'Faerie Fire' }, { level: 5, spellName: 'Darkness' }] },
      { id: 'high', name: 'Alto Elfo', cantrip: 'Prestidigitation', spells: [{ level: 3, spellName: 'Detect Magic' }, { level: 5, spellName: 'Misty Step' }] },
      { id: 'wood', name: 'Elfo del Bosque', cantrip: 'Druidcraft', spells: [{ level: 3, spellName: 'Longstrider' }, { level: 5, spellName: 'Pass without Trace' }] }
    ]
  },
  'Tiefling': {
    requiresSelection: true,
    selectionName: 'Legado Infernal',
    options: [
      { id: 'abyssal', name: 'Abismal', cantrip: 'Poison Spray', spells: [{ level: 3, spellName: 'Ray of Sickness' }, { level: 5, spellName: 'Hold Person' }] },
      { id: 'chthonic', name: 'Ctónico', cantrip: 'Chill Touch', spells: [{ level: 3, spellName: 'False Life' }, { level: 5, spellName: 'Ray of Enfeeblement' }] },
      { id: 'infernal', name: 'Infernal', cantrip: 'Fire Bolt', spells: [{ level: 3, spellName: 'Hellish Rebuke' }, { level: 5, spellName: 'Darkness' }] }
    ]
  },
  'Gnome': {
    requiresSelection: true,
    selectionName: 'Linaje Gnómico',
    options: [
      { id: 'forest', name: 'Gnomo del Bosque', cantrip: 'Minor Illusion' },
      { id: 'rock', name: 'Gnomo de Roca', cantrip: 'Mending', spells: [{ level: 1, spellName: 'Prestidigitation' }] }
    ]
  },
  'Goliath': {
    requiresSelection: true,
    selectionName: 'Ancestro Gigante',
    options: [
      { id: 'cloud', name: 'Gigante de las Nubes' },
      { id: 'fire', name: 'Gigante de Fuego' },
      { id: 'frost', name: 'Gigante de Escarcha' },
      { id: 'hill', name: 'Gigante de las Colinas' },
      { id: 'stone', name: 'Gigante de Piedra' },
      { id: 'storm', name: 'Gigante de Tormentas' }
    ]
  },
  'Aasimar': {
    requiresSelection: true,
    selectionName: 'Revelación Celestial',
    options: [
      { id: 'heavenly_wings', name: 'Alas Celestiales' },
      { id: 'inner_radiance', name: 'Radiancia Interior', spells: [{ level: 1, spellName: 'Light' }] },
      { id: 'necrotic_shroud', name: 'Manto Necrótico' }
    ]
  }
}

// GET all characters
// Updated: CharacterSpell now has source field (class, domain, species, feat)
export async function GET() {
  try {
    const characters = await database.character.findMany({
      include: {
        species: true,
        characterClass: true,
        subclass: true,
        background: true,
        inventoryItems: {
          include: {
            weapon: true,
            armor: true,
            item: true,
            magicItem: true
          }
        },
        characterSpells: {
          include: {
            spell: true
          }
        },
        characterFeats: {
          include: {
            feat: true
          }
        },
        classLevels: {
          include: {
            class: true,
            subclass: true
          }
        }
      },
      orderBy: { updatedAt: 'desc' }
    });
    return NextResponse.json(characters);
  } catch (error) {
    console.error('Error fetching characters:', error);
    return NextResponse.json({ error: 'Failed to fetch characters' }, { status: 500 });
  }
}

// POST create new character
export async function POST(request: Request) {
  try {
    const body = await request.json();
    
    // Debug logging
    console.log('Creating character with:', {
      classId: body.classId,
      backgroundId: body.backgroundId,
      speciesId: body.speciesId,
      name: body.name
    });
    
    // Calculate initial stats based on class and background
    const characterClass = await database.characterClass.findUnique({
      where: { id: body.classId }
    });
    
    const background = await database.background.findUnique({
      where: { id: body.backgroundId }
    });
    
    const species = await database.species.findUnique({
      where: { id: body.speciesId }
    });
    
    // Debug logging
    console.log('Lookup results:', {
      characterClass: characterClass ? characterClass.name : 'NOT FOUND',
      background: background ? background.name : 'NOT FOUND',
      species: species ? species.name : 'NOT FOUND'
    });
    
    if (!characterClass || !background || !species) {
      return NextResponse.json({ 
        error: 'Invalid class, background, or species',
        details: {
          classId: body.classId,
          backgroundId: body.backgroundId,
          speciesId: body.speciesId,
          classFound: !!characterClass,
          backgroundFound: !!background,
          speciesFound: !!species
        }
      }, { status: 400 });
    }
    
    // Get level from request or default to 1
    const level = body.level || 1;
    
    // Calculate proficiency bonus based on level
    const proficiencyBonus = level < 5 ? 2 : level < 9 ? 3 : level < 13 ? 4 : level < 17 ? 5 : 6;
    
    // Calculate HP based on user choice (max or average)
    const constitutionModifier = Math.floor((body.constitution - 10) / 2);
    const hitDieMax = characterClass.hitDie;
    const hitDieAverage = Math.floor(hitDieMax / 2) + 1;
    
    // For level 1, use the user's choice; for higher levels, the frontend handles HP calculation
    const maxHp = body.hpChoice === 'average' ? hitDieAverage + constitutionModifier : hitDieMax + constitutionModifier;
    
    // Calculate saving throw proficiencies
    const savingThrows = JSON.parse(characterClass.savingThrows);
    
    // Calculate skill proficiencies from background
    const backgroundSkills = JSON.parse(background.skillProficiencies);
    
    // Get class skill selections from user
    const classSkills = body.selectedClassSkills || [];
    
    // Combine skills (user must have proficiency from either source)
    const allProficientSkills = [...new Set([...backgroundSkills, ...classSkills])];
    
    // Calculate AC (base 10 + DEX modifier, modified by armor later)
    const dexterityModifier = Math.floor((body.dexterity - 10) / 2);
    const baseAC = 10 + dexterityModifier;
    
    // Create character
    const character = await database.character.create({
      data: {
        name: body.name,
        level: level,
        xp: 0,
        proficiencyBonus: proficiencyBonus,
        
        // Ability Scores
        strength: body.strength,
        dexterity: body.dexterity,
        constitution: body.constitution,
        intelligence: body.intelligence,
        wisdom: body.wisdom,
        charisma: body.charisma,
        
        // Combat Stats
        currentHp: maxHp,
        maxHp: maxHp,
        tempHp: 0,
        hitDiceCurrent: level,
        hitDiceMax: level,
        hitDiceType: characterClass.hitDie,
        armorClass: baseAC,
        initiative: dexterityModifier,
        speed: species.speed,
        
        // Saving Throws
        saveStr: savingThrows.includes('Strength'),
        saveDex: savingThrows.includes('Dexterity'),
        saveCon: savingThrows.includes('Constitution'),
        saveInt: savingThrows.includes('Intelligence'),
        saveWis: savingThrows.includes('Wisdom'),
        saveCha: savingThrows.includes('Charisma'),
        
        // Skills from background + class selection
        skillAcrobatics: allProficientSkills.includes('Acrobatics'),
        skillAnimalHandling: allProficientSkills.includes('Animal Handling'),
        skillArcana: allProficientSkills.includes('Arcana'),
        skillAthletics: allProficientSkills.includes('Athletics'),
        skillDeception: allProficientSkills.includes('Deception'),
        skillHistory: allProficientSkills.includes('History'),
        skillInsight: allProficientSkills.includes('Insight'),
        skillIntimidation: allProficientSkills.includes('Intimidation'),
        skillInvestigation: allProficientSkills.includes('Investigation'),
        skillMedicine: allProficientSkills.includes('Medicine'),
        skillNature: allProficientSkills.includes('Nature'),
        skillPerception: allProficientSkills.includes('Perception'),
        skillPerformance: allProficientSkills.includes('Performance'),
        skillPersuasion: allProficientSkills.includes('Persuasion'),
        skillReligion: allProficientSkills.includes('Religion'),
        skillSleightOfHand: allProficientSkills.includes('Sleight of Hand'),
        skillStealth: allProficientSkills.includes('Stealth'),
        skillSurvival: allProficientSkills.includes('Survival'),
        
        // Character Details
        alignment: body.alignment || null,
        backgroundStory: body.backgroundStory || null,
        appearance: body.appearance || null,
        
        // Proficiencies
        languages: JSON.stringify(['Common']),
        toolProficiencies: background.toolProficiency, // Already JSON string from database
        armorProficiencies: characterClass.armorTraining,
        weaponProficiencies: characterClass.weaponProficiencies,
        
        // Currency
        gp: 15, // Standard starting gold
        
        // Features
        classFeatures: characterClass.features,
        speciesTraits: species.traits,
        
        // Spellcasting
        spellcastingAbility: characterClass.spellcasting ? getSpellcastingAbility(characterClass.name) : null,
        
        // Relationships
        speciesId: body.speciesId,
        classId: body.classId,
        subclassId: body.subclassId || null,
        backgroundId: body.backgroundId
      }
    });
    
    // Create initial class level record for multiclass support
    await database.characterClassLevel.create({
      data: {
        characterId: character.id,
        classId: body.classId,
        level: level,
        hitDieType: characterClass.hitDie,
        hitDiceCurrent: level,
        hitDiceMax: level,
        isPrimary: true,
        subclassId: body.subclassId || null
      }
    });
    
    // Add background feat
    const feat = await database.feat.findFirst({
      where: { name: background.feat }
    });
    
    if (feat) {
      await database.characterFeat.create({
        data: {
          characterId: character.id,
          featId: feat.id,
          source: 'Background'
        }
      });
    }
    
    // Add species subtype cantrip if applicable
    if (body.speciesSubtype && species.name) {
      const subtypeConfig = SPECIES_SUBTYPES[species.name];
      if (subtypeConfig) {
        const subtypeOption = subtypeConfig.options.find(opt => opt.id === body.speciesSubtype);
        if (subtypeOption?.cantrip) {
          // Find the cantrip spell
          const cantripSpell = await database.spell.findFirst({
            where: { name: subtypeOption.cantrip }
          });
          
          if (cantripSpell) {
            await database.characterSpell.create({
              data: {
                characterId: character.id,
                spellId: cantripSpell.id,
                prepared: true,
                known: true
              }
            });
          }
        }
        
        // Update species traits to include subtype info
        if (subtypeOption) {
          const existingTraits = JSON.parse(species.traits);
          const updatedTraits = {
            ...existingTraits,
            subtype: {
              id: body.speciesSubtype,
              name: subtypeOption.name,
              selectionName: subtypeConfig.selectionName
            }
          };
          
          await database.character.update({
            where: { id: character.id },
            data: { speciesTraits: JSON.stringify(updatedTraits) }
          });
        }
      }
    }
    
    // Sync subclass spells for higher level characters with subclasses
    if (body.subclassId && level >= 3 && characterClass.name) {
      try {
        const subclass = await database.subclass.findUnique({
          where: { id: body.subclassId }
        });
        
        if (subclass?.subclassSpells && subclass.subclassSpells !== 'null') {
          const spellSource = getSpellSourceForClass(characterClass.name);
          let subclassSpellsByLevel: Record<number, string[]> = {};
          
          try {
            subclassSpellsByLevel = JSON.parse(subclass.subclassSpells);
          } catch {
            // Invalid JSON, skip
          }
          
          const unlockLevels = Object.keys(subclassSpellsByLevel)
            .map(Number)
            .filter(n => !isNaN(n));
          
          for (const unlockLevel of unlockLevels) {
            if (level >= unlockLevel && Array.isArray(subclassSpellsByLevel[unlockLevel])) {
              for (const spellName of subclassSpellsByLevel[unlockLevel]) {
                if (!spellName) continue;
                
                try {
                  const spell = await database.spell.findFirst({
                    where: { name: { equals: spellName } }
                  });
                  
                  if (spell) {
                    await database.characterSpell.create({
                      data: {
                        characterId: character.id,
                        spellId: spell.id,
                        prepared: true,
                        known: true,
                        source: spellSource
                      }
                    });
                  }
                } catch {
                  // Continue on error
                }
              }
            }
          }
        }
      } catch (syncError) {
        console.error('Error syncing subclass spells during creation:', syncError);
        // Don't fail character creation if spell sync fails
      }
    }
    
    // Create expertise reminder notes for higher level characters
    // Expertise is gained by: Rogue (levels 1, 6), Bard (levels 3, 10)
    const expertiseByClassAndLevel: Record<string, number[]> = {
      'Rogue': [1, 6],
      'Bard': [3, 10]
    };
    
    const expertiseLevels = expertiseByClassAndLevel[characterClass.name];
    if (expertiseLevels) {
      for (const expertiseLevel of expertiseLevels) {
        if (level >= expertiseLevel) {
          const expertiseCount = characterClass.name === 'Rogue'
            ? (expertiseLevel >= 6 ? 'dos habilidades más' : 'dos habilidades')
            : (expertiseLevel >= 10 ? 'dos habilidades más' : 'dos habilidades');
          
          await database.note.create({
            data: {
              characterId: character.id,
              title: `⭐ ACCIÓN REQUERIDA: Experticia (${characterClass.name})`,
              content: `Tu ${characterClass.name} ha alcanzado el nivel ${expertiseLevel} y ha ganado **Experticia**.

Eliges ${expertiseCount} en las que ya tienes competencia. Tu bonificador de competencia se duplica para cualquier prueba que use esas habilidades.

⚠️ **Debes marcar la experticia manualmente:**
1. Ve a la sección de habilidades del personaje
2. Haz clic en el botón de experticia (⭐) junto a las habilidades elegidas
3. La experticia duplica tu bonificador de competencia para esa habilidad

**Recordatorio:** La experticia no se aplica automáticamente. Debes activarla manualmente en la hoja de personaje.`,
              color: 'amber'
            }
          });
        }
      }
    }
    
    // Fetch the character with all relations populated
    const fullCharacter = await database.character.findUnique({
      where: { id: character.id },
      include: {
        species: true,
        characterClass: true,
        subclass: true,
        background: true,
        classLevels: {
          include: {
            class: true,
            subclass: true
          }
        },
        inventoryItems: {
          include: {
            weapon: true,
            armor: true,
            item: true,
            magicItem: true
          }
        },
        characterSpells: {
          include: {
            spell: true
          }
        },
        characterFeats: {
          include: {
            feat: true
          }
        }
      }
    });
    
    return NextResponse.json(fullCharacter);
  } catch (error) {
    console.error('Error creating character:', error);
    return NextResponse.json({ error: 'Failed to create character' }, { status: 500 });
  }
}

function getSpellcastingAbility(className: string): string {
  const spellcastingAbilities: Record<string, string> = {
    'Bard': 'Charisma',
    'Cleric': 'Wisdom',
    'Druid': 'Wisdom',
    'Paladin': 'Charisma',
    'Ranger': 'Wisdom',
    'Sorcerer': 'Charisma',
    'Warlock': 'Charisma',
    'Wizard': 'Intelligence'
  };
  return spellcastingAbilities[className] || 'Intelligence';
}

function getSpellSourceForClass(className: string): string {
  const spellSources: Record<string, string> = {
    'Artificer': 'artificer',
    'Bard': 'subclass',
    'Cleric': 'domain',
    'Druid': 'circle',
    'Paladin': 'oath',
    'Ranger': 'ranger',
    'Sorcerer': 'sorcerer',
    'Warlock': 'warlock',
    'Wizard': 'subclass',
  };
  return spellSources[className] || 'subclass';
}
