import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - Get all notes for a character
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    
    const notes = await db.note.findMany({
      where: { characterId: id },
      orderBy: [
        { pinned: 'desc' },
        { updatedAt: 'desc' }
      ]
    })
    
    return NextResponse.json(notes)
  } catch (error) {
    console.error('Error fetching notes:', error)
    return NextResponse.json({ error: 'Error fetching notes' }, { status: 500 })
  }
}

// POST - Create a new note
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    
    const { title, content, color } = body
    
    const note = await db.note.create({
      data: {
        characterId: id,
        title: title || 'Nueva Nota',
        content: content || '',
        color: color || 'default'
      }
    })
    
    return NextResponse.json(note)
  } catch (error) {
    console.error('Error creating note:', error)
    return NextResponse.json({ error: 'Error creating note' }, { status: 500 })
  }
}

// PUT - Update a note (using PUT instead of PATCH due to gateway restrictions)
export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    
    console.log('PUT note request:', { characterId: id, body })
    
    const { noteId, title, content, color, pinned } = body
    
    if (!noteId) {
      console.error('Missing noteId in PUT request')
      return NextResponse.json({ error: 'Note ID is required' }, { status: 400 })
    }
    
    const note = await db.note.update({
      where: { 
        id: noteId,
        characterId: id 
      },
      data: {
        ...(title !== undefined && { title }),
        ...(content !== undefined && { content }),
        ...(color !== undefined && { color }),
        ...(pinned !== undefined && { pinned })
      }
    })
    
    console.log('Note updated successfully:', note)
    
    return NextResponse.json(note)
  } catch (error) {
    console.error('Error updating note:', error)
    return NextResponse.json({ error: 'Error updating note' }, { status: 500 })
  }
}

// DELETE - Delete a note
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const noteId = request.nextUrl.searchParams.get('noteId')
    
    if (!noteId) {
      return NextResponse.json({ error: 'Note ID is required' }, { status: 400 })
    }
    
    await db.note.delete({
      where: { 
        id: noteId,
        characterId: id 
      }
    })
    
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting note:', error)
    return NextResponse.json({ error: 'Error deleting note' }, { status: 500 })
  }
}
