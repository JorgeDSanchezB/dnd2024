import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET character inventory
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    const inventory = await db.inventoryItem.findMany({
      where: { characterId: id },
      include: {
        weapon: true,
        armor: true,
        item: true,
        magicItem: true
      }
    });
    
    return NextResponse.json(inventory);
  } catch (error) {
    console.error('Error fetching inventory:', error);
    return NextResponse.json({ error: 'Failed to fetch inventory' }, { status: 500 });
  }
}

// POST add item to inventory
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    
    const inventoryItem = await db.inventoryItem.create({
      data: {
        characterId: id,
        quantity: body.quantity || 1,
        equipped: body.equipped || false,
        attuned: body.attuned || false,
        weaponId: body.weaponId || null,
        armorId: body.armorId || null,
        itemId: body.itemId || null,
        magicItemId: body.magicItemId || null
      },
      include: {
        weapon: true,
        armor: true,
        item: true,
        magicItem: true
      }
    });
    
    // Update AC if armor is equipped
    if (body.armorId && body.equipped) {
      const armor = await db.armor.findUnique({
        where: { id: body.armorId }
      });
      
      if (armor) {
        const character = await db.character.findUnique({
          where: { id }
        });
        
        if (character) {
          const dexMod = Math.floor((character.dexterity - 10) / 2);
          let newAC = armor.baseAC;
          
          if (armor.dexBonus) {
            const dexBonus = armor.maxDexBonus 
              ? Math.min(dexMod, armor.maxDexBonus) 
              : dexMod;
            newAC += dexBonus;
          }
          
          // Check for shield
          const hasShield = await db.inventoryItem.findFirst({
            where: {
              characterId: id,
              equipped: true,
              armor: { category: 'Shield' }
            }
          });
          
          if (hasShield || armor.category === 'Shield') {
            // Shield adds +2 AC
            if (armor.category !== 'Shield') {
              newAC += 2;
            }
          }
          
          await db.character.update({
            where: { id },
            data: { armorClass: newAC }
          });
        }
      }
    }
    
    return NextResponse.json(inventoryItem);
  } catch (error) {
    console.error('Error adding to inventory:', error);
    return NextResponse.json({ error: 'Failed to add to inventory' }, { status: 500 });
  }
}

// DELETE remove item from inventory
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);
    const itemId = searchParams.get('itemId');
    
    if (!itemId) {
      return NextResponse.json({ error: 'Item ID required' }, { status: 400 });
    }
    
    // Get the item before deleting to check if it's armor
    const item = await db.inventoryItem.findUnique({
      where: { id: itemId },
      include: { armor: true }
    });
    
    await db.inventoryItem.delete({
      where: { id: itemId }
    });
    
    // Recalculate AC if the deleted item was equipped armor
    if (item?.equipped && item?.armor) {
      await recalculateAC(id);
    }
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error removing from inventory:', error);
    return NextResponse.json({ error: 'Failed to remove from inventory' }, { status: 500 });
  }
}

// PUT update inventory item (equip/unequip, attune, etc.) - changed from PATCH due to gateway restrictions
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    
    const inventoryItem = await db.inventoryItem.update({
      where: { id: body.itemId },
      data: {
        quantity: body.quantity,
        equipped: body.equipped,
        attuned: body.attuned
      },
      include: {
        weapon: true,
        armor: true,
        item: true,
        magicItem: true
      }
    });
    
    // Recalculate AC if armor equip status changed
    if (body.armorId || body.equipped !== undefined) {
      await recalculateAC(id);
    }
    
    return NextResponse.json(inventoryItem);
  } catch (error) {
    console.error('Error updating inventory:', error);
    return NextResponse.json({ error: 'Failed to update inventory' }, { status: 500 });
  }
}

async function recalculateAC(characterId: string) {
  const character = await db.character.findUnique({
    where: { id: characterId }
  });
  
  if (!character) return;
  
  const equippedArmor = await db.inventoryItem.findFirst({
    where: {
      characterId,
      equipped: true,
      armor: { category: { not: 'Shield' } }
    },
    include: { armor: true }
  });
  
  const equippedShield = await db.inventoryItem.findFirst({
    where: {
      characterId,
      equipped: true,
      armor: { category: 'Shield' }
    },
    include: { armor: true }
  });
  
  let ac = 10;
  const dexMod = Math.floor((character.dexterity - 10) / 2);
  
  if (equippedArmor?.armor) {
    const armor = equippedArmor.armor;
    ac = armor.baseAC;
    
    if (armor.dexBonus) {
      const dexBonus = armor.maxDexBonus 
        ? Math.min(dexMod, armor.maxDexBonus) 
        : dexMod;
      ac += dexBonus;
    }
  } else {
    ac += dexMod;
  }
  
  if (equippedShield?.armor) {
    ac += equippedShield.armor.baseAC;
  }
  
  await db.character.update({
    where: { id: characterId },
    data: { armorClass: ac }
  });
}
