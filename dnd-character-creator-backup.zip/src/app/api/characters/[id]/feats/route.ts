import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - Get all feats for a character
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    
    const characterFeats = await db.characterFeat.findMany({
      where: { characterId: id },
      include: {
        feat: true
      },
      orderBy: { createdAt: 'desc' }
    })
    
    return NextResponse.json(characterFeats)
  } catch (error) {
    console.error('Error fetching character feats:', error)
    return NextResponse.json({ error: 'Error fetching character feats' }, { status: 500 })
  }
}

// POST - Add a feat to a character (manual implementation - no automatic benefits)
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    
    const { featId, source } = body
    
    // Check if character already has this feat (and it's not repeatable)
    const feat = await db.feat.findUnique({ where: { id: featId } })
    if (!feat) {
      return NextResponse.json({ error: 'Feat not found' }, { status: 404 })
    }
    
    const existingFeat = await db.characterFeat.findFirst({
      where: { characterId: id, featId }
    })
    
    if (existingFeat && !feat.repeatable) {
      return NextResponse.json({ error: 'Character already has this feat and it is not repeatable' }, { status: 400 })
    }
    
    // Get character to verify it exists
    const character = await db.character.findUnique({ where: { id } })
    if (!character) {
      return NextResponse.json({ error: 'Character not found' }, { status: 404 })
    }
    
    // Only add the feat to the character - NO automatic benefits
    // All benefits (ability scores, skills, spells, expertise, etc.) must be applied manually
    const characterFeat = await db.characterFeat.create({
      data: {
        characterId: id,
        featId,
        source: source || 'Level'
      },
      include: { feat: true }
    })
    
    return NextResponse.json(characterFeat)
  } catch (error) {
    console.error('Error adding feat:', error)
    return NextResponse.json({ error: 'Error adding feat' }, { status: 500 })
  }
}

// DELETE - Remove a feat from a character (manual implementation - no automatic reversion)
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const characterFeatId = request.nextUrl.searchParams.get('characterFeatId')
    
    if (!characterFeatId) {
      return NextResponse.json({ error: 'Character feat ID is required' }, { status: 400 })
    }
    
    // Get the character feat details
    const characterFeat = await db.characterFeat.findUnique({
      where: { id: characterFeatId },
      include: { feat: true }
    })
    
    if (!characterFeat) {
      return NextResponse.json({ error: 'Character feat not found' }, { status: 404 })
    }
    
    // Only delete the character feat - NO automatic reversion of benefits
    // All benefits that were applied manually must be reverted manually
    await db.characterFeat.delete({
      where: { id: characterFeatId }
    })
    
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error removing feat:', error)
    return NextResponse.json({ error: 'Error removing feat' }, { status: 500 })
  }
}
