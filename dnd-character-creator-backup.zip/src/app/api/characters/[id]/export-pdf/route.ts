import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Helper functions
const getModifier = (score: number): number => Math.floor((score - 10) / 2);
const getModifierString = (score: number): string => {
  const mod = getModifier(score);
  return mod >= 0 ? `+${mod}` : `${mod}`;
};

const skillNames: Record<string, string> = {
  skillAcrobatics: 'Acróbatas',
  skillAnimalHandling: 'Trato con Animales',
  skillArcana: 'Arcano',
  skillAthletics: 'Atletismo',
  skillDeception: 'Engaño',
  skillHistory: 'Historia',
  skillInsight: 'Perspicacia',
  skillIntimidation: 'Intimidación',
  skillInvestigation: 'Investigación',
  skillMedicine: 'Medicina',
  skillNature: 'Naturaleza',
  skillPerception: 'Percepción',
  skillPerformance: 'Interpretación',
  skillPersuasion: 'Persuasión',
  skillReligion: 'Religión',
  skillSleightOfHand: 'Juego de Manos',
  skillStealth: 'Sigilo',
  skillSurvival: 'Supervivencia',
};

const skillAbilities: Record<string, string> = {
  skillAcrobatics: 'DES',
  skillAnimalHandling: 'SAB',
  skillArcana: 'INT',
  skillAthletics: 'FUE',
  skillDeception: 'CAR',
  skillHistory: 'INT',
  skillInsight: 'SAB',
  skillIntimidation: 'CAR',
  skillInvestigation: 'INT',
  skillMedicine: 'SAB',
  skillNature: 'INT',
  skillPerception: 'SAB',
  skillPerformance: 'CAR',
  skillPersuasion: 'CAR',
  skillReligion: 'INT',
  skillSleightOfHand: 'DES',
  skillStealth: 'DES',
  skillSurvival: 'SAB',
};

// Generate PDF using Python script
async function generatePDF(character: any): Promise<Buffer> {
  const { exec } = await import('child_process');
  const { promisify } = await import('util');
  const execAsync = promisify(exec);
  const fs = await import('fs');
  const path = await import('path');
  const os = await import('os');

  // Parse class features
  let classFeatures: any[] = [];
  try {
    const rawFeatures = JSON.parse(character.classFeatures || '[]');
    if (Array.isArray(rawFeatures)) {
      classFeatures = rawFeatures;
    }
  } catch {
    classFeatures = character.classFeatures ? [character.classFeatures] : [];
  }

  // Parse species traits with full details
  let speciesTraits: any[] = [];
  try {
    const speciesTraitsRaw = character.species?.traits;
    if (speciesTraitsRaw) {
      const parsed = JSON.parse(speciesTraitsRaw);
      if (typeof parsed === 'object' && !Array.isArray(parsed)) {
        // Convert object to array of {name, description}
        speciesTraits = Object.entries(parsed).map(([key, value]) => {
          if (typeof value === 'object' && value !== null) {
            return { name: key, ...value };
          }
          return { name: key, description: String(value) };
        });
      } else if (Array.isArray(parsed)) {
        speciesTraits = parsed;
      }
    }
  } catch {
    speciesTraits = [];
  }

  // Parse subclass features
  let subclassFeatures: any[] = [];
  try {
    if (character.subclass?.features) {
      const parsed = JSON.parse(character.subclass.features);
      if (Array.isArray(parsed)) {
        subclassFeatures = parsed;
      } else if (typeof parsed === 'object') {
        subclassFeatures = Object.entries(parsed).map(([key, value]) => ({
          name: key,
          description: String(value)
        }));
      }
    }
  } catch {
    subclassFeatures = [];
  }

  // Build inventory with all details
  const inventory = character.inventoryItems?.map((item: any) => {
    const base: any = {
      quantity: item.quantity,
      equipped: item.equipped,
      attuned: item.attuned,
    };
    
    if (item.weapon) {
      return {
        ...base,
        type: 'weapon',
        name: item.weapon.name,
        damage: item.weapon.damage,
        damageType: item.weapon.damageType,
        properties: item.weapon.properties,
        mastery: item.weapon.mastery,
        range: item.weapon.range,
        weight: item.weapon.weight,
        cost: item.weapon.cost,
      };
    }
    
    if (item.armor) {
      return {
        ...base,
        type: 'armor',
        name: item.armor.name,
        category: item.armor.category,
        baseAC: item.armor.baseAC,
        dexBonus: item.armor.dexBonus,
        maxDexBonus: item.armor.maxDexBonus,
        stealthDisadv: item.armor.stealthDisadv,
        weight: item.armor.weight,
        cost: item.armor.cost,
      };
    }
    
    if (item.magicItem) {
      return {
        ...base,
        type: 'magic',
        name: item.magicItem.name,
        rarity: item.magicItem.rarity,
        itemType: item.magicItem.type,
        attunement: item.magicItem.attunement,
        attunementReq: item.magicItem.attunementReq,
        description: item.magicItem.description,
        effects: item.magicItem.effects,
      };
    }
    
    if (item.item) {
      return {
        ...base,
        type: 'item',
        name: item.item.name,
        category: item.item.category,
        subcategory: item.item.subcategory,
        description: item.item.description,
        weight: item.item.weight,
        cost: item.item.cost,
      };
    }
    
    return { ...base, type: 'unknown', name: 'Unknown' };
  }) || [];

  // Build spells with full details
  const spells = character.characterSpells?.map((cs: any) => {
    const spell = cs.spell;
    if (!spell) return null;
    
    return {
      name: spell.name,
      level: spell.level,
      school: spell.school,
      castingTime: spell.castingTime,
      range: spell.range,
      components: spell.components,
      duration: spell.duration,
      description: spell.description,
      concentration: spell.concentration,
      ritual: spell.ritual,
      damageType: spell.damageType,
      damageDice: spell.damageDice,
      prepared: cs.prepared,
      known: cs.known,
      source: cs.source,
      spellClass: cs.spellClass?.name || null,
    };
  }).filter(Boolean) || [];

  // Build feats with full details
  const feats = character.characterFeats?.map((cf: any) => {
    const feat = cf.feat;
    if (!feat) return null;
    
    return {
      name: feat.name,
      category: feat.category,
      prerequisite: feat.prerequisite,
      description: feat.description,
      benefit: feat.benefit,
      source: cf.source,
      chosenAbilityScore: cf.chosenAbilityScore,
      chosenSpellId: cf.chosenSpellId,
      chosenSkills: cf.chosenSkills,
    };
  }).filter(Boolean) || [];

  // Prepare complete character data for Python
  const pdfData = {
    // Basic info
    name: character.name,
    level: character.level,
    xp: character.xp,
    class: character.characterClass?.name || 'Sin clase',
    subclass: character.subclass?.name || null,
    species: character.species?.name || 'Sin especie',
    background: character.background?.name || 'Sin trasfondo',
    alignment: character.alignment || null,
    
    // Ability Scores
    abilities: {
      strength: { score: character.strength, mod: getModifierString(character.strength) },
      dexterity: { score: character.dexterity, mod: getModifierString(character.dexterity) },
      constitution: { score: character.constitution, mod: getModifierString(character.constitution) },
      intelligence: { score: character.intelligence, mod: getModifierString(character.intelligence) },
      wisdom: { score: character.wisdom, mod: getModifierString(character.wisdom) },
      charisma: { score: character.charisma, mod: getModifierString(character.charisma) },
    },
    
    // Combat Stats
    hp: { current: character.currentHp, max: character.maxHp, temp: character.tempHp },
    ac: character.armorClass,
    initiative: character.initiative,
    speed: character.speed,
    proficiencyBonus: character.proficiencyBonus,
    
    // Hit Dice
    hitDice: {
      current: character.hitDiceCurrent,
      max: character.hitDiceMax,
      type: character.hitDiceType,
    },
    
    // Saving Throws
    saves: {
      strength: { proficient: character.saveStr, mod: getModifier(character.strength) + (character.saveStr ? character.proficiencyBonus : 0) },
      dexterity: { proficient: character.saveDex, mod: getModifier(character.dexterity) + (character.saveDex ? character.proficiencyBonus : 0) },
      constitution: { proficient: character.saveCon, mod: getModifier(character.constitution) + (character.saveCon ? character.proficiencyBonus : 0) },
      intelligence: { proficient: character.saveInt, mod: getModifier(character.intelligence) + (character.saveInt ? character.proficiencyBonus : 0) },
      wisdom: { proficient: character.saveWis, mod: getModifier(character.wisdom) + (character.saveWis ? character.proficiencyBonus : 0) },
      charisma: { proficient: character.saveCha, mod: getModifier(character.charisma) + (character.saveCha ? character.proficiencyBonus : 0) },
    },
    
    // Skills with all info
    skills: Object.keys(skillNames).map(key => ({
      name: skillNames[key],
      ability: skillAbilities[key],
      proficient: (character as any)[key] || false,
      expertise: (character as any)[`expert${key.replace('skill', '')}`] || false,
    })),
    
    // Money
    money: {
      cp: character.cp,
      sp: character.sp,
      ep: character.ep,
      gp: character.gp,
      pp: character.pp,
    },
    
    // Languages
    languages: JSON.parse(character.languages || '[]'),
    
    // Proficiencies
    toolProfs: JSON.parse(character.toolProficiencies || '[]'),
    armorProfs: JSON.parse(character.armorProficiencies || '[]'),
    weaponProfs: JSON.parse(character.weaponProficiencies || '[]'),
    
    // Character details
    appearance: character.appearance || null,
    backgroundStory: character.backgroundStory || null,
    personalityTraits: character.personalityTraits || null,
    ideals: character.ideals || null,
    bonds: character.bonds || null,
    flaws: character.flaws || null,
    backgroundEquipment: character.background?.equipment || null,
    
    // Full inventory with all details
    inventory,
    
    // Full spells with all details
    spells,
    
    // Full feats with all details
    feats,
    
    // Class features with full descriptions
    classFeatures,
    
    // Species traits with full details
    speciesTraits,
    
    // Subclass features
    subclassFeatures,
    
    // Spellcasting
    spellcastingAbility: character.spellcastingAbility,
    spellSaveDC: character.spellSaveDC,
    spellAttackBonus: character.spellAttackBonus,
    
    // Class info for reference
    classInfo: {
      name: character.characterClass?.name,
      description: character.characterClass?.description,
      hitDie: character.characterClass?.hitDie,
      primaryAbility: character.characterClass?.primaryAbility,
      savingThrows: character.characterClass?.savingThrows,
      skillProficiencies: character.characterClass?.skillProficiencies,
      armorTraining: character.characterClass?.armorTraining,
      weaponProficiencies: character.characterClass?.weaponProficiencies,
      startingEquipment: character.characterClass?.startingEquipment,
      features: character.characterClass?.features,
    },
    
    // Subclass info
    subclassInfo: character.subclass ? {
      name: character.subclass.name,
      description: character.subclass.description,
      features: character.subclass.features,
      subclassSpells: character.subclass.subclassSpells,
    } : null,
    
    // Species info
    speciesInfo: character.species ? {
      name: character.species.name,
      description: character.species.description,
      size: character.species.size,
      speed: character.species.speed,
      traits: character.species.traits,
    } : null,
    
    // Background info
    backgroundInfo: character.background ? {
      name: character.background.name,
      description: character.background.description,
      abilityScores: character.background.abilityScores,
      feat: character.background.feat,
      skillProficiencies: character.background.skillProficiencies,
      toolProficiency: character.background.toolProficiency,
      equipment: character.background.equipment,
    } : null,
    
    // Multiclass
    classLevels: character.classLevels?.map((cl: any) => ({
      class: cl.class?.name || 'Unknown',
      level: cl.level,
      subclass: cl.subclass?.name || null,
      hitDieType: cl.hitDieType,
      hitDiceCurrent: cl.hitDiceCurrent,
      hitDiceMax: cl.hitDiceMax,
      isPrimary: cl.isPrimary,
    })) || [],
    
    // Death saves
    deathSaves: {
      successes: character.deathSaveSuccesses || 0,
      failures: character.deathSaveFailures || 0,
    },
  };

  // Create temp file with data
  const tmpDir = os.tmpdir();
  const dataFile = path.join(tmpDir, `char_${character.id}.json`);
  const outputFile = path.join(tmpDir, `char_${character.id}.pdf`);
  
  fs.writeFileSync(dataFile, JSON.stringify(pdfData, null, 2));
  
  // Python script path
  const scriptPath = path.join(process.cwd(), 'scripts', 'generate_character_pdf.py');
  
  // Use venv python which has reportlab installed
  const pythonPath = '/home/z/.venv/bin/python3';
  
  try {
    // Execute Python script
    await execAsync(`${pythonPath} "${scriptPath}" "${dataFile}" "${outputFile}"`);
    
    // Read generated PDF
    const pdfBuffer = fs.readFileSync(outputFile);
    
    // Cleanup temp files
    fs.unlinkSync(dataFile);
    fs.unlinkSync(outputFile);
    
    return pdfBuffer;
  } catch (error) {
    // Cleanup on error
    try {
      fs.unlinkSync(dataFile);
      if (fs.existsSync(outputFile)) fs.unlinkSync(outputFile);
    } catch {}
    throw error;
  }
}

// GET - Export character as PDF
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    // Fetch character with all related data
    const character = await db.character.findUnique({
      where: { id },
      include: {
        species: true,
        characterClass: true,
        subclass: true,
        background: true,
        inventoryItems: {
          include: {
            weapon: true,
            armor: true,
            item: true,
            magicItem: true
          }
        },
        characterSpells: {
          include: {
            spell: true,
            spellClass: true
          }
        },
        characterFeats: {
          include: {
            feat: true
          }
        },
        classLevels: {
          include: {
            class: true,
            subclass: true
          }
        }
      }
    });
    
    if (!character) {
      return NextResponse.json({ error: 'Character not found' }, { status: 404 });
    }
    
    // Generate PDF
    const pdfBuffer = await generatePDF(character);
    
    // Return PDF as download
    return new NextResponse(pdfBuffer, {
      headers: {
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="${character.name.replace(/[^a-zA-Z0-9]/g, '_')}_character_sheet.pdf"`,
      },
    });
  } catch (error) {
    console.error('Error generating PDF:', error);
    return NextResponse.json({ error: 'Failed to generate PDF' }, { status: 500 });
  }
}
