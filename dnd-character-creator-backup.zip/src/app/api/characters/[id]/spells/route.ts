import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Sources that don't count toward spell limits and can't be removed
// These are spells granted by subclass features, species traits, or feats
const PROTECTED_SOURCES = ['domain', 'circle', 'oath', 'ranger', 'sorcerer', 'warlock', 'subclass', 'artificer', 'species', 'feat'];

// GET character spells
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const spells = await db.characterSpell.findMany({
      where: { characterId: id },
      include: {
        spell: true,
        spellClass: true // Include the class relation for multiclass support
      },
      orderBy: {
        spell: {
          level: 'asc'
        }
      }
    });

    return NextResponse.json(spells);
  } catch (error) {
    console.error('Error fetching character spells:', error);
    return NextResponse.json({ error: 'Failed to fetch character spells' }, { status: 500 });
  }
}

// POST add spell to character
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();

    // Determine source (default to 'class')
    const source = body.source || 'class';
    const isProtected = PROTECTED_SOURCES.includes(source);

    // Check if spell already known
    const existing = await db.characterSpell.findFirst({
      where: {
        characterId: id,
        spellId: body.spellId
      }
    });

    if (existing) {
      // If spell exists but needs to be upgraded to a protected source
      if (isProtected && existing.source === 'class') {
        const updated = await db.characterSpell.update({
          where: { id: existing.id },
          data: {
            source: source,
            prepared: true, // Protected spells are always prepared
            classId: body.classId || existing.classId // Update classId if provided
          },
          include: { spell: true, spellClass: true }
        });
        return NextResponse.json(updated);
      }
      return NextResponse.json(existing);
    }

    const characterSpell = await db.characterSpell.create({
      data: {
        characterId: id,
        spellId: body.spellId,
        prepared: isProtected ? true : (body.prepared || false),
        known: true,
        source: source,
        classId: body.classId || null // Store the classId for multiclass
      },
      include: {
        spell: true,
        spellClass: true
      }
    });

    return NextResponse.json(characterSpell);
  } catch (error) {
    console.error('Error adding spell:', error);
    return NextResponse.json({ error: 'Failed to add spell' }, { status: 500 });
  }
}

// DELETE remove spell from character
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);
    const spellId = searchParams.get('spellId');
    const characterSpellId = searchParams.get('characterSpellId');

    let characterSpell;

    // Support both spellId and characterSpellId parameters
    if (characterSpellId) {
      // Find by CharacterSpell ID directly
      characterSpell = await db.characterSpell.findFirst({
        where: {
          id: characterSpellId,
          characterId: id
        }
      });

      if (!characterSpell) {
        return NextResponse.json({ error: 'Spell not found' }, { status: 404 });
      }
    } else if (spellId) {
      // Find by Spell ID (legacy support)
      characterSpell = await db.characterSpell.findFirst({
        where: {
          characterId: id,
          spellId
        }
      });
    } else {
      return NextResponse.json({ error: 'Spell ID or CharacterSpell ID required' }, { status: 400 });
    }

    // Check if it's a protected spell (domain, species, feat)
    if (characterSpell && PROTECTED_SOURCES.includes(characterSpell.source)) {
      return NextResponse.json({
        error: `Cannot remove ${characterSpell.source} spells`
      }, { status: 400 });
    }

    // Delete by the CharacterSpell ID
    await db.characterSpell.delete({
      where: {
        id: characterSpell.id
      }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error removing spell:', error);
    return NextResponse.json({ error: 'Failed to remove spell' }, { status: 500 });
  }
}

// PUT toggle spell prepared status (changed from PATCH due to gateway restrictions)
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    
    // If spellId is provided, toggle prepared status
    if (body.spellId !== undefined && body.prepared !== undefined) {
      // Check if it's a protected spell
      const existing = await db.characterSpell.findFirst({
        where: {
          characterId: id,
          spellId: body.spellId
        }
      });
      
      if (existing && PROTECTED_SOURCES.includes(existing.source)) {
        return NextResponse.json({ 
          error: `Cannot change prepared status of ${existing.source} spells` 
        }, { status: 400 });
      }
      
      const characterSpell = await db.characterSpell.update({
        where: {
          characterId_spellId: {
            characterId: id,
            spellId: body.spellId
          }
        },
        data: {
          prepared: body.prepared
        },
        include: {
          spell: true
        }
      });
      
      return NextResponse.json(characterSpell);
    }
    
    return NextResponse.json({ error: 'spellId and prepared are required' }, { status: 400 });
  } catch (error) {
    console.error('Error updating spell:', error);
    return NextResponse.json({ error: 'Failed to update spell' }, { status: 500 });
  }
}
