import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Multiclass ability score requirements (D&D 2024 rules)
const MULTICLASS_REQUIREMENTS: Record<string, { primary: string; primaryValue: number; secondary?: string; secondaryValue?: number; useOr?: boolean }> = {
  'Artificer': { primary: 'intelligence', primaryValue: 13 },
  'Barbarian': { primary: 'strength', primaryValue: 13 },
  'Bard': { primary: 'charisma', primaryValue: 13 },
  'Cleric': { primary: 'wisdom', primaryValue: 13 },
  'Druid': { primary: 'wisdom', primaryValue: 13 },
  'Fighter': { primary: 'strength', primaryValue: 13, secondary: 'dexterity', secondaryValue: 13, useOr: true },
  'Monk': { primary: 'dexterity', primaryValue: 13, secondary: 'wisdom', secondaryValue: 13 },
  'Paladin': { primary: 'strength', primaryValue: 13, secondary: 'charisma', secondaryValue: 13 },
  'Ranger': { primary: 'dexterity', primaryValue: 13, secondary: 'wisdom', secondaryValue: 13 },
  'Rogue': { primary: 'dexterity', primaryValue: 13 },
  'Sorcerer': { primary: 'charisma', primaryValue: 13 },
  'Warlock': { primary: 'charisma', primaryValue: 13 },
  'Wizard': { primary: 'intelligence', primaryValue: 13 }
};

// Sources for subclass spells
const SPELL_SOURCES: Record<string, string> = {
  'Artificer': 'artificer',
  'Bard': 'subclass',  // Bard subclass spells (e.g., College of the Moon)
  'Cleric': 'domain',
  'Druid': 'circle',
  'Paladin': 'oath',
  'Ranger': 'ranger',
  'Sorcerer': 'sorcerer',
  'Warlock': 'warlock',
  'Wizard': 'subclass',  // Wizard subclass spells (e.g., Bladesinger)
};

// Sync subclass spells helper (single class)
async function syncSubclassSpells(
  characterId: string, 
  subclassId: string, 
  classLevel: number, 
  className: string,
  classId?: string
): Promise<number> {
  try {
    const subclass = await db.subclass.findUnique({
      where: { id: subclassId }
    });
    
    if (!subclass || !subclass.subclassSpells || subclass.subclassSpells === 'null') {
      return 0;
    }
    
    let subclassSpellsByLevel: Record<number, string[]> = {};
    try {
      subclassSpellsByLevel = JSON.parse(subclass.subclassSpells);
    } catch {
      return 0;
    }
    
    const spellSource = SPELL_SOURCES[className] || 'subclass';
    const unlockLevels = Object.keys(subclassSpellsByLevel)
      .map(Number)
      .filter(n => !isNaN(n));
    
    let spellsAdded = 0;
    
    for (const unlockLevel of unlockLevels) {
      if (classLevel >= unlockLevel && Array.isArray(subclassSpellsByLevel[unlockLevel])) {
        for (const spellName of subclassSpellsByLevel[unlockLevel]) {
          if (!spellName) continue;
          
          try {
            const spell = await db.spell.findFirst({
              where: { name: { equals: spellName } }
            });
            
            if (spell) {
              const existing = await db.characterSpell.findFirst({
                where: { characterId, spellId: spell.id }
              });
              
              if (!existing) {
                await db.characterSpell.create({
                  data: {
                    characterId,
                    spellId: spell.id,
                    prepared: true,
                    known: true,
                    source: spellSource,
                    classId: classId || null
                  }
                });
                spellsAdded++;
              } else if (existing.source === 'class' && classId) {
                // Upgrade to subclass spell with proper classId
                await db.characterSpell.update({
                  where: { id: existing.id },
                  data: {
                    source: spellSource,
                    prepared: true,
                    classId: classId
                  }
                });
                spellsAdded++;
              }
            }
          } catch {
            // Continue on error
          }
        }
      }
    }
    
    return spellsAdded;
  } catch (error) {
    console.error('Error syncing subclass spells:', error);
    return 0;
  }
}

// Sync ALL subclass spells for multiclass characters
async function syncAllSubclassSpells(characterId: string): Promise<number> {
  try {
    // Get character with all class levels and their subclasses
    const character = await db.character.findUnique({
      where: { id: characterId },
      include: {
        classLevels: {
          include: {
            class: true,
            subclass: true
          }
        }
      }
    });
    
    if (!character) return 0;
    
    let totalSpellsAdded = 0;
    
    // Iterate through all class levels
    for (const classLevel of character.classLevels) {
      // Skip if no subclass
      if (!classLevel.subclassId || !classLevel.subclass) continue;
      
      // Skip if level is less than 3 (subclass chosen at level 3)
      if (classLevel.level < 3) continue;
      
      const spellsAdded = await syncSubclassSpells(
        characterId,
        classLevel.subclassId,
        classLevel.level,
        classLevel.class.name,
        classLevel.classId
      );
      
      totalSpellsAdded += spellsAdded;
    }
    
    return totalSpellsAdded;
  } catch (error) {
    console.error('Error syncing all subclass spells:', error);
    return 0;
  }
}

// Check if character meets multiclass requirements for a class
function meetsMulticlassRequirements(character: any, className: string): boolean {
  const requirements = MULTICLASS_REQUIREMENTS[className];
  if (!requirements) return false;

  const abilityMap: Record<string, number> = {
    'strength': character.strength,
    'dexterity': character.dexterity,
    'constitution': character.constitution,
    'intelligence': character.intelligence,
    'wisdom': character.wisdom,
    'charisma': character.charisma
  };

  const primaryValue = abilityMap[requirements.primary] || 0;
  
  if (requirements.useOr) {
    // Fighter: Strength 13 OR Dexterity 13
    const secondaryValue = abilityMap[requirements.secondary!] || 0;
    return primaryValue >= requirements.primaryValue || secondaryValue >= requirements.secondaryValue!;
  } else if (requirements.secondary) {
    // Both required (Monk, Paladin, Ranger)
    const secondaryValue = abilityMap[requirements.secondary] || 0;
    return primaryValue >= requirements.primaryValue && secondaryValue >= requirements.secondaryValue!;
  } else {
    return primaryValue >= requirements.primaryValue;
  }
}

// POST level up character
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    
    const character = await db.character.findUnique({
      where: { id },
      include: {
        characterClass: true
      }
    });
    
    if (!character) {
      return NextResponse.json({ error: 'Character not found' }, { status: 404 });
    }
    
    // Fetch class levels separately
    const classLevels = await db.characterClassLevel.findMany({
      where: { characterId: id },
      include: { class: true }
    });
    
    const newLevel = character.level + 1;
    
    // Check if advancing in a specific existing class (multiclass character)
    const isAdvancingExistingClass = body.classLevelIdToAdvance && !body.multiclassClassId;
    
    // Check if multiclassing into a new class
    const isMulticlass = body.multiclassClassId && !classLevels.some((cl: any) => cl.classId === body.multiclassClassId);
    
    let hpGain: number;
    let hitDieType: number;
    let classLevelUpdates: any = {};
    let classAdvanced: any = null;
    
    if (isAdvancingExistingClass) {
      // Level up in a specific existing class (for multiclass characters)
      const classLevelToAdvance = classLevels.find((cl: any) => cl.id === body.classLevelIdToAdvance);
      
      if (!classLevelToAdvance) {
        return NextResponse.json({ error: 'Class level not found' }, { status: 404 });
      }
      
      const classToAdvance = classLevelToAdvance.class;
      hitDieType = classToAdvance.hitDie;
      const constitutionModifier = Math.floor((character.constitution - 10) / 2);
      hpGain = Math.floor(classToAdvance.hitDie / 2) + 1 + constitutionModifier;
      
      // Check if this class will reach level 3 and needs a subclass
      const newClassLevel = classLevelToAdvance.level + 1;
      const needsSubclass = newClassLevel === 3 && !classLevelToAdvance.subclassId && body.subclassId;
      
      // Update the specific class level
      await db.characterClassLevel.update({
        where: { id: body.classLevelIdToAdvance },
        data: {
          level: newClassLevel,
          hitDiceCurrent: classLevelToAdvance.hitDiceCurrent + 1,
          hitDiceMax: classLevelToAdvance.hitDiceMax + 1,
          // Add subclass if chosen at level 3
          ...(needsSubclass && { subclassId: body.subclassId })
        }
      });
      
      classAdvanced = classToAdvance;
      
    } else if (isMulticlass) {
      // Multiclass: Get new class info
      const newClass = await db.characterClass.findUnique({
        where: { id: body.multiclassClassId }
      });
      
      if (!newClass) {
        return NextResponse.json({ error: 'New class not found' }, { status: 404 });
      }
      
      // Check multiclass requirements
      if (!meetsMulticlassRequirements(character, newClass.name)) {
        return NextResponse.json({ 
          error: `No cumples los requisitos para multiclasear como ${newClass.name}. Requiere ${MULTICLASS_REQUIREMENTS[newClass.name] ? formatRequirements(MULTICLASS_REQUIREMENTS[newClass.name]) : 'desconocido'}.`
        }, { status: 400 });
      }
      
      hitDieType = newClass.hitDie;
      const constitutionModifier = Math.floor((character.constitution - 10) / 2);
      hpGain = Math.floor(newClass.hitDie / 2) + 1 + constitutionModifier; // Average + CON
      
      // Create new class level entry for multiclass
      await db.characterClassLevel.create({
        data: {
          characterId: id,
          classId: body.multiclassClassId,
          level: 1,
          hitDieType: newClass.hitDie,
          hitDiceCurrent: 1,
          hitDiceMax: 1,
          isPrimary: false
        }
      });
      
      // Add new class proficiencies
      const currentWeapons = character.weaponProficiencies ? JSON.parse(character.weaponProficiencies) : [];
      const currentArmor = character.armorProficiencies ? JSON.parse(character.armorProficiencies) : [];
      const currentTools = character.toolProficiencies ? JSON.parse(character.toolProficiencies) : [];
      
      // Special handling for Artificer multiclass (D&D 2024 rules)
      if (newClass.name === 'Artificer') {
        // Artificer multiclass proficiencies:
        // - Light Armor, Medium Armor, Shields
        // - Tinker's Tools
        // - ONE skill from Artificer list (handled separately via body.multiclassSkillChoice)
        // - Does NOT grant weapon proficiencies
        
        const artificerArmor = ['Light Armor', 'Medium Armor', 'Shields'];
        const mergedArmor = [...new Set([...currentArmor, ...artificerArmor])];
        const mergedTools = [...new Set([...currentTools, 'Tinker\'s Tools'])];
        
        classLevelUpdates = {
          weaponProficiencies: JSON.stringify(currentWeapons), // No new weapon proficiencies
          armorProficiencies: JSON.stringify(mergedArmor),
          toolProficiencies: JSON.stringify(mergedTools)
        };
        
        // Add the chosen skill if provided
        if (body.multiclassSkillChoice) {
          // Map skill name to database field
          const skillFieldMap: Record<string, string> = {
            'Acrobatics': 'skillAcrobatics',
            'Animal Handling': 'skillAnimalHandling',
            'Arcana': 'skillArcana',
            'Athletics': 'skillAthletics',
            'Deception': 'skillDeception',
            'History': 'skillHistory',
            'Insight': 'skillInsight',
            'Intimidation': 'skillIntimidation',
            'Investigation': 'skillInvestigation',
            'Medicine': 'skillMedicine',
            'Nature': 'skillNature',
            'Perception': 'skillPerception',
            'Performance': 'skillPerformance',
            'Persuasion': 'skillPersuasion',
            'Religion': 'skillReligion',
            'Sleight of Hand': 'skillSleightOfHand',
            'Stealth': 'skillStealth',
            'Survival': 'skillSurvival'
          };
          
          const skillField = skillFieldMap[body.multiclassSkillChoice];
          if (skillField) {
            classLevelUpdates[skillField] = true;
          }
        }
      } else {
        // Standard multiclass proficiencies
        const newWeapons = newClass.weaponProficiencies ? JSON.parse(newClass.weaponProficiencies) : [];
        const newArmor = newClass.armorTraining ? JSON.parse(newClass.armorTraining) : [];
        
        // Merge proficiencies (don't add duplicates)
        const mergedWeapons = [...new Set([...currentWeapons, ...newWeapons])];
        const mergedArmor = [...new Set([...currentArmor, ...newArmor])];
        
        classLevelUpdates = {
          weaponProficiencies: JSON.stringify(mergedWeapons),
          armorProficiencies: JSON.stringify(mergedArmor)
        };
      }
      
    } else {
      // Normal level up in primary class
      const hitDie = character.characterClass?.hitDie || 8;
      hitDieType = character.hitDiceType;
      const constitutionModifier = Math.floor((character.constitution - 10) / 2);
      hpGain = Math.floor(hitDie / 2) + 1 + constitutionModifier;
      
      // Update existing class level
      const primaryClassLevel = await db.characterClassLevel.findFirst({
        where: { characterId: id, isPrimary: true }
      });
      
      if (primaryClassLevel) {
        await db.characterClassLevel.update({
          where: { id: primaryClassLevel.id },
          data: {
            level: primaryClassLevel.level + 1,
            hitDiceCurrent: primaryClassLevel.hitDiceCurrent + 1,
            hitDiceMax: primaryClassLevel.hitDiceMax + 1
          }
        });
        classAdvanced = primaryClassLevel.class;
      } else {
        // Create primary class level if it doesn't exist
        await db.characterClassLevel.create({
          data: {
            characterId: id,
            classId: character.classId!,
            level: newLevel,
            hitDieType: character.hitDiceType,
            hitDiceCurrent: character.hitDiceMax + 1,
            hitDiceMax: character.hitDiceMax + 1,
            isPrimary: true,
            subclassId: body.subclassId || character.subclassId
          }
        });
        classAdvanced = character.characterClass;
      }
    }
    
    // Calculate new proficiency bonus
    const proficiencyBonus = Math.ceil(newLevel / 4) + 1;
    
    // Update character
    const updateData: any = {
      level: newLevel,
      maxHp: character.maxHp + hpGain,
      currentHp: character.currentHp + hpGain,
      hitDiceMax: character.hitDiceMax + 1,
      hitDiceCurrent: character.hitDiceCurrent + 1,
      proficiencyBonus: Math.max(2, Math.min(6, proficiencyBonus)),
      
      // Update ability scores if chosen
      ...(body.abilityScores && {
        strength: body.abilityScores.strength || character.strength,
        dexterity: body.abilityScores.dexterity || character.dexterity,
        constitution: body.abilityScores.constitution || character.constitution,
        intelligence: body.abilityScores.intelligence || character.intelligence,
        wisdom: body.abilityScores.wisdom || character.wisdom,
        charisma: body.abilityScores.charisma || character.charisma
      }),
      
      // Update subclass if chosen at level 3
      ...(!isMulticlass && newLevel === 3 && body.subclassId && {
        subclassId: body.subclassId
      }),
      
      // Update XP
      xp: body.xp || character.xp,
      
      // Multiclass updates
      ...(isMulticlass && classLevelUpdates)
    };
    
    const updatedCharacter = await db.character.update({
      where: { id },
      data: updateData,
      include: {
        characterClass: true,
        classLevels: {
          include: { class: true, subclass: true }
        }
      }
    });
    
    // Add feat if chosen (manual implementation - no automatic benefits)
    if (body.featId) {
      const existingFeat = await db.characterFeat.findFirst({
        where: { characterId: id, featId: body.featId }
      });

      if (!existingFeat) {
        await db.characterFeat.create({
          data: {
            characterId: id,
            featId: body.featId,
            source: `Level ${newLevel}`
          }
        });
        // All feat benefits must be applied manually - no automatic effects
      }
    }
    
    // Add spell if spellcaster chose one
    if (body.spellId) {
      const existingSpell = await db.characterSpell.findFirst({
        where: { characterId: id, spellId: body.spellId }
      });
      
      if (!existingSpell) {
        await db.characterSpell.create({
          data: {
            characterId: id,
            spellId: body.spellId,
            prepared: false,
            known: true
          }
        });
      }
    }
    
    // Sync ALL subclass spells for multiclass characters
    // This ensures all classes with level 3+ and subclasses get their spells
    await syncAllSubclassSpells(id);
    
    // Check if character gains Expertise feature at this level and create reminder note
    // Expertise is gained by: Rogue (levels 1, 6), Bard (levels 3, 10)
    const expertiseByClassAndLevel: Record<string, number[]> = {
      'Rogue': [1, 6],
      'Bard': [3, 10]
    };
    
    // Check each class level for expertise
    const classLevelsAfterUpdate = await db.characterClassLevel.findMany({
      where: { characterId: id },
      include: { class: true }
    });
    
    for (const cl of classLevelsAfterUpdate) {
      const className = cl.class.name;
      const expertiseLevels = expertiseByClassAndLevel[className];
      
      if (expertiseLevels && expertiseLevels.includes(cl.level)) {
        // Check if this is a new expertise gain (character just reached this level)
        // Create reminder note for expertise
        const expertiseCount = className === 'Rogue' 
          ? (cl.level >= 6 ? 'dos habilidades más' : 'dos habilidades')
          : (cl.level >= 10 ? 'dos habilidades más' : 'dos habilidades');
        
        await db.note.create({
          data: {
            characterId: id,
            title: `⭐ ACCIÓN REQUERIDA: Experticia (${className})`,
            content: `Tu ${className} ha alcanzado el nivel ${cl.level} y ha ganado **Experticia**.

Eliges ${expertiseCount} en las que ya tienes competencia. Tu bonificador de competencia se duplica para cualquier prueba que use esas habilidades.

⚠️ **Debes marcar la experticia manualmente:**
1. Ve a la sección de habilidades del personaje
2. Haz clic en el botón de experticia (⭐) junto a las habilidades elegidas
3. La experticia duplica tu bonificador de competencia para esa habilidad

**Recordatorio:** La experticia no se aplica automáticamente. Debes activarla manualmente en la hoja de personaje.`,
            color: 'amber'
          }
        });
      }
    }
    
    return NextResponse.json(updatedCharacter);
  } catch (error) {
    console.error('Error leveling up character:', error);
    return NextResponse.json({ error: 'Failed to level up character' }, { status: 500 });
  }
}

// Helper function to format requirements for display
function formatRequirements(req: { primary: string; primaryValue: number; secondary?: string; secondaryValue?: number; useOr?: boolean }): string {
  const formatAbility = (ability: string) => {
    const names: Record<string, string> = {
      'strength': 'Fuerza',
      'dexterity': 'Destreza',
      'constitution': 'Constitución',
      'intelligence': 'Inteligencia',
      'wisdom': 'Sabiduría',
      'charisma': 'Carisma'
    };
    return `${names[ability] || ability} ${req.primaryValue}`;
  };
  
  if (req.useOr) {
    return `${formatAbility(req.primary)} O ${formatAbility(req.secondary!)} ${req.secondaryValue}`;
  } else if (req.secondary) {
    return `${formatAbility(req.primary)} Y ${formatAbility(req.secondary)} ${req.secondaryValue}`;
  } else {
    return formatAbility(req.primary);
  }
}

// GET level up options
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    const character = await db.character.findUnique({
      where: { id },
      include: {
        characterClass: true,
        subclass: true,
        characterFeats: {
          include: { feat: true }
        },
        characterSpells: {
          include: { spell: true }
        }
      }
    });
    
    if (!character) {
      return NextResponse.json({ error: 'Character not found' }, { status: 404 });
    }
    
    // Fetch class levels separately
    const classLevels = await db.characterClassLevel.findMany({
      where: { characterId: id },
      include: { class: true, subclass: true }
    });
    
    const newLevel = character.level + 1;
    
    // Get all classes for multiclass options
    const allClasses = await db.characterClass.findMany({
      orderBy: { name: 'asc' }
    });
    
    // Filter available multiclass options based on requirements
    const currentClassIds = new Set(classLevels?.map(cl => cl.classId) || []);
    if (character.classId) currentClassIds.add(character.classId);
    
    const availableMulticlassOptions = allClasses.filter(cls => {
      // Can't multiclass into a class you already have
      if (currentClassIds.has(cls.id)) return false;
      // Must meet ability score requirements
      return meetsMulticlassRequirements(character, cls.name);
    });
    
    // Get available feats
    const allFeats = await db.feat.findMany({
      orderBy: { name: 'asc' }
    });
    
    // Get available spells for spellcasters
    let availableSpells: any[] = [];
    if (character.characterClass?.spellcasting) {
      const knownSpellIds = character.characterSpells.map(cs => cs.spellId);
      availableSpells = await db.spell.findMany({
        where: {
          level: { lte: Math.ceil(newLevel / 2) }, // Max spell level
          id: { notIn: knownSpellIds },
          classes: { contains: character.characterClass.name }
        },
        orderBy: [{ level: 'asc' }, { name: 'asc' }]
      });
    }
    
    // Get available subclasses at level 3 for primary class
    let availableSubclasses: any[] = [];
    if (newLevel === 3 && character.classId && !character.subclassId) {
      availableSubclasses = await db.subclass.findMany({
        where: { classId: character.classId }
      });
    }
    
    // For multiclass characters: get available subclasses for each class that will reach level 3
    const existingClassOptions = classLevels?.map((cl: any) => {
      const willReachLevel3 = cl.level === 2; // Next level will be 3
      const needsSubclass = !cl.subclassId && !cl.subclass;
      
      return {
        id: cl.id,
        classId: cl.classId,
        className: cl.class?.name,
        level: cl.level,
        hitDieType: cl.hitDieType,
        isPrimary: cl.isPrimary,
        subclassId: cl.subclassId,
        subclass: cl.subclass,
        // Flag if this class will need subclass selection on level up
        needsSubclassOnLevelUp: willReachLevel3 && needsSubclass
      };
    }) || [];
    
    // Get subclasses available for each class that might need one
    const subclassOptionsByClass: Record<string, any[]> = {};
    for (const clOpt of existingClassOptions) {
      if (clOpt.needsSubclassOnLevelUp || (clOpt.level >= 2 && !clOpt.subclassId && !clOpt.subclass)) {
        const subclasses = await db.subclass.findMany({
          where: { classId: clOpt.classId }
        });
        subclassOptionsByClass[clOpt.classId] = subclasses;
      }
    }
    
    // Get class features for new level
    let newFeatures: string[] = [];
    if (character.characterClass?.features) {
      const features = JSON.parse(character.characterClass.features);
      newFeatures = features[newLevel] || [];
    }
    
    // Check if ASI/feat at this level
    const asiLevels = [4, 8, 12, 16, 19];
    const canIncreaseAbilityScores = asiLevels.includes(newLevel);
    
    return NextResponse.json({
      currentLevel: character.level,
      newLevel,
      canIncreaseAbilityScores,
      availableFeats: allFeats,
      availableSpells,
      availableSubclasses,
      newFeatures,
      proficiencyBonusChange: getProficiencyBonusChange(character.level, newLevel),
      // Multiclass options
      canMulticlass: character.level >= 1,
      currentClassLevels: classLevels || [],
      availableMulticlassOptions,
      multiclassRequirements: MULTICLASS_REQUIREMENTS,
      // For multiclass characters: can advance in any existing class
      canAdvanceExistingClass: (classLevels?.length || 0) > 1,
      existingClassOptions,
      // Subclass options by class for multiclass
      subclassOptionsByClass
    });
  } catch (error) {
    console.error('Error getting level up options:', error);
    return NextResponse.json({ error: 'Failed to get level up options' }, { status: 500 });
  }
}

function getProficiencyBonusChange(oldLevel: number, newLevel: number): number {
  const oldBonus = Math.ceil(oldLevel / 4) + 1;
  const newBonus = Math.ceil(newLevel / 4) + 1;
  return Math.max(0, Math.min(4, newBonus - oldBonus));
}
