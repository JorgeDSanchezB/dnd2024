import { NextResponse } from 'next/server';
import { database } from '@/lib/database';

// POST - Duplicate a character with a new name
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const newName = body.name;
    
    if (!newName || typeof newName !== 'string' || newName.trim() === '') {
      return NextResponse.json({ error: 'New name is required' }, { status: 400 });
    }

    // Fetch the original character with all related data
    const originalCharacter = await database.character.findUnique({
      where: { id },
      include: {
        species: true,
        characterClass: true,
        subclass: true,
        background: true,
        classLevels: {
          include: {
            class: true,
            subclass: true
          }
        },
        inventoryItems: {
          include: {
            weapon: true,
            armor: true,
            item: true,
            magicItem: true
          }
        },
        characterSpells: true,
        characterFeats: true,
        notes: true
      }
    });

    if (!originalCharacter) {
      return NextResponse.json({ error: 'Character not found' }, { status: 404 });
    }

    // Create the duplicated character
    const duplicatedCharacter = await database.character.create({
      data: {
        // Basic info with new name
        name: newName.trim(),
        level: originalCharacter.level,
        xp: originalCharacter.xp,
        
        // Ability Scores
        strength: originalCharacter.strength,
        dexterity: originalCharacter.dexterity,
        constitution: originalCharacter.constitution,
        intelligence: originalCharacter.intelligence,
        wisdom: originalCharacter.wisdom,
        charisma: originalCharacter.charisma,
        
        // Combat Stats
        currentHp: originalCharacter.currentHp,
        maxHp: originalCharacter.maxHp,
        tempHp: originalCharacter.tempHp,
        hitDiceCurrent: originalCharacter.hitDiceCurrent,
        hitDiceMax: originalCharacter.hitDiceMax,
        hitDiceType: originalCharacter.hitDiceType,
        armorClass: originalCharacter.armorClass,
        initiative: originalCharacter.initiative,
        speed: originalCharacter.speed,
        proficiencyBonus: originalCharacter.proficiencyBonus,
        
        // Saving Throws
        saveStr: originalCharacter.saveStr,
        saveDex: originalCharacter.saveDex,
        saveCon: originalCharacter.saveCon,
        saveInt: originalCharacter.saveInt,
        saveWis: originalCharacter.saveWis,
        saveCha: originalCharacter.saveCha,
        
        // Skills
        skillAcrobatics: originalCharacter.skillAcrobatics,
        skillAnimalHandling: originalCharacter.skillAnimalHandling,
        skillArcana: originalCharacter.skillArcana,
        skillAthletics: originalCharacter.skillAthletics,
        skillDeception: originalCharacter.skillDeception,
        skillHistory: originalCharacter.skillHistory,
        skillInsight: originalCharacter.skillInsight,
        skillIntimidation: originalCharacter.skillIntimidation,
        skillInvestigation: originalCharacter.skillInvestigation,
        skillMedicine: originalCharacter.skillMedicine,
        skillNature: originalCharacter.skillNature,
        skillPerception: originalCharacter.skillPerception,
        skillPerformance: originalCharacter.skillPerformance,
        skillPersuasion: originalCharacter.skillPersuasion,
        skillReligion: originalCharacter.skillReligion,
        skillSleightOfHand: originalCharacter.skillSleightOfHand,
        skillStealth: originalCharacter.skillStealth,
        skillSurvival: originalCharacter.skillSurvival,
        
        // Expertise
        expertAcrobatics: originalCharacter.expertAcrobatics,
        expertAnimalHandling: originalCharacter.expertAnimalHandling,
        expertArcana: originalCharacter.expertArcana,
        expertAthletics: originalCharacter.expertAthletics,
        expertDeception: originalCharacter.expertDeception,
        expertHistory: originalCharacter.expertHistory,
        expertInsight: originalCharacter.expertInsight,
        expertIntimidation: originalCharacter.expertIntimidation,
        expertInvestigation: originalCharacter.expertInvestigation,
        expertMedicine: originalCharacter.expertMedicine,
        expertNature: originalCharacter.expertNature,
        expertPerception: originalCharacter.expertPerception,
        expertPerformance: originalCharacter.expertPerformance,
        expertPersuasion: originalCharacter.expertPersuasion,
        expertReligion: originalCharacter.expertReligion,
        expertSleightOfHand: originalCharacter.expertSleightOfHand,
        expertStealth: originalCharacter.expertStealth,
        expertSurvival: originalCharacter.expertSurvival,
        
        // Character Details
        alignment: originalCharacter.alignment,
        backgroundStory: originalCharacter.backgroundStory,
        appearance: originalCharacter.appearance,
        personalityTraits: originalCharacter.personalityTraits,
        ideals: originalCharacter.ideals,
        bonds: originalCharacter.bonds,
        flaws: originalCharacter.flaws,
        
        // Proficiencies
        languages: originalCharacter.languages,
        toolProficiencies: originalCharacter.toolProficiencies,
        armorProficiencies: originalCharacter.armorProficiencies,
        weaponProficiencies: originalCharacter.weaponProficiencies,
        
        // Currency
        cp: originalCharacter.cp,
        sp: originalCharacter.sp,
        ep: originalCharacter.ep,
        gp: originalCharacter.gp,
        pp: originalCharacter.pp,
        
        // Features
        classFeatures: originalCharacter.classFeatures,
        speciesTraits: originalCharacter.speciesTraits,
        
        // Spellcasting
        spellcastingAbility: originalCharacter.spellcastingAbility,
        spellSaveDC: originalCharacter.spellSaveDC,
        spellAttackBonus: originalCharacter.spellAttackBonus,
        
        // Death saves
        deathSaveSuccesses: 0,
        deathSaveFailures: 0,
        
        // Relationships
        speciesId: originalCharacter.speciesId,
        classId: originalCharacter.classId,
        subclassId: originalCharacter.subclassId,
        backgroundId: originalCharacter.backgroundId,
        
        // Related data
        classLevels: {
          create: originalCharacter.classLevels.map(cl => ({
            classId: cl.classId,
            level: cl.level,
            hitDieType: cl.hitDieType,
            hitDiceCurrent: cl.hitDiceCurrent,
            hitDiceMax: cl.hitDiceMax,
            isPrimary: cl.isPrimary,
            subclassId: cl.subclassId
          }))
        },
        inventoryItems: {
          create: originalCharacter.inventoryItems.map(item => ({
            quantity: item.quantity,
            equipped: item.equipped,
            attuned: item.attuned,
            weaponId: item.weaponId,
            armorId: item.armorId,
            itemId: item.itemId,
            magicItemId: item.magicItemId
          }))
        },
        characterSpells: {
          create: originalCharacter.characterSpells.map(spell => ({
            spellId: spell.spellId,
            prepared: spell.prepared,
            known: spell.known,
            source: spell.source,
            isDomain: spell.isDomain
          }))
        },
        characterFeats: {
          create: originalCharacter.characterFeats.map(feat => ({
            featId: feat.featId,
            source: feat.source,
            chosenAbilityScore: feat.chosenAbilityScore,
            chosenSpellId: feat.chosenSpellId,
            chosenSkills: feat.chosenSkills
          }))
        }
      },
      include: {
        species: true,
        characterClass: true,
        subclass: true,
        background: true,
        classLevels: {
          include: {
            class: true,
            subclass: true
          }
        },
        inventoryItems: {
          include: {
            weapon: true,
            armor: true,
            item: true,
            magicItem: true
          }
        },
        characterSpells: {
          include: {
            spell: true
          }
        },
        characterFeats: {
          include: {
            feat: true
          }
        }
      }
    });

    return NextResponse.json(duplicatedCharacter);
  } catch (error) {
    console.error('Error duplicating character:', error);
    return NextResponse.json({ error: 'Failed to duplicate character' }, { status: 500 });
  }
}
