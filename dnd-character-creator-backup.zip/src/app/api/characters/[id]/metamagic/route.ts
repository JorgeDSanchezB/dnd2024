import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET Metamagic options chosen by a character
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;

    const characterMetamagic = await db.characterMetamagic.findMany({
      where: { characterId: id },
      include: {
        metamagicOption: true
      },
      orderBy: {
        chosenAtLevel: 'asc'
      }
    });

    return NextResponse.json(characterMetamagic);
  } catch (error) {
    console.error('Error fetching character Metamagic:', error);
    return NextResponse.json({ error: 'Failed to fetch character Metamagic' }, { status: 500 });
  }
}

// POST - Choose a Metamagic option
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { metamagicOptionId, chosenAtLevel } = body;

    if (!metamagicOptionId) {
      return NextResponse.json({ error: 'Metamagic option ID is required' }, { status: 400 });
    }

    // Check if already chosen
    const existing = await db.characterMetamagic.findUnique({
      where: {
        characterId_metamagicOptionId: {
          characterId: id,
          metamagicOptionId
        }
      }
    });

    if (existing) {
      return NextResponse.json({ error: 'Metamagic option already chosen' }, { status: 400 });
    }

    // Get the character to check class and level
    const character = await db.character.findUnique({
      where: { id },
      include: {
        characterClass: true,
        classLevels: {
          include: { class: true }
        }
      }
    });

    if (!character) {
      return NextResponse.json({ error: 'Character not found' }, { status: 404 });
    }

    // Check if character is a Sorcerer (either primary or multiclass)
    const isSorcerer = character.characterClass?.name === 'Sorcerer' ||
      character.classLevels.some(cl => cl.class.name === 'Sorcerer');

    if (!isSorcerer) {
      return NextResponse.json({ error: 'Only Sorcerers can choose Metamagic options' }, { status: 400 });
    }

    // Get Sorcerer level
    let sorcererLevel = 0;
    if (character.characterClass?.name === 'Sorcerer') {
      sorcererLevel = character.level;
    } else {
      const sorcererClassLevel = character.classLevels.find(cl => cl.class.name === 'Sorcerer');
      if (sorcererClassLevel) {
        sorcererLevel = sorcererClassLevel.level;
      }
    }

    // Check if level is high enough for Metamagic (level 2+)
    if (sorcererLevel < 2) {
      return NextResponse.json({ error: 'Sorcerer must be level 2 or higher to choose Metamagic options' }, { status: 400 });
    }

    // Calculate how many Metamagic options the character should have
    // Level 2: 2 options, Level 10: +1, Level 17: +1 = total 4 max at level 17+
    const maxOptions = sorcererLevel >= 17 ? 4 : sorcererLevel >= 10 ? 3 : 2;
    
    // Count current Metamagic options
    const currentOptions = await db.characterMetamagic.count({
      where: { characterId: id }
    });

    if (currentOptions >= maxOptions) {
      return NextResponse.json({ 
        error: `Sorcerer at level ${sorcererLevel} can only have ${maxOptions} Metamagic options` 
      }, { status: 400 });
    }

    // Create the Metamagic choice
    const characterMetamagic = await db.characterMetamagic.create({
      data: {
        characterId: id,
        metamagicOptionId,
        chosenAtLevel: chosenAtLevel || sorcererLevel
      },
      include: {
        metamagicOption: true
      }
    });

    return NextResponse.json(characterMetamagic);
  } catch (error) {
    console.error('Error choosing Metamagic option:', error);
    return NextResponse.json({ error: 'Failed to choose Metamagic option' }, { status: 500 });
  }
}

// DELETE - Remove a Metamagic option
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const { searchParams } = new URL(request.url);
    const metamagicOptionId = searchParams.get('metamagicOptionId');

    if (!metamagicOptionId) {
      return NextResponse.json({ error: 'Metamagic option ID is required' }, { status: 400 });
    }

    await db.characterMetamagic.delete({
      where: {
        characterId_metamagicOptionId: {
          characterId: id,
          metamagicOptionId
        }
      }
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error removing Metamagic option:', error);
    return NextResponse.json({ error: 'Failed to remove Metamagic option' }, { status: 500 });
  }
}

// PUT - Update sorcery points
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    const { sorceryPoints, sorceryPointsMax } = body;

    const updateData: { sorceryPoints?: number; sorceryPointsMax?: number } = {};
    
    if (typeof sorceryPoints === 'number') {
      updateData.sorceryPoints = sorceryPoints;
    }
    if (typeof sorceryPointsMax === 'number') {
      updateData.sorceryPointsMax = sorceryPointsMax;
    }

    if (Object.keys(updateData).length === 0) {
      return NextResponse.json({ error: 'No update data provided' }, { status: 400 });
    }

    const character = await db.character.update({
      where: { id },
      data: updateData
    });

    return NextResponse.json(character);
  } catch (error) {
    console.error('Error updating sorcery points:', error);
    return NextResponse.json({ error: 'Failed to update sorcery points' }, { status: 500 });
  }
}
