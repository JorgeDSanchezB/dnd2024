// Database connection - Prisma client
import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

// Create a new PrismaClient instance
// In development, we need to ensure the client is updated with new models
function createPrismaClient() {
  return new PrismaClient({ log: ['query'] })
}

// Always create a fresh client to ensure all models are available
// This is important during development when schema changes occur
export const db = createPrismaClient()

if (process.env.NODE_ENV !== 'production') {
  // In development, store in global to prevent multiple instances during hot reload
  // But also check if the existing client has all required models
  if (!globalForPrisma.prisma || typeof (globalForPrisma.prisma as any).metamagicOption === 'undefined') {
    globalForPrisma.prisma = db
  }
}
