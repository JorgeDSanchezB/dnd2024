'use client'

import React, { createContext, useContext, useState, useCallback } from 'react'
import { translations as enTranslations } from './en'
import { translations as esTranslations } from './es'

type Language = 'en' | 'es'
type TranslationKey = keyof typeof enTranslations

interface I18nContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: TranslationKey, fallback?: string) => string
  toggleLanguage: () => void
}

const I18nContext = createContext<I18nContextType | undefined>(undefined)

const translations = {
  en: enTranslations,
  es: esTranslations,
}

// Helper to safely access localStorage (handles sandbox security errors)
const safeGetLocalStorage = (key: string): string | null => {
  if (typeof window === 'undefined') return null
  try {
    return localStorage.getItem(key)
  } catch {
    // localStorage not available (sandbox, private mode, etc.)
    return null
  }
}

const safeSetLocalStorage = (key: string, value: string): void => {
  if (typeof window === 'undefined') return
  try {
    localStorage.setItem(key, value)
  } catch {
    // localStorage not available (sandbox, private mode, etc.)
  }
}

// Helper to get initial language (called once during initial render)
const getInitialLanguage = (): Language => {
  const savedLang = safeGetLocalStorage('dnd-language')
  if (savedLang === 'en' || savedLang === 'es') {
    return savedLang
  }
  return 'es' // Default language
}

export function I18nProvider({ children }: { children: React.ReactNode }) {
  // Initialize language from localStorage or default
  const [language, setLanguageState] = useState<Language>(getInitialLanguage)

  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang)
    safeSetLocalStorage('dnd-language', lang)
  }, [])

  const t = useCallback((key: TranslationKey, fallback?: string): string => {
    const translation = translations[language][key]
    if (translation) return translation
    if (fallback) return fallback
    const otherLang = language === 'en' ? 'es' : 'en'
    return (translations[otherLang] as Record<string, string>)[key] || key
  }, [language])

  const toggleLanguage = useCallback(() => {
    setLanguage(language === 'en' ? 'es' : 'en')
  }, [language, setLanguage])

  return (
    <I18nContext.Provider value={{ language, setLanguage, t, toggleLanguage }}>
      {children}
    </I18nContext.Provider>
  )
}

export function useI18n() {
  const context = useContext(I18nContext)
  if (!context) {
    throw new Error('useI18n must be used within an I18nProvider')
  }
  return context
}

export type { Language, TranslationKey }
