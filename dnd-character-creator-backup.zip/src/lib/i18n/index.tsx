'use client'

import React, { createContext, useContext, useState, useEffect, useCallback } from 'react'
import { translations as enTranslations } from './en'
import { translations as esTranslations } from './es'

type Language = 'en' | 'es'
type TranslationKey = keyof typeof enTranslations

interface I18nContextType {
  language: Language
  setLanguage: (lang: Language) => void
  t: (key: TranslationKey, fallback?: string) => string
  toggleLanguage: () => void
}

const I18nContext = createContext<I18nContextType | undefined>(undefined)

const translations = {
  en: enTranslations,
  es: esTranslations,
}

export function I18nProvider({ children }: { children: React.ReactNode }) {
  // Initialize from localStorage if available
  const [language, setLanguageState] = useState<Language>(() => {
    if (typeof window !== 'undefined') {
      const savedLang = localStorage.getItem('dnd-language') as Language
      if (savedLang && (savedLang === 'en' || savedLang === 'es')) {
        return savedLang
      }
    }
    return 'es'
  })

  const setLanguage = useCallback((lang: Language) => {
    setLanguageState(lang)
    if (typeof window !== 'undefined') {
      localStorage.setItem('dnd-language', lang)
    }
  }, [])

  const t = useCallback((key: TranslationKey, fallback?: string): string => {
    const translation = translations[language][key]
    if (translation) return translation
    if (fallback) return fallback
    const otherLang = language === 'en' ? 'es' : 'en'
    return (translations[otherLang] as Record<string, string>)[key] || key
  }, [language])

  const toggleLanguage = useCallback(() => {
    setLanguage(language === 'en' ? 'es' : 'en')
  }, [language, setLanguage])

  return (
    <I18nContext.Provider value={{ language, setLanguage, t, toggleLanguage }}>
      {children}
    </I18nContext.Provider>
  )
}

export function useI18n() {
  const context = useContext(I18nContext)
  if (!context) {
    throw new Error('useI18n must be used within an I18nProvider')
  }
  return context
}

export type { Language, TranslationKey }
