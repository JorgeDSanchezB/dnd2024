export const translations = {
  // Navigation
  create: 'Create',
  characters: 'Characters',
  sheet: 'Sheet',
  
  // Character Creation
  characterCreation: 'Character Creation',
  step: 'Step',
  of: 'of',
  next: 'Next',
  previous: 'Previous',
  cancel: 'Cancel',
  save: 'Save',
  delete: 'Delete',
  edit: 'Edit',
  createCharacter: 'Create Character',
  
  // Step 1 - Basics
  basics: 'Basics',
  characterName: 'Character Name',
  enterName: 'Enter character name',
  startingLevel: 'Starting Level',
  selectLevel: 'Select starting level',
  
  // Step 2 - Species
  selectSpecies: 'Select Species',
  species: 'Species',
  chooseSpecies: 'Choose your character\'s species',
  size: 'Size',
  speed: 'Speed',
  traits: 'Traits',
  
  // Step 3 - Class
  selectClass: 'Select Class',
  class: 'Class',
  chooseClass: 'Choose your character\'s class',
  primaryAbility: 'Primary Ability',
  hitDie: 'Hit Die',
  savingThrows: 'Saving Throws',
  skillProficiencies: 'Skill Proficiencies',
  armorTraining: 'Armor Training',
  weaponProficiencies: 'Weapon Proficiencies',
  startingEquipment: 'Starting Equipment',
  features: 'Features',
  spellcasting: 'Spellcasting',
  subclasses: 'Subclasses',
  
  // Step 4 - Background
  selectBackground: 'Select Background',
  background: 'Background',
  chooseBackground: 'Choose your character\'s background',
  feat: 'Feat',
  toolProficiency: 'Tool Proficiency',
  equipment: 'Equipment',
  
  // Step 5 - Details
  details: 'Details',
  alignment: 'Alignment',
  selectAlignment: 'Select alignment',
  appearance: 'Appearance',
  describeAppearance: 'Describe your character\'s physical appearance',
  history: 'History',
  describeHistory: 'Describe your character\'s backstory and personality',
  
  // Alignments
  lawfulGood: 'Lawful Good',
  neutralGood: 'Neutral Good',
  chaoticGood: 'Chaotic Good',
  lawfulNeutral: 'Lawful Neutral',
  neutral: 'Neutral',
  chaoticNeutral: 'Chaotic Neutral',
  lawfulEvil: 'Lawful Evil',
  neutralEvil: 'Neutral Evil',
  chaoticEvil: 'Chaotic Evil',
  
  // Character Sheet
  characterSheet: 'Character Sheet',
  level: 'Level',
  xp: 'XP',
  levelUp: 'Level Up',
  shop: 'Shop',
  spellbook: 'Spellbook',
  exportPDF: 'Export PDF',
  
  // Ability Scores
  abilityScores: 'Ability Scores',
  strength: 'Strength',
  dexterity: 'Dexterity',
  constitution: 'Constitution',
  intelligence: 'Intelligence',
  wisdom: 'Wisdom',
  charisma: 'Charisma',
  str: 'STR',
  dex: 'DEX',
  con: 'CON',
  int: 'INT',
  wis: 'WIS',
  cha: 'CHA',
  
  // Combat
  combat: 'Combat',
  hitPoints: 'Hit Points',
  current: 'Current',
  max: 'Max',
  temp: 'Temp',
  armorClass: 'Armor Class',
  initiative: 'Initiative',
  proficiencyBonus: 'Proficiency Bonus',
  hitDice: 'Hit Dice',
  deathSaves: 'Death Saves',
  successes: 'Successes',
  failures: 'Failures',
  
  // Skills
  skills: 'Skills',
  proficient: 'Proficient',
  expertise: 'Expertise',
  acrobatics: 'Acrobatics',
  animalHandling: 'Animal Handling',
  arcana: 'Arcana',
  athletics: 'Athletics',
  deception: 'Deception',
  history: 'History',
  insight: 'Insight',
  intimidation: 'Intimidation',
  investigation: 'Investigation',
  medicine: 'Medicine',
  nature: 'Nature',
  perception: 'Perception',
  performance: 'Performance',
  persuasion: 'Persuasion',
  religion: 'Religion',
  sleightOfHand: 'Sleight of Hand',
  stealth: 'Stealth',
  survival: 'Survival',
  
  // Saving Throws
  savingThrowsTitle: 'Saving Throws',
  
  // Money
  money: 'Money',
  copper: 'CP',
  silver: 'SP',
  electrum: 'EP',
  gold: 'GP',
  platinum: 'PP',
  
  // Proficiencies
  proficiencies: 'Proficiencies',
  languages: 'Languages',
  tools: 'Tools',
  armor: 'Armor',
  weapons: 'Weapons',
  
  // Inventory
  inventory: 'Inventory',
  item: 'Item',
  quantity: 'Quantity',
  equipped: 'Equipped',
  attuned: 'Attuned',
  weight: 'Weight',
  cost: 'Cost',
  damage: 'Damage',
  damageType: 'Damage Type',
  properties: 'Properties',
  rarity: 'Rarity',
  type: 'Type',
  
  // Damage Types
  acid: 'Acid',
  bludgeoning: 'Bludgeoning',
  cold: 'Cold',
  fire: 'Fire',
  force: 'Force',
  lightning: 'Lightning',
  necrotic: 'Necrotic',
  piercing: 'Piercing',
  poison: 'Poison',
  psychic: 'Psychic',
  radiant: 'Radiant',
  slashing: 'Slashing',
  thunder: 'Thunder',
  
  // Spells
  spells: 'Spells',
  cantrips: 'Cantrips',
  level1: '1st Level',
  level2: '2nd Level',
  level3: '3rd Level',
  level4: '4th Level',
  level5: '5th Level',
  level6: '6th Level',
  level7: '7th Level',
  level8: '8th Level',
  level9: '9th Level',
  castingTime: 'Casting Time',
  range: 'Range',
  components: 'Components',
  duration: 'Duration',
  concentration: 'Concentration',
  ritual: 'Ritual',
  prepared: 'Prepared',
  known: 'Known',
  spellcastingAbility: 'Spellcasting Ability',
  spellSaveDC: 'Spell Save DC',
  spellAttackBonus: 'Spell Attack Bonus',
  addSpell: 'Add Spell',
  removeSpell: 'Remove Spell',
  
  // Spell Schools
  abjuration: 'Abjuration',
  conjuration: 'Conjuration',
  divination: 'Divination',
  enchantment: 'Enchantment',
  evocation: 'Evocation',
  illusion: 'Illusion',
  necromancy: 'Necromancy',
  transmutation: 'Transmutation',
  
  // Feats
  feats: 'Feats',
  addFeat: 'Add Feat',
  removeFeat: 'Remove Feat',
  category: 'Category',
  prerequisite: 'Prerequisite',
  benefit: 'Benefit',
  repeatable: 'Repeatable',
  
  // Class Features
  classFeatures: 'Class Features',
  speciesTraits: 'Species Traits',
  subclassFeatures: 'Subclass Features',
  
  // Character Details
  characterDetails: 'Character Details',
  personalityTraits: 'Personality Traits',
  ideals: 'Ideals',
  bonds: 'Bonds',
  flaws: 'Flaws',
  backstory: 'Backstory',
  
  // Shop
  buy: 'Buy',
  sell: 'Sell',
  price: 'Price',
  shopWeapons: 'Weapons',
  shopArmor: 'Armor',
  shopItems: 'Items',
  shopMagic: 'Magic Items',
  
  // Actions
  roll: 'Roll',
  attack: 'Attack',
  cast: 'Cast',
  use: 'Use',
  copy: 'Copy',
  duplicate: 'Duplicate',
  
  // Messages
  selectCharacterToView: 'Select a character to view its sheet.',
  viewCharacters: 'View Characters',
  noCharactersYet: 'No characters yet. Create your first character!',
  characterCreated: 'Character created successfully!',
  characterUpdated: 'Character updated successfully!',
  characterDeleted: 'Character deleted successfully!',
  confirmDelete: 'Are you sure you want to delete this character?',
  
  // Level Up
  levelUpAvailable: 'Level Up Available!',
  chooseASIOrFeat: 'Choose Ability Score Improvement or Feat',
  abilityScoreImprovement: 'Ability Score Improvement',
  selectFeat: 'Select Feat',
  newLevel: 'New Level',
  
  // Multiclass
  multiclass: 'Multiclass',
  newClass: 'New Class',
  
  // Misc
  name: 'Name',
  description: 'Description',
  notes: 'Notes',
  addNote: 'Add Note',
  editNote: 'Edit Note',
  noteTitle: 'Title',
  noteContent: 'Content',
  pinned: 'Pinned',
  
  // Sizes
  tiny: 'Tiny',
  small: 'Small',
  medium: 'Medium',
  large: 'Large',
  huge: 'Huge',
  gargantuan: 'Gargantuan',
  
  // Rarity
  common: 'Common',
  uncommon: 'Uncommon',
  rare: 'Rare',
  veryRare: 'Very Rare',
  legendary: 'Legendary',
  artifact: 'Artifact',
  
  // PDF Export
  characterSheetPDF: 'Character Sheet',
  allRightsReserved: 'All rights reserved',
  
  // Search and Filter
  search: 'Search',
  filter: 'Filter',
  all: 'All',
  none: 'None',
  
  // Encyclopedias
  monsters: 'Monsters',
  rules: 'Rules',
  
  // Summary
  summary: 'Summary',
  summaryCharacter: 'Character Summary',
  
  // Error/Success
  error: 'Error',
  success: 'Success',
  loading: 'Loading...',
  noData: 'No data available',
  
  // Toggle Language
  language: 'Language',
  spanish: 'Spanish',
  english: 'English',
  
  // Armor Properties
  light: 'Light',
  medium: 'Medium',
  heavy: 'Heavy',
  shield: 'Shield',
  stealthDisadvantage: 'Stealth Disadvantage',
  dexBonus: 'DEX Bonus',
  maxDexBonus: 'Max DEX Bonus',
  strRequired: 'STR Required',
  
  // Weapon Properties
  simple: 'Simple',
  martial: 'Martial',
  melee: 'Melee',
  ranged: 'Ranged',
  twoHanded: 'Two-Handed',
  versatile: 'Versatile',
  finesse: 'Finesse',
  reach: 'Reach',
  thrown: 'Thrown',
  ammunition: 'Ammunition',
  loadingWeapon: 'Loading',
  heavyWeapon: 'Heavy',
  lightWeapon: 'Light',
  lance: 'Lance',
  net: 'Net',
  pike: 'Pike',
  
  // Mastery
  mastery: 'Mastery',
  
  // Attunement
  attunement: 'Attunement',
  requiresAttunement: 'Requires Attunement',
  attunementRequirements: 'Attunement Requirements',
  
  // Character Sheet Card Titles
  spellcastingTitle: 'Spellcasting',
  skillsTitle: 'Skills',
  inventoryTitle: 'Inventory',
  speciesTitle: 'Species',
  featsTitle: 'Feats',
  classFeaturesTitle: 'Class Features',
  subclassFeaturesTitle: 'Subclass Features',
  combatTitle: 'Combat',
  moneyTitle: 'Money',
  proficienciesTitle: 'Proficiencies',
  backgroundTitle: 'Background',
  
  // Spellcasting
  spellDC: 'Spell DC',
  spellAttack: 'Attack',
  ability: 'Ability',
  cantripsTitle: 'Cantrips',
  spellsKnown: 'Spells Known',
  spellsPrepared: 'Spells Prepared',
  spellsByLevel: 'Spells by Level',
  spellSlots: 'Spell Slots',
  maxLevel: 'Max Level',
  longRest: 'Long Rest',
  effectiveLevel: 'Eff. Level',
  canLearnMoreCantrips: 'You can learn {count} more cantrips',
  canKnowMoreSpells: 'You can know {count} more spells',
  prepareFromSpellbook: 'Prepare {count} spells from your spellbook',
  prepareFromClassList: 'Prepare {count} spells from your class list',
  byClass: 'By Class:',
  
  // Spell Types
  knownSpells: 'Known Spells',
  preparedSpells: 'Prepared Spells',
  pactMagic: 'Pact Magic',
  noSpellcasting: 'No Spellcasting',
  bookPrepared: 'Spellbook (Prepared)',
  
  // Level Ordinals
  levelOrdinal1: '1st',
  levelOrdinal2: '2nd',
  levelOrdinal3: '3rd',
  levelOrdinal4: '4th',
  levelOrdinal5: '5th',
  levelOrdinal6: '6th',
  levelOrdinal7: '7th',
  levelOrdinal8: '8th',
  levelOrdinal9: '9th',
  levelSuffix: 'Level',
  
  // Skills (Short Names)
  athleticsShort: 'Athletics',
  acrobaticsShort: 'Acrobatics',
  sleightOfHandShort: 'Sleight of Hand',
  stealthShort: 'Stealth',
  arcanaShort: 'Arcana',
  historyShort: 'History',
  investigationShort: 'Investigation',
  natureShort: 'Nature',
  religionShort: 'Religion',
  animalHandlingShort: 'Animals',
  insightShort: 'Insight',
  medicineShort: 'Medicine',
  perceptionShort: 'Perception',
  survivalShort: 'Survival',
  deceptionShort: 'Deception',
  intimidationShort: 'Intimidation',
  performanceShort: 'Performance',
  persuasionShort: 'Persuasion',
  
  // Skill Status
  notProficient: 'Not Proficient',
  proficientSkill: 'Proficient',
  expertSkill: 'Expert',
  modifier: 'Modifier',
  
  // Inventory
  noItemsInInventory: 'No items in inventory',
  clickAddToEquip: 'Click "Add" to add equipment',
  objects: 'Objects',
  items: 'items',
  weapon: 'Weapon',
  armorItem: 'Armor',
  magicItem: 'Magic',
  itemItem: 'Item',
  equippedStatus: 'Equipped',
  attunedStatus: 'Attuned',
  
  // Combat Stats
  hp: 'HP',
  ac: 'AC',
  profBonus: 'Prof.',
  viewButton: 'View',
  copyCharacter: 'Copy character',
  yourCharacters: 'Your Characters',
  noCharactersCreated: 'You have no characters created.',
  
  // Death Saves
  deathSaveSuccess: 'Success',
  deathSaveFailure: 'Failure',
  deathSaveTitle: 'Death Saves',
  
  // Character Details
  noBackgroundStory: 'No background story written',
  noAppearance: 'No appearance description',
  
  // Class Feature Labels
  selectClassSkills: 'Select Class Skills',
  chooseCount: 'Choose',
  classSkillsAvailable: 'class skills available',
  selectClassToContinue: 'Select a class to continue',
  selected: 'Selected',
  spellcaster: 'Spellcaster',
  abilityLabel: 'Ability:',
  savesLabel: 'Saves:',
  skillsFromBackground: 'Skills from your background',
  allClassSkillsCovered: 'All class skills are already covered by your background.',
  
  // Species Selection
  requiresSelection: 'Requires selection',
  sizeLabel: 'Size:',
  speedLabel: 'Speed:',
  originFeatVersatile: 'Origin Feat (Versatile)',
  
  // Actions
  applyAndContinue: 'Apply and Continue',
  skipAutoApply: 'Skip (auto-apply)',
  selectAlignmentPrompt: 'Select alignment',
  
  // Background ASI
  plus2Plus1: '+2 to one, +1 to another',
  plus1All: '+1 to all listed',
  selectPlus2Ability: 'Select +2 Ability',
  selectPlus1Ability: 'Select +1 Ability',
  clickForPlus2: 'Click for +2',
  clickForPlus1: 'Click for +1',
  selectedPlus2: '+2 selected',
  selectedPlus1: '+1 selected',
  willApplyPlus1: 'Will apply +1 to:',
  goldPieces: 'Gold Pieces',
  noAdditionalItems: 'No additional items',
  
  // Misc
  select: 'Select',
  noneSelected: 'None selected',
  
  // Character Details Section
  characterDetailsTitle: 'Character Details',
  appearanceLabel: 'Appearance',
  historyLabel: 'History',
  alignmentLabel: 'Alignment',
  addAppearance: '+ Add appearance',
  addHistory: '+ Add history',
  addAlignment: '+ Add alignment',
  fieldsCount: 'fields',
  information: 'Information',
  
  // Class Section
  classTitle: 'Class',
  
  // Feats Section
  featsTitle: 'Feats',
  addFeatButton: 'Add Feat',
  noFeats: 'No feats. Add one to get started.',
  
  // Spells Section
  knownSpellsTitle: 'Known Spells',
  fromSpeciesTraits: 'From Species/Traits',
  spellsCount: 'spells',
  noKnownSpells: 'No known spells. Click the + button to add.',
  levelLabels: ['Cantrips', '1st Level', '2nd Level', '3rd Level', '4th Level', '5th Level', '6th Level', '7th Level', '8th Level', '9th Level'],
  
  // Currency Section
  coinsTitle: 'Coins',
  treasure: 'Treasure',
  
  // Proficiencies Section
  proficienciesTitle: 'Proficiencies',
  proficienciesCount: 'proficiencies',
  competenciesTitle: 'Competencies',
  toolsLabel: 'Tools',
  weaponsLabel: 'Weapons',
  armorLabel: 'Armor',
  none: 'None',
  
  // Notes Section
  quickNotes: 'Quick Notes',
  newNote: 'New Note',
  deleteAll: 'Delete All',
  noNotes: 'No notes. Click "New Note" to create one.',
  noContent: 'No content',
  
  // Combat Stats
  hitPointsLabel: 'Hit Points',
  passiveWisdom: 'Passive Wisdom',
  
  // Alignment translations
  lawfulGoodAlign: 'Lawful Good',
  neutralGoodAlign: 'Neutral Good',
  chaoticGoodAlign: 'Chaotic Good',
  lawfulNeutralAlign: 'Lawful Neutral',
  neutralAlign: 'Neutral',
  chaoticNeutralAlign: 'Chaotic Neutral',
  lawfulEvilAlign: 'Lawful Evil',
  neutralEvilAlign: 'Neutral Evil',
  chaoticEvilAlign: 'Chaotic Evil',
  
  // Spell source badges
  domainBadge: 'Domain',
  circleBadge: 'Circle',
  oathBadge: 'Oath',
  speciesBadge: 'Species',
  featBadge: 'Feat',
  prepBadge: 'Prep.',
};
