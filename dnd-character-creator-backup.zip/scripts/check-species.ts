import { db } from '../src/lib/db';

async function checkSpecies() {
  const species = await db.species.findMany({ orderBy: { name: 'asc' } });
  
  console.log('=== Species Traits Check ===\n');
  
  for (const sp of species) {
    console.log(`\n--- ${sp.name} ---`);
    console.log(`Traits raw: ${sp.traits}`);
    
    if (sp.traits) {
      try {
        const parsed = JSON.parse(sp.traits);
        console.log(`Parsed type: ${typeof parsed}`);
        if (Array.isArray(parsed)) {
          console.log(`Array length: ${parsed.length}`);
          parsed.forEach((item: any, idx: number) => {
            console.log(`  ${idx}: ${typeof item} - ${JSON.stringify(item).substring(0, 100)}`);
          });
        } else {
          console.log(`Not an array: ${JSON.stringify(parsed).substring(0, 100)}`);
        }
      } catch (e) {
        console.log(`Parse error: ${e}`);
      }
    }
  }
}

checkSpecies().catch(console.error);
