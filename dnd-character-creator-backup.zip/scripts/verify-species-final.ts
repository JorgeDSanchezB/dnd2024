import { db } from '../src/lib/db';

async function verifySpecies() {
  const species = await db.species.findMany({ orderBy: { name: 'asc' } });
  
  console.log('=== Species Traits Final Verification ===\n');
  
  for (const sp of species) {
    if (!sp.traits) {
      console.log(`⚠ ${sp.name}: No traits`);
      continue;
    }
    
    try {
      const parsed = JSON.parse(sp.traits);
      
      if (typeof parsed === 'object' && !Array.isArray(parsed)) {
        const keys = Object.keys(parsed);
        console.log(`✓ ${sp.name}: ${keys.length} traits (${keys.slice(0,3).join(', ')}${keys.length > 3 ? '...' : ''})`);
      } else {
        console.log(`✗ ${sp.name}: Wrong format - ${sp.traits.substring(0, 60)}...`);
      }
    } catch (e) {
      console.log(`✗ ${sp.name}: Parse error`);
    }
  }
  
  console.log('\n=== Done ===');
}

verifySpecies().catch(console.error);
