import { db } from '../src/lib/db';

async function fixFeatsJson() {
  console.log('=== Fixing Feats JSON fields ===\n');
  
  const feats = await db.feat.findMany();
  let fixedCount = 0;
  
  for (const feat of feats) {
    let needsFix = false;
    let updates: any = {};
    
    // Helper function to check and fix JSON
    const fixJsonField = (value: string | null, fieldName: string): string | null => {
      if (!value) return null;
      if (typeof value !== 'string') return value;
      if (value.startsWith('[')) return value;
      
      const items = value.split(',').map(s => s.trim()).filter(s => s);
      console.log(`  ${feat.name} - ${fieldName}: "${value}" -> ${JSON.stringify(items)}`);
      return JSON.stringify(items);
    };
    
    // Check all JSON fields
    if (feat.spellsGranted && typeof feat.spellsGranted === 'string' && !feat.spellsGranted.startsWith('[')) {
      updates.spellsGranted = fixJsonField(feat.spellsGranted, 'spellsGranted');
      needsFix = true;
    }
    
    if (feat.skillProficienciesGranted && typeof feat.skillProficienciesGranted === 'string' && !feat.skillProficienciesGranted.startsWith('[')) {
      updates.skillProficienciesGranted = fixJsonField(feat.skillProficienciesGranted, 'skillProficienciesGranted');
      needsFix = true;
    }
    
    if (feat.abilityScoreOptions && typeof feat.abilityScoreOptions === 'string' && !feat.abilityScoreOptions.startsWith('[')) {
      updates.abilityScoreOptions = fixJsonField(feat.abilityScoreOptions, 'abilityScoreOptions');
      needsFix = true;
    }
    
    if (feat.spellOptions && typeof feat.spellOptions === 'string' && !feat.spellOptions.startsWith('[')) {
      updates.spellOptions = fixJsonField(feat.spellOptions, 'spellOptions');
      needsFix = true;
    }
    
    if (needsFix) {
      await db.feat.update({
        where: { id: feat.id },
        data: updates
      });
      fixedCount++;
    }
  }
  
  console.log(`\n=== Fixed ${fixedCount} feats! ===`);
}

fixFeatsJson().catch(console.error);
