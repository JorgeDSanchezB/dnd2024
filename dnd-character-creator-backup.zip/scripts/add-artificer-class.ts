import { db } from '../src/lib/db';

async function addArtificer() {
  console.log('=== Adding Artificer Class ===\n');
  
  // Check if Artificer already exists
  const existing = await db.characterClass.findFirst({
    where: { name: 'Artificer' }
  });
  
  if (existing) {
    console.log('Artificer already exists with ID:', existing.id);
    return;
  }
  
  // Create Artificer class
  const artificer = await db.characterClass.create({
    data: {
      name: 'Artificer',
      description: 'A supreme inventor who channels magic into objects, creating tools that blend science and spellcraft. Artificers view magic as a complex system waiting to be decoded and redirected.',
      primaryAbility: 'Intelligence',
      hitDie: 8, // d8
      savingThrows: JSON.stringify(['Constitution', 'Intelligence']),
      skillProficiencies: JSON.stringify({
        count: 3,
        options: ['Arcana', 'History', 'Investigation', 'Medicine', 'Nature', 'Perception', 'Sleight of Hand']
      }),
      armorTraining: JSON.stringify(['Light Armor', 'Medium Armor', 'Shields']),
      weaponProficiencies: JSON.stringify(['Simple Weapons']),
      startingEquipment: JSON.stringify({
        A: { items: ['Two Daggers', 'Light Crossbow', '20 Bolts', "Thieves' Tools", 'Leather Armor', "Dungeoneer's Pack"], gold: 8 },
        B: { items: ['Handaxe', 'Light Hammer', 'Any Simple Weapon', "Thieves' Tools", 'Leather Armor', "Dungeoneer's Pack"], gold: 8 }
      }),
      features: JSON.stringify([
        {
          level: 1,
          name: 'Magical Tinkering',
          description: 'You can cast Magical Tinkering and Prestidigitation at will. You know three cantrips of your choice from the Artificer spell list.'
        },
        {
          level: 1,
          name: 'Artificer Specialist',
          description: 'You choose an Artificer Specialist subclass at 1st level: Alchemist, Armorer, Artillerist, Battle Smith, or Cartographer.'
        },
        {
          level: 1,
          name: 'Spellcasting',
          description: 'You have learned to cast spells. Intelligence is your spellcasting ability. You can cast artificer spells using any spellcasting focus.'
        },
        {
          level: 2,
          name: 'Infuse Item',
          description: "You've gained the ability to imbue mundane items with certain magical infusions. You know 4 infusions and can use 2 at a time. The number increases at higher levels."
        },
        {
          level: 2,
          name: 'Artificer Infusions',
          description: 'Available infusions: Boots of the Winding Path, Enhanced Arcane Focus, Enhanced Defense, Enhanced Weapon, Homunculus Servant, Lantern of Revealing, Repeating Shot, Replicate Magic Item, Resistant Armor, Returning Weapon.'
        },
        {
          level: 3,
          name: 'The Right Tool for the Job',
          description: "You can produce any artisan's tools using your thieves' tools and 1 hour of work."
        },
        {
          level: 5,
          name: 'Tool Expertise',
          description: 'Your proficiency bonus is doubled for any ability check you make that uses your proficiency with a tool.'
        },
        {
          level: 6,
          name: 'Flash of Genius',
          description: 'When you or another creature within 30 feet makes an ability check or saving throw, you can use your reaction to add your Intelligence modifier to the roll. You can use this feature a number of times equal to your Intelligence modifier per long rest.'
        },
        {
          level: 7,
          name: 'Magic Item Adept',
          description: 'You can attune to up to four magic items at once. You ignore all class, race, spell, and level requirements on attuning to magic items.'
        },
        {
          level: 10,
          name: 'Magic Item Savant',
          description: 'You can attune to up to five magic items at once. You ignore all requirements on attuning to magic items. You can craft magic items in half the normal time.'
        },
        {
          level: 11,
          name: 'Spell-Storing Item',
          description: 'You can store a spell in an object. When a creature uses an action to use the object, the spell is cast. The object has a number of charges equal to twice your Intelligence modifier.'
        },
        {
          level: 14,
          name: 'Magic Item Master',
          description: 'You can attune to up to six magic items at once.'
        },
        {
          level: 18,
          name: 'Soul of Artifice',
          description: 'You have a +1 bonus to all saving throws per magic item you are attuned to. If you drop to 0 hit points, you can end one of your artificer infusions to drop to 1 hit point instead.'
        }
      ]),
      spellcasting: true
    }
  });
  
  console.log('✓ Created Artificer class:', artificer.id);
  
  // Create Artificer subclasses
  const subclasses = [
    {
      name: 'Alchemist',
      description: 'An artificer who masters the science of potions, elixirs, and transformative chemistry.',
      features: JSON.stringify([
        { level: 3, name: 'Experimental Elixir', description: 'You can create an Experimental Elixir as an action. When drunk, it grants one effect: Healing (2d4+Int), Swiftness (walking speed +10 ft for 1 hour), Resilience (1d4 to AC for 10 min), Boldness (1d4 to attack rolls for 10 min), Flight (10 min flying), or Transformation (alter appearance for 1 hour).' },
        { level: 3, name: 'Alchemical Savant', description: 'When you cast a spell using a spell slot that restores hit points or deals acid/fire/poison damage, you add your Intelligence modifier to one damage/healing roll.' },
        { level: 5, name: 'Alchemist Spells', description: "Expanded spells: Healing Word, Ray of Sickness, Flaming Sphere, Melf's Acid Arrow, Gaseous Form, Mass Healing Word." },
        { level: 9, name: 'Tool Proficiency', description: "Proficiency with Alchemist's Supplies." },
        { level: 14, name: 'Chemical Mastery', description: 'Resistance to acid and poison damage. Immunity to the poisoned condition. You can create two Experimental Elixirs per long rest without spending a spell slot.' }
      ])
    },
    {
      name: 'Armorer',
      description: 'An artificer who forges magical armor, becoming a living fortress on the battlefield.',
      features: JSON.stringify([
        { level: 3, name: 'Arcane Armor', description: 'You can turn any armor you are wearing into Arcane Armor. If you do so, you can use Intelligence instead of Strength for strength requirements. Armor can be donned/doffed instantly.' },
        { level: 3, name: 'Armor Model', description: "Choose Guardian (melee tank) or Infiltrator (ranged/stealth) model. Guardian: Extra 1d6 thunder damage on hits, enemies hit can't make opportunity attacks. Infiltrator: +1 AC, advantage on Stealth, built-in weapon." },
        { level: 5, name: 'Armorer Spells', description: 'Expanded spells: Magic Missile, Thunderwave, Mirror Image, Shatter, Hypnotic Pattern, Lightning Bolt.' },
        { level: 9, name: 'Armor Modifications', description: 'You can use any armor as an Arcane Focus. You can attach infusions to your armor.' },
        { level: 14, name: 'Perfected Armor', description: 'Guardian: When you hit a creature, it has disadvantage on attacks against others. Infiltrator: Your speed increases by 5 feet per armor.' }
      ])
    },
    {
      name: 'Artillerist',
      description: 'An artificer who summons magical cannons to devastate the battlefield.',
      features: JSON.stringify([
        { level: 3, name: 'Eldritch Cannon', description: 'As an action, you can summon a Small or Tiny cannon. Choose type: Flamethrower (15 ft cone, 2d8 fire), Force Ballista (120 ft range, 2d8 force, push 5 ft), or Protector (10 ft radius, 1d8+Int temp HP). Uses your spell attack for ranged.' },
        { level: 3, name: 'Arcane Firearm', description: 'You can use a wand/staff/rod as an Arcane Firearm. When you cast an artificer spell through it, add 1d8 fire damage.' },
        { level: 5, name: 'Artillerist Spells', description: 'Expanded spells: Shield, Scorching Ray, Shatter, Fireball, Ice Storm, Wall of Fire.' },
        { level: 9, name: 'Explosive Cannon', description: 'Your Eldritch Cannon deals 3d8 damage. You can command it to detonate as an action, dealing 3d8 damage in 20 ft radius.' },
        { level: 14, name: 'Fortified Position', description: 'You and allies have half cover when within 10 feet of your cannon. You can summon two cannons at once.' }
      ])
    },
    {
      name: 'Battle Smith',
      description: 'An artificer who fights alongside a magical Steel Defender companion.',
      features: JSON.stringify([
        { level: 3, name: 'Steel Defender', description: "You create a Steel Defender (Medium construct). It takes its turn immediately after yours. It can take reactions. If it dies, you can create a new one with 1 hour of work and 100 gp of materials." },
        { level: 3, name: 'Battle Ready', description: 'You gain proficiency with martial weapons. When you attack with a magic weapon, you use Intelligence for attack and damage.' },
        { level: 5, name: "Battle Smith Spells", description: "Expanded spells: Heroism, Shield of Faith, Branding Smite, Spiritual Weapon, Aura of Vitality, Crusader's Mantle." },
        { level: 9, name: 'Arcane Jolt', description: 'When your Steel Defender or you hit with a weapon attack, you can deal extra 2d6 force damage. When it heals, it restores extra 2d6 HP. Int mod uses per long rest.' },
        { level: 14, name: 'Improved Defender', description: 'Your Steel Defender gains a +2 bonus to AC. Your Arcane Jolt increases to 4d6.' }
      ])
    },
    {
      name: 'Cartographer',
      description: 'An artificer who channels magic through maps and charts, guiding allies through any terrain.',
      features: JSON.stringify([
        { level: 3, name: "Adventurer's Atlas", description: 'You can create magical maps. You and allies have advantage on navigation checks. You can cast Pass without Trace and Locate Object using your atlas.' },
        { level: 3, name: 'Mapping Magic', description: "You can use your maps as an Arcane Focus. You gain proficiency with Navigator's Tools and Cartographer's Tools." },
        { level: 5, name: 'Cartographer Spells', description: 'Expanded spells: Expeditious Retreat, Find Familiar, Misty Step, Locate Object, Sending, Phantom Steed.' },
        { level: 9, name: 'Detailed Directions', description: 'You can teleport to any location you have mapped. You can create short-range teleportation circles for your party.' },
        { level: 14, name: 'Master Navigator', description: 'You cannot be lost. You always know your exact location. You can create permanent teleportation circles.' }
      ])
    }
  ];
  
  for (const sub of subclasses) {
    const created = await db.subclass.create({
      data: {
        name: sub.name,
        description: sub.description,
        features: sub.features,
        classId: artificer.id
      }
    });
    console.log('✓ Created subclass:', created.name);
  }
  
  console.log('\n=== Artificer Class Added Successfully! ===');
}

addArtificer().catch(console.error);
