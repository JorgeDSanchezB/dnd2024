import { db } from '../src/lib/db';

async function fixAllEquipment() {
  console.log('=== Fixing ALL background equipment to JSON format ===\n');
  
  const backgrounds = await db.background.findMany();
  
  for (const bg of backgrounds) {
    if (!bg.equipment) continue;
    
    // Check if already in correct JSON format
    try {
      const parsed = JSON.parse(bg.equipment);
      if (parsed.A && parsed.B) {
        console.log(`✓ ${bg.name} - Already correct format`);
        continue;
      }
    } catch {}
    
    // Parse the text format and convert to JSON
    let equipmentJson: { A: { items: string[], gold: number }, B: { items: string[], gold: number } };
    
    const text = bg.equipment;
    
    // Pattern 1: "Choose A or B: (A) ... ; or (B) ..."
    const choosePattern = text.match(/Choose A or B:\s*\(A\)\s*([^;]+);\s*or\s*\(B\)\s*(.+)/i);
    
    if (choosePattern) {
      const partA = choosePattern[1].trim();
      const partB = choosePattern[2].trim();
      
      equipmentJson = {
        A: parseEquipmentPart(partA),
        B: parseEquipmentPart(partB)
      };
    } else {
      // Pattern 2: Just a list of items - put everything in option A, B gets 50 GP
      equipmentJson = {
        A: parseEquipmentPart(text),
        B: { items: [], gold: 50 }
      };
    }
    
    const newEquipment = JSON.stringify(equipmentJson);
    
    await db.background.update({
      where: { id: bg.id },
      data: { equipment: newEquipment }
    });
    
    console.log(`✓ Fixed: ${bg.name}`);
    console.log(`  A: ${equipmentJson.A.items.join(', ')} + ${equipmentJson.A.gold} GP`);
    console.log(`  B: ${equipmentJson.B.items.length > 0 ? equipmentJson.B.items.join(', ') + ' + ' : ''}${equipmentJson.B.gold} GP`);
  }
  
  console.log('\n=== Done! ===');
}

function parseEquipmentPart(text: string): { items: string[], gold: number } {
  const items: string[] = [];
  let gold = 0;
  
  // Extract gold amount (e.g., "19 GP", "50 GP", "4 GP")
  const goldMatch = text.match(/(\d+)\s*GP/i);
  if (goldMatch) {
    gold = parseInt(goldMatch[1]);
    text = text.replace(goldMatch[0], '').trim();
  }
  
  // Split by comma, but be careful with parentheses
  const parts = text.split(',').map(s => s.trim()).filter(s => s);
  
  for (let part of parts) {
    // Clean up the part
    part = part.replace(/^,\s*/, '').replace(/\s*$/, '');
    if (part && part !== 'or' && part !== ';') {
      items.push(part);
    }
  }
  
  return { items, gold };
}

fixAllEquipment().catch(console.error);
