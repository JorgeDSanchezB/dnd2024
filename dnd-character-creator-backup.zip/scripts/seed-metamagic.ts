import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('Seeding Metamagic options...');

  const metamagicOptions = [
    {
      name: 'Careful Spell',
      nameEs: 'Hechizo Cuidadoso',
      description: 'When you cast a spell that forces other creatures to make a saving throw, you can protect some of those creatures from the spell\'s full force. To do so, you spend 1 sorcery point and choose a number of those creatures up to your Charisma modifier (minimum of one creature). A chosen creature automatically succeeds on its saving throw against the spell.',
      descriptionEs: 'Cuando lanzas un hechizo que obliga a otras criaturas a realizar una tirada de salvación, puedes proteger a algunas de esas criaturas de la fuerza completa del hechizo. Para hacerlo, gastas 1 punto de hechicería y eliges un número de esas criaturas hasta tu modificador de Carisma (mínimo una criatura). Una criatura elegida tiene éxito automáticamente en su tirada de salvación contra el hechizo.',
      sorceryPointCost: 1,
      isVariableCost: false,
      prerequisiteLevel: 2,
      source: "Player's Handbook 2024"
    },
    {
      name: 'Distant Spell',
      nameEs: 'Hechizo Distante',
      description: 'When you cast a spell that has a range of 5 feet or greater, you can spend 1 sorcery point to double the range of the spell. When you cast a spell that has a range of touch, you can spend 1 sorcery point to make the range of the spell 30 feet.',
      descriptionEs: 'Cuando lanzas un hechizo que tiene un alcance de 5 pies o más, puedes gastar 1 punto de hechicería para duplicar el alcance del hechizo. Cuando lanzas un hechizo que tiene un alcance de toque, puedes gastar 1 punto de hechicería para que el alcance del hechizo sea de 30 pies.',
      sorceryPointCost: 1,
      isVariableCost: false,
      prerequisiteLevel: 2,
      source: "Player's Handbook 2024"
    },
    {
      name: 'Empowered Spell',
      nameEs: 'Hechizo Potenciado',
      description: 'When you roll damage for a spell, you can spend 1 sorcery point to reroll a number of the damage dice up to your Charisma modifier (minimum of one). You must use this reroll before you know if the roll succeeds or fails, and you must use the new rolls.',
      descriptionEs: 'Cuando tiras daño para un hechizo, puedes gastar 1 punto de hechicería para volver a tirar un número de dados de daño hasta tu modificador de Carisma (mínimo uno). Debes usar esta repetición antes de saber si la tirada tiene éxito o falla, y debes usar los nuevos resultados.',
      sorceryPointCost: 1,
      isVariableCost: false,
      prerequisiteLevel: 2,
      source: "Player's Handbook 2024"
    },
    {
      name: 'Extended Spell',
      nameEs: 'Hechizo Extendido',
      description: 'When you cast a spell that has a duration of 1 minute or longer, you can spend 1 sorcery point to double its duration, to a maximum duration of 24 hours.',
      descriptionEs: 'Cuando lanzas un hechizo que tiene una duración de 1 minuto o más, puedes gastar 1 punto de hechicería para duplicar su duración, hasta una duración máxima de 24 horas.',
      sorceryPointCost: 1,
      isVariableCost: false,
      prerequisiteLevel: 2,
      source: "Player's Handbook 2024"
    },
    {
      name: 'Heightened Spell',
      nameEs: 'Hechizo Intensificado',
      description: 'When you cast a spell that forces a creature to make a saving throw to resist its effects, you can spend 3 sorcery points to give one target of the spell disadvantage on its first saving throw made against the spell.',
      descriptionEs: 'Cuando lanzas un hechizo que obliga a una criatura a realizar una tirada de salvación para resistir sus efectos, puedes gastar 3 puntos de hechicería para dar a un objetivo del hechizo desventaja en su primera tirada de salvación realizada contra el hechizo.',
      sorceryPointCost: 3,
      isVariableCost: false,
      prerequisiteLevel: 2,
      source: "Player's Handbook 2024"
    },
    {
      name: 'Quickened Spell',
      nameEs: 'Hechizo Acelerado',
      description: 'When you cast a spell that has a casting time of 1 action, you can spend 2 sorcery points to change the casting time to 1 bonus action for this casting.',
      descriptionEs: 'Cuando lanzas un hechizo que tiene un tiempo de lanzamiento de 1 acción, puedes gastar 2 puntos de hechicería para cambiar el tiempo de lanzamiento a 1 acción adicional para este lanzamiento.',
      sorceryPointCost: 2,
      isVariableCost: false,
      prerequisiteLevel: 2,
      source: "Player's Handbook 2024"
    },
    {
      name: 'Subtle Spell',
      nameEs: 'Hechizo Sutil',
      description: 'When you cast a spell, you can spend 1 sorcery point to cast it without any somatic or verbal components.',
      descriptionEs: 'Cuando lanzas un hechizo, puedes gastar 1 punto de hechicería para lanzarlo sin ningún componente somático o verbal.',
      sorceryPointCost: 1,
      isVariableCost: false,
      prerequisiteLevel: 2,
      source: "Player's Handbook 2024"
    },
    {
      name: 'Twinned Spell',
      nameEs: 'Hechizo Doble',
      description: 'When you cast a spell that targets only one creature and doesn\'t have a range of self, you can spend a number of sorcery points equal to the spell\'s level to target a second creature in range with the same spell (1 sorcery point if the spell is a cantrip). To be eligible for Twinned Spell, a spell must be incapable of targeting more than one creature at the spell\'s current level.',
      descriptionEs: 'Cuando lanzas un hechizo que tiene como objetivo solo una criatura y no tiene un alcance de uno mismo, puedes gastar una cantidad de puntos de hechicería igual al nivel del hechizo para objetivo a una segunda criatura en el alcance con el mismo hechizo (1 punto de hechicería si el hechizo es un truco). Para ser elegible para Hechizo Doble, un hechizo debe ser incapaz de objetivo a más de una criatura al nivel actual del hechizo.',
      sorceryPointCost: 1,
      isVariableCost: true,
      prerequisiteLevel: 2,
      source: "Player's Handbook 2024"
    },
    // Additional Metamagic from Tasha's Cauldron / 2024 expansions
    {
      name: 'Seeking Spell',
      nameEs: 'Hechizo Buscador',
      description: 'If you make an attack roll for a spell and miss, you can spend 2 sorcery points to reroll the attack roll. You must use this reroll before you know if the roll succeeds or fails, and you must use the new roll.',
      descriptionEs: 'Si realizas una tirada de ataque para un hechizo y fallas, puedes gastar 2 puntos de hechicería para volver a tirar la tirada de ataque. Debes usar esta repetición antes de saber si la tirada tiene éxito o falla, y debes usar la nueva tirada.',
      sorceryPointCost: 2,
      isVariableCost: false,
      prerequisiteLevel: 2,
      source: "Tasha's Cauldron of Everything"
    },
    {
      name: 'Transmuted Spell',
      nameEs: 'Hechizo Transmutado',
      description: 'When you cast a spell that deals a type of damage from the following list, you can spend 1 sorcery point to change that damage type to one of the other listed types: acid, cold, fire, lightning, poison, thunder.',
      descriptionEs: 'Cuando lanzas un hechizo que inflige un tipo de daño de la siguiente lista, puedes gastar 1 punto de hechicería para cambiar ese tipo de daño a uno de los otros tipos listados: ácido, frío, fuego, rayo, veneno, trueno.',
      sorceryPointCost: 1,
      isVariableCost: false,
      prerequisiteLevel: 2,
      source: "Tasha's Cauldron of Everything"
    }
  ];

  for (const option of metamagicOptions) {
    const existing = await prisma.metamagicOption.findUnique({
      where: { name: option.name }
    });

    if (existing) {
      await prisma.metamagicOption.update({
        where: { name: option.name },
        data: option
      });
      console.log(`Updated: ${option.name}`);
    } else {
      await prisma.metamagicOption.create({
        data: option
      });
      console.log(`Created: ${option.name}`);
    }
  }

  console.log('Metamagic options seeded successfully!');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
