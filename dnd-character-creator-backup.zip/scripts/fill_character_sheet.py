#!/usr/bin/env python3
"""
D&D 2024 Character Sheet PDF Filler
Fills the official D&D 2024 character sheet with character data
"""

import sys
import json
import os
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from pypdf import PdfReader, PdfWriter
from io import BytesIO

# Page dimensions from the PDF
PAGE_WIDTH = 603.0
PAGE_HEIGHT = 774.0

def get_modifier(score):
    """Calculate ability modifier"""
    return (score - 10) // 2

def format_modifier(mod):
    """Format modifier with sign"""
    return f"+{mod}" if mod >= 0 else str(mod)

def fill_page1(c, char):
    """Fill the first page of the character sheet"""
    # Character name (centered in the name field)
    c.setFont("Helvetica-Bold", 12)
    c.drawString(25, PAGE_HEIGHT - 45, char.get('name', ''))
    
    # Level (in the level box)
    c.setFont("Helvetica-Bold", 14)
    c.drawString(270, PAGE_HEIGHT - 60, str(char.get('level', 1)))
    
    # Background
    c.setFont("Helvetica", 9)
    c.drawString(25, PAGE_HEIGHT - 68, char.get('background', {}).get('name', '')[:20])
    
    # Class
    c.drawString(150, PAGE_HEIGHT - 68, char.get('characterClass', {}).get('name', '')[:15])
    
    # XP
    c.setFont("Helvetica", 10)
    c.drawString(270, PAGE_HEIGHT - 82, str(char.get('xp', 0)))
    
    # Species
    c.setFont("Helvetica", 9)
    c.drawString(25, PAGE_HEIGHT - 90, char.get('species', {}).get('name', '')[:20])
    
    # Subclass
    c.drawString(150, PAGE_HEIGHT - 90, char.get('subclass', {}).get('name', '')[:15] if char.get('subclass') else '')
    
    # Armor Class
    c.setFont("Helvetica-Bold", 20)
    c.drawString(335, PAGE_HEIGHT - 50, str(char.get('armorClass', 10)))
    
    # Hit Points - Current and Max
    c.setFont("Helvetica-Bold", 16)
    current_hp = char.get('currentHp', 0)
    max_hp = char.get('maxHp', 0)
    temp_hp = char.get('tempHp', 0)
    c.drawString(400, PAGE_HEIGHT - 50, f"{current_hp}")
    c.drawString(400, PAGE_HEIGHT - 72, f"{max_hp}")
    if temp_hp > 0:
        c.setFont("Helvetica", 8)
        c.drawString(440, PAGE_HEIGHT - 50, f"+{temp_hp} temp")
    
    # Hit Dice
    c.setFont("Helvetica-Bold", 14)
    hit_dice_current = char.get('hitDiceCurrent', 1)
    hit_dice_max = char.get('hitDiceMax', 1)
    hit_dice_type = char.get('hitDiceType', 8)
    c.drawString(492, PAGE_HEIGHT - 50, f"{hit_dice_current}/{hit_dice_max}d{hit_dice_type}")
    
    # Death Saves
    death_successes = char.get('deathSaveSuccesses', 0)
    death_failures = char.get('deathSaveFailures', 0)
    c.setFont("Helvetica", 8)
    # Draw circles for death saves (successes)
    for i in range(3):
        x = 545 + (i * 12)
        if i < death_successes:
            c.circle(x, PAGE_HEIGHT - 55, 4, fill=1)
        else:
            c.circle(x, PAGE_HEIGHT - 55, 4, fill=0)
    # Draw circles for death saves (failures)
    for i in range(3):
        x = 545 + (i * 12)
        if i < death_failures:
            c.circle(x, PAGE_HEIGHT - 75, 4, fill=1)
        else:
            c.circle(x, PAGE_HEIGHT - 75, 4, fill=0)
    
    # Proficiency Bonus
    c.setFont("Helvetica-Bold", 14)
    c.drawString(45, PAGE_HEIGHT - 140, f"+{char.get('proficiencyBonus', 2)}")
    
    # Ability Scores
    abilities = [
        ('strength', 'FUE', 195),
        ('dexterity', 'DES', 265),
        ('constitution', 'CON', 335),
        ('intelligence', 'INT', 405),
        ('wisdom', 'SAB', 475),
        ('charisma', 'CAR', 545)
    ]
    
    for ability, abbr, y_offset in abilities:
        score = char.get(ability, 10)
        modifier = get_modifier(score)
        y_pos = PAGE_HEIGHT - y_offset
        
        # Score
        c.setFont("Helvetica-Bold", 18)
        c.drawCentredString(82, y_pos, str(score))
        
        # Modifier
        c.setFont("Helvetica-Bold", 12)
        c.drawCentredString(82, y_pos - 18, format_modifier(modifier))
    
    # Saving Throws
    saves = [
        ('saveStr', 'strength', 210),
        ('saveDex', 'dexterity', 232),
        ('saveCon', 'constitution', 254),
        ('saveInt', 'intelligence', 276),
        ('saveWis', 'wisdom', 298),
        ('saveCha', 'charisma', 320)
    ]
    
    for save_field, ability, y_offset in saves:
        is_proficient = char.get(save_field, False)
        score = char.get(ability, 10)
        modifier = get_modifier(score)
        if is_proficient:
            modifier += char.get('proficiencyBonus', 2)
        
        y_pos = PAGE_HEIGHT - y_offset
        # Circle for proficiency
        if is_proficient:
            c.circle(25, y_pos + 3, 3, fill=1)
        else:
            c.circle(25, y_pos + 3, 3, fill=0)
        
        # Modifier
        c.setFont("Helvetica", 10)
        c.drawString(35, y_pos, format_modifier(modifier))
    
    # Skills
    skills = [
        ('skillAcrobatics', 'dexterity', 232, 'Acrobacias'),
        ('skillAnimalHandling', 'wisdom', 246, 'Trato Animales'),
        ('skillArcana', 'intelligence', 260, 'Arcano'),
        ('skillAthletics', 'strength', 274, 'Atletismo'),
        ('skillDeception', 'charisma', 288, 'Engano'),
        ('skillHistory', 'intelligence', 302, 'Historia'),
        ('skillInsight', 'wisdom', 316, 'Perspicacia'),
        ('skillIntimidation', 'charisma', 330, 'Intimidacion'),
        ('skillInvestigation', 'intelligence', 344, 'Investigacion'),
        ('skillMedicine', 'wisdom', 358, 'Medicina'),
        ('skillNature', 'intelligence', 372, 'Naturaleza'),
        ('skillPerception', 'wisdom', 386, 'Percepcion'),
        ('skillPerformance', 'charisma', 400, 'Interpretacion'),
        ('skillPersuasion', 'charisma', 414, 'Persuasion'),
        ('skillReligion', 'intelligence', 428, 'Religion'),
        ('skillSleightOfHand', 'dexterity', 442, 'Juego Manos'),
        ('skillStealth', 'dexterity', 456, 'Sigilo'),
        ('skillSurvival', 'wisdom', 470, 'Supervivencia')
    ]
    
    # Expert skills
    expert_skills = {
        'skillAcrobatics': 'expertAcrobatics',
        'skillAnimalHandling': 'expertAnimalHandling',
        'skillArcana': 'expertArcana',
        'skillAthletics': 'expertAthletics',
        'skillDeception': 'expertDeception',
        'skillHistory': 'expertHistory',
        'skillInsight': 'expertInsight',
        'skillIntimidation': 'expertIntimidation',
        'skillInvestigation': 'expertInvestigation',
        'skillMedicine': 'expertMedicine',
        'skillNature': 'expertNature',
        'skillPerception': 'expertPerception',
        'skillPerformance': 'expertPerformance',
        'skillPersuasion': 'expertPersuasion',
        'skillReligion': 'expertReligion',
        'skillSleightOfHand': 'expertSleightOfHand',
        'skillStealth': 'expertStealth',
        'skillSurvival': 'expertSurvival'
    }
    
    for skill_field, ability, y_offset, skill_name in skills:
        is_proficient = char.get(skill_field, False)
        is_expert = char.get(expert_skills.get(skill_field, ''), False)
        score = char.get(ability, 10)
        modifier = get_modifier(score)
        if is_expert:
            modifier += char.get('proficiencyBonus', 2) * 2
        elif is_proficient:
            modifier += char.get('proficiencyBonus', 2)
        
        y_pos = PAGE_HEIGHT - y_offset
        # Circle for proficiency/expertise
        if is_expert:
            c.circle(25, y_pos + 3, 3, fill=1)
            c.circle(25, y_pos + 3, 4, fill=0)  # Outer circle for expertise
        elif is_proficient:
            c.circle(25, y_pos + 3, 3, fill=1)
        else:
            c.circle(25, y_pos + 3, 3, fill=0)
        
        # Modifier
        c.setFont("Helvetica", 9)
        c.drawString(35, y_pos, format_modifier(modifier))
    
    # Initiative
    c.setFont("Helvetica-Bold", 14)
    initiative = get_modifier(char.get('dexterity', 10))
    c.drawCentredString(270, PAGE_HEIGHT - 145, format_modifier(initiative))
    
    # Speed
    c.setFont("Helvetica-Bold", 14)
    c.drawCentredString(355, PAGE_HEIGHT - 145, str(char.get('speed', 30)))
    
    # Size - calculate from species
    size = char.get('species', {}).get('size', 'M')
    size_map = {'Tiny': 'T', 'Small': 'S', 'Medium': 'M', 'Large': 'L', 'Huge': 'H', 'Gargantuan': 'G'}
    size_letter = size_map.get(size, 'M')
    c.setFont("Helvetica-Bold", 14)
    c.drawCentredString(455, PAGE_HEIGHT - 145, size_letter)
    
    # Passive Perception
    c.setFont("Helvetica-Bold", 14)
    wis_mod = get_modifier(char.get('wisdom', 10))
    perception_bonus = 0
    if char.get('expertPerception', False):
        perception_bonus = char.get('proficiencyBonus', 2) * 2
    elif char.get('skillPerception', False):
        perception_bonus = char.get('proficiencyBonus', 2)
    passive_perception = 10 + wis_mod + perception_bonus
    c.drawCentredString(545, PAGE_HEIGHT - 145, str(passive_perception))
    
    # Languages
    c.setFont("Helvetica", 8)
    try:
        languages = json.loads(char.get('languages', '[]'))
        c.drawString(25, PAGE_HEIGHT - 725, ', '.join(languages)[:50])
    except:
        pass
    
    # Currency
    c.setFont("Helvetica", 10)
    c.drawString(490, PAGE_HEIGHT - 735, str(char.get('pp', 0)))
    c.drawString(520, PAGE_HEIGHT - 735, str(char.get('gp', 0)))
    c.drawString(550, PAGE_HEIGHT - 735, str(char.get('ep', 0)))
    c.drawString(490, PAGE_HEIGHT - 750, str(char.get('sp', 0)))
    c.drawString(520, PAGE_HEIGHT - 750, str(char.get('cp', 0)))

def fill_page2(c, char):
    """Fill the second page of the character sheet"""
    # Alignment
    c.setFont("Helvetica", 9)
    alignment = char.get('alignment', '')
    alignment_map = {
        'LG': 'Lawful Good', 'NG': 'Neutral Good', 'CG': 'Chaotic Good',
        'LN': 'Lawful Neutral', 'N': 'Neutral', 'CN': 'Chaotic Neutral',
        'LE': 'Lawful Evil', 'NE': 'Neutral Evil', 'CE': 'Chaotic Evil'
    }
    alignment_text = alignment_map.get(alignment, alignment)
    c.drawString(440, PAGE_HEIGHT - 300, alignment_text[:20])
    
    # Appearance
    c.setFont("Helvetica", 8)
    appearance = char.get('appearance', '') or ''
    # Split into lines and draw
    y_pos = PAGE_HEIGHT - 50
    for line in appearance[:200].split('\n')[:8]:
        c.drawString(450, y_pos, line[:30])
        y_pos -= 10
    
    # Backstory
    c.setFont("Helvetica", 8)
    backstory = char.get('backgroundStory', '') or ''
    y_pos = PAGE_HEIGHT - 360
    for line in backstory[:300].split('\n')[:12]:
        c.drawString(25, y_pos, line[:50])
        y_pos -= 10

def fill_pdf(character_data, output_path):
    """Main function to fill the PDF with character data"""
    # Load the template
    template_path = '/home/z/my-project/upload/DnD 2024 CharacterSheet.pdf'
    
    # Create a buffer for the overlay
    overlay_buffer = BytesIO()
    c = canvas.Canvas(overlay_buffer, pagesize=(PAGE_WIDTH, PAGE_HEIGHT))
    
    # Fill page 1
    fill_page1(c, character_data)
    c.showPage()
    
    # Fill page 2
    fill_page2(c, character_data)
    c.save()
    
    # Merge with template
    overlay_buffer.seek(0)
    
    # Read template
    template_reader = PdfReader(template_path)
    overlay_reader = PdfReader(overlay_buffer)
    
    # Create output
    writer = PdfWriter()
    
    # Merge first page
    page1 = template_reader.pages[0]
    overlay1 = overlay_reader.pages[0]
    page1.merge_page(overlay1)
    writer.add_page(page1)
    
    # Merge second page if exists
    if len(template_reader.pages) > 1:
        page2 = template_reader.pages[1]
        overlay2 = overlay_reader.pages[1]
        page2.merge_page(overlay2)
        writer.add_page(page2)
    
    # Write output
    with open(output_path, 'wb') as output:
        writer.write(output)
    
    return output_path

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Usage: python fill_character_sheet.py <character_json> <output_path>")
        sys.exit(1)
    
    character_json = sys.argv[1]
    output_path = sys.argv[2]
    
    try:
        character_data = json.loads(character_json)
        result = fill_pdf(character_data, output_path)
        print(f"PDF created: {result}")
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)
