import { db } from '../src/lib/db';

async function restoreSpellOptions() {
  console.log('Restoring spellOptions for specific feats...\n');
  
  const spellOptionsData: Record<string, string> = {
    "Fey-Touched": JSON.stringify({ schools: ["Divination", "Enchantment"], level1Spell: true, bonusSpell: "Misty Step" }),
    "Shadow-Touched": JSON.stringify({ schools: ["Illusion", "Necromancy"], level1Spell: true, bonusSpell: "Invisibility" }),
    "Ritual Caster": JSON.stringify({ ritualOnly: true }),
    "Spell Sniper": JSON.stringify({ attackCantrip: true }),
    "Magic Initiate": JSON.stringify({ cantripChoice: true, level1Choice: true })
  };
  
  for (const [name, spellOptions] of Object.entries(spellOptionsData)) {
    const feat = await db.feat.findFirst({ where: { name } });
    if (feat) {
      await db.feat.update({
        where: { id: feat.id },
        data: { spellOptions }
      });
      console.log(`Restored: ${name}`);
    }
  }
  
  console.log('\nDone!');
}

restoreSpellOptions().catch(console.error);
