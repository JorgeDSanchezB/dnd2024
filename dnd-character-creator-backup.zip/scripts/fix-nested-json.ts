import { db } from '../src/lib/db';

async function fixNestedJson() {
  console.log('=== Fixing Nested JSON in Characters ===\n');
  
  const characters = await db.character.findMany();
  
  for (const char of characters) {
    console.log(`\n--- ${char.name} ---`);
    const updates: any = {};
    
    // Fields to check
    const fields = ['toolProficiencies', 'weaponProficiencies', 'armorProficiencies', 'languages'];
    
    for (const field of fields) {
      const value = (char as any)[field];
      if (!value) continue;
      
      try {
        let parsed = JSON.parse(value);
        let needsFix = false;
        
        // Check if array contains JSON strings
        if (Array.isArray(parsed)) {
          const fixed: string[] = [];
          for (const item of parsed) {
            if (typeof item === 'string') {
              // Check if it's a JSON string
              if (item.startsWith('[') || item.startsWith('{')) {
                try {
                  const inner = JSON.parse(item);
                  if (Array.isArray(inner)) {
                    fixed.push(...inner.filter((s: any) => typeof s === 'string'));
                  } else if (typeof inner === 'string') {
                    fixed.push(inner);
                  }
                  needsFix = true;
                  console.log(`  ${field}: Fixed nested JSON - "${item.substring(0, 30)}..."`);
                } catch {
                  fixed.push(item);
                }
              } else {
                fixed.push(item);
              }
            }
          }
          if (needsFix) {
            updates[field] = JSON.stringify(fixed);
            console.log(`  ${field}: Result -> ${JSON.stringify(fixed)}`);
          }
        }
      } catch (e) {
        console.log(`  ${field}: Parse error`);
      }
    }
    
    if (Object.keys(updates).length > 0) {
      await db.character.update({
        where: { id: char.id },
        data: updates
      });
      console.log(`  ✓ Updated`);
    } else {
      console.log(`  ✓ All correct`);
    }
  }
  
  console.log('\n=== Done! ===');
}

fixNestedJson().catch(console.error);
