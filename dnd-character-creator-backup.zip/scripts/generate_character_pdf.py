#!/usr/bin/env python3
"""
Generate a comprehensive D&D 2024 character sheet PDF with ALL information
"""

import sys
import json
import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, 
    PageBreak, KeepTogether, HRFlowable, ListFlowable, ListItem
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# Register fonts
FONT_PATHS = {
    'Times New Roman': '/usr/share/fonts/truetype/english/Times-New-Roman.ttf',
    'SimHei': '/usr/share/fonts/truetype/chinese/SimHei.ttf',
}

for font_name, font_path in FONT_PATHS.items():
    if os.path.exists(font_path):
        pdfmetrics.registerFont(TTFont(font_name, font_path))

# Color scheme - minimalist
COLORS = {
    'primary': colors.HexColor('#2C3E50'),
    'secondary': colors.HexColor('#34495E'),
    'accent': colors.HexColor('#3498DB'),
    'light': colors.HexColor('#ECF0F1'),
    'text': colors.HexColor('#2C3E50'),
    'muted': colors.HexColor('#7F8C8D'),
    'white': colors.white,
    'success': colors.HexColor('#27AE60'),
    'danger': colors.HexColor('#E74C3C'),
    'header_bg': colors.HexColor('#1a365d'),
}

def create_styles():
    """Create paragraph styles for the PDF"""
    styles = getSampleStyleSheet()
    
    # Title style
    styles.add(ParagraphStyle(
        name='CharacterName',
        fontName='Times New Roman',
        fontSize=22,
        textColor=COLORS['primary'],
        alignment=TA_CENTER,
        spaceAfter=2*mm,
        leading=26,
    ))
    
    # Subtitle style
    styles.add(ParagraphStyle(
        name='Subtitle',
        fontName='Times New Roman',
        fontSize=11,
        textColor=COLORS['muted'],
        alignment=TA_CENTER,
        spaceAfter=4*mm,
    ))
    
    # Section header
    styles.add(ParagraphStyle(
        name='SectionHeader',
        fontName='Times New Roman',
        fontSize=14,
        textColor=COLORS['primary'],
        spaceBefore=6*mm,
        spaceAfter=3*mm,
        borderPadding=1*mm,
    ))
    
    # Subsection header
    styles.add(ParagraphStyle(
        name='SubsectionHeader',
        fontName='Times New Roman',
        fontSize=11,
        textColor=COLORS['secondary'],
        spaceBefore=4*mm,
        spaceAfter=2*mm,
    ))
    
    # Normal text
    styles.add(ParagraphStyle(
        name='CustomBodyText',
        fontName='Times New Roman',
        fontSize=9,
        textColor=COLORS['text'],
        alignment=TA_JUSTIFY,
        leading=12,
    ))
    
    # Small text
    styles.add(ParagraphStyle(
        name='SmallText',
        fontName='Times New Roman',
        fontSize=8,
        textColor=COLORS['muted'],
        alignment=TA_LEFT,
        leading=10,
    ))
    
    # Feature name
    styles.add(ParagraphStyle(
        name='FeatureName',
        fontName='Times New Roman',
        fontSize=10,
        textColor=COLORS['primary'],
        spaceBefore=2*mm,
        spaceAfter=1*mm,
    ))
    
    # Feature description
    styles.add(ParagraphStyle(
        name='FeatureDesc',
        fontName='Times New Roman',
        fontSize=9,
        textColor=COLORS['text'],
        alignment=TA_JUSTIFY,
        leading=11,
        leftIndent=5*mm,
    ))
    
    # Table cell
    styles.add(ParagraphStyle(
        name='TableCell',
        fontName='Times New Roman',
        fontSize=9,
        textColor=COLORS['text'],
        alignment=TA_CENTER,
        leading=11,
    ))
    
    # Table cell left aligned
    styles.add(ParagraphStyle(
        name='TableCellLeft',
        fontName='Times New Roman',
        fontSize=9,
        textColor=COLORS['text'],
        alignment=TA_LEFT,
        leading=11,
    ))
    
    # Table header
    styles.add(ParagraphStyle(
        name='TableHeader',
        fontName='Times New Roman',
        fontSize=9,
        textColor=COLORS['white'],
        alignment=TA_CENTER,
        leading=11,
    ))
    
    # Spell description
    styles.add(ParagraphStyle(
        name='SpellDesc',
        fontName='Times New Roman',
        fontSize=8,
        textColor=COLORS['text'],
        alignment=TA_JUSTIFY,
        leading=10,
    ))
    
    return styles

def create_ability_table(data: dict, styles) -> Table:
    """Create the ability scores table"""
    abilities = data['abilities']
    
    header_style = styles['TableHeader']
    cell_style = styles['TableCell']
    
    # Create header row
    headers = ['FUE', 'DES', 'CON', 'INT', 'SAB', 'CAR']
    header_row = [Paragraph(f'<b>{h}</b>', header_style) for h in headers]
    
    # Score row
    scores = [
        abilities['strength']['score'],
        abilities['dexterity']['score'],
        abilities['constitution']['score'],
        abilities['intelligence']['score'],
        abilities['wisdom']['score'],
        abilities['charisma']['score'],
    ]
    score_row = [Paragraph(str(s), cell_style) for s in scores]
    
    # Modifier row
    mods = [
        abilities['strength']['mod'],
        abilities['dexterity']['mod'],
        abilities['constitution']['mod'],
        abilities['intelligence']['mod'],
        abilities['wisdom']['mod'],
        abilities['charisma']['mod'],
    ]
    mod_row = [Paragraph(f'<b>{m}</b>', cell_style) for m in mods]
    
    # Saving throws row
    saves = data.get('saves', {})
    save_mods = []
    save_keys = ['strength', 'dexterity', 'constitution', 'intelligence', 'wisdom', 'charisma']
    for key in save_keys:
        save_data = saves.get(key, {'proficient': False, 'mod': 0})
        mod = save_data.get('mod', 0)
        mod_str = f"+{mod}" if mod >= 0 else str(mod)
        if save_data.get('proficient'):
            mod_str = f"*{mod_str}"
        save_mods.append(Paragraph(mod_str, cell_style))
    
    table_data = [header_row, score_row, mod_row, save_mods]
    
    col_widths = [25*mm] * 6
    table = Table(table_data, colWidths=col_widths)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), COLORS['primary']),
        ('TEXTCOLOR', (0, 0), (-1, 0), COLORS['white']),
        ('BACKGROUND', (0, 3), (-1, 3), COLORS['light']),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('FONTNAME', (0, 0), (-1, -1), 'Times New Roman'),
        ('FONTSIZE', (0, 0), (-1, 0), 9),
        ('FONTSIZE', (0, 1), (-1, -1), 11),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 3*mm),
        ('TOPPADDING', (0, 0), (-1, -1), 3*mm),
        ('GRID', (0, 0), (-1, -1), 0.5, COLORS['light']),
        ('BOX', (0, 0), (-1, -1), 1, COLORS['primary']),
    ]))
    
    return table

def create_skills_table(data: dict, styles) -> Table:
    """Create skills table with all modifiers"""
    header_style = styles['TableHeader']
    cell_style = styles['TableCell']
    cell_left = styles['TableCellLeft']
    
    skills = data.get('skills', [])
    proficiency = data.get('proficiencyBonus', 2)
    abilities = data.get('abilities', {})
    
    rows = [[Paragraph('<b>Habilidad</b>', header_style), 
             Paragraph('<b>Car</b>', header_style), 
             Paragraph('<b>Mod</b>', header_style),
             Paragraph('<b>Notas</b>', header_style)]]
    
    ability_map = {'FUE': 'strength', 'DES': 'dexterity', 'CON': 'constitution', 
                   'INT': 'intelligence', 'SAB': 'wisdom', 'CAR': 'charisma'}
    
    for skill in skills:
        ability_key = ability_map.get(skill.get('ability', 'FUE'), 'strength')
        ability_data = abilities.get(ability_key, {'mod': '+0'})
        base_mod = int(ability_data.get('mod', '0')) if isinstance(ability_data.get('mod'), str) else ability_data.get('mod', 0)
        if isinstance(base_mod, str):
            base_mod = int(base_mod.replace('+', ''))
        
        if skill.get('expertise'):
            mod = base_mod + (proficiency * 2)
            notes = '** Experto'
        elif skill.get('proficient'):
            mod = base_mod + proficiency
            notes = '* Competente'
        else:
            mod = base_mod
            notes = ''
        
        mod_str = f"+{mod}" if mod >= 0 else str(mod)
        
        rows.append([
            Paragraph(skill.get('name', 'Unknown'), cell_left),
            Paragraph(skill.get('ability', ''), cell_style),
            Paragraph(mod_str, cell_style),
            Paragraph(notes, cell_style),
        ])
    
    table = Table(rows, colWidths=[50*mm, 12*mm, 15*mm, 25*mm])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), COLORS['primary']),
        ('TEXTCOLOR', (0, 0), (-1, 0), COLORS['white']),
        ('ALIGN', (0, 0), (0, -1), 'LEFT'),
        ('ALIGN', (1, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('FONTNAME', (0, 0), (-1, -1), 'Times New Roman'),
        ('FONTSIZE', (0, 0), (-1, -1), 8),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 1.5*mm),
        ('TOPPADDING', (0, 0), (-1, -1), 1.5*mm),
        ('GRID', (0, 0), (-1, -1), 0.5, COLORS['light']),
        ('BOX', (0, 0), (-1, -1), 1, COLORS['primary']),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [COLORS['white'], COLORS['light']]),
    ]))
    
    return table

def create_combat_stats(data: dict, styles) -> list:
    """Create combat stats section"""
    elements = []
    cell_style = styles['TableCell']
    body_style = styles['CustomBodyText']
    
    # Combat basics
    hp = data.get('hp', {})
    hp_text = f"{hp.get('current', 0)}/{hp.get('max', 0)}"
    if hp.get('temp', 0) > 0:
        hp_text += f" (+{hp.get('temp', 0)} temporal)"
    
    hit_dice = data.get('hitDice', {})
    hd_str = f"{hit_dice.get('current', 0)}/{hit_dice.get('max', 0)}d{hit_dice.get('type', 8)}"
    
    combat_data = [
        ['Puntos de Golpe', hp_text, 'Clase de Armadura', str(data.get('ac', 10))],
        ['Iniciativa', f"+{data.get('initiative', 0)}" if data.get('initiative', 0) >= 0 else str(data.get('initiative', 0)), 'Velocidad', f"{data.get('speed', 30)} pies"],
        ['Bon. Competencia', f"+{data.get('proficiencyBonus', 2)}", 'Dados de Golpe', hd_str],
    ]
    
    table = Table(combat_data, colWidths=[35*mm, 30*mm, 35*mm, 30*mm])
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (0, -1), COLORS['light']),
        ('BACKGROUND', (2, 0), (2, -1), COLORS['light']),
        ('FONTNAME', (0, 0), (-1, -1), 'Times New Roman'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 2*mm),
        ('TOPPADDING', (0, 0), (-1, -1), 2*mm),
        ('GRID', (0, 0), (-1, -1), 0.5, COLORS['light']),
        ('BOX', (0, 0), (-1, -1), 1, COLORS['primary']),
    ]))
    
    elements.append(table)
    return elements

def create_money_table(data: dict, styles) -> Table:
    """Create money table"""
    cell_style = styles['TableCell']
    money = data.get('money', {})
    
    rows = [
        [Paragraph('<b>PC</b>', cell_style), Paragraph('<b>PP</b>', cell_style), 
         Paragraph('<b>PE</b>', cell_style), Paragraph('<b>PO</b>', cell_style), 
         Paragraph('<b>PP</b>', cell_style)],
        [Paragraph(str(money.get('cp', 0)), cell_style), 
         Paragraph(str(money.get('sp', 0)), cell_style),
         Paragraph(str(money.get('ep', 0)), cell_style), 
         Paragraph(str(money.get('gp', 0)), cell_style),
         Paragraph(str(money.get('pp', 0)), cell_style)],
    ]
    
    table = Table(rows, colWidths=[18*mm] * 5)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), COLORS['accent']),
        ('TEXTCOLOR', (0, 0), (-1, 0), COLORS['white']),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('FONTNAME', (0, 0), (-1, -1), 'Times New Roman'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 2*mm),
        ('TOPPADDING', (0, 0), (-1, -1), 2*mm),
        ('GRID', (0, 0), (-1, -1), 0.5, COLORS['light']),
        ('BOX', (0, 0), (-1, -1), 1, COLORS['accent']),
    ]))
    
    return table

def add_features_list(elements: list, features: list, styles, title: str = None):
    """Add a list of features with descriptions"""
    feature_style = styles['FeatureName']
    desc_style = styles['FeatureDesc']
    
    if title:
        elements.append(Paragraph(f'<b>{title}</b>', styles['SubsectionHeader']))
    
    for feature in features:
        if isinstance(feature, dict):
            name = feature.get('name', 'Unknown')
            desc = feature.get('description', '') or feature.get('desc', '')
            if desc:
                elements.append(Paragraph(f'<b>• {name}</b>', feature_style))
                elements.append(Paragraph(desc, desc_style))
            else:
                elements.append(Paragraph(f'<b>• {name}</b>', feature_style))
        elif isinstance(feature, str):
            elements.append(Paragraph(f'<b>• {feature}</b>', feature_style))
    
    elements.append(Spacer(1, 2*mm))

def create_inventory_section(data: dict, styles) -> list:
    """Create detailed inventory section"""
    elements = []
    header_style = styles['TableHeader']
    cell_style = styles['TableCell']
    cell_left = styles['TableCellLeft']
    body_style = styles['CustomBodyText']
    
    inventory = data.get('inventory', [])
    
    if not inventory:
        return elements
    
    # Group by type
    weapons = [i for i in inventory if i.get('type') == 'weapon']
    armor = [i for i in inventory if i.get('type') == 'armor']
    magic = [i for i in inventory if i.get('type') == 'magic']
    items = [i for i in inventory if i.get('type') == 'item']
    
    if weapons:
        elements.append(Paragraph('<b>Armas</b>', styles['SubsectionHeader']))
        rows = [[Paragraph('<b>Nombre</b>', header_style), 
                 Paragraph('<b>Daño</b>', header_style),
                 Paragraph('<b>Tipo</b>', header_style),
                 Paragraph('<b>Propiedades</b>', header_style),
                 Paragraph('<b>Eq</b>', header_style)]]
        
        for w in weapons:
            rows.append([
                Paragraph(w.get('name', ''), cell_left),
                Paragraph(w.get('damage', ''), cell_style),
                Paragraph(w.get('damageType', ''), cell_style),
                Paragraph(w.get('properties', ''), cell_left),
                Paragraph('✓' if w.get('equipped') else '', cell_style),
            ])
        
        table = Table(rows, colWidths=[40*mm, 20*mm, 20*mm, 35*mm, 10*mm])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), COLORS['secondary']),
            ('TEXTCOLOR', (0, 0), (-1, 0), COLORS['white']),
            ('ALIGN', (0, 0), (0, -1), 'LEFT'),
            ('ALIGN', (1, 0), (-1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('FONTNAME', (0, 0), (-1, -1), 'Times New Roman'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 1.5*mm),
            ('TOPPADDING', (0, 0), (-1, -1), 1.5*mm),
            ('GRID', (0, 0), (-1, -1), 0.5, COLORS['light']),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [COLORS['white'], COLORS['light']]),
        ]))
        elements.append(table)
        elements.append(Spacer(1, 3*mm))
    
    if armor:
        elements.append(Paragraph('<b>Armaduras</b>', styles['SubsectionHeader']))
        rows = [[Paragraph('<b>Nombre</b>', header_style), 
                 Paragraph('<b>CA</b>', header_style),
                 Paragraph('<b>Tipo</b>', header_style),
                 Paragraph('<b>Propiedades</b>', header_style),
                 Paragraph('<b>Eq</b>', header_style)]]
        
        for a in armor:
            ac_str = str(a.get('baseAC', 10))
            if a.get('dexBonus'):
                max_dex = a.get('maxDexBonus', 99)
                if max_dex and max_dex < 99:
                    ac_str += f"+DES(max {max_dex})"
                else:
                    ac_str += "+DES"
            stealth = "Desv. Sigilo" if a.get('stealthDisadv') else ""
            
            rows.append([
                Paragraph(a.get('name', ''), cell_left),
                Paragraph(ac_str, cell_style),
                Paragraph(a.get('category', ''), cell_style),
                Paragraph(stealth, cell_left),
                Paragraph('✓' if a.get('equipped') else '', cell_style),
            ])
        
        table = Table(rows, colWidths=[40*mm, 25*mm, 20*mm, 30*mm, 10*mm])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), COLORS['secondary']),
            ('TEXTCOLOR', (0, 0), (-1, 0), COLORS['white']),
            ('ALIGN', (0, 0), (0, -1), 'LEFT'),
            ('ALIGN', (1, 0), (-1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('FONTNAME', (0, 0), (-1, -1), 'Times New Roman'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 1.5*mm),
            ('TOPPADDING', (0, 0), (-1, -1), 1.5*mm),
            ('GRID', (0, 0), (-1, -1), 0.5, COLORS['light']),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [COLORS['white'], COLORS['light']]),
        ]))
        elements.append(table)
        elements.append(Spacer(1, 3*mm))
    
    if magic:
        elements.append(Paragraph('<b>Objetos Mágicos</b>', styles['SubsectionHeader']))
        rows = [[Paragraph('<b>Nombre</b>', header_style), 
                 Paragraph('<b>Rareza</b>', header_style),
                 Paragraph('<b>Tipo</b>', header_style),
                 Paragraph('<b>Sinton</b>', header_style),
                 Paragraph('<b>Eq</b>', header_style)]]
        
        for m in magic:
            rows.append([
                Paragraph(m.get('name', ''), cell_left),
                Paragraph(m.get('rarity', ''), cell_style),
                Paragraph(m.get('itemType', ''), cell_style),
                Paragraph('Sí' if m.get('attunement') else 'No', cell_style),
                Paragraph('✓' if m.get('equipped') else '', cell_style),
            ])
        
        table = Table(rows, colWidths=[45*mm, 25*mm, 25*mm, 20*mm, 10*mm])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), COLORS['secondary']),
            ('TEXTCOLOR', (0, 0), (-1, 0), COLORS['white']),
            ('ALIGN', (0, 0), (0, -1), 'LEFT'),
            ('ALIGN', (1, 0), (-1, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('FONTNAME', (0, 0), (-1, -1), 'Times New Roman'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 1.5*mm),
            ('TOPPADDING', (0, 0), (-1, -1), 1.5*mm),
            ('GRID', (0, 0), (-1, -1), 0.5, COLORS['light']),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [COLORS['white'], COLORS['light']]),
        ]))
        elements.append(table)
        elements.append(Spacer(1, 3*mm))
        
        # Add descriptions for magic items
        for m in magic:
            if m.get('description'):
                elements.append(Paragraph(f'<i>{m.get("name")}: {m.get("description")}</i>', body_style))
                elements.append(Spacer(1, 2*mm))
    
    if items:
        elements.append(Paragraph('<b>Otros Objetos</b>', styles['SubsectionHeader']))
        rows = [[Paragraph('<b>Nombre</b>', header_style), 
                 Paragraph('<b>Categoría</b>', header_style),
                 Paragraph('<b>Cant</b>', header_style),
                 Paragraph('<b>Descripción</b>', header_style)]]
        
        for i in items:
            rows.append([
                Paragraph(i.get('name', ''), cell_left),
                Paragraph(i.get('category', ''), cell_style),
                Paragraph(str(i.get('quantity', 1)), cell_style),
                Paragraph((i.get('description', '') or '')[:50], cell_left),
            ])
        
        table = Table(rows, colWidths=[40*mm, 25*mm, 15*mm, 45*mm])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), COLORS['secondary']),
            ('TEXTCOLOR', (0, 0), (-1, 0), COLORS['white']),
            ('ALIGN', (0, 0), (0, -1), 'LEFT'),
            ('ALIGN', (2, 0), (2, -1), 'CENTER'),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('FONTNAME', (0, 0), (-1, -1), 'Times New Roman'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 1.5*mm),
            ('TOPPADDING', (0, 0), (-1, -1), 1.5*mm),
            ('GRID', (0, 0), (-1, -1), 0.5, COLORS['light']),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [COLORS['white'], COLORS['light']]),
        ]))
        elements.append(table)
        elements.append(Spacer(1, 3*mm))
    
    return elements

def create_spells_section(data: dict, styles) -> list:
    """Create detailed spells section"""
    elements = []
    header_style = styles['TableHeader']
    cell_style = styles['TableCell']
    cell_left = styles['TableCellLeft']
    body_style = styles['CustomBodyText']
    spell_style = styles['SpellDesc']
    
    spells = data.get('spells', [])
    
    if not spells:
        return elements
    
    # Spellcasting info
    if data.get('spellcastingAbility'):
        spell_info = f"<b>Habilidad de Conjuración:</b> {data.get('spellcastingAbility', '').upper()}"
        if data.get('spellSaveDC'):
            spell_info += f" | <b>CD:</b> {data.get('spellSaveDC')}"
        if data.get('spellAttackBonus'):
            spell_info += f" | <b>Bon. Ataque:</b> +{data.get('spellAttackBonus')}"
        elements.append(Paragraph(spell_info, body_style))
        elements.append(Spacer(1, 3*mm))
    
    # Group spells by level
    spell_levels = {i: [] for i in range(10)}
    for spell in spells:
        level = spell.get('level', 0)
        spell_levels[level].append(spell)
    
    level_names = ['Trucos', 'Nivel 1', 'Nivel 2', 'Nivel 3', 'Nivel 4', 
                   'Nivel 5', 'Nivel 6', 'Nivel 7', 'Nivel 8', 'Nivel 9']
    
    for level in range(10):
        if not spell_levels[level]:
            continue
        
        elements.append(Paragraph(f'<b>{level_names[level]}</b>', styles['SubsectionHeader']))
        
        for spell in spell_levels[level]:
            name = spell.get('name', 'Unknown')
            school = spell.get('school', '')
            casting = spell.get('castingTime', '')
            rng = spell.get('range', '')
            components = spell.get('components', '')
            duration = spell.get('duration', '')
            concentration = ' [C]' if spell.get('concentration') else ''
            ritual = ' [R]' if spell.get('ritual') else ''
            prepared = ' ✓' if spell.get('prepared') else ''
            desc = spell.get('description', '')
            
            # Header line
            header = f'<b>{name}</b> ({school}){concentration}{ritual}{prepared}'
            elements.append(Paragraph(header, body_style))
            
            # Details line
            details = f'<i>Tiempo: {casting} | Alcance: {rng} | Componentes: {components} | Duración: {duration}</i>'
            elements.append(Paragraph(details, spell_style))
            
            # Description
            if desc:
                # Truncate very long descriptions
                if len(desc) > 500:
                    desc = desc[:500] + '...'
                elements.append(Paragraph(desc, spell_style))
            
            elements.append(Spacer(1, 2*mm))
        
        elements.append(Spacer(1, 2*mm))
    
    return elements

def generate_pdf(data: dict, output_path: str):
    """Generate the complete character sheet PDF"""
    
    # Create document
    doc = SimpleDocTemplate(
        output_path,
        pagesize=A4,
        rightMargin=15*mm,
        leftMargin=15*mm,
        topMargin=15*mm,
        bottomMargin=15*mm,
        title=f"{data.get('name', 'Character')} - Hoja de Personaje",
        author='Z.ai',
        creator='Z.ai',
        subject='D&D 2024 Character Sheet',
    )
    
    styles = create_styles()
    story = []
    body_style = styles['CustomBodyText']
    
    # ========== HEADER ==========
    story.append(Paragraph(data.get('name', 'Personaje'), styles['CharacterName']))
    
    # Class and level info
    class_info = data.get('class', 'Sin clase')
    subclass = data.get('subclass')
    if subclass:
        class_info += f" ({subclass})"
    
    class_levels = data.get('classLevels', [])
    if class_levels and len(class_levels) > 1:
        class_parts = []
        for cl in class_levels:
            part = f"{cl.get('class', 'Unknown')} {cl.get('level', 1)}"
            if cl.get('subclass'):
                part += f" ({cl.get('subclass')})"
            class_parts.append(part)
        class_info = ' / '.join(class_parts)
    else:
        class_info = f"{class_info} Nivel {data.get('level', 1)}"
    
    subtitle = f"{class_info} | {data.get('species', 'Sin especie')} | {data.get('background', 'Sin trasfondo')}"
    if data.get('alignment'):
        subtitle += f" | {data.get('alignment')}"
    story.append(Paragraph(subtitle, styles['Subtitle']))
    
    story.append(HRFlowable(width="100%", thickness=1, color=COLORS['primary'], spaceAfter=4*mm))
    
    # ========== ABILITY SCORES ==========
    story.append(Paragraph('<b>Puntuaciones de Característica</b>', styles['SectionHeader']))
    story.append(create_ability_table(data, styles))
    story.append(Paragraph('<font size="7">* Tirada de salvación competente</font>', styles['SmallText']))
    story.append(Spacer(1, 4*mm))
    
    # ========== COMBAT STATS ==========
    story.append(Paragraph('<b>Estadísticas de Combate</b>', styles['SectionHeader']))
    story.extend(create_combat_stats(data, styles))
    story.append(Spacer(1, 4*mm))
    
    # ========== SKILLS ==========
    story.append(Paragraph('<b>Habilidades</b>', styles['SectionHeader']))
    story.append(create_skills_table(data, styles))
    story.append(Paragraph('<font size="7">* Competente | ** Experto</font>', styles['SmallText']))
    story.append(Spacer(1, 4*mm))
    
    # ========== MONEY ==========
    story.append(Paragraph('<b>Moneda</b>', styles['SectionHeader']))
    story.append(create_money_table(data, styles))
    story.append(Spacer(1, 4*mm))
    
    # ========== PROFICIENCIES ==========
    story.append(Paragraph('<b>Competencias</b>', styles['SectionHeader']))
    
    languages = data.get('languages', [])
    if languages:
        story.append(Paragraph(f'<b>Idiomas:</b> {", ".join(languages)}', body_style))
    
    tool_profs = data.get('toolProfs', [])
    if tool_profs:
        story.append(Paragraph(f'<b>Herramientas:</b> {", ".join(tool_profs)}', body_style))
    
    armor_profs = data.get('armorProfs', [])
    if armor_profs:
        story.append(Paragraph(f'<b>Armaduras:</b> {", ".join(armor_profs)}', body_style))
    
    weapon_profs = data.get('weaponProfs', [])
    if weapon_profs:
        story.append(Paragraph(f'<b>Armas:</b> {", ".join(weapon_profs)}', body_style))
    
    story.append(Spacer(1, 4*mm))
    
    # ========== CLASS FEATURES ==========
    class_features = data.get('classFeatures', [])
    if class_features:
        story.append(Paragraph('<b>Rasgos de Clase</b>', styles['SectionHeader']))
        if isinstance(class_features, list):
            add_features_list(story, class_features, styles)
        elif isinstance(class_features, str):
            story.append(Paragraph(class_features, body_style))
        story.append(Spacer(1, 4*mm))
    
    # ========== SUBCLASS FEATURES ==========
    subclass_features = data.get('subclassFeatures', [])
    if subclass_features:
        story.append(Paragraph('<b>Rasgos de Subclase</b>', styles['SectionHeader']))
        if isinstance(subclass_features, list):
            add_features_list(story, subclass_features, styles)
        elif isinstance(subclass_features, str):
            story.append(Paragraph(subclass_features, body_style))
        story.append(Spacer(1, 4*mm))
    
    # ========== SPECIES TRAITS ==========
    species_traits = data.get('speciesTraits', [])
    if species_traits:
        story.append(Paragraph('<b>Rasgos de Especie</b>', styles['SectionHeader']))
        if isinstance(species_traits, list):
            add_features_list(story, species_traits, styles)
        elif isinstance(species_traits, str):
            story.append(Paragraph(species_traits, body_style))
        story.append(Spacer(1, 4*mm))
    
    # ========== FEATS ==========
    feats = data.get('feats', [])
    if feats:
        story.append(Paragraph('<b>Dotes</b>', styles['SectionHeader']))
        for feat in feats:
            if isinstance(feat, dict):
                name = feat.get('name', 'Unknown')
                desc = feat.get('description', '') or feat.get('benefit', '')
                source = feat.get('source', '')
                story.append(Paragraph(f'<b>• {name}</b>{f" ({source})" if source else ""}', styles['FeatureName']))
                if desc:
                    story.append(Paragraph(desc, styles['FeatureDesc']))
            elif isinstance(feat, str):
                story.append(Paragraph(f'<b>• {feat}</b>', styles['FeatureName']))
        story.append(Spacer(1, 4*mm))
    
    # ========== SPELLS ==========
    spells_elements = create_spells_section(data, styles)
    if spells_elements:
        story.append(Paragraph('<b>Conjuros</b>', styles['SectionHeader']))
        story.extend(spells_elements)
    
    # ========== INVENTORY ==========
    inventory_elements = create_inventory_section(data, styles)
    if inventory_elements:
        story.append(Paragraph('<b>Inventario</b>', styles['SectionHeader']))
        story.extend(inventory_elements)
    
    # ========== CHARACTER DETAILS ==========
    story.append(PageBreak())
    story.append(Paragraph('<b>Detalles del Personaje</b>', styles['SectionHeader']))
    
    appearance = data.get('appearance')
    if appearance:
        story.append(Paragraph('<b>Apariencia</b>', styles['SubsectionHeader']))
        story.append(Paragraph(appearance, body_style))
        story.append(Spacer(1, 3*mm))
    
    background_story = data.get('backgroundStory')
    if background_story:
        story.append(Paragraph('<b>Trasfondo</b>', styles['SubsectionHeader']))
        story.append(Paragraph(background_story, body_style))
        story.append(Spacer(1, 3*mm))
    
    personality = data.get('personalityTraits')
    if personality:
        story.append(Paragraph('<b>Rasgos de Personalidad</b>', styles['SubsectionHeader']))
        story.append(Paragraph(personality, body_style))
        story.append(Spacer(1, 3*mm))
    
    ideals = data.get('ideals')
    if ideals:
        story.append(Paragraph('<b>Ideales</b>', styles['SubsectionHeader']))
        story.append(Paragraph(ideals, body_style))
        story.append(Spacer(1, 3*mm))
    
    bonds = data.get('bonds')
    if bonds:
        story.append(Paragraph('<b>Vínculos</b>', styles['SubsectionHeader']))
        story.append(Paragraph(bonds, body_style))
        story.append(Spacer(1, 3*mm))
    
    flaws = data.get('flaws')
    if flaws:
        story.append(Paragraph('<b>Defectos</b>', styles['SubsectionHeader']))
        story.append(Paragraph(flaws, body_style))
        story.append(Spacer(1, 3*mm))
    
    # Background equipment
    bg_equipment = data.get('backgroundEquipment')
    if bg_equipment:
        story.append(Paragraph('<b>Equipo de Trasfondo</b>', styles['SubsectionHeader']))
        story.append(Paragraph(bg_equipment, body_style))
        story.append(Spacer(1, 3*mm))
    
    # Notes
    notes = data.get('notes', [])
    if notes:
        story.append(Paragraph('<b>Notas</b>', styles['SectionHeader']))
        for note in notes:
            if isinstance(note, dict):
                title = note.get('title', '')
                content = note.get('content', '')
                story.append(Paragraph(f'<b>{title}</b>', styles['SubsectionHeader']))
                story.append(Paragraph(content, body_style))
                story.append(Spacer(1, 2*mm))
        story.append(Spacer(1, 4*mm))
    
    # Build PDF
    doc.build(story)
    print(f"PDF generated: {output_path}")

def main():
    if len(sys.argv) != 3:
        print("Usage: python generate_character_pdf.py <input_json> <output_pdf>")
        sys.exit(1)
    
    input_path = sys.argv[1]
    output_path = sys.argv[2]
    
    with open(input_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    generate_pdf(data, output_path)

if __name__ == '__main__':
    main()
