import { db } from '../src/lib/db'

async function main() {
  console.log('🌱 Seeding Forge of the Artificer data...')

  // ========================================
  // SPECIES - 5 new species from Eberron
  // ========================================
  console.log('\n📦 Adding Species...')

  const changeling = await db.species.upsert({
    where: { name: 'Changeling' },
    update: {},
    create: {
      name: 'Changeling',
      description: 'With ever-changing appearances, changelings reside in many societies undetected. Each changeling can supernaturally adopt any face they like. For some changelings, a new face may reveal an aspect of their soul. The first changelings in the multiverse appeared in the Feywild, and the wondrous, mutable essence of that plane lingers in changelings today.',
      size: 'Medium or Small',
      speed: 30,
      traits: JSON.stringify([
        { name: 'Creature Type', description: 'Fey' },
        { name: 'Size', description: 'Medium (about 4–7 feet tall) or Small (about 2–4 feet tall), chosen when you select this species' },
        { name: 'Speed', description: '30 feet' },
        { name: 'Changeling Instincts', description: 'Thanks to your connection to the fey realm, you gain proficiency in two of the following skills of your choice: Deception, Insight, Intimidation, Performance, or Persuasion.' },
        { name: 'Shape-Shifter', description: 'As an action, you can shape-shift to change your appearance and your voice. You determine the specifics of the changes, including your coloration, hair length, and sex. You can also adjust your height and weight and can change your size between Medium and Small. You can make yourself appear as a member of another playable species, though none of your game statistics change. You can\'t duplicate the appearance of an individual you\'ve never seen, and you must adopt a form that has the same basic arrangement of limbs that you have. This trait doesn\'t change your clothing and equipment. While shape-shifted with this trait, you have Advantage on Charisma checks. You stay in the new form until you take an action to revert to your true form.' }
      ])
    }
  })
  console.log('✓ Changeling created')

  const kalashtar = await db.species.upsert({
    where: { name: 'Kalashtar' },
    update: {},
    create: {
      name: 'Kalashtar',
      description: 'Kalashtar (pronounced kal-ASH-tar) are created from the union of humanity and renegade spirits called quori from the plane of dreams. Kalashtar appear human, but their spiritual connection affects them in a variety of ways. They have symmetrical, slightly angular features, and their eyes often glow when they are concentrating or expressing strong emotions.',
      size: 'Medium',
      speed: 30,
      traits: JSON.stringify([
        { name: 'Creature Type', description: 'Aberration' },
        { name: 'Size', description: 'Medium (about 6–7 feet tall)' },
        { name: 'Speed', description: '30 feet' },
        { name: 'Dual Mind', description: 'You have Advantage on Wisdom and Charisma saving throws.' },
        { name: 'Mental Discipline', description: 'You have Resistance to Psychic damage.' },
        { name: 'Mind Link', description: 'You have telepathy with a range in feet equal to 10 times your level. When you\'re using this trait to speak telepathically to a creature, you can take a Magic action to give that creature the ability to speak telepathically with you for 1 hour or until you take another Magic action to end this effect.' },
        { name: 'Severed from Dreams', description: 'You can\'t be the target of the Dream spell. In addition, when you finish a Long Rest, you gain proficiency in one skill of your choice. This proficiency lasts until you finish another Long Rest.' }
      ])
    }
  })
  console.log('✓ Kalashtar created')

  const khoravar = await db.species.upsert({
    where: { name: 'Khoravar' },
    update: {},
    create: {
      name: 'Khoravar',
      description: 'Over the course of centuries, those descended from both humans and elves have developed their own communities and traditions in Khorvaire. The rise of House Lyrandar and House Medani has strengthened this identity. Members of these communities call themselves Khoravar, an Elvish term meaning "children of Khorvaire," as they dislike the term "half-elf."',
      size: 'Medium or Small',
      speed: 30,
      traits: JSON.stringify([
        { name: 'Creature Type', description: 'Humanoid' },
        { name: 'Size', description: 'Medium (about 4–6 feet tall) or Small (about 2–4 feet tall), chosen when you select this species' },
        { name: 'Speed', description: '30 feet' },
        { name: 'Darkvision', description: 'You have Darkvision with a range of 60 feet.' },
        { name: 'Fey Ancestry', description: 'You have Advantage on saving throws you make to avoid or end the Charmed condition.' },
        { name: 'Fey Gift', description: 'You know the Friends cantrip. Whenever you finish a Long Rest, you can replace that cantrip with a different cantrip from the Cleric, Druid, or Wizard spell list. Intelligence, Wisdom, or Charisma is your spellcasting ability for the spell you cast with this trait (chosen when you select this species).' },
        { name: 'Lethargy Resilience', description: 'When you fail a saving throw to avoid or end the Unconscious condition, you can succeed instead. Once you use this trait, you can\'t do so again until you finish 1d4 Long Rests.' },
        { name: 'Skill Versatility', description: 'You gain proficiency in one skill or with one tool of your choice. Whenever you finish a Long Rest, you can replace it with another skill or tool proficiency.' }
      ])
    }
  })
  console.log('✓ Khoravar created')

  const shifter = await db.species.upsert({
    where: { name: 'Shifter' },
    update: {},
    create: {
      name: 'Shifter',
      description: 'Shifters—sometimes called "weretouched"—descend from people who contracted full or partial lycanthropy. Humanoids with a bestial aspect, shifters can\'t change shape fully, but they can enhance their animalistic features temporarily in a process they call "shifting."',
      size: 'Medium or Small',
      speed: 30,
      traits: JSON.stringify([
        { name: 'Creature Type', description: 'Humanoid' },
        { name: 'Size', description: 'Medium (about 4–7 feet tall) or Small (about 2–4 feet tall), chosen when you select this species' },
        { name: 'Speed', description: '30 feet' },
        { name: 'Bestial Instincts', description: 'Channeling the beast within, you gain proficiency in one of the following skills of your choice: Acrobatics, Athletics, Intimidation, or Survival.' },
        { name: 'Darkvision', description: 'You have Darkvision with a range of 60 feet.' },
        { name: 'Shifting', description: 'As a Bonus Action, you can shape-shift to assume a more bestial appearance. This transformation lasts for 1 minute or until you revert to your normal appearance as a Bonus Action. When you shift, you gain Temporary Hit Points equal to 2 times your Proficiency Bonus. You can shift a number of times equal to your Proficiency Bonus, and you regain all expended uses when you finish a Long Rest.' },
        { name: 'Beasthide', description: 'You gain 1d6 additional Temporary Hit Points when shifting. While shifted, you have a +1 bonus to your Armor Class.' },
        { name: 'Longtooth', description: 'When you shift and as a Bonus Action on your other turns while shifted, you can use your elongated fangs to make an Unarmed Strike dealing 1d6 + Strength modifier Piercing damage.' },
        { name: 'Swiftstride', description: 'While shifted, your Speed increases by 10 feet. Additionally, you can move up to 10 feet as a Reaction when a creature ends its turn within 5 feet of you. This reactive movement doesn\'t provoke Opportunity Attacks.' },
        { name: 'Wildhunt', description: 'While shifted, you have Advantage on Wisdom checks. Additionally, no creature within 30 feet of you can have Advantage on an attack roll against you unless you have the Incapacitated condition.' }
      ])
    }
  })
  console.log('✓ Shifter created')

  const warforged = await db.species.upsert({
    where: { name: 'Warforged' },
    update: {},
    create: {
      name: 'Warforged',
      description: 'Warforged are mechanical beings built as weapons to fight in the Last War. An unexpected breakthrough produced sentient beings made from wood and metal that nevertheless can feel pain and emotion. Warforged comprise a blend of organic and inorganic materials. Rootlike cords infused with alchemical fluids serve as their muscles, wrapped around a framework of steel, darkwood, or stone.',
      size: 'Medium or Small',
      speed: 30,
      traits: JSON.stringify([
        { name: 'Creature Type', description: 'Construct' },
        { name: 'Size', description: 'Medium (about 6–8 feet tall) or Small (about 3–4 feet tall), chosen when you select this species' },
        { name: 'Speed', description: '30 feet' },
        { name: 'Construct Resilience', description: 'You have Resistance to Poison damage. You also have Advantage on saving throws to avoid or end the Poisoned condition.' },
        { name: 'Integrated Protection', description: 'You gain a +1 bonus to your Armor Class. In addition, armor you have donned can\'t be removed against your will while you\'re alive.' },
        { name: 'Sentry\'s Rest', description: 'You don\'t need to sleep, and magic can\'t put you to sleep. You can finish a Long Rest in 6 hours if you spend those hours in an inactive, motionless state. During this time, you appear inert but remain conscious.' },
        { name: 'Specialized Design', description: 'You gain one skill proficiency and one tool proficiency of your choice.' },
        { name: 'Tireless', description: 'You don\'t gain Exhaustion levels from dehydration, malnutrition, or suffocation.' }
      ])
    }
  })
  console.log('✓ Warforged created')

  // ========================================
  // BACKGROUNDS - 17 Eberron backgrounds
  // ========================================
  console.log('\n📦 Adding Backgrounds...')

  const aberrantHeir = await db.background.upsert({
    where: { name: 'Aberrant Heir' },
    update: {},
    create: {
      name: 'Aberrant Heir',
      description: 'Your aberrant dragonmark has made life challenging since it manifested. You might have hidden it successfully for most of your life or managed to avoid notice. Alternatively, you might have encountered suspicion and fear, perhaps coupled with the outright antagonism of one or more dragonmarked houses.',
      abilityScores: '["Strength","Constitution","Charisma"]',
      feat: 'Aberrant Dragonmark',
      skillProficiencies: 'History, Intimidation',
      toolProficiency: 'Disguise Kit',
      equipment: 'Choose A or B: (A) Dagger, Disguise Kit, Costume, Traveler\'s Clothes, 16 GP; or (B) 50 GP'
    }
  })
  console.log('✓ Aberrant Heir created')

  const archaeologist = await db.background.upsert({
    where: { name: 'Archaeologist' },
    update: {},
    create: {
      name: 'Archaeologist',
      description: 'You\'ve made a lifelong study of the lost and fallen cultures of the past, visiting their ruins, deciphering their written records, and examining their surviving masterworks. Perhaps you studied at Morgrave University or a similar institution, supplementing your time in the library with fieldwork amid ancient ruins in remote locations.',
      abilityScores: '["Dexterity","Intelligence","Wisdom"]',
      feat: 'Skilled',
      skillProficiencies: 'History, Survival',
      toolProficiency: 'Cartographer\'s Tools',
      equipment: 'Choose A or B: (A) Cartographer\'s Tools, Bullseye Lantern, Map, Map or Scroll Case, Shovel, Tent, Traveler\'s Clothes, 17 GP; or (B) 50 GP'
    }
  })
  console.log('✓ Archaeologist created')

  const houseAgent = await db.background.upsert({
    where: { name: 'House Agent' },
    update: {},
    create: {
      name: 'House Agent',
      description: 'You are connected to one of the dragonmarked houses, but you haven\'t (yet) manifested a dragonmark. You might be a member of the family by birth or an employee of the house with no familial connection. You\'ve earned your living by doing the business of the house, serving as the hands, feet, and eyes of house leadership in the world.',
      abilityScores: '["Strength","Intelligence","Charisma"]',
      feat: 'Lucky',
      skillProficiencies: 'Investigation, Persuasion',
      toolProficiency: 'Choose one kind of Artisan\'s Tools',
      equipment: 'Choose A or B: (A) Artisan\'s Tools (same as above), Fine Clothes, 20 GP; or (B) 50 GP'
    }
  })
  console.log('✓ House Agent created')

  const houseCannithHeir = await db.background.upsert({
    where: { name: 'House Cannith Heir' },
    update: {},
    create: {
      name: 'House Cannith Heir',
      description: 'As a scion of House Cannith, you carry a proud legacy. Cannith creates wonders of the modern world, and you\'re expected to contribute to the ongoing success of the house through invention, scholarship, business, or diplomacy.',
      abilityScores: '["Strength","Dexterity","Intelligence"]',
      feat: 'Mark of Making',
      skillProficiencies: 'Investigation, Sleight of Hand',
      toolProficiency: 'Choose one kind of Artisan\'s Tools',
      equipment: 'Choose A or B: (A) Artisan\'s Tools (same as above), Crowbar, Fine Clothes, 2 Pouches, 17 GP; or (B) 50 GP'
    }
  })
  console.log('✓ House Cannith Heir created')

  const houseDeneithHeir = await db.background.upsert({
    where: { name: 'House Deneith Heir' },
    update: {},
    create: {
      name: 'House Deneith Heir',
      description: 'As an heir of House Deneith, you\'ve been trained for combat—not to seek it out, but not to shy from it either. You\'ve learned the importance of duty, honor, and the laws used to govern society when duty and honor fail.',
      abilityScores: '["Strength","Constitution","Wisdom"]',
      feat: 'Mark of Sentinel',
      skillProficiencies: 'Insight, Perception',
      toolProficiency: 'Choose one kind of Gaming Set',
      equipment: 'Choose A or B: (A) Spear, Shortbow, 20 Arrows, Gaming Set (same as above), Fine Clothes, Healer\'s Kit, Quiver, 1 GP; or (B) 50 GP'
    }
  })
  console.log('✓ House Deneith Heir created')

  const houseGhallandaHeir = await db.background.upsert({
    where: { name: 'House Ghallanda Heir' },
    update: {},
    create: {
      name: 'House Ghallanda Heir',
      description: 'Thanks to your connections to House Ghallanda, you grew up accustomed to creature comforts, lively conversation, good drink, and delicious food. You might be a charming and witty scion of the house who loves nothing more than a pleasant evening beside a warm hearth.',
      abilityScores: '["Dexterity","Wisdom","Charisma"]',
      feat: 'Mark of Hospitality',
      skillProficiencies: 'Insight, Persuasion',
      toolProficiency: 'Cook\'s Utensils',
      equipment: 'Choose A or B: (A) Cook\'s Utensils, Fine Clothes, Iron Pot, Lamp, Oil (5 flasks), Perfume, 26 GP; or (B) 50 GP'
    }
  })
  console.log('✓ House Ghallanda Heir created')

  const houseJorascoHeir = await db.background.upsert({
    where: { name: 'House Jorasco Heir' },
    update: {},
    create: {
      name: 'House Jorasco Heir',
      description: 'House Jorasco teaches that illness and injury stalk the living like ghosts, robbing people of health and longevity. You\'ve been taught ways to combat these scourges, both magically and medically. You\'re trained to use those skills in the service of others.',
      abilityScores: '["Dexterity","Constitution","Wisdom"]',
      feat: 'Mark of Healing',
      skillProficiencies: 'Medicine, Stealth',
      toolProficiency: 'Herbalism Kit',
      equipment: 'Choose A or B: (A) Herbalism Kit, Fine Clothes, Healer\'s Kit, 25 GP; or (B) 50 GP'
    }
  })
  console.log('✓ House Jorasco Heir created')

  const houseKundarakHeir = await db.background.upsert({
    where: { name: 'House Kundarak Heir' },
    update: {},
    create: {
      name: 'House Kundarak Heir',
      description: 'As an heir of House Kundarak, you take great pride in your family and its work of safeguarding the valuables of Khorvaire. Your house has always been a leader among the clans of the Mror Holds.',
      abilityScores: '["Strength","Constitution","Intelligence"]',
      feat: 'Mark of Warding',
      skillProficiencies: 'Arcana, Investigation',
      toolProficiency: 'Thieves\' Tools',
      equipment: 'Choose A or B: (A) Thieves\' Tools, Fine Clothes, 10 GP; or (B) 50 GP'
    }
  })
  console.log('✓ House Kundarak Heir created')

  const houseLyrandarHeir = await db.background.upsert({
    where: { name: 'House Lyrandar Heir' },
    update: {},
    create: {
      name: 'House Lyrandar Heir',
      description: 'As an heir of House Lyrandar, the wind is your ally, the sea and sky your dominion. Despite the devastation of the Last War, your house is on the ascendancy, buoyed by its mastery of the new airship technology.',
      abilityScores: '["Strength","Dexterity","Charisma"]',
      feat: 'Mark of Storm',
      skillProficiencies: 'Acrobatics, Nature',
      toolProficiency: 'Navigator\'s Tools',
      equipment: 'Choose A or B: (A) Navigator\'s Tools, Fine Clothes, 10 GP; or (B) 50 GP'
    }
  })
  console.log('✓ House Lyrandar Heir created')

  const houseMedaniHeir = await db.background.upsert({
    where: { name: 'House Medani Heir' },
    update: {},
    create: {
      name: 'House Medani Heir',
      description: 'As a member of House Medani, your life revolves around subterfuge—not engaging in it, but preventing others from doing so. You see the world around you as an intricate web of schemes, plots, and counterplots.',
      abilityScores: '["Dexterity","Intelligence","Wisdom"]',
      feat: 'Mark of Detection',
      skillProficiencies: 'Insight, Investigation',
      toolProficiency: 'Disguise Kit',
      equipment: 'Choose A or B: (A) Disguise Kit, Fine Clothes, 10 GP; or (B) 50 GP'
    }
  })
  console.log('✓ House Medani Heir created')

  const houseOrienHeir = await db.background.upsert({
    where: { name: 'House Orien Heir' },
    update: {},
    create: {
      name: 'House Orien Heir',
      description: 'Before the Last War, Orien\'s influence covered Khorvaire, and its trade roads and lightning rails were the lifeblood of a vibrant kingdom. But the war cut those arteries, leaving Galifar dead and House Orien bloodied.',
      abilityScores: '["Dexterity","Constitution","Intelligence"]',
      feat: 'Mark of Passage',
      skillProficiencies: 'Acrobatics, Athletics',
      toolProficiency: 'Cartographer\'s Tools',
      equipment: 'Choose A or B: (A) Cartographer\'s Tools, Fine Clothes, Map, Map or Scroll Case, 18 GP; or (B) 50 GP'
    }
  })
  console.log('✓ House Orien Heir created')

  const housePhiarlanHeir = await db.background.upsert({
    where: { name: 'House Phiarlan Heir' },
    update: {},
    create: {
      name: 'House Phiarlan Heir',
      description: 'Though you have seen wealth, fame, and beauty as a child of House Phiarlan, you consider knowledge (and the power it brings) the greatest treasure of all. You might pursue that power as an artist or performer.',
      abilityScores: '["Dexterity","Wisdom","Charisma"]',
      feat: 'Mark of Shadow',
      skillProficiencies: 'Deception, Stealth',
      toolProficiency: 'Disguise Kit',
      equipment: 'Choose A or B: (A) Disguise Kit, Fine Clothes, 10 GP; or (B) 50 GP'
    }
  })
  console.log('✓ House Phiarlan Heir created')

  const houseSivisHeir = await db.background.upsert({
    where: { name: 'House Sivis Heir' },
    update: {},
    create: {
      name: 'House Sivis Heir',
      description: 'For nearly thirty centuries, your family has worked to maintain order. Communication is the cord that binds civilization together, and your ancestors settled the disputes of sovereigns and helped the dragonmarked houses find a place in the world.',
      abilityScores: '["Intelligence","Wisdom","Charisma"]',
      feat: 'Mark of Scribing',
      skillProficiencies: 'History, Perception',
      toolProficiency: 'Calligrapher\'s Supplies',
      equipment: 'Choose A or B: (A) Calligrapher\'s Supplies, Fine Clothes, Ink, 5 Ink Pens, Paper (30 sheets), Parchment (9 sheets), 8 GP; or (B) 50 GP'
    }
  })
  console.log('✓ House Sivis Heir created')

  const houseTharashkHeir = await db.background.upsert({
    where: { name: 'House Tharashk Heir' },
    update: {},
    create: {
      name: 'House Tharashk Heir',
      description: 'Heirs of other houses lead lives of luxury, but in House Tharashk you learned self-reliance from an early age. What your young house lacks in resources, it makes up for in spirit and determination.',
      abilityScores: '["Constitution","Intelligence","Wisdom"]',
      feat: 'Mark of Finding',
      skillProficiencies: 'Perception, Survival',
      toolProficiency: 'Choose one kind of Gaming Set',
      equipment: 'Choose A or B: (A) Gaming Set (same as above), Climber\'s Kit, Fine Clothes, Hunting Trap, Manacles, 2 GP; or (B) 50 GP'
    }
  })
  console.log('✓ House Tharashk Heir created')

  const houseThuranniHeir = await db.background.upsert({
    where: { name: 'House Thuranni Heir' },
    update: {},
    create: {
      name: 'House Thuranni Heir',
      description: 'Given House Thuranni\'s short history and focus on espionage, its leaders expect you to further the interests of the house at every opportunity. During the house\'s formative years as an independent entity, every move you make has been watched closely.',
      abilityScores: '["Dexterity","Intelligence","Charisma"]',
      feat: 'Mark of Shadow',
      skillProficiencies: 'Performance, Stealth',
      toolProficiency: 'Choose one kind of Musical Instrument',
      equipment: 'Choose A or B: (A) Musical Instrument (same as above), Costume, Fine Clothes, 13 GP; or (B) 50 GP'
    }
  })
  console.log('✓ House Thuranni Heir created')

  const houseVadalisHeir = await db.background.upsert({
    where: { name: 'House Vadalis Heir' },
    update: {},
    create: {
      name: 'House Vadalis Heir',
      description: 'You have grown up with respect for both family and nature. You understand the culture of the Five Nations, but you don\'t get drawn into the games of ambition and status that others play.',
      abilityScores: '["Constitution","Wisdom","Charisma"]',
      feat: 'Mark of Handling',
      skillProficiencies: 'Animal Handling, Nature',
      toolProficiency: 'Herbalism Kit',
      equipment: 'Choose A or B: (A) Herbalism Kit, Fine Clothes, Net, 29 GP; or (B) 50 GP'
    }
  })
  console.log('✓ House Vadalis Heir created')

  const inquisitive = await db.background.upsert({
    where: { name: 'Inquisitive' },
    update: {},
    create: {
      name: 'Inquisitive',
      description: 'You have honed your talents of investigation and deduction—fueled by a boundless curiosity—to explore mysteries, find missing people, recover stolen goods, unearth corruption and conspiracies, and solve crimes.',
      abilityScores: '["Constitution","Intelligence","Charisma"]',
      feat: 'Alert',
      skillProficiencies: 'Insight, Investigation',
      toolProficiency: 'Thieves\' Tools',
      equipment: 'Choose A or B: (A) Thieves\' Tools, Bullseye Lantern, Crowbar, Oil (10 flasks), Traveler\'s Clothes, 10 GP; or (B) 50 GP'
    }
  })
  console.log('✓ Inquisitive created')

  // ========================================
  // FEATS - Dragonmark Feats (13)
  // ========================================
  console.log('\n📦 Adding Dragonmark Feats...')

  const aberrantDragonmark = await db.feat.upsert({
    where: { name: 'Aberrant Dragonmark' },
    update: {},
    create: {
      name: 'Aberrant Dragonmark',
      category: 'Dragonmark',
      prerequisite: 'Eberron Campaign, Can\'t Have Another Dragonmark Feat',
      description: 'You gain the following benefits.',
      benefit: 'Aberrant Fortitude: When you fail a Constitution saving throw, you can take a Reaction to roll 1d4 and add the number rolled to the save, potentially turning the failure into a success. Once you\'ve used this benefit, you can\'t use it again until you finish a Long Rest.\n\nAberrant Magic: You know one cantrip of your choice from the Sorcerer spell list. Also, choose a level 1 spell from that spell list. You always have that spell prepared. You can cast it once without a spell slot, and you regain the ability to cast it in that way when you finish a Short or Long Rest. You can also cast this spell using any spell slots you have. Constitution is your spellcasting ability for this spell.\n\nAberrant Surge: When you cast the level 1 spell from this feat, you can expend one of your Hit Point Dice and roll it. If you roll an even number, you gain a number of Temporary Hit Points equal to the number rolled. If you roll an odd number, one creature within 30 feet of you (not including you) takes Force damage equal to the number rolled.',
      repeatable: false,
      abilityScoreBonus: 0
    }
  })
  console.log('✓ Aberrant Dragonmark created')

  const markOfDetection = await db.feat.upsert({
    where: { name: 'Mark of Detection' },
    update: {},
    create: {
      name: 'Mark of Detection',
      category: 'Dragonmark',
      prerequisite: 'Eberron Campaign, Can\'t Have Another Dragonmark Feat',
      description: 'You gain the following benefits.',
      benefit: 'Deductive Intuition: When you make an Intelligence (Investigation) or Wisdom (Insight) check, you can roll 1d4 and add the number rolled to the ability check.\n\nMagical Detection: You always have the Detect Magic and Detect Poison and Disease spells prepared. You can cast each spell once without a spell slot, and you regain the ability to cast it in that way when you finish a Long Rest. You can also cast these spells using any spell slots you have of the appropriate level. Intelligence, Wisdom, or Charisma is your spellcasting ability for these spells (choose when you select this feat).\n\nWhen you reach character level 3, you also always have the See Invisibility spell prepared and can cast it the same way.\n\nSpells of the Mark: If you have the Spellcasting or Pact Magic class feature, the spells Detect Evil and Good, Identify, Detect Thoughts, Find Traps, Clairvoyance, Nondetection, Arcane Eye, Divination, and Legend Lore are added to that feature\'s spell list.',
      repeatable: false,
      abilityScoreBonus: 0,
      spellsGranted: 'Detect Magic, Detect Poison and Disease, See Invisibility (level 3+)'
    }
  })
  console.log('✓ Mark of Detection created')

  const markOfFinding = await db.feat.upsert({
    where: { name: 'Mark of Finding' },
    update: {},
    create: {
      name: 'Mark of Finding',
      category: 'Dragonmark',
      prerequisite: 'Eberron Campaign, Can\'t Have Another Dragonmark Feat',
      description: 'You gain the following benefits.',
      benefit: 'Hunter\'s Intuition: When you make a Wisdom (Perception or Survival) check, you can roll 1d4 and add the number rolled to the ability check.\n\nFinder\'s Magic: You always have the Hunter\'s Mark spell prepared. You can cast it once without a spell slot, and you regain the ability to cast it in that way when you finish a Long Rest. You can also cast it using any spell slots you have of the appropriate level.\n\nWhen you reach character level 3, you also always have the Locate Object spell prepared and can cast it the same way.\n\nSpells of the Mark: Faerie Fire, Longstrider, Locate Animals or Plants, Mind Spike, Clairvoyance, Speak with Plants, Divination, Locate Creature, Commune with Nature are added to your spell list if you have Spellcasting.',
      repeatable: false,
      abilityScoreBonus: 0,
      spellsGranted: 'Hunter\'s Mark, Locate Object (level 3+)'
    }
  })
  console.log('✓ Mark of Finding created')

  const markOfHandling = await db.feat.upsert({
    where: { name: 'Mark of Handling' },
    update: {},
    create: {
      name: 'Mark of Handling',
      category: 'Dragonmark',
      prerequisite: 'Eberron Campaign, Can\'t Have Another Dragonmark Feat',
      description: 'You gain the following benefits.',
      benefit: 'Wild Intuition: When you make an Intelligence (Nature) or Wisdom (Animal Handling) check, you can roll 1d4 and add the number rolled to the ability check.\n\nPrimal Connection: You always have the Animal Friendship and Speak with Animals spells prepared. You can cast each spell once without a spell slot, and you regain the ability to cast it in that way when you finish a Long Rest.\n\nMonstrous Connections: When you reach character level 3, you can target a Monstrosity when you cast Animal Friendship or Speak with Animals if the creature\'s Intelligence score is 3 or lower.\n\nSpells of the Mark: Command, Find Familiar, Beast Sense, Calm Emotions, Beacon of Hope, Conjure Animals, Aura of Life, Dominate Beast, Awaken are added to your spell list.',
      repeatable: false,
      abilityScoreBonus: 0,
      spellsGranted: 'Animal Friendship, Speak with Animals'
    }
  })
  console.log('✓ Mark of Handling created')

  const markOfHealing = await db.feat.upsert({
    where: { name: 'Mark of Healing' },
    update: {},
    create: {
      name: 'Mark of Healing',
      category: 'Dragonmark',
      prerequisite: 'Eberron Campaign, Can\'t Have Another Dragonmark Feat',
      description: 'You gain the following benefits.',
      benefit: 'Medical Intuition: When you make a Wisdom (Medicine) check or an ability check using a Herbalism Kit, you can roll 1d4 and add the number rolled to the ability check.\n\nHealing Touch: You always have the Cure Wounds spell prepared. You can cast it once without a spell slot, and you regain the ability to cast it in that way when you finish a Long Rest.\n\nWhen you reach character level 3, you also always have the Lesser Restoration spell prepared and can cast it the same way.\n\nSpells of the Mark: False Life, Healing Word, Arcane Vigor, Prayer of Healing, Aura of Vitality, Mass Healing Word, Aura of Life, Aura of Purity, Greater Restoration are added to your spell list.',
      repeatable: false,
      abilityScoreBonus: 0,
      spellsGranted: 'Cure Wounds, Lesser Restoration (level 3+)'
    }
  })
  console.log('✓ Mark of Healing created')

  const markOfHospitality = await db.feat.upsert({
    where: { name: 'Mark of Hospitality' },
    update: {},
    create: {
      name: 'Mark of Hospitality',
      category: 'Dragonmark',
      prerequisite: 'Eberron Campaign, Can\'t Have Another Dragonmark Feat',
      description: 'You gain the following benefits.',
      benefit: 'Ever Hospitable: When you make a Charisma (Persuasion) check or an ability check using Brewer\'s Supplies or Cook\'s Utensils, you can roll 1d4 and add the number rolled to the ability check.\n\nInnkeeper\'s Magic: You always have the Purify Food and Drink and Unseen Servant spells prepared. You can cast each spell once without a spell slot.\n\nWhen you reach character level 3, you also always have the Calm Emotions spell prepared.\n\nSpells of the Mark: Goodberry, Sleep, Aid, Enhance Ability, Create Food and Water, Leomund\'s Tiny Hut, Aura of Purity, Mordenkainen\'s Private Sanctum, Hallow are added to your spell list.',
      repeatable: false,
      abilityScoreBonus: 0,
      spellsGranted: 'Purify Food and Drink, Unseen Servant, Calm Emotions (level 3+)'
    }
  })
  console.log('✓ Mark of Hospitality created')

  const markOfMaking = await db.feat.upsert({
    where: { name: 'Mark of Making' },
    update: {},
    create: {
      name: 'Mark of Making',
      category: 'Dragonmark',
      prerequisite: 'Eberron Campaign, Can\'t Have Another Dragonmark Feat',
      description: 'You gain the following benefits.',
      benefit: 'Artisan\'s Intuition: When you make an Intelligence (Arcana) check or an ability check using Artisan\'s Tools, you can roll 1d4 and add the number rolled to the ability check.\n\nSpellsmith: You know the Mending cantrip. You also always have the Magic Weapon spell prepared. You can cast it once without a spell slot.\n\nSpells of the Mark: Identify, Tenser\'s Floating Disk, Continual Flame, Spiritual Weapon, Conjure Barrage, Elemental Weapon, Fabricate, Stone Shape, Creation are added to your spell list.',
      repeatable: false,
      abilityScoreBonus: 0,
      spellsGranted: 'Mending, Magic Weapon'
    }
  })
  console.log('✓ Mark of Making created')

  const markOfPassage = await db.feat.upsert({
    where: { name: 'Mark of Passage' },
    update: {},
    create: {
      name: 'Mark of Passage',
      category: 'Dragonmark',
      prerequisite: 'Eberron Campaign, Can\'t Have Another Dragonmark Feat',
      description: 'You gain the following benefits.',
      benefit: 'Courier\'s Speed: Your Speed increases by 5 feet.\n\nIntuitive Motion: When you make a Strength (Athletics) or Dexterity (Acrobatics) check, you can roll 1d4 and add the number rolled to the ability check.\n\nMagical Passage: You always have the Misty Step spell prepared. You can cast it once without a spell slot.\n\nSpells of the Mark: Expeditious Retreat, Jump, Find Steed, Pass without Trace, Blink, Phantom Steed, Dimension Door, Freedom of Movement, Teleportation Circle are added to your spell list.',
      repeatable: false,
      abilityScoreBonus: 0,
      spellsGranted: 'Misty Step'
    }
  })
  console.log('✓ Mark of Passage created')

  const markOfScribing = await db.feat.upsert({
    where: { name: 'Mark of Scribing' },
    update: {},
    create: {
      name: 'Mark of Scribing',
      category: 'Dragonmark',
      prerequisite: 'Eberron Campaign, Can\'t Have Another Dragonmark Feat',
      description: 'You gain the following benefits.',
      benefit: 'Gifted Scribe: When you make an Intelligence (History) check or an ability check using Calligrapher\'s Supplies, you can roll 1d4 and add the number rolled to the ability check.\n\nScribe\'s Insight: You know the Message cantrip. You also always have the Comprehend Languages spell prepared. You can cast it once without a spell slot.\n\nWhen you reach character level 3, you also always have the Magic Mouth spell prepared.\n\nSpells of the Mark: Command, Illusory Script, Animal Messenger, Silence, Sending, Tongues, Arcane Eye, Confusion, Dream are added to your spell list.',
      repeatable: false,
      abilityScoreBonus: 0,
      spellsGranted: 'Message, Comprehend Languages, Magic Mouth (level 3+)'
    }
  })
  console.log('✓ Mark of Scribing created')

  const markOfSentinel = await db.feat.upsert({
    where: { name: 'Mark of Sentinel' },
    update: {},
    create: {
      name: 'Mark of Sentinel',
      category: 'Dragonmark',
      prerequisite: 'Eberron Campaign, Can\'t Have Another Dragonmark Feat',
      description: 'You gain the following benefits.',
      benefit: 'Sentinel\'s Intuition: When you make a Wisdom (Insight or Perception) check, you can roll 1d4 and add the number rolled to the ability check.\n\nGuardian\'s Shield: You always have the Shield spell prepared. You can cast it once without a spell slot.\n\nVigilant Guardian: When a creature you can see within 5 feet of you is hit by an attack roll, you can take a Reaction to swap places with that creature, and you are hit by the attack instead. You can use this feature a number of times equal to your Proficiency Bonus.\n\nSpells of the Mark: Compelled Duel, Shield of Faith, Warding Bond, Zone of Truth, Counterspell, Protection from Energy, Death Ward, Guardian of Faith, Bigby\'s Hand are added to your spell list.',
      repeatable: false,
      abilityScoreBonus: 0,
      spellsGranted: 'Shield'
    }
  })
  console.log('✓ Mark of Sentinel created')

  const markOfShadow = await db.feat.upsert({
    where: { name: 'Mark of Shadow' },
    update: {},
    create: {
      name: 'Mark of Shadow',
      category: 'Dragonmark',
      prerequisite: 'Eberron Campaign, Can\'t Have Another Dragonmark Feat',
      description: 'You gain the following benefits.',
      benefit: 'Cunning Intuition: When you make a Dexterity (Stealth) or Charisma (Performance) check, you can roll 1d4 and add the number rolled to the ability check.\n\nShape Shadows: You know the Minor Illusion cantrip. You also always have the Invisibility spell prepared. You can cast it once without a spell slot.\n\nSpells of the Mark: Disguise Self, Silent Image, Darkness, Pass without Trace, Clairvoyance, Major Image, Greater Invisibility, Hallucinatory Terrain, Mislead are added to your spell list.',
      repeatable: false,
      abilityScoreBonus: 0,
      spellsGranted: 'Minor Illusion, Invisibility'
    }
  })
  console.log('✓ Mark of Shadow created')

  const markOfStorm = await db.feat.upsert({
    where: { name: 'Mark of Storm' },
    update: {},
    create: {
      name: 'Mark of Storm',
      category: 'Dragonmark',
      prerequisite: 'Eberron Campaign, Can\'t Have Another Dragonmark Feat',
      description: 'You gain the following benefits.',
      benefit: 'Windwright\'s Intuition: When you make a Dexterity (Acrobatics) check or an ability check using Navigator\'s Tools, you can roll 1d4 and add the number rolled to the ability check.\n\nStorm\'s Boon: You have Resistance to Lightning damage.\n\nStorm Magic: You know the Thunderclap cantrip. When you reach character level 3, you also always have the Gust of Wind spell prepared. You can cast it once without a spell slot.\n\nSpells of the Mark: Feather Fall, Fog Cloud, Levitate, Shatter, Sleet Storm, Wind Wall, Conjure Minor Elementals, Control Water, Conjure Elemental are added to your spell list.',
      repeatable: false,
      abilityScoreBonus: 0,
      spellsGranted: 'Thunderclap, Gust of Wind (level 3+)'
    }
  })
  console.log('✓ Mark of Storm created')

  const markOfWarding = await db.feat.upsert({
    where: { name: 'Mark of Warding' },
    update: {},
    create: {
      name: 'Mark of Warding',
      category: 'Dragonmark',
      prerequisite: 'Eberron Campaign, Can\'t Have Another Dragonmark Feat',
      description: 'You gain the following benefits.',
      benefit: 'Warder\'s Intuition: When you make an Intelligence (Investigation) check or an ability check using Thieves\' Tools, you can roll 1d4 and add the number rolled to the ability check.\n\nWards and Seals: You always have the Alarm and Mage Armor spells prepared. You can cast each spell once without a spell slot.\n\nWhen you reach character level 3, you also always have the Arcane Lock spell prepared.\n\nSpells of the Mark: Armor of Agathys, Sanctuary, Knock, Nystul\'s Magic Aura, Glyph of Warding, Magic Circle, Leomund\'s Secret Chest, Mordenkainen\'s Faithful Hound, Antilife Shell are added to your spell list.',
      repeatable: false,
      abilityScoreBonus: 0,
      spellsGranted: 'Alarm, Mage Armor, Arcane Lock (level 3+)'
    }
  })
  console.log('✓ Mark of Warding created')

  // ========================================
  // GREATER DRAGONMARK FEATS (13)
  // ========================================
  console.log('\n📦 Adding Greater Dragonmark Feats...')

  const greaterAberrantMark = await db.feat.upsert({
    where: { name: 'Greater Aberrant Mark' },
    update: {},
    create: {
      name: 'Greater Aberrant Mark',
      category: 'General',
      prerequisite: 'Level 4+, Aberrant Dragonmark Feat',
      description: 'You gain the following benefits.',
      benefit: 'Ability Score Increase: Increase your Constitution score by 1, to a maximum of 20.\n\nImproved Fortitude: When you use the Aberrant Fortitude benefit of your Aberrant Dragonmark feat, you can roll 1d6 instead of 1d4. You also now regain your use of Aberrant Fortitude whenever you finish a Short or Long Rest.\n\nMark of Inspiration: When you cast a cantrip, you can roll one or two of your unexpended Hit Point Dice. You gain a number of Temporary Hit Points equal to the number rolled plus your Constitution modifier, and one creature of your choice within 30 feet of you (not including you) takes Force damage equal to the number rolled. Those dice are then expended.',
      repeatable: false,
      abilityScoreOptions: 'Constitution',
      abilityScoreBonus: 1
    }
  })
  console.log('✓ Greater Aberrant Mark created')

  // Add remaining greater marks (abbreviated for space - they follow similar pattern)
  const greaterMarks = [
    { name: 'Greater Mark of Detection', prereq: 'Level 4+, Mark of Detection Feat', benefit: 'Ability Score Increase: Increase one ability score by 1 (max 20). Improved Intuition: Roll 1d6 instead of 1d4 for Deductive Intuition. Shared Detection: When you cast See Invisibility without a spell slot, choose one creature within 30 feet to also gain the benefits.' },
    { name: 'Greater Mark of Finding', prereq: 'Level 4+, Mark of Finding Feat', benefit: 'Ability Score Increase: Increase one ability score by 1 (max 20). Improved Intuition: Roll 1d6 instead of 1d4 for Hunter\'s Intuition. Improved Finding: Hunter\'s Mark has doubled range, and target can\'t benefit from Invisible condition.' },
    { name: 'Greater Mark of Handling', prereq: 'Level 4+, Mark of Handling Feat', benefit: 'Ability Score Increase: Increase one ability score by 1 (max 20). Improved Intuition: Roll 1d6 instead of 1d4 for Wild Intuition. Improved Handling: After hitting with melee attack while mounted, mount can take Reaction to move or attack. Subdue Animal: As Magic action, force Beast/Monstrosity to make Wis save or be Frightened.' },
    { name: 'Greater Mark of Healing', prereq: 'Level 4+, Mark of Healing Feat', benefit: 'Ability Score Increase: Increase one ability score by 1 (max 20). Improved Intuition: Roll 1d6 instead of 1d4 for Medical Intuition. Improved Healing: Cast Cure Wounds without slot PB times per Long Rest. Treat 1s and 2s as 3s on healing rolls.' },
    { name: 'Greater Mark of Hospitality', prereq: 'Level 4+, Mark of Hospitality Feat', benefit: 'Ability Score Increase: Increase one ability score by 1 (max 20). Improved Intuition: Roll 1d6 instead of 1d4 for Ever Hospitable. Inspired Hospitality: Modify Purify Food and Drink to reduce Exhaustion by 1 and grant Temp HP.' },
    { name: 'Greater Mark of Making', prereq: 'Level 4+, Mark of Making Feat', benefit: 'Ability Score Increase: Increase one ability score by 1 (max 20). Improved Intuition: Roll 1d6 instead of 1d4 for Artisan\'s Intuition. Improved Making: Cast Magic Weapon as level 3 version when using without spell slot.' },
    { name: 'Greater Mark of Passage', prereq: 'Level 4+, Mark of Passage Feat', benefit: 'Ability Score Increase: Increase one ability score by 1 (max 20). Improved Intuition: Roll 1d6 instead of 1d4 for Intuitive Motion. Inspired Passage: When casting Misty Step without slot, choose up to 2 willing creatures to also teleport 30 feet as Reaction.' },
    { name: 'Greater Mark of Scribing', prereq: 'Level 4+, Mark of Scribing Feat', benefit: 'Ability Score Increase: Increase one ability score by 1 (max 20). Improved Intuition: Roll 1d6 instead of 1d4 for Gifted Scribe. Inspired Scribing: Modify Comprehend Languages to affect up to 3 creatures and grant telepathy within 1 mile.' },
    { name: 'Greater Mark of Sentinel', prereq: 'Level 4+, Mark of Sentinel Feat', benefit: 'Ability Score Increase: Increase one ability score by 1 (max 20). Improved Intuition: Roll 1d6 instead of 1d4 for Sentinel\'s Intuition. Improved Sentinel: When using Vigilant Guardian, also make one weapon attack as part of the Reaction.' },
    { name: 'Greater Mark of Shadow', prereq: 'Level 4+, Mark of Shadow Feat', benefit: 'Ability Score Increase: Increase one ability score by 1 (max 20). Improved Intuition: Roll 1d6 instead of 1d4 for Cunning Intuition. Improved Shadow: Cast Invisibility as level 3 version when using without spell slot.' },
    { name: 'Greater Mark of Storm', prereq: 'Level 4+, Mark of Storm Feat', benefit: 'Ability Score Increase: Increase one ability score by 1 (max 20). Improved Intuition: Roll 1d6 instead of 1d4 for Windwright\'s Intuition. Improved Storm: When casting Gust of Wind without slot, gain 60 ft Fly Speed for duration.' },
    { name: 'Greater Mark of Warding', prereq: 'Level 4+, Mark of Warding Feat', benefit: 'Ability Score Increase: Increase one ability score by 1 (max 20). Improved Intuition: Roll 1d6 instead of 1d4 for Warder\'s Intuition. Improved Warding: As Reaction, impose Disadvantage on attack roll against you or creature within 30 ft. PB uses per Long Rest.' }
  ]

  for (const mark of greaterMarks) {
    await db.feat.upsert({
      where: { name: mark.name },
      update: {},
      create: {
        name: mark.name,
        category: 'General',
        prerequisite: mark.prereq,
        description: 'You gain the following benefits.',
        benefit: mark.benefit,
        repeatable: false,
        abilityScoreOptions: 'Any',
        abilityScoreBonus: 1
      }
    })
    console.log(`✓ ${mark.name} created`)
  }

  // ========================================
  // POTENT DRAGONMARK
  // ========================================
  const potentDragonmark = await db.feat.upsert({
    where: { name: 'Potent Dragonmark' },
    update: {},
    create: {
      name: 'Potent Dragonmark',
      category: 'General',
      prerequisite: 'Level 4+, Any Dragonmark Feat',
      description: 'You gain the following benefits.',
      benefit: 'Ability Score Increase: Increase the spellcasting ability score used by your Dragonmark feat by 1, to a maximum of 20.\n\nDragonmark Preparation: You always have the spells on your Spells of the Mark list (if any) prepared.\n\nDragonmark Spellcasting: You have one extra spell slot to cast the spells granted by your Dragonmark feat. The spell slot\'s level is half your level (round up), to a maximum of level 5. You regain the expended slot when you finish a Short or Long Rest.',
      repeatable: false,
      abilityScoreOptions: 'Dragonmark spellcasting ability',
      abilityScoreBonus: 1
    }
  })
  console.log('✓ Potent Dragonmark created')

  // ========================================
  // BOON OF SIBERYS
  // ========================================
  const boonOfSiberys = await db.feat.upsert({
    where: { name: 'Boon of Siberys' },
    update: {},
    create: {
      name: 'Boon of Siberys',
      category: 'Epic Boon',
      prerequisite: 'Level 19+, Eberron Campaign',
      description: 'You gain the following benefits.',
      benefit: 'Ability Score Increase: Increase one ability score of your choice by 1, to a maximum of 30.\n\nAberrant Magic: Choose a level 8 or lower spell from the Sorcerer spell list or a spell from the Siberys Dragonmark Spells table. You always have that spell prepared. You can cast it once without a spell slot or spell components, and you regain the ability to cast it in that way when you finish a Short or Long Rest. You can also cast this spell using any spell slots you have of the appropriate level.\n\nSiberys Spells: Animal Shapes (Handling), Control Weather (Storm), Demiplane (Making), Heroes\' Feast (Hospitality), Maze (Warding), Mind Blank (Sentinel), Plane Shift (Passage), Project Image (Shadow), Regenerate (Healing), Symbol (Scribing), Teleport (Finding), True Seeing (Detection).',
      repeatable: false,
      abilityScoreOptions: 'Any',
      abilityScoreBonus: 1
    }
  })
  console.log('✓ Boon of Siberys created')

  // ========================================
  // SPELL - Homunculus Servant
  // ========================================
  console.log('\n📦 Adding Spell...')

  const homunculusServant = await db.spell.upsert({
    where: { name: 'Homunculus Servant' },
    update: {},
    create: {
      name: 'Homunculus Servant',
      level: 2,
      school: 'Conjuration',
      castingTime: '1 hour or Ritual',
      range: '10 feet',
      components: 'V, S, M (a gem worth 100+ GP)',
      duration: 'Instantaneous',
      description: 'You summon a special homunculus in an unoccupied space within range. This creature uses the Homunculus Servant stat block. If you already have a homunculus from this spell, the homunculus is replaced by the new one. You determine the homunculus\'s appearance, such as a mechanical-looking bird, winged vial, or miniature animate cauldron.\n\nCombat: The homunculus is an ally to you and your allies. In combat, it shares your Initiative count, but it takes its turn immediately after yours. It obeys your commands (no action required by you). If you don\'t issue any, it takes the Dodge action and uses its movement to avoid danger.\n\nUsing a Higher-Level Spell Slot: Use the spell slot\'s level for the spell\'s level in the stat block.',
      concentration: false,
      ritual: true,
      classes: 'Artificer'
    }
  })
  console.log('✓ Homunculus Servant spell created')

  // ========================================
  // MONSTERS - Steel Defender and Homunculus Servant
  // ========================================
  console.log('\n📦 Adding Monsters...')

  const steelDefender = await db.monster.upsert({
    where: { name: 'Steel Defender' },
    update: {},
    create: {
      name: 'Steel Defender',
      type: 'Construct',
      size: 'Medium',
      alignment: 'Neutral',
      cr: 0,
      xp: 0,
      proficiencyBonus: 2,
      ac: 12, // + Int modifier
      initiative: 1,
      hp: 5, // + 5x Artificer level
      hpFormula: '5 + 5 × Artificer Level',
      speed: '40 ft.',
      str: 14,
      strSave: 2,
      dex: 12,
      dexSave: 1,
      con: 14,
      conSave: 2,
      int: 4,
      intSave: -3,
      wis: 10,
      wisSave: 0,
      cha: 6,
      chaSave: -2,
      skills: JSON.stringify([]),
      resistances: JSON.stringify([]),
      immunities: JSON.stringify(['Poison', 'Charmed', 'Exhaustion', 'Poisoned']),
      senses: 'Darkvision 60 ft.; Passive Perception 10',
      languages: 'Understands the languages you know',
      traits: JSON.stringify([
        { name: 'Steel Bond', description: 'Add your Proficiency Bonus to any ability check or saving throw the defender makes.' }
      ]),
      actions: JSON.stringify([
        { name: 'Force-Empowered Rend', type: 'Melee Attack', description: 'Melee Attack Roll: Bonus equals your spell attack modifier, reach 5 ft. Hit: 1d8 + 2 plus your Intelligence modifier Force damage.' },
        { name: 'Repair', type: 'Special', uses: '3/Day', description: 'The defender, or one Construct or object it can see within 5 feet of itself, regains 2d8 + Int modifier Hit Points.' }
      ]),
      bonusActions: JSON.stringify([]),
      legendaryActions: JSON.stringify([]),
      reactions: JSON.stringify([
        { name: 'Deflect Attack', description: 'Trigger: A creature the defender can see within 5 feet of itself makes an attack roll against a creature other than the defender. Response: The triggering creature makes the attack roll with Disadvantage.' }
      ]),
      lairActions: JSON.stringify([]),
      description: 'A Steel Defender is a protective companion created by a Battle Smith artificer. It appears as a mechanical creature with either two legs or four, as determined by its creator.',
      habitat: 'Any',
      treasure: 'None'
    }
  })
  console.log('✓ Steel Defender created')

  const homunculusServantMonster = await db.monster.upsert({
    where: { name: 'Homunculus Servant (Creature)' },
    update: {},
    create: {
      name: 'Homunculus Servant (Creature)',
      type: 'Construct',
      size: 'Tiny',
      alignment: 'Neutral',
      cr: 0,
      xp: 0,
      proficiencyBonus: 2,
      ac: 13,
      initiative: 2,
      hp: 5, // + 5 per spell level
      hpFormula: '5 + 5 per spell level',
      speed: '20 ft., Fly 30 ft.',
      str: 4,
      strSave: -3,
      dex: 15,
      dexSave: 2,
      con: 12,
      conSave: 1,
      int: 10,
      intSave: 0,
      wis: 10,
      wisSave: 0,
      cha: 7,
      chaSave: -2,
      skills: JSON.stringify([]),
      resistances: JSON.stringify([]),
      immunities: JSON.stringify(['Poison', 'Exhaustion', 'Poisoned']),
      senses: 'Darkvision 60 ft.; Passive Perception 10',
      languages: 'Telepathy 1 mile (works only with you)',
      traits: JSON.stringify([
        { name: 'Evasion', description: 'If the homunculus is subjected to an effect that allows it to make a Dexterity saving throw to take only half damage, it instead takes no damage if it succeeds on the save and only half damage if it fails. It can\'t use this trait if it has the Incapacitated condition.' },
        { name: 'Magic Bond', description: 'Add the spell\'s level to any ability check or saving throw the homunculus makes.' }
      ]),
      actions: JSON.stringify([
        { name: 'Force Strike', type: 'Melee or Ranged Attack', description: 'Melee or Ranged Attack Roll: Bonus equals your spell attack modifier, reach 5 ft. or range 30 ft. Hit: 1d6 plus the spell\'s level Force damage.' }
      ]),
      bonusActions: JSON.stringify([]),
      legendaryActions: JSON.stringify([]),
      reactions: JSON.stringify([
        { name: 'Channel Magic', description: 'Trigger: You cast a spell that has a range of touch while the homunculus is within 120 feet of you. Response: The homunculus delivers the spell through its touch.' }
      ]),
      lairActions: JSON.stringify([]),
      description: 'A homunculus servant is a tiny construct summoned by the Homunculus Servant spell. It can appear as a mechanical bird, winged vial, or miniature animate cauldron.',
      habitat: 'Any',
      treasure: 'None'
    }
  })
  console.log('✓ Homunculus Servant (Creature) created')

  // ========================================
  // ARTIFICER SUBCLASSES
  // ========================================
  console.log('\n📦 Adding Artificer Subclasses...')

  const alchemistSubclass = await db.subclass.upsert({
    where: { name: 'Alchemist' },
    update: {},
    create: {
      name: 'Alchemist',
      description: 'An Alchemist is an expert at combining reagents to produce magical effects. Alchemists use their creations to give life and to leech it away.',
      classId: 'artificer', // Will need to link properly
      features: JSON.stringify([
        { level: 3, name: 'Tools of the Trade', description: 'Tool Proficiency: You gain proficiency with Alchemist\'s Supplies and the Herbalism Kit. Potion Crafting: When you brew a potion using the crafting rules, the time required is halved.' },
        { level: 3, name: 'Alchemist Spells', description: 'Always prepared: Level 3 - Healing Word, Ray of Sickness; Level 5 - Flaming Sphere, Melf\'s Acid Arrow; Level 9 - Gaseous Form, Mass Healing Word; Level 13 - Death Ward, Vitriolic Sphere; Level 17 - Cloudkill, Raise Dead' },
        { level: 3, name: 'Experimental Elixir', description: 'When you finish a Long Rest holding Alchemist\'s Supplies, produce 2 elixirs (3 at level 5, 4 at level 9, 5 at level 15). Roll 1d6 for effect: 1=Healing (2d8+Int), 2=Swiftness (+10 ft Speed for 1 hour), 3=Resilience (+1 AC for 10 min), 4=Boldness (+1d4 to attacks and saves for 1 min), 5=Flight (10 ft Fly Speed for 10 min), 6=Choose effect.' },
        { level: 5, name: 'Alchemical Savant', description: 'When you cast a spell using Alchemist\'s Supplies as focus, add Int modifier to one damage roll (Acid, Fire, Poison) or healing roll.' },
        { level: 9, name: 'Restorative Reagents', description: 'Cast Lesser Restoration without spell slot Int mod times per Long Rest using Alchemist\'s Supplies as focus.' },
        { level: 15, name: 'Chemical Mastery', description: 'Alchemical Eruption: When casting Artificer spell dealing Acid, Fire, or Poison damage, also deal 2d8 Force damage (once per turn). Chemical Resistance: Resistance to Acid and Poison damage, Immunity to Poisoned condition. Conjured Cauldron: Cast Tasha\'s Bubbling Cauldron without slot or components once per Long Rest.' }
      ]),
      subclassSpells: JSON.stringify({
        3: ['Healing Word', 'Ray of Sickness'],
        5: ['Flaming Sphere', 'Melf\'s Acid Arrow'],
        9: ['Gaseous Form', 'Mass Healing Word'],
        13: ['Death Ward', 'Vitriolic Sphere'],
        17: ['Cloudkill', 'Raise Dead']
      })
    }
  })
  console.log('✓ Alchemist subclass created')

  const armorerSubclass = await db.subclass.upsert({
    where: { name: 'Armorer' },
    update: {},
    create: {
      name: 'Armorer',
      description: 'An Armorer modifies armor to function almost like a second skin. The armor is enhanced to hone the Armorer\'s magic, unleash potent attacks, and generate a formidable defense.',
      classId: 'artificer',
      features: JSON.stringify([
        { level: 3, name: 'Tools of the Trade', description: 'Armor Training: Training with Heavy armor. Tool Proficiency: Smith\'s Tools. Armor Crafting: Time to craft armor is halved.' },
        { level: 3, name: 'Armorer Spells', description: 'Always prepared: Level 3 - Magic Missile, Thunderwave; Level 5 - Mirror Image, Shatter; Level 9 - Hypnotic Pattern, Lightning Bolt; Level 13 - Fire Shield, Greater Invisibility; Level 17 - Passwall, Wall of Force' },
        { level: 3, name: 'Arcane Armor', description: 'As Magic action with Smith\'s Tools, turn worn armor into Arcane Armor. Benefits: No Strength requirement, don/doff as Utilize action, use as Spellcasting Focus.' },
        { level: 3, name: 'Armor Model', description: 'Choose model: Dreadnaught (Force Demolisher 1d10 Reach weapon, Giant Stature for 1 min), Guardian (Thunder Pulse 1d8, Defensive Field for Temp HP when Bloodied), or Infiltrator (Lightning Launcher 1d6 ranged 90/300 ft, +5 ft Speed, Advantage on Stealth).' },
        { level: 5, name: 'Extra Attack', description: 'Attack twice instead of once when taking the Attack action.' },
        { level: 9, name: 'Improved Armorer', description: 'Armor Replication: Learn additional Armor plan for Replicate Magic Item. Improved Arsenal: +1 bonus to attack and damage with Arcane Armor special weapon.' },
        { level: 15, name: 'Perfected Armor', description: 'Dreadnaught: 2d6 Force Demolisher, +10 ft reach and Large/Huge size with Advantage on Strength checks. Guardian: 1d10 Thunder Pulse, pull creatures as Reaction. Infiltrator: 2d6 Lightning Launcher, glimmering targets have Disadvantage vs you, Fly Speed as Bonus Action.' }
      ]),
      subclassSpells: JSON.stringify({
        3: ['Magic Missile', 'Thunderwave'],
        5: ['Mirror Image', 'Shatter'],
        9: ['Hypnotic Pattern', 'Lightning Bolt'],
        13: ['Fire Shield', 'Greater Invisibility'],
        17: ['Passwall', 'Wall of Force']
      })
    }
  })
  console.log('✓ Armorer subclass created')

  const artilleristSubclass = await db.subclass.upsert({
    where: { name: 'Artillerist' },
    update: {},
    create: {
      name: 'Artillerist',
      description: 'An Artillerist specializes in using magic to hurl energy, projectiles, and explosions on a battlefield.',
      classId: 'artificer',
      features: JSON.stringify([
        { level: 3, name: 'Tools of the Trade', description: 'Ranged Weaponry: Proficiency with Martial Ranged weapons. Tool Proficiency: Woodcarver\'s Tools. Wand Crafting: Time to craft magic Wands is halved.' },
        { level: 3, name: 'Artillerist Spells', description: 'Always prepared: Level 3 - Shield, Thunderwave; Level 5 - Scorching Ray, Shatter; Level 9 - Fireball, Wind Wall; Level 13 - Ice Storm, Wall of Fire; Level 17 - Cone of Cold, Wall of Force' },
        { level: 3, name: 'Eldritch Cannon', description: 'As Magic action with Smith\'s/Woodcarver\'s Tools, create Small/Tiny cannon (AC 18, HP 5×Artificer level). Bonus Action to activate: Flamethrower (2d8 Fire in 15-ft cone), Force Ballista (2d8 Force ranged 120 ft, push 5 ft), or Protector (1d8+Int Temp HP to creatures within 10 ft). Lasts 1 hour or until 0 HP.' },
        { level: 5, name: 'Arcane Firearm', description: 'Carve sigils into Rod, Staff, Wand, or Martial Ranged weapon to make it your Arcane Firearm. Use as Spellcasting Focus, add 1d8 to one damage roll of spells cast through it.' },
        { level: 9, name: 'Explosive Cannon', description: 'Detonate: As Reaction when cannon takes damage, destroy it to deal 3d10 Force in 20-ft radius (Dex save). Firepower: Damage and Temp HP increase by 1d8.' },
        { level: 15, name: 'Fortified Position', description: 'Double Firepower: Have two cannons at once. Shimmering Field Projection: You and allies have Half Cover within 10 ft of cannon.' }
      ]),
      subclassSpells: JSON.stringify({
        3: ['Shield', 'Thunderwave'],
        5: ['Scorching Ray', 'Shatter'],
        9: ['Fireball', 'Wind Wall'],
        13: ['Ice Storm', 'Wall of Fire'],
        17: ['Cone of Cold', 'Wall of Force']
      })
    }
  })
  console.log('✓ Artillerist subclass created')

  const battleSmithSubclass = await db.subclass.upsert({
    where: { name: 'Battle Smith' },
    update: {},
    create: {
      name: 'Battle Smith',
      description: 'A Battle Smith is a combination of protector and medic, an expert at defending others and repairing both materiel and personnel. To aid in their work, Battle Smiths are accompanied by a Steel Defender.',
      classId: 'artificer',
      features: JSON.stringify([
        { level: 3, name: 'Tools of the Trade', description: 'Tool Proficiency: Smith\'s Tools. Weapon Crafting: Time to craft weapons is halved.' },
        { level: 3, name: 'Battle Smith Spells', description: 'Always prepared: Level 3 - Heroism, Shield; Level 5 - Shining Smite, Warding Bond; Level 9 - Aura of Vitality, Conjure Barrage; Level 13 - Aura of Purity, Fire Shield; Level 17 - Banishing Smite, Mass Cure Wounds' },
        { level: 3, name: 'Battle Ready', description: 'Arcane Empowerment: Use Intelligence for attack and damage with magic weapons. Weapon Knowledge: Proficiency with Martial weapons, use weapon as Spellcasting Focus.' },
        { level: 3, name: 'Steel Defender', description: 'Gain a Steel Defender companion (Medium Construct). In combat, acts on your turn, takes Dodge action unless you use Bonus Action to command. If you\'re Incapacitated, acts independently. Can restore dead defender with spell slot, or create new one during Long Rest.' },
        { level: 5, name: 'Extra Attack', description: 'Attack twice instead of once when taking the Attack action. Can forgo one attack to command Steel Defender to use Force-Empowered Rend.' },
        { level: 9, name: 'Arcane Jolt', description: 'When you or Steel Defender hits with magic weapon attack, choose: Destructive Energy (extra 2d6 Force damage) or Restorative Energy (heal 2d6 HP to creature/object within 30 ft). Int mod uses per Long Rest.' },
        { level: 15, name: 'Improved Defender', description: 'Improved Jolt: Extra damage and healing increase to 4d6. Improved Deflection: When Steel Defender uses Deflect Attack, attacker takes 1d4+Int Force damage.' }
      ]),
      subclassSpells: JSON.stringify({
        3: ['Heroism', 'Shield'],
        5: ['Shining Smite', 'Warding Bond'],
        9: ['Aura of Vitality', 'Conjure Barrage'],
        13: ['Aura of Purity', 'Fire Shield'],
        17: ['Banishing Smite', 'Mass Cure Wounds']
      })
    }
  })
  console.log('✓ Battle Smith subclass created')

  const cartographerSubclass = await db.subclass.upsert({
    where: { name: 'Cartographer' },
    update: {},
    create: {
      name: 'Cartographer',
      description: 'Cartographers are the premier navigators and reconnaissance agents. Using their creations, Cartographers can highlight threats, safeguard allies, and carve portals to distant locations.',
      classId: 'artificer',
      features: JSON.stringify([
        { level: 3, name: 'Tools of the Trade', description: 'Tool Proficiency: Calligrapher\'s Supplies and Cartographer\'s Tools. Scroll Crafting: Time to scribe Spell Scrolls is halved.' },
        { level: 3, name: 'Cartographer Spells', description: 'Always prepared: Level 3 - Faerie Fire, Guiding Bolt, Healing Word; Level 5 - Locate Object, Mind Spike; Level 9 - Call Lightning, Clairvoyance; Level 13 - Banishment, Locate Creature; Level 17 - Scrying, Teleportation Circle' },
        { level: 3, name: 'Adventurer\'s Atlas', description: 'When finishing Long Rest with Cartographer\'s Tools, create magical maps for up to 1+Int mod creatures. Benefits: +1d4 to Initiative, know location of other map holders on same plane, can target other map holders with spells regardless of sight/cover.' },
        { level: 3, name: 'Mapping Magic', description: 'Illuminated Cartography: Cast Faerie Fire without slot Int mod times per Long Rest. Portal Jump: Spend half Speed to teleport 10 ft to visible space or within 5 ft of map holder within 30 ft.' },
        { level: 5, name: 'Guided Precision', description: 'Once per turn, when casting Cartographer spell or hitting Faerie Fire target, add Int modifier to one damage roll. Damage doesn\'t break Faerie Fire concentration.' },
        { level: 9, name: 'Ingenious Movement', description: 'When using Flash of Genius, you or willing creature within 30 ft can teleport up to 30 ft to unoccupied visible space as part of the Reaction.' },
        { level: 15, name: 'Superior Atlas', description: 'Safe Haven: When map holder would drop to 0 HP, can destroy map to instead have 2×Artificer level HP and teleport within 5 ft of you or another map holder. Unerring Path: Cast Find the Path without slot or components once per Long Rest.' }
      ]),
      subclassSpells: JSON.stringify({
        3: ['Faerie Fire', 'Guiding Bolt', 'Healing Word'],
        5: ['Locate Object', 'Mind Spike'],
        9: ['Call Lightning', 'Clairvoyance'],
        13: ['Banishment', 'Locate Creature'],
        17: ['Scrying', 'Teleportation Circle']
      })
    }
  })
  console.log('✓ Cartographer subclass created')

  console.log('\n✅ Forge of the Artificer seeding completed successfully!')
}

main()
  .catch((e) => {
    console.error('❌ Error during seeding:', e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })
