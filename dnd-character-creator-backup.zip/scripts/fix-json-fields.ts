import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

function parseToArray(value: string | null): string[] {
  if (!value) return []
  try {
    const parsed = JSON.parse(value)
    return Array.isArray(parsed) ? parsed : [parsed]
  } catch {
    return value.split(',').map(s => s.trim()).filter(s => s)
  }
}

async function main() {
  console.log('Fixing JSON fields in database...')
  
  // Fix Background skillProficiencies
  const backgrounds = await prisma.background.findMany()
  let fixedBackgrounds = 0
  for (const bg of backgrounds) {
    if (bg.skillProficiencies) {
      const skills = parseToArray(bg.skillProficiencies)
      const skillsJson = JSON.stringify(skills)
      if (bg.skillProficiencies !== skillsJson) {
        await prisma.background.update({
          where: { id: bg.id },
          data: { skillProficiencies: skillsJson }
        })
        fixedBackgrounds++
      }
    }
    if (bg.toolProficiency) {
      const tools = parseToArray(bg.toolProficiency)
      const toolsJson = JSON.stringify(tools)
      if (bg.toolProficiency !== toolsJson) {
        await prisma.background.update({
          where: { id: bg.id },
          data: { toolProficiency: toolsJson }
        })
        fixedBackgrounds++
      }
    }
  }
  console.log(`Fixed ${fixedBackgrounds} background fields`)
  
  // Fix Spell classes
  const spells = await prisma.spell.findMany()
  let fixedSpells = 0
  for (const spell of spells) {
    if (spell.classes) {
      const classes = parseToArray(spell.classes)
      const classesJson = JSON.stringify(classes)
      if (spell.classes !== classesJson) {
        await prisma.spell.update({
          where: { id: spell.id },
          data: { classes: classesJson }
        })
        fixedSpells++
      }
    }
  }
  console.log(`Fixed ${fixedSpells} spell fields`)
  
  // Fix CharacterClass skillProficiencies
  const characterClasses = await prisma.characterClass.findMany()
  let fixedClasses = 0
  for (const cls of characterClasses) {
    if (cls.skillProficiencies) {
      try {
        const parsed = JSON.parse(cls.skillProficiencies)
        // If it's already valid JSON, skip
        if (Array.isArray(parsed) || typeof parsed === 'object') continue
      } catch {
        // Not valid JSON, convert from comma-separated
        const skills = cls.skillProficiencies.split(',').map(s => s.trim()).filter(s => s)
        await prisma.characterClass.update({
          where: { id: cls.id },
          data: { skillProficiencies: JSON.stringify(skills) }
        })
        fixedClasses++
      }
    }
  }
  console.log(`Fixed ${fixedClasses} class skill fields`)
  
  console.log('Done!')
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect())
