import { db } from '../src/lib/db';

async function verifySpecies() {
  const species = await db.species.findMany({ orderBy: { name: 'asc' } });
  
  console.log('=== Species Traits Verification ===\n');
  
  let allCorrect = true;
  
  for (const sp of species) {
    if (!sp.traits) {
      console.log(`⚠ ${sp.name}: No traits`);
      continue;
    }
    
    try {
      const parsed = JSON.parse(sp.traits);
      
      if (Array.isArray(parsed) && parsed.length > 0) {
        const first = parsed[0];
        if (typeof first === 'object' && first.name && first.description) {
          console.log(`✓ ${sp.name}: ${parsed.length} traits`);
        } else {
          console.log(`✗ ${sp.name}: Wrong format - ${JSON.stringify(first).substring(0, 50)}`);
          allCorrect = false;
        }
      } else {
        console.log(`✗ ${sp.name}: Not array or empty`);
        allCorrect = false;
      }
    } catch (e) {
      console.log(`✗ ${sp.name}: Parse error`);
      allCorrect = false;
    }
  }
  
  console.log(`\n${allCorrect ? '✓ All correct!' : '✗ Some errors found'}`);
}

verifySpecies().catch(console.error);
