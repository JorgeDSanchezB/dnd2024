import { db } from '../src/lib/db';

async function checkChar() {
  const char = await db.character.findFirst({
    where: { name: { contains: 'piedrita' } }
  });
  
  if (char) {
    console.log('Character:', char.name);
    console.log('\ntoolProficiencies raw:', char.toolProficiencies);
    console.log('\nweaponProficiencies raw:', char.weaponProficiencies);
    console.log('\narmorProficiencies raw:', char.armorProficiencies);
    
    // Try to parse
    console.log('\n=== Parsing ===');
    if (char.toolProficiencies) {
      try {
        const parsed = JSON.parse(char.toolProficiencies);
        console.log('toolProficiencies parsed:', typeof parsed, Array.isArray(parsed), parsed);
      } catch (e) {
        console.log('toolProficiencies parse error:', e);
      }
    }
  }
}

checkChar().catch(console.error);
