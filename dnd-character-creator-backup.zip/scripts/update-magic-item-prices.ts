import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

// D&D 2024 Magic Item Pricing by Rarity (minimum values)
// Based on DMG 2024 guidelines
const RARITY_PRICES: Record<string, number> = {
  'Common': 100,           // Common items: 50-100 gp
  'Uncommon': 400,         // Uncommon: 100-500 gp
  'Rare': 4000,            // Rare: 500-5,000 gp
  'Very Rare': 40000,      // Very Rare: 5,000-50,000 gp
  'Legendary': 100000,     // Legendary: 50,000+ gp
  'Artifact': 500000,      // Artifacts: priceless, but set high value
}

// Potions and consumables have reduced prices (usually 25-50% of permanent items)
const CONSUMABLE_MULTIPLIER = 0.25

const CONSUMABLE_TYPES = ['Potion', 'Scroll', 'Ammunition']

async function main() {
  console.log('🔮 Updating Magic Item prices based on D&D 2024 rarity...\n')
  
  const magicItems = await prisma.magicItem.findMany()
  
  let updated = 0
  let skipped = 0
  let alreadyCorrect = 0
  
  for (const item of magicItems) {
    const basePrice = RARITY_PRICES[item.rarity]
    
    if (!basePrice) {
      console.log(`⚠️  Unknown rarity for ${item.name}: ${item.rarity}`)
      skipped++
      continue
    }
    
    // Calculate price based on type (consumables are cheaper)
    let calculatedPrice = basePrice
    if (CONSUMABLE_TYPES.some(type => item.type?.includes(type))) {
      calculatedPrice = Math.round(basePrice * CONSUMABLE_MULTIPLIER)
    }
    
    // Only update if current price is lower than minimum or not set
    if (item.cost === null || item.cost === 0 || item.cost < calculatedPrice) {
      await prisma.magicItem.update({
        where: { id: item.id },
        data: { cost: calculatedPrice }
      })
      console.log(`✅ ${item.name} (${item.rarity}): ${item.cost ?? 'no price'} → ${calculatedPrice} gp`)
      updated++
    } else {
      alreadyCorrect++
    }
  }
  
  console.log(`\n📊 Summary:`)
  console.log(`   Updated: ${updated} items`)
  console.log(`   Already correct: ${alreadyCorrect} items`)
  console.log(`   Skipped: ${skipped} items`)
  console.log(`   Total processed: ${magicItems.length} items`)
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect())
