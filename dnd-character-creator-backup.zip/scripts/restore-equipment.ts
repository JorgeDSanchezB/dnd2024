import { db } from '../src/lib/db';

// Equipment data for backgrounds that need restoration
const equipmentData: Record<string, string> = {
  "Acolyte": JSON.stringify({
    A: { items: ["Calligrapher's Supplies", "Book (prayers)", "Holy Symbol", "Parchment (10 sheets)", "Robe"], gold: 8 },
    B: { items: [], gold: 50 }
  }),
  "Artisan": JSON.stringify({
    A: { items: ["Artisan's Tools (chosen)", "2 Pouches", "Traveler's Clothes"], gold: 32 },
    B: { items: [], gold: 50 }
  }),
  "Charlatan": JSON.stringify({
    A: { items: ["Fine Clothes", "Disguise Kit", "10-sided die", "Signet ring of an imaginary duke"], gold: 15 },
    B: { items: [], gold: 50 }
  }),
  "Criminal": JSON.stringify({
    A: { items: ["Crowbar", "Common Clothes", "Thieves' Tools"], gold: 15 },
    B: { items: [], gold: 50 }
  }),
  "Entertainer": JSON.stringify({
    A: { items: ["Musical Instrument", "Common Clothes", "Costume"], gold: 15 },
    B: { items: [], gold: 50 }
  }),
  "Farmer": JSON.stringify({
    A: { items: ["Common Clothes", "Sickle", "Shovel", "Iron Pot"], gold: 10 },
    B: { items: [], gold: 50 }
  }),
  "Guard": JSON.stringify({
    A: { items: ["Common Clothes", "Club", "Manacles"], gold: 10 },
    B: { items: [], gold: 50 }
  }),
  "Guide": JSON.stringify({
    A: { items: ["Common Clothes", "Rope", "Torch", "Torches (5)"], gold: 10 },
    B: { items: [], gold: 50 }
  }),
  "Hermit": JSON.stringify({
    A: { items: ["Common Clothes", "Herbalism Kit", "Scroll case", "Winter blanket"], gold: 5 },
    B: { items: [], gold: 50 }
  }),
  "Merchant": JSON.stringify({
    A: { items: ["Common Clothes", "Abacus", "Fine Clothes"], gold: 20 },
    B: { items: [], gold: 50 }
  }),
  "Noble": JSON.stringify({
    A: { items: ["Fine Clothes", "Signet Ring", "Scroll of Pedigree"], gold: 25 },
    B: { items: [], gold: 50 }
  }),
  "Sage": JSON.stringify({
    A: { items: ["Quarterstaff", "Book", "Robe", "Ink", "Parchment (10 sheets)"], gold: 8 },
    B: { items: [], gold: 50 }
  }),
  "Sailor": JSON.stringify({
    A: { items: ["Dagger", "Rope", "Common Clothes", "Belaying Pin"], gold: 20 },
    B: { items: [], gold: 50 }
  }),
  "Scribe": JSON.stringify({
    A: { items: ["Fine Clothes", "Lamp", "Oil (2 flasks)", "Parchment (20 sheets)", "Calligrapher's Supplies"], gold: 23 },
    B: { items: [], gold: 50 }
  }),
  "Soldier": JSON.stringify({
    A: { items: ["Spear", "Shortbow", "Healer's Kit", "Common Clothes"], gold: 14 },
    B: { items: [], gold: 50 }
  }),
  "Wayfarer": JSON.stringify({
    A: { items: ["2 Daggers", "Thieves' Tools", "Common Clothes", "Small knife"], gold: 15 },
    B: { items: [], gold: 50 }
  }),
  // Forgotten Realms backgrounds - use simple text format
  "Carouser": "Choose A or B: (A) Dagger, Gaming Set, Fine Clothes, Glass Bottle, Mirror, Perfume, Pouch, Tinderbox, 19 GP; or (B) 50 GP",
  "Vampire Devotee": "Choose A or B: (A) Cook's Utensils, Fine Clothes, 2 Glass Bottles, Healer's Kit, Perfume, Lamp, Oil (3 flasks), Waterskin, 19 GP; or (B) 50 GP",
  "Vampire Survivor": "Choose A or B: (A) Woodcarver's Tools, Crowbar, Hooded Lantern, Holy Symbol (reliquary), Holy Water, Mirror, Oil (3 flasks), Tinderbox, Traveler's Clothes, Waterskin, 4 GP; or (B) 50 GP",
  "Aberrant Heir": "Choose A or B: (A) Dagger, Disguise Kit, Costume, Traveler's Clothes, 16 GP; or (B) 50 GP",
  "Archaeologist": "Choose A or B: (A) Cartographer's Tools, Bullseye Lantern, Map, Map or Scroll Case, Shovel, Tent, Traveler's Clothes, 17 GP; or (B) 50 GP",
  "House Agent": "Choose A or B: (A) Artisan's Tools, Fine Clothes, 20 GP; or (B) 50 GP",
  "House Cannith Heir": "Choose A or B: (A) Artisan's Tools, Crowbar, Fine Clothes, 2 Pouches, 17 GP; or (B) 50 GP",
  "House Deneith Heir": "Choose A or B: (A) Spear, Shortbow, 20 Arrows, Gaming Set, Fine Clothes, Healer's Kit, Quiver, 1 GP; or (B) 50 GP",
  "House Ghallanda Heir": "Choose A or B: (A) Cook's Utensils, Fine Clothes, Iron Pot, Lamp, Oil (5 flasks), Perfume, 26 GP; or (B) 50 GP",
  "House Jorasco Heir": "Choose A or B: (A) Herbalism Kit, Fine Clothes, Healer's Kit, 25 GP; or (B) 50 GP",
  "House Kundarak Heir": "Choose A or B: (A) Thieves' Tools, Fine Clothes, 10 GP; or (B) 50 GP",
  "House Lyrandar Heir": "Choose A or B: (A) Navigator's Tools, Fine Clothes, 10 GP; or (B) 50 GP",
  "House Medani Heir": "Choose A or B: (A) Disguise Kit, Fine Clothes, 10 GP; or (B) 50 GP",
  "House Orien Heir": "Choose A or B: (A) Cartographer's Tools, Fine Clothes, Map, Map or Scroll Case, 18 GP; or (B) 50 GP",
  "House Phiarlan Heir": "Choose A or B: (A) Disguise Kit, Fine Clothes, 10 GP; or (B) 50 GP",
  "House Sivis Heir": "Choose A or B: (A) Calligrapher's Supplies, Fine Clothes, Ink, 5 Ink Pens, Paper (30 sheets), Parchment (9 sheets), 8 GP; or (B) 50 GP",
  "House Tharashk Heir": "Choose A or B: (A) Gaming Set, Climber's Kit, Fine Clothes, Hunting Trap, Manacles, 2 GP; or (B) 50 GP",
  "House Thuranni Heir": "Choose A or B: (A) Musical Instrument, Costume, Fine Clothes, 13 GP; or (B) 50 GP",
  "House Vadalis Heir": "Choose A or B: (A) Herbalism Kit, Fine Clothes, Net, 29 GP; or (B) 50 GP",
  "Inquisitive": "Choose A or B: (A) Thieves' Tools, Bullseye Lantern, Crowbar, Oil (10 flasks), Traveler's Clothes, 10 GP; or (B) 50 GP",
  "Chondathan Freebooter": "Dagger, Weaver's Tools, Backpack, Ball Bearings, Basket, Bedroll, Bucket, Rations (3 days), Rope, Signal Whistle, Traveler's Clothes, 38 GP",
  "Dead Magic Dweller": "Greatclub, Leatherworker's Tools, Bedroll, Blanket, Healer's Kit, Pole, Rations (3 days), Tent, Tinderbox, 5 Torches, Traveler's Clothes, Waterskin, 32 GP",
  "Dragon Cultist": "Calligrapher's Supplies, Dagger, Glass Bottle, Lamp, Manacles, Oil (5 flasks), 2 Pouches, Robe, Rope, 30 GP",
  "Emerald Enclave Caretaker": "Shortbow, 20 Arrows, Herbalism Kit, Bedroll, Blanket, Pouch, Tent, Traveler's Clothes, 13 GP",
  "Flaming Fist Mercenary": "Mace, Smith's Tools, Fine Clothes, Manacles, Portable Ram, 4 GP",
  "Genie Touched": "Light Hammer, Glassblower's Tools, Fine Clothes, Lamp, Oil (3 flasks), Waterskin, 2 GP",
  "Harper": "Disguise Kit, Bedroll, Costume, Grappling Hook, Rope, Traveler's Clothes, 14 GP",
  "Ice Fisher": "Woodcarver's Tools, Basket, Block and Tackle, Bucket, Chain, Hunting Trap, Net, Pole, Rations (3 days), Rope, Traveler's Clothes, 32 GP",
  "Knight of the Gauntlet": "Spear, Smith's Tools, Bullseye Lantern, Holy Symbol, Manacles, Oil (5 flasks), Tinderbox, Traveler's Clothes, 9 GP",
  "Lords' Alliance Vassal": "2 Javelins, Calligrapher's Supplies, Fine Clothes, Ink, 5 Ink Pens, Parchment (9 sheets), 13 GP",
  "Moonwell Pilgrim": "Quarterstaff, Painter's Supplies, Bedroll, Bell, Pouch, Robe, String, Traveler's Clothes, Waterskin, 34 GP",
  "Mulhorandi Tomb Raider": "Dagger, Light Hammer, Mason's Tools, Backpack, Bedroll, Crowbar, Ladder, Pole, 2 Pouches, Rope, String, Tinderbox, 5 Torches, Traveler's Clothes, Waterskin, 26 GP",
  "Mythalkeeper": "Quarterstaff, Jeweler's Tools, Perfume, Pouch, Robe, Shovel, String, Waterskin, 16 GP",
  "Purple Dragon Squire": "Spear, Navigator's Tools, Fine Clothes, 9 GP",
  "Rashemi Wanderer": "Cartographer's Tools, Backpack, Bedroll, Hooded Lantern, Oil (3 flasks), Rope, Tinderbox, Traveler's Clothes, Waterskin, 23 GP",
  "Shadowmasters Exile": "2 Daggers, Thieves' Tools, Caltrops, Costume, Grappling Hook, Iron Spikes, Mirror, 2 Pouches, Rope, Traveler's Clothes, 3 GP",
  "Spellfire Initiate": "Gaming Set, Arcane Focus (Crystal or Wand), 2 Pouches, Traveler's Clothes, 36 GP",
  "Zhentarim Mercenary": "Club, Dagger, Forgery Kit, Fine Clothes, Hooded Lantern, Oil (3 flasks), 2 Pouches, String, Tinderbox, 11 GP"
};

async function restoreEquipment() {
  console.log('Restoring equipment data...\n');
  
  for (const [name, equipment] of Object.entries(equipmentData)) {
    const bg = await db.background.findFirst({
      where: { name }
    });
    
    if (bg) {
      await db.background.update({
        where: { id: bg.id },
        data: { equipment }
      });
      console.log(`Restored: ${name}`);
    } else {
      console.log(`Not found: ${name}`);
    }
  }
  
  console.log('\nDone restoring equipment!');
}

restoreEquipment().catch(console.error);
