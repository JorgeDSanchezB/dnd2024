import { db } from '../src/lib/db';

async function verifyClasses() {
  const classes = await db.characterClass.findMany({
    include: { subclasses: true },
    orderBy: { name: 'asc' }
  });
  
  console.log('=== All Classes ===\n');
  for (const c of classes) {
    console.log(`${c.name}: ${c.subclasses.length} subclasses`);
    for (const s of c.subclasses) {
      console.log(`  - ${s.name}`);
    }
  }
  
  console.log(`\nTotal: ${classes.length} classes`);
}

verifyClasses();
