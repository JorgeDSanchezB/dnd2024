import { db } from '../src/lib/db';

async function fixSpeciesTraits() {
  console.log('=== Fixing Species Traits ===\n');
  
  const species = await db.species.findMany();
  
  for (const sp of species) {
    if (!sp.traits) continue;
    
    try {
      const parsed = JSON.parse(sp.traits);
      
      // Check if it's the wrong format (array with string inside)
      if (Array.isArray(parsed) && parsed.length > 0 && typeof parsed[0] === 'string') {
        console.log(`Fixing: ${sp.name}`);
        
        // Parse the inner JSON string
        const innerData = JSON.parse(parsed[0]);
        
        // Convert to proper format
        const newTraits: { name: string; description: string }[] = [];
        
        for (const [key, value] of Object.entries(innerData)) {
          // Convert camelCase to Title Case for name
          const name = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase()).trim();
          newTraits.push({
            name,
            description: String(value)
          });
        }
        
        const newTraitsJson = JSON.stringify(newTraits);
        
        await db.species.update({
          where: { id: sp.id },
          data: { traits: newTraitsJson }
        });
        
        console.log(`  Converted ${newTraits.length} traits`);
      } else if (Array.isArray(parsed) && parsed.length > 0 && typeof parsed[0] === 'object') {
        console.log(`✓ Already correct: ${sp.name} (${parsed.length} traits)`);
      }
    } catch (e) {
      console.log(`Error parsing ${sp.name}: ${e}`);
    }
  }
  
  console.log('\n=== Done! ===');
}

fixSpeciesTraits().catch(console.error);
