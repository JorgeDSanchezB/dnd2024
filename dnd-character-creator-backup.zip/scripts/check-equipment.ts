import { db } from '../src/lib/db';

async function checkEquipment() {
  const backgrounds = await db.background.findMany({
    select: { name: true, equipment: true },
    orderBy: { name: 'asc' }
  });
  
  console.log('=== Equipment Format Check ===\n');
  
  for (const bg of backgrounds) {
    if (bg.equipment) {
      try {
        const parsed = JSON.parse(bg.equipment);
        if (parsed.A && parsed.B) {
          console.log(`✓ ${bg.name}: JSON con A/B`);
        } else {
          console.log(`? ${bg.name}: JSON sin A/B - ${bg.equipment.substring(0, 60)}...`);
        }
      } catch {
        console.log(`✗ ${bg.name}: Texto simple - "${bg.equipment.substring(0, 60)}..."`);
      }
    }
  }
}

checkEquipment().catch(console.error);
