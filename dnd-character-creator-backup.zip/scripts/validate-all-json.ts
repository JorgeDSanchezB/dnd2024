import { db } from '../src/lib/db';

async function validateAllJson() {
  console.log('=== Validating all JSON fields ===\n');
  
  let errors = 0;
  
  // Check Backgrounds
  console.log('Checking Backgrounds...');
  const backgrounds = await db.background.findMany();
  for (const bg of backgrounds) {
    const fields = ['skillProficiencies', 'abilityScores', 'equipment'];
    for (const field of fields) {
      const value = (bg as any)[field];
      if (value && typeof value === 'string') {
        try {
          JSON.parse(value);
        } catch (e) {
          console.log(`  ERROR: ${bg.name}.${field} - Invalid JSON: ${value.substring(0, 50)}...`);
          errors++;
        }
      }
    }
  }
  
  // Check Feats
  console.log('Checking Feats...');
  const feats = await db.feat.findMany();
  for (const feat of feats) {
    const fields = ['spellsGranted', 'abilityScoreOptions', 'spellOptions', 'skillProficienciesGranted'];
    for (const field of fields) {
      const value = (feat as any)[field];
      if (value && typeof value === 'string') {
        try {
          JSON.parse(value);
        } catch (e) {
          console.log(`  ERROR: ${feat.name}.${field} - Invalid JSON: ${value.substring(0, 50)}...`);
          errors++;
        }
      }
    }
  }
  
  // Check Spells
  console.log('Checking Spells...');
  const spells = await db.spell.findMany();
  for (const spell of spells) {
    const fields = ['classes'];
    for (const field of fields) {
      const value = (spell as any)[field];
      if (value && typeof value === 'string') {
        try {
          JSON.parse(value);
        } catch (e) {
          console.log(`  ERROR: ${spell.name}.${field} - Invalid JSON: ${value.substring(0, 50)}...`);
          errors++;
        }
      }
    }
  }
  
  // Check Species
  console.log('Checking Species...');
  const species = await db.species.findMany();
  for (const sp of species) {
    const fields = ['traits', 'languages', 'skillProficiencies'];
    for (const field of fields) {
      const value = (sp as any)[field];
      if (value && typeof value === 'string') {
        try {
          JSON.parse(value);
        } catch (e) {
          console.log(`  ERROR: ${sp.name}.${field} - Invalid JSON: ${value.substring(0, 50)}...`);
          errors++;
        }
      }
    }
  }
  
  // Check Subclasses
  console.log('Checking Subclasses...');
  const subclasses = await db.subclass.findMany();
  for (const sub of subclasses) {
    const fields = ['features', 'subclassSpells'];
    for (const field of fields) {
      const value = (sub as any)[field];
      if (value && typeof value === 'string') {
        try {
          JSON.parse(value);
        } catch (e) {
          console.log(`  ERROR: ${sub.name}.${field} - Invalid JSON: ${value.substring(0, 50)}...`);
          errors++;
        }
      }
    }
  }
  
  console.log('\n=== Validation Complete ===');
  console.log(`Total errors: ${errors}`);
}

validateAllJson().catch(console.error);
