import { db } from '../src/lib/db';

async function checkDatabase() {
  console.log('=== Database Summary ===\n');
  
  const counts = {
    species: await db.species.count(),
    classes: await db.characterClass.count(),
    subclasses: await db.subclass.count(),
    backgrounds: await db.background.count(),
    feats: await db.feat.count(),
    spells: await db.spell.count(),
    weapons: await db.weapon.count(),
    armor: await db.armor.count(),
    items: await db.item.count(),
    magicItems: await db.magicItem.count(),
    monsters: await db.monster.count(),
    characters: await db.character.count()
  };
  
  console.log('Counts:');
  for (const [key, value] of Object.entries(counts)) {
    console.log(`  ${key}: ${value}`);
  }
  
  // Check for backgrounds with valid JSON skillProficiencies
  const bgs = await db.background.findMany({ select: { name: true, skillProficiencies: true } });
  let validJson = 0;
  let invalidJson = 0;
  
  for (const bg of bgs) {
    try {
      if (bg.skillProficiencies) {
        JSON.parse(bg.skillProficiencies);
        validJson++;
      }
    } catch {
      invalidJson++;
      console.log(`  Invalid JSON in: ${bg.name}`);
    }
  }
  
  console.log(`\nBackground JSON check:`);
  console.log(`  Valid: ${validJson}`);
  console.log(`  Invalid: ${invalidJson}`);
  
  // Check some specific Forgotten Realms data
  console.log('\nForgotten Realms Heroes samples:');
  const frSubclass = await db.subclass.findFirst({ where: { name: 'Bladesinger' } });
  console.log(`  Bladesinger subclass: ${frSubclass ? 'Found' : 'NOT FOUND'}`);
  
  const frBackground = await db.background.findFirst({ where: { name: 'Harper' } });
  console.log(`  Harper background: ${frBackground ? 'Found' : 'NOT FOUND'}`);
  
  const frFeat = await db.feat.findFirst({ where: { name: 'Elven Accuracy' } });
  console.log(`  Elven Accuracy feat: ${frFeat ? 'Found' : 'NOT FOUND'}`);
  
  const frSpell = await db.spell.findFirst({ where: { name: "Alustriel's Moonbeam" } });
  console.log(`  Alustriel's Moonbeam spell: ${frSpell ? 'Found' : 'NOT FOUND'}`);
  
  console.log('\n=== Check Complete ===');
}

checkDatabase().catch(console.error);
