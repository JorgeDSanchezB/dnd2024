import { db } from '../src/lib/db';

async function fixBackgrounds() {
  console.log('Checking backgrounds with invalid skillProficiencies...');
  
  const backgrounds = await db.background.findMany();
  
  for (const bg of backgrounds) {
    let needsFix = false;
    let fixedSkills = bg.skillProficiencies;
    let fixedTool = bg.toolProficiencies;
    let fixedLanguages = bg.languages;
    
    // Check skillProficiencies
    if (bg.skillProficiencies && !bg.skillProficiencies.startsWith('[')) {
      // Convert plain text to JSON array
      const skills = bg.skillProficiencies.split(',').map(s => s.trim()).filter(s => s);
      fixedSkills = JSON.stringify(skills);
      needsFix = true;
      console.log(`Fixing ${bg.name}: skillProficiencies "${bg.skillProficiencies}" -> ${fixedSkills}`);
    }
    
    // Check toolProficiencies
    if (bg.toolProficiencies && !bg.toolProficiencies.startsWith('[')) {
      const tools = bg.toolProficiencies.split(',').map(s => s.trim()).filter(s => s);
      fixedTool = JSON.stringify(tools);
      needsFix = true;
      console.log(`Fixing ${bg.name}: toolProficiencies "${bg.toolProficiencies}" -> ${fixedTool}`);
    }
    
    // Check languages
    if (bg.languages && !bg.languages.startsWith('[')) {
      const langs = bg.languages.split(',').map(s => s.trim()).filter(s => s);
      fixedLanguages = JSON.stringify(langs);
      needsFix = true;
      console.log(`Fixing ${bg.name}: languages "${bg.languages}" -> ${fixedLanguages}`);
    }
    
    if (needsFix) {
      await db.background.update({
        where: { id: bg.id },
        data: {
          skillProficiencies: fixedSkills,
          toolProficiencies: fixedTool,
          languages: fixedLanguages
        }
      });
      console.log(`Updated: ${bg.name}`);
    }
  }
  
  console.log('\nDone fixing backgrounds!');
}

fixBackgrounds().catch(console.error);
