import { db } from '../src/lib/db';

async function verifyAllCharacters() {
  const chars = await db.character.findMany();
  
  console.log('=== All Characters Field Verification ===\n');
  
  const fields = [
    'toolProficiencies', 
    'weaponProficiencies', 
    'armorProficiencies', 
    'languages',
    'classFeatures',
    'speciesTraits'
  ];
  
  let allCorrect = true;
  
  for (const char of chars) {
    let charOk = true;
    
    for (const field of fields) {
      const value = (char as any)[field];
      if (!value) continue;
      
      try {
        const parsed = JSON.parse(value);
        
        // Check for nested JSON strings
        if (Array.isArray(parsed)) {
          for (const item of parsed) {
            if (typeof item === 'string' && (item.startsWith('[') || item.startsWith('{'))) {
              try {
                JSON.parse(item); // If this succeeds, it's nested JSON
                console.log(`✗ ${char.name}.${field}: Nested JSON - ${item.substring(0, 40)}...`);
                charOk = false;
                allCorrect = false;
              } catch {
                // Not nested JSON, it's fine
              }
            }
          }
        }
      } catch {
        console.log(`✗ ${char.name}.${field}: Invalid JSON`);
        charOk = false;
        allCorrect = false;
      }
    }
    
    if (charOk) {
      console.log(`✓ ${char.name}: All fields correct`);
    }
  }
  
  console.log(`\n${allCorrect ? '✓ ALL CORRECT!' : '✗ Some issues found'}`);
}

verifyAllCharacters().catch(console.error);
