import { db } from '../src/lib/db';

async function fixSpeciesTraits() {
  console.log('=== Fixing ALL Species Traits to Object Format ===\n');
  
  const species = await db.species.findMany();
  
  for (const sp of species) {
    if (!sp.traits) continue;
    
    console.log(`\n--- ${sp.name} ---`);
    console.log(`Current: ${sp.traits.substring(0, 100)}...`);
    
    try {
      const parsed = JSON.parse(sp.traits);
      let correctFormat: Record<string, string> = {};
      
      // Case 1: Array with objects {name, description}
      if (Array.isArray(parsed) && parsed.length > 0 && typeof parsed[0] === 'object' && parsed[0].name) {
        for (const trait of parsed) {
          // Convert name to camelCase key
          const key = trait.name
            .toLowerCase()
            .replace(/[^a-zA-Z0-9]+(.)/g, (_, chr) => chr.toUpperCase())
            .replace(/^./, chr => chr.toLowerCase());
          correctFormat[key] = trait.description;
        }
        console.log(`  Converting from [{name, description}] format`);
      }
      // Case 2: Array with strings (JSON inside)
      else if (Array.isArray(parsed) && parsed.length > 0 && typeof parsed[0] === 'string') {
        const inner = JSON.parse(parsed[0]);
        correctFormat = inner;
        console.log(`  Converting from ["{...}"] format`);
      }
      // Case 3: Already an object
      else if (typeof parsed === 'object' && !Array.isArray(parsed)) {
        console.log(`  ✓ Already correct format`);
        continue;
      }
      else {
        console.log(`  ✗ Unknown format`);
        continue;
      }
      
      const newTraits = JSON.stringify(correctFormat);
      console.log(`  Result keys: ${Object.keys(correctFormat).join(', ')}`);
      
      await db.species.update({
        where: { id: sp.id },
        data: { traits: newTraits }
      });
      
    } catch (e) {
      console.log(`  Error: ${e}`);
    }
  }
  
  console.log('\n=== Done! ===');
}

fixSpeciesTraits().catch(console.error);
