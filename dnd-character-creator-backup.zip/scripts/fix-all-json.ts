import { db } from '../src/lib/db';

async function fixAllJsonFields() {
  console.log('=== Fixing all JSON fields ===\n');
  
  // Fix Backgrounds - toolProficiency, equipment
  console.log('Checking Background toolProficiency and equipment...');
  const backgrounds = await db.background.findMany();
  
  for (const bg of backgrounds) {
    let needsFix = false;
    let updates: any = {};
    
    // Check toolProficiency
    if (bg.toolProficiency && !bg.toolProficiency.startsWith('[')) {
      const tools = bg.toolProficiency.split(',').map(s => s.trim()).filter(s => s);
      updates.toolProficiency = JSON.stringify(tools);
      needsFix = true;
      console.log(`  ${bg.name} toolProficiency: "${bg.toolProficiency}" -> ${updates.toolProficiency}`);
    }
    
    // Check equipment
    if (bg.equipment && !bg.equipment.startsWith('[')) {
      const equip = bg.equipment.split(',').map(s => s.trim()).filter(s => s);
      updates.equipment = JSON.stringify(equip);
      needsFix = true;
      console.log(`  ${bg.name} equipment: "${bg.equipment}" -> ${updates.equipment}`);
    }
    
    if (needsFix) {
      await db.background.update({
        where: { id: bg.id },
        data: updates
      });
    }
  }
  
  // Fix Species - traits, languages, skillProficiencies
  console.log('\nChecking Species...');
  const species = await db.species.findMany();
  
  for (const sp of species) {
    let needsFix = false;
    let updates: any = {};
    
    if (sp.traits && !sp.traits.startsWith('[')) {
      updates.traits = JSON.stringify([sp.traits]);
      needsFix = true;
      console.log(`  ${sp.name} traits fixed`);
    }
    
    if (sp.languages && !sp.languages.startsWith('[')) {
      const langs = sp.languages.split(',').map(s => s.trim()).filter(s => s);
      updates.languages = JSON.stringify(langs);
      needsFix = true;
      console.log(`  ${sp.name} languages: "${sp.languages}" -> ${updates.languages}`);
    }
    
    if (sp.skillProficiencies && !sp.skillProficiencies.startsWith('[')) {
      const skills = sp.skillProficiencies.split(',').map(s => s.trim()).filter(s => s);
      updates.skillProficiencies = JSON.stringify(skills);
      needsFix = true;
      console.log(`  ${sp.name} skillProficiencies fixed`);
    }
    
    if (needsFix) {
      await db.species.update({
        where: { id: sp.id },
        data: updates
      });
    }
  }
  
  // Fix Subclasses - features
  console.log('\nChecking Subclass features...');
  const subclasses = await db.subclass.findMany();
  
  for (const sub of subclasses) {
    if (sub.features) {
      try {
        const parsed = JSON.parse(sub.features);
        // Already valid JSON
      } catch (e) {
        // Not valid JSON - try to fix
        console.log(`  ${sub.name} has invalid features JSON, needs manual review`);
      }
    }
  }
  
  // Fix Feats - prerequisites
  console.log('\nChecking Feat prerequisites...');
  const feats = await db.feat.findMany();
  
  for (const feat of feats) {
    if (feat.prerequisites && !feat.prerequisites.startsWith('[')) {
      const prereqs = feat.prerequisites.split(',').map(s => s.trim()).filter(s => s);
      await db.feat.update({
        where: { id: feat.id },
        data: { prerequisites: JSON.stringify(prereqs) }
      });
      console.log(`  ${feat.name} prerequisites fixed`);
    }
  }
  
  // Fix Spells - classes
  console.log('\nChecking Spell classes...');
  const spells = await db.spell.findMany();
  
  for (const spell of spells) {
    if (spell.classes && !spell.classes.startsWith('[')) {
      const classes = spell.classes.split(',').map(s => s.trim()).filter(s => s);
      await db.spell.update({
        where: { id: spell.id },
        data: { classes: JSON.stringify(classes) }
      });
      console.log(`  ${spell.name} classes fixed`);
    }
  }
  
  console.log('\n=== Done fixing all JSON fields! ===');
}

fixAllJsonFields().catch(console.error);
