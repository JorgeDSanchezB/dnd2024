import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

function parseToArray(value: string | null): string[] {
  if (!value) return []
  try {
    const parsed = JSON.parse(value)
    return Array.isArray(parsed) ? parsed : [parsed]
  } catch {
    return value.split(',').map(s => s.trim()).filter(s => s)
  }
}

function parseToObject(value: string | null): Record<string, any> | null {
  if (!value) return null
  try {
    const parsed = JSON.parse(value)
    return typeof parsed === 'object' ? parsed : null
  } catch {
    return null
  }
}

async function main() {
  console.log('Fixing ALL JSON fields in database...')
  
  // Fix Backgrounds
  console.log('\n--- Fixing Backgrounds ---')
  const backgrounds = await prisma.background.findMany()
  for (const bg of backgrounds) {
    const updates: any = {}
    
    if (bg.skillProficiencies) {
      const skills = parseToArray(bg.skillProficiencies)
      const skillsJson = JSON.stringify(skills)
      if (bg.skillProficiencies !== skillsJson) {
        updates.skillProficiencies = skillsJson
      }
    }
    
    if (bg.toolProficiency) {
      const tools = parseToArray(bg.toolProficiency)
      const toolsJson = JSON.stringify(tools)
      if (bg.toolProficiency !== toolsJson) {
        updates.toolProficiency = toolsJson
      }
    }
    
    if (bg.abilityScores) {
      const abilities = parseToArray(bg.abilityScores)
      const abilitiesJson = JSON.stringify(abilities)
      if (bg.abilityScores !== abilitiesJson) {
        updates.abilityScores = abilitiesJson
      }
    }
    
    if (Object.keys(updates).length > 0) {
      await prisma.background.update({ where: { id: bg.id }, data: updates })
      console.log(`Updated background: ${bg.name}`)
    }
  }
  
  // Fix Spells
  console.log('\n--- Fixing Spells ---')
  const spells = await prisma.spell.findMany()
  for (const spell of spells) {
    const updates: any = {}
    
    if (spell.classes) {
      const classes = parseToArray(spell.classes)
      const classesJson = JSON.stringify(classes)
      if (spell.classes !== classesJson) {
        updates.classes = classesJson
      }
    }
    
    if (Object.keys(updates).length > 0) {
      await prisma.spell.update({ where: { id: spell.id }, data: updates })
      console.log(`Updated spell: ${spell.name}`)
    }
  }
  
  // Fix CharacterClasses
  console.log('\n--- Fixing CharacterClasses ---')
  const classes = await prisma.characterClass.findMany()
  for (const cls of classes) {
    const updates: any = {}
    
    if (cls.savingThrows) {
      const saves = parseToArray(cls.savingThrows)
      const savesJson = JSON.stringify(saves)
      if (cls.savingThrows !== savesJson) {
        updates.savingThrows = savesJson
      }
    }
    
    if (cls.skillProficiencies) {
      try {
        const parsed = JSON.parse(cls.skillProficiencies)
        // It's already an object or array, leave it
      } catch {
        // Not valid JSON, try to parse as comma-separated
        const skills = cls.skillProficiencies.split(',').map(s => s.trim()).filter(s => s)
        updates.skillProficiencies = JSON.stringify(skills)
      }
    }
    
    if (Object.keys(updates).length > 0) {
      await prisma.characterClass.update({ where: { id: cls.id }, data: updates })
      console.log(`Updated class: ${cls.name}`)
    }
  }
  
  // Fix Characters
  console.log('\n--- Fixing Characters ---')
  const characters = await prisma.character.findMany()
  for (const char of characters) {
    const updates: any = {}
    
    if (char.toolProficiencies) {
      try {
        JSON.parse(char.toolProficiencies)
      } catch {
        updates.toolProficiencies = JSON.stringify(parseToArray(char.toolProficiencies))
      }
    }
    
    if (char.weaponProficiencies) {
      try {
        JSON.parse(char.weaponProficiencies)
      } catch {
        updates.weaponProficiencies = JSON.stringify(parseToArray(char.weaponProficiencies))
      }
    }
    
    if (char.armorProficiencies) {
      try {
        JSON.parse(char.armorProficiencies)
      } catch {
        updates.armorProficiencies = JSON.stringify(parseToArray(char.armorProficiencies))
      }
    }
    
    if (Object.keys(updates).length > 0) {
      await prisma.character.update({ where: { id: char.id }, data: updates })
      console.log(`Updated character: ${char.name}`)
    }
  }
  
  // Fix Feats
  console.log('\n--- Fixing Feats ---')
  const feats = await prisma.feat.findMany()
  for (const feat of feats) {
    const updates: any = {}
    
    if (feat.abilityScoreOptions) {
      try {
        JSON.parse(feat.abilityScoreOptions)
      } catch {
        updates.abilityScoreOptions = JSON.stringify(parseToArray(feat.abilityScoreOptions))
      }
    }
    
    if (feat.spellsGranted) {
      try {
        JSON.parse(feat.spellsGranted)
      } catch {
        updates.spellsGranted = JSON.stringify(parseToArray(feat.spellsGranted))
      }
    }
    
    if (Object.keys(updates).length > 0) {
      await prisma.feat.update({ where: { id: feat.id }, data: updates })
      console.log(`Updated feat: ${feat.name}`)
    }
  }
  
  console.log('\n--- Done! ---')
}

main()
  .catch(console.error)
  .finally(() => prisma.$disconnect())
