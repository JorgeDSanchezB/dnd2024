import { db } from '../src/lib/db';

async function checkBackgrounds() {
  const bgs = await db.background.findMany({ orderBy: { name: 'asc' } });
  
  console.log('=== Background toolProficiency Check ===\n');
  
  for (const bg of bgs) {
    if (!bg.toolProficiency) continue;
    
    // Check if it's JSON or plain text
    if (bg.toolProficiency.startsWith('[')) {
      try {
        const parsed = JSON.parse(bg.toolProficiency);
        console.log(`${bg.name}: JSON array - ${bg.toolProficiency}`);
      } catch {
        console.log(`${bg.name}: Invalid JSON - ${bg.toolProficiency}`);
      }
    } else {
      // Plain text - this is correct
    }
  }
  console.log('\nDone');
}

checkBackgrounds().catch(console.error);
