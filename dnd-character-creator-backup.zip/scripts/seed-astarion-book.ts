import { db } from '../src/lib/db'

async function main() {
  console.log('🌱 Seeding Astarion\'s Book of Hungers data...')

  // ========================================
  // SPECIES - Dhampir
  // ========================================
  console.log('Adding Species: Dhampir...')
  const dhampir = await db.species.upsert({
    where: { name: 'Dhampir' },
    update: {},
    create: {
      name: 'Dhampir',
      description: 'Dhampirs are living people who possess vampiric prowess but are cursed with macabre hunger. Most dhampirs thirst for blood, but some gain sustenance from dreams, life energy, or other vital sources. Dhampirs must choose whether to fight to control their hunger or give in to predatory urges. Dhampirs often arise from encounters with vampires; some are the descendants of a powerful vampire, while others are partially transformed by a vampire\'s bite.',
      size: 'Medium or Small',
      speed: 35,
      traits: JSON.stringify([
        {
          name: 'Creature Type',
          description: 'Humanoid'
        },
        {
          name: 'Size',
          description: 'Medium (about 4–7 feet tall) or Small (about 2–4 feet tall), chosen when you select this species'
        },
        {
          name: 'Speed',
          description: '35 feet'
        },
        {
          name: 'Darkvision',
          description: 'You have Darkvision with a range of 60 feet.'
        },
        {
          name: 'Spider Climb',
          description: 'You have a Climb Speed equal to your Speed. When you reach character level 3, you can move up, down, and across vertical surfaces and along ceilings while leaving your hands free.'
        },
        {
          name: 'Trace of Undeath',
          description: 'You have Resistance to Necrotic damage.'
        },
        {
          name: 'Vampiric Bite',
          description: 'When you use your Unarmed Strike and deal damage, you can choose to bite with your fangs. You deal Piercing damage equal to 1d4 plus your Constitution modifier instead of the normal damage of an Unarmed Strike. In addition, when you deal this damage to a creature that isn\'t a Construct or an Undead, you can empower yourself in one of the following ways:\n• Drain: You regain Hit Points equal to the Piercing damage dealt.\n• Strengthen: You gain a bonus to the next ability check or attack roll you make within the next minute; the bonus is equal to the Piercing damage dealt.\nYou can empower yourself with this trait a number of times equal to your Proficiency Bonus, and you regain all expended uses when you finish a Long Rest.'
        }
      ])
    }
  })
  console.log('✓ Dhampir created')

  // ========================================
  // BACKGROUNDS
  // ========================================
  console.log('Adding Backgrounds...')
  
  const carouser = await db.background.upsert({
    where: { name: 'Carouser' },
    update: {},
    create: {
      name: 'Carouser',
      description: 'You grew to adulthood in the beating heart of a large city, such as Baldur\'s Gate. You spent countless evenings in taverns, playhouses, parlors, and gambling dens, savoring all the city had to offer. You\'re a natural at interacting with people to learn their secrets, whether over a high-stakes game or at a high-class soiree. You might have been thrown out of an establishment or ten, but only by people who don\'t know how to party.',
      abilityScores: '["Dexterity","Intelligence","Charisma"]',
      feat: 'Tireless Reveler',
      skillProficiencies: 'Deception, Persuasion',
      toolProficiency: 'Choose one kind of Gaming Set',
      equipment: 'Choose A or B: (A) Dagger, Gaming Set (same as above), Fine Clothes, Glass Bottle, Mirror, Perfume, Pouch, Tinderbox, 19 GP; or (B) 50 GP'
    }
  })
  console.log('✓ Carouser created')

  const vampireDevotee = await db.background.upsert({
    where: { name: 'Vampire Devotee' },
    update: {},
    create: {
      name: 'Vampire Devotee',
      description: 'You were in service to a vampire or a small group of vampires lairing together. The Undead drank your blood more times than you can count. You might have served willingly, perhaps with aspirations of one day becoming a vampire yourself. Or you might have been magically charmed and retain only a few muddled memories of your time as a vampire familiar. In either case, your time in the vampire den is over.',
      abilityScores: '["Strength","Constitution","Charisma"]',
      feat: 'Vampire\'s Plaything',
      skillProficiencies: 'Persuasion, Stealth',
      toolProficiency: 'Cook\'s Utensils',
      equipment: 'Choose A or B: (A) Cook\'s Utensils, Fine Clothes, 2 Glass Bottles, Healer\'s Kit, Perfume, Lamp, Oil (3 flasks), Waterskin, 19 GP; or (B) 50 GP'
    }
  })
  console.log('✓ Vampire Devotee created')

  const vampireSurvivor = await db.background.upsert({
    where: { name: 'Vampire Survivor' },
    update: {},
    create: {
      name: 'Vampire Survivor',
      description: 'You witnessed or survived a vampire attack. You might have been directly involved in this confrontation, or perhaps you were frozen in terror by what you saw. Regardless, you remain vigilant for monster attacks and pride yourself on being ready for anything. No vampire will catch you or your allies by surprise again.',
      abilityScores: '["Dexterity","Constitution","Wisdom"]',
      feat: 'Vampire Hunter',
      skillProficiencies: 'Insight, Religion',
      toolProficiency: 'Woodcarver\'s Tools',
      equipment: 'Choose A or B: (A) Woodcarver\'s Tools, Crowbar, Hooded Lantern, Holy Symbol (reliquary), Holy Water, Mirror, Oil (3 flasks), Tinderbox, Traveler\'s Clothes, Waterskin, 4 GP; or (B) 50 GP'
    }
  })
  console.log('✓ Vampire Survivor created')

  // ========================================
  // FEATS
  // ========================================
  console.log('Adding Feats...')

  // ORIGIN FEATS
  const tirelessReveler = await db.feat.upsert({
    where: { name: 'Tireless Reveler' },
    update: {},
    create: {
      name: 'Tireless Reveler',
      category: 'Origin',
      prerequisite: null,
      description: 'When an ally you can see within 60 feet of yourself expends Heroic Inspiration, you can gain Heroic Inspiration if you lack it.',
      benefit: 'You can use this benefit a number of times equal to your Proficiency Bonus, and you regain all expended uses when you finish a Short or Long Rest.',
      repeatable: false,
      abilityScoreBonus: 0
    }
  })
  console.log('✓ Tireless Reveler created')

  const vampireHunter = await db.feat.upsert({
    where: { name: 'Vampire Hunter' },
    update: {},
    create: {
      name: 'Vampire Hunter',
      category: 'Origin',
      prerequisite: null,
      description: 'You gain the following benefits.',
      benefit: 'Adroit Escape: You have Advantage on checks to escape from nonmagical restraints or the Grappled condition.\n\nVitality Ward: When you take Necrotic damage, you can take a Reaction to mitigate the damage. Roll a number of d6s equal to your Proficiency Bonus, and add them together. Reduce the Necrotic damage you take by this total. Once you use this benefit, you can\'t use it again until you finish a Short or Long Rest.',
      repeatable: false,
      abilityScoreBonus: 0
    }
  })
  console.log('✓ Vampire Hunter created')

  const vampiresPlaything = await db.feat.upsert({
    where: { name: 'Vampire\'s Plaything' },
    update: {},
    create: {
      name: 'Vampire\'s Plaything',
      category: 'Origin',
      prerequisite: null,
      description: 'You gain the following benefits.',
      benefit: 'Decanting: When you finish a Long Rest, you can create one Potion of Healing or an Antitoxin, as long as you have an empty vial or flask. These liquids evaporate when you finish another Long Rest.\n\nTimely Retreat: You can take a Bonus Action to take the Dash action or the Disengage action. You can use this benefit a number of times equal to your Proficiency Bonus, and you recover all expended uses when you finish a Long Rest.\n\nVampiric Connection: The DM determines the fate of your former vampire master. While you and your former vampire master are on the same plane of existence, the vampire can communicate with you telepathically, and you can choose to allow the vampire to perceive through your senses.',
      repeatable: false,
      abilityScoreBonus: 0
    }
  })
  console.log('✓ Vampire\'s Plaything created')

  // GENERAL FEATS
  const bloodlust = await db.feat.upsert({
    where: { name: 'Bloodlust' },
    update: {},
    create: {
      name: 'Bloodlust',
      category: 'General',
      prerequisite: 'Level 4+',
      description: 'You gain the following benefits.',
      benefit: 'Ability Score Increase: Increase your Strength, Dexterity, or Constitution score by 1, to a maximum of 20.\n\nPowerful Recovery: When you roll a Hit Point Die to regain Hit Points, you can treat any roll of 1 or 2 as a 3.\n\nSanguine Feast: Once per turn when you hit a Bloodied creature that isn\'t a Construct or Undead with an attack roll, you can expend a Hit Point Die, roll it, and regain a number of Hit Points equal to the number rolled plus your Constitution modifier. You can use this feature a number of times equal to your Proficiency Bonus, and you regain all expended uses when you finish a Long Rest.',
      repeatable: false,
      abilityScoreOptions: 'Strength, Dexterity, Constitution',
      abilityScoreBonus: 1
    }
  })
  console.log('✓ Bloodlust created')

  const bomber = await db.feat.upsert({
    where: { name: 'Bomber' },
    update: {},
    create: {
      name: 'Bomber',
      category: 'General',
      prerequisite: 'Level 4+',
      description: 'You gain the following benefits.',
      benefit: 'Ability Score Increase: Increase your Dexterity score by 1, to a maximum of 20.\n\nFar Lobber: When you use the Attack action to throw a vial or flask, you can target an object or creature you can see within 40 feet of yourself.\n\nLong Shots: Attacking at long range doesn\'t impose Disadvantage on your attack rolls with Thrown weapons.',
      repeatable: false,
      abilityScoreOptions: 'Dexterity',
      abilityScoreBonus: 1
    }
  })
  console.log('✓ Bomber created')

  const cloyingMists = await db.feat.upsert({
    where: { name: 'Cloying Mists' },
    update: {},
    create: {
      name: 'Cloying Mists',
      category: 'General',
      prerequisite: 'Level 4+',
      description: 'You gain the following benefits.',
      benefit: 'Ability Score Increase: Increase your Intelligence, Wisdom, or Charisma score by 1, to a maximum of 20.\n\nArise, Fog: You always have the Fog Cloud spell prepared. You can cast it without a spell slot, and you must finish a Long Rest before you can cast it in this way again. You can also cast it using spell slots you have of the appropriate level. Your spellcasting ability for the spell is the ability increased by this feat.\n\nGrasping Mist: Whenever you cast Fog Cloud, nonmagical flames in the spell\'s Sphere are extinguished, and creatures other than you and your allies have their Speed reduced by 5 feet while in the spell\'s Sphere.',
      repeatable: false,
      abilityScoreOptions: 'Intelligence, Wisdom, Charisma',
      abilityScoreBonus: 1,
      spellsGranted: 'Fog Cloud'
    }
  })
  console.log('✓ Cloying Mists created')

  const deliciousPain = await db.feat.upsert({
    where: { name: 'Delicious Pain' },
    update: {},
    create: {
      name: 'Delicious Pain',
      category: 'General',
      prerequisite: 'Level 4+',
      description: 'You gain the following benefits.',
      benefit: 'Ability Score Increase: Increase one ability score of your choice by 1, to a maximum of 20.\n\nToughened Flesh: Immediately after you take Bludgeoning, Piercing, or Slashing damage, you can take a Reaction to gain Resistance to Bludgeoning, Piercing, and Slashing damage until the start of your next turn. Once you use this benefit, you can\'t use it again until you finish a Short or Long Rest.',
      repeatable: false,
      abilityScoreOptions: 'Any',
      abilityScoreBonus: 1
    }
  })
  console.log('✓ Delicious Pain created')

  const lightBringer = await db.feat.upsert({
    where: { name: 'Light Bringer' },
    update: {},
    create: {
      name: 'Light Bringer',
      category: 'General',
      prerequisite: 'Level 4+',
      description: 'You gain the following benefits.',
      benefit: 'Ability Score Increase: Increase your Intelligence, Wisdom, or Charisma score by 1, to a maximum of 20.\n\nSacred Magic: You learn the Light spell and can cast it without Material components. If you already know that cantrip, you learn a different Cleric cantrip of your choice. The spell\'s spellcasting ability is the ability increased by this feat.\n\nSolar Luminance: When you cast Light, you can have the light from the spell be sunlight. Once you use this benefit, you can\'t use it again until you finish a Long Rest.\n\nSun\'s Healing: As a Bonus Action while within sunlight, you can expend one of your Hit Point Dice, roll the die, and regain a number of Hit Points equal to the roll. Once you use this benefit, you can\'t use it again until you finish a Short or Long Rest.',
      repeatable: false,
      abilityScoreOptions: 'Intelligence, Wisdom, Charisma',
      abilityScoreBonus: 1,
      spellsGranted: 'Light'
    }
  })
  console.log('✓ Light Bringer created')

  const loveBites = await db.feat.upsert({
    where: { name: 'Love Bites' },
    update: {},
    create: {
      name: 'Love Bites',
      category: 'General',
      prerequisite: 'Level 4+',
      description: 'You gain the following benefits.',
      benefit: 'Ability Score Increase: Increase one ability score of your choice by 1, to a maximum of 20.\n\nEndearing Pain: Immediately after you damage a creature with a Melee weapon or an Unarmed Strike, you can take a Bonus Action to give the target the Charmed condition until the start of your next turn or until you or your allies damage it. Once you use this benefit, you can\'t use it again until you finish a Short or Long Rest.',
      repeatable: false,
      abilityScoreOptions: 'Any',
      abilityScoreBonus: 1
    }
  })
  console.log('✓ Love Bites created')

  const putrefy = await db.feat.upsert({
    where: { name: 'Putrefy' },
    update: {},
    create: {
      name: 'Putrefy',
      category: 'General',
      prerequisite: 'Level 4+',
      description: 'You gain the following benefits.',
      benefit: 'Ability Score Increase: Increase one ability score of your choice by 1, to a maximum of 20.\n\nNecrosis: When you make a damage roll that deals Necrotic damage, you can cause one creature taking that damage to have the Poisoned condition until the start of your next turn. Once you use this benefit, you can\'t use it again until you finish a Short or Long Rest.',
      repeatable: false,
      abilityScoreOptions: 'Any',
      abilityScoreBonus: 1
    }
  })
  console.log('✓ Putrefy created')

  const rebuke = await db.feat.upsert({
    where: { name: 'Rebuke' },
    update: {},
    create: {
      name: 'Rebuke',
      category: 'General',
      prerequisite: 'Level 4+',
      description: 'You gain the following benefits.',
      benefit: 'Ability Score Increase: Increase one ability score of your choice by 1, to a maximum of 20.\n\nRadiant Strike: When you make a damage roll that deals Radiant damage, you can cause one Huge or smaller creature taking the damage to have the Prone condition. Once you use this benefit, you can\'t use it again until you finish a Short or Long Rest.',
      repeatable: false,
      abilityScoreOptions: 'Any',
      abilityScoreBonus: 1
    }
  })
  console.log('✓ Rebuke created')

  const treacherousAllure = await db.feat.upsert({
    where: { name: 'Treacherous Allure' },
    update: {},
    create: {
      name: 'Treacherous Allure',
      category: 'General',
      prerequisite: 'Level 4+',
      description: 'You gain the following benefits.',
      benefit: 'Ability Score Increase: Increase your Intelligence, Wisdom, or Charisma score by 1, to a maximum of 20.\n\nEnchanting Presence: You always have the Charm Person spell prepared. You can cast it without a spell slot, and you must finish a Long Rest before you can cast it in this way again. You can also cast it using spell slots you have of the appropriate level. Your spellcasting ability for the spell is the ability increased by this feat.\n\nInevitable Betrayal: You have Advantage on attack rolls against creatures with the Charmed condition.',
      repeatable: false,
      abilityScoreOptions: 'Intelligence, Wisdom, Charisma',
      abilityScoreBonus: 1,
      spellsGranted: 'Charm Person'
    }
  })
  console.log('✓ Treacherous Allure created')

  const vampireTouched = await db.feat.upsert({
    where: { name: 'Vampire Touched' },
    update: {},
    create: {
      name: 'Vampire Touched',
      category: 'General',
      prerequisite: 'Level 4+',
      description: 'You gain the following benefits.',
      benefit: 'Ability Score Increase: Increase your Intelligence, Wisdom, or Charisma score by 1, to a maximum of 20.\n\nVampire Magic: Choose one level 1 spell from the Enchantment or Illusion school of magic. You always have that spell and the Spider Climb spell prepared. You can cast each of these spells without expending a spell slot, but when you cast Spider Climb this way, you must target yourself, and you must finish a Long Rest before you can cast each spell in this way again. You can also cast either spell using spell slots you have of the appropriate level. Your spellcasting ability for the spells is the ability increased by this feat.',
      repeatable: false,
      abilityScoreOptions: 'Intelligence, Wisdom, Charisma',
      abilityScoreBonus: 1,
      spellsGranted: 'Spider Climb, one Enchantment or Illusion spell of choice'
    }
  })
  console.log('✓ Vampire Touched created')

  // EPIC BOON FEATS
  const boonOfBlazingDawn = await db.feat.upsert({
    where: { name: 'Boon of Blazing Dawn' },
    update: {},
    create: {
      name: 'Boon of Blazing Dawn',
      category: 'Epic Boon',
      prerequisite: 'Level 19+',
      description: 'You gain the following benefits.',
      benefit: 'Ability Score Increase: Increase one ability score of your choice by 1, to a maximum of 30.\n\nBeloved of the Sun: You have Immunity to Radiant damage.\n\nBlazing Strike: When you hit a creature with a weapon attack, the damage can be Radiant or the weapon\'s normal damage type (your choice).\n\nBurst of Sunlight: Once per turn when you hit a creature with an attack that deals Radiant damage, you can emit Bright Light in a 30-foot radius from yourself and Dim Light for an additional 30 feet until the start of your next turn. This light is sunlight.',
      repeatable: false,
      abilityScoreOptions: 'Any',
      abilityScoreBonus: 1
    }
  })
  console.log('✓ Boon of Blazing Dawn created')

  const boonOfLoomingShadows = await db.feat.upsert({
    where: { name: 'Boon of Looming Shadows' },
    update: {},
    create: {
      name: 'Boon of Looming Shadows',
      category: 'Epic Boon',
      prerequisite: 'Level 19+',
      description: 'You gain the following benefits.',
      benefit: 'Ability Score Increase: Increase one ability score of your choice by 1, to a maximum of 30.\n\nShadowy Stretch: When you take the Attack action, your reach for your Melee weapon attacks increases by 10 feet until the end of your turn.\n\nDancing Silhouette: You can take the Dodge action as a Bonus Action.',
      repeatable: false,
      abilityScoreOptions: 'Any',
      abilityScoreBonus: 1
    }
  })
  console.log('✓ Boon of Looming Shadows created')

  const boonOfMistyEscape = await db.feat.upsert({
    where: { name: 'Boon of Misty Escape' },
    update: {},
    create: {
      name: 'Boon of Misty Escape',
      category: 'Epic Boon',
      prerequisite: 'Level 19+',
      description: 'You gain the following benefits.',
      benefit: 'Ability Score Increase: Increase your Intelligence, Wisdom, or Charisma score by 1, to a maximum of 30.\n\nGaseous Form: If you drop to 0 Hit Points but aren\'t killed outright, you can instead drop to 1 Hit Point and cast Gaseous Form without expending a spell slot (no action required). When you cast this spell this way, you can target only yourself, your Fly Speed is 20 feet, and you regain 10 Hit Points at the start of each of your turns for the spell\'s duration. The spell\'s spellcasting ability is the ability increased by this feat. Once you use this benefit, you can\'t do so again until you finish a Long Rest.',
      repeatable: false,
      abilityScoreOptions: 'Intelligence, Wisdom, Charisma',
      abilityScoreBonus: 1
    }
  })
  console.log('✓ Boon of Misty Escape created')

  // ========================================
  // MONSTERS
  // ========================================
  console.log('Adding Monsters...')

  // Fiendish Icon
  const fiendishIcon = await db.monster.upsert({
    where: { name: 'Fiendish Icon' },
    update: {},
    create: {
      name: 'Fiendish Icon',
      type: 'Construct',
      size: 'Small',
      alignment: 'Lawful Evil',
      cr: 1,
      xp: 200,
      proficiencyBonus: 2,
      ac: 13,
      initiative: 1,
      hp: 22,
      hpFormula: '5d6 + 5',
      speed: '30 ft.',
      str: 15,
      strSave: 2,
      dex: 12,
      dexSave: 1,
      con: 13,
      conSave: 1,
      int: 6,
      intSave: -2,
      wis: 11,
      wisSave: 0,
      cha: 6,
      chaSave: -2,
      skills: JSON.stringify([{ name: 'Stealth', bonus: 5 }]),
      resistances: JSON.stringify([]),
      immunities: JSON.stringify(['Fire', 'Poison', 'Charmed', 'Deafened', 'Exhaustion', 'Frightened', 'Paralyzed', 'Petrified', 'Poisoned']),
      senses: 'Darkvision 60 ft.; Passive Perception 10',
      languages: 'Understands Common and Infernal but can\'t speak',
      traits: JSON.stringify([
        {
          name: 'Magic Resistance',
          description: 'The icon has Advantage on saving throws against spells and other magical effects.'
        }
      ]),
      actions: JSON.stringify([
        {
          name: 'Multiattack',
          description: 'The icon makes two Slam attacks and uses Fiery Eruption.'
        },
        {
          name: 'Slam',
          type: 'Melee Attack',
          description: 'Melee Attack Roll: +4, reach 5 ft. Hit: 4 (1d4 + 2) Bludgeoning damage.'
        },
        {
          name: 'Fiery Eruption',
          type: 'Save',
          description: 'Dexterity Saving Throw: DC 11, each creature in a 5-foot Emanation originating from the icon. Failure: 7 (2d6) Fire damage.'
        }
      ]),
      bonusActions: JSON.stringify([]),
      legendaryActions: JSON.stringify([]),
      reactions: JSON.stringify([]),
      lairActions: JSON.stringify([]),
      description: 'Fiendish icons are grotesque, sapient statues depicting fearsome fiends. These creatures gain life as a result of sinister rituals. Fiendish icons can explode with hellfire to roast their foes, and they often pretend to be ordinary statues until they leap up to ambush invaders.',
      habitat: 'Urban',
      treasure: 'None'
    }
  })
  console.log('✓ Fiendish Icon created')

  // Harvester Devil
  const harvesterDevil = await db.monster.upsert({
    where: { name: 'Harvester Devil' },
    update: {},
    create: {
      name: 'Harvester Devil',
      type: 'Fiend (Devil)',
      size: 'Medium',
      alignment: 'Lawful Evil',
      cr: 3,
      xp: 700,
      proficiencyBonus: 2,
      ac: 14,
      initiative: 3,
      hp: 65,
      hpFormula: '10d8 + 20',
      speed: '30 ft.',
      str: 12,
      strSave: 1,
      dex: 17,
      dexSave: 3,
      con: 14,
      conSave: 2,
      int: 14,
      intSave: 2,
      wis: 13,
      wisSave: 1,
      cha: 19,
      chaSave: 4,
      skills: JSON.stringify([
        { name: 'Perception', bonus: 3 },
        { name: 'Persuasion', bonus: 8 },
        { name: 'Stealth', bonus: 5 }
      ]),
      resistances: JSON.stringify(['Cold']),
      immunities: JSON.stringify(['Fire', 'Poison', 'Charmed', 'Poisoned']),
      senses: 'Darkvision 120 ft. (unimpeded by magical Darkness); Passive Perception 13',
      languages: 'Common, Infernal; telepathy 120 ft.',
      traits: JSON.stringify([
        {
          name: 'Diabolic Ward',
          description: 'Attack rolls against the devil have Disadvantage. If the devil makes an attack roll, this trait is suppressed until the start of its next turn.'
        },
        {
          name: 'Diabolical Restoration',
          description: 'If the devil dies outside the Nine Hells, its body disappears in sulfurous smoke, and it gains a new body instantly, reviving with all its Hit Points somewhere in the Nine Hells.'
        },
        {
          name: 'Magic Resistance',
          description: 'The devil has Advantage on saving throws against spells and other magical effects.'
        }
      ]),
      actions: JSON.stringify([
        {
          name: 'Multiattack',
          description: 'The devil makes two attacks, using Infernal Blade or Confounding Ray in any combination.'
        },
        {
          name: 'Infernal Blade',
          type: 'Melee Attack',
          description: 'Melee Attack Roll: +5, reach 5 ft. Hit: 6 (1d6 + 3) Slashing damage and 7 (2d6) Fire damage.'
        },
        {
          name: 'Confounding Ray',
          type: 'Ranged Attack',
          description: 'Ranged Attack Roll: +5, range 120 ft. Hit: 13 (2d12) Psychic damage. If the target is a creature, it can\'t make Opportunity Attacks until the start of the devil\'s next turn.'
        },
        {
          name: 'Compelling Contract',
          type: 'Save',
          uses: '1/Day',
          description: 'Charisma Saving Throw: DC 14, one creature within 30 feet of the devil. Failure: The target has the Charmed condition. While it is Charmed, it has the Stunned condition, except the target can speak. If the target agrees to the devil\'s contract, the effect ends. Otherwise, the target repeats the save whenever it takes damage and at the end of each of its turns, ending the effect on itself on a success. After 1 minute, it succeeds automatically.'
        }
      ]),
      bonusActions: JSON.stringify([]),
      legendaryActions: JSON.stringify([]),
      reactions: JSON.stringify([]),
      lairActions: JSON.stringify([]),
      description: 'With a name that hints at their skill at gathering souls for the Nine Hells, harvester devils are smooth-talking creatures that resemble tieflings. Also known as falxugons among the ranks of the Nine Hells, harvester devils have short horns and expressive tails. Most harvester devils dress in flattering finery. They promise wealth or influence to corruptible mortals, often securing a deal with a contract they produce in a flash of brimstone. This contract binds the mortal signatory\'s soul to the Nine Hells.',
      habitat: 'Planar (Nine Hells)',
      treasure: 'Implements'
    }
  })
  console.log('✓ Harvester Devil created')

  // Speaker Devil
  const speakerDevil = await db.monster.upsert({
    where: { name: 'Speaker Devil' },
    update: {},
    create: {
      name: 'Speaker Devil',
      type: 'Fiend (Devil)',
      size: 'Large',
      alignment: 'Lawful Evil',
      cr: 12,
      xp: 8400,
      proficiencyBonus: 4,
      ac: 17,
      initiative: 4,
      hp: 189,
      hpFormula: '18d10 + 90',
      speed: '30 ft., Fly 30 ft.',
      str: 21,
      strSave: 5,
      dex: 19,
      dexSave: 4,
      con: 20,
      conSave: 5,
      int: 22,
      intSave: 6,
      wis: 18,
      wisSave: 4,
      cha: 17,
      chaSave: 3,
      skills: JSON.stringify([
        { name: 'Arcana', bonus: 10 },
        { name: 'History', bonus: 10 },
        { name: 'Perception', bonus: 8 }
      ]),
      resistances: JSON.stringify(['Cold']),
      immunities: JSON.stringify(['Fire', 'Poison', 'Poisoned']),
      senses: 'Darkvision 120 ft. (unimpeded by magical Darkness); Passive Perception 18',
      languages: 'Infernal; telepathy 120 ft.',
      traits: JSON.stringify([
        {
          name: 'Diabolical Restoration',
          description: 'If the devil dies outside the Nine Hells, its body disappears in sulfurous smoke, and it gains a new body instantly, reviving with all its Hit Points somewhere in the Nine Hells.'
        },
        {
          name: 'Magic Resistance',
          description: 'The devil has Advantage on saving throws against spells and other magical effects.'
        }
      ]),
      actions: JSON.stringify([
        {
          name: 'Multiattack',
          description: 'The devil makes two Thundering Halberd attacks.'
        },
        {
          name: 'Thundering Halberd',
          type: 'Melee Attack',
          description: 'Melee Attack Roll: +9, reach 10 ft. Hit: 16 (2d10 + 5) Slashing damage plus 14 (4d6) Thunder damage.'
        },
        {
          name: 'Spellcasting',
          type: 'Spell',
          description: 'The devil casts one of the following spells, requiring no Material components and using Intelligence as the spellcasting ability (spell save DC 18):\nAt Will: Detect Magic, Detect Thoughts\n2/Day Each: Dimension Door, Modify Memory'
        }
      ]),
      bonusActions: JSON.stringify([
        {
          name: 'Utterance of Pain',
          type: 'Save',
          description: 'Wisdom Saving Throw: DC 18, each creature in a 20-foot Emanation originating from the devil. Failure: The target has the Stunned condition until the end of the devil\'s next turn.'
        },
        {
          name: 'Utterance of Unmaking',
          type: 'Save',
          description: 'Constitution Saving Throw: DC 18, each creature in a 20-foot Emanation originating from the devil. Failure: 22 (4d10) Force damage. Success: Half damage.'
        }
      ]),
      legendaryActions: JSON.stringify([]),
      reactions: JSON.stringify([]),
      lairActions: JSON.stringify([]),
      description: 'Speaker devils are hulking, four-armed devils who discover the secrets of creatures they then compel to perform wicked deeds. Despite their large tongues, speaker devils speak with clear and pleasing voices. Among the ranks of the Nine Hells, they are known as logokrons. Many speaker devils are loyal to the archdevil Mephistopheles. These devils record the secrets they uncover in Mephistar, Mephistopheles\'s vast library in Cania.',
      habitat: 'Planar (Nine Hells), Urban',
      treasure: 'Armaments'
    }
  })
  console.log('✓ Speaker Devil created')

  // Vampire Infernalist
  const vampireInfernalist = await db.monster.upsert({
    where: { name: 'Vampire Infernalist' },
    update: {},
    create: {
      name: 'Vampire Infernalist',
      type: 'Undead (Wizard)',
      size: 'Medium or Small',
      alignment: 'Lawful Evil',
      cr: 14,
      xp: 11500,
      proficiencyBonus: 5,
      ac: 16,
      initiative: 13,
      hp: 172,
      hpFormula: '23d8 + 69',
      speed: '40 ft., Fly 40 ft. (hover)',
      str: 19,
      strSave: 4,
      dex: 16,
      dexSave: 3,
      con: 17,
      conSave: 3,
      int: 20,
      intSave: 5,
      wis: 16,
      wisSave: 3,
      cha: 18,
      chaSave: 4,
      skills: JSON.stringify([
        { name: 'Arcana', bonus: 10 },
        { name: 'Perception', bonus: 8 },
        { name: 'Religion', bonus: 10 },
        { name: 'Stealth', bonus: 8 }
      ]),
      resistances: JSON.stringify(['Fire', 'Necrotic', 'Poison']),
      immunities: JSON.stringify(['Poisoned']),
      senses: 'Darkvision 120 ft. (unimpeded by magical Darkness); Passive Perception 18',
      languages: 'Common, Infernal',
      traits: JSON.stringify([
        {
          name: 'Legendary Resistance',
          uses: '3/Day, or 4/Day in Lair',
          description: 'If the vampire fails a saving throw, it can choose to succeed instead.'
        },
        {
          name: 'Misty Escape',
          description: 'If the vampire drops to 0 Hit Points outside its resting place, the vampire uses Shape-Shift to become mist (no action required). If it can\'t use Shape-Shift, it is destroyed. While it has 0 Hit Points in mist form, it can\'t return to its vampire form, and it must reach its resting place within 2 hours or be destroyed. Once in its resting place, it returns to its vampire form and has the Paralyzed condition until it regains any Hit Points, and it regains 1 Hit Point after spending 1 hour there.'
        },
        {
          name: 'Vampire Weakness',
          description: 'Forbiddance: The vampire can\'t enter a residence without an invitation from an occupant.\nRunning Water: The vampire takes 20 Acid damage if it ends its turn in running water.\nStake to the Heart: If a weapon that deals Piercing damage is driven into the vampire\'s heart while the vampire has the Incapacitated condition in its resting place, the vampire has the Paralyzed condition until the weapon is removed.\nSunlight: The vampire takes 20 Radiant damage if it starts its turn in sunlight. While in sunlight, it has Disadvantage on attack rolls and ability checks.'
        }
      ]),
      actions: JSON.stringify([
        {
          name: 'Multiattack',
          description: '(Vampire Form Only) The vampire makes two Hellfire Claw attacks and uses Bite.'
        },
        {
          name: 'Hellfire Claw',
          type: 'Melee Attack',
          description: '(Vampire Form Only) Melee Attack Roll: +9, reach 5 ft. Hit: 13 (2d8 + 4) Slashing damage plus 10 (3d6) Fire damage. If the target is a Medium or smaller creature, it has the Grappled condition (escape DC 17) from one of two claws.'
        },
        {
          name: 'Bite',
          type: 'Save',
          description: '(Imp or Vampire Form Only) Constitution Saving Throw: DC 18, one creature within 5 feet that is willing or that has the Grappled, Incapacitated, or Restrained condition. Failure: 6 (1d4 + 4) Piercing damage plus 16 (3d10) Necrotic damage and the creature loses its highest-level available spell slot (if any). The target\'s Hit Point maximum decreases by an amount equal to the Necrotic damage taken, and the vampire regains Hit Points equal to that amount. A Humanoid reduced to 0 Hit Points by this damage and then buried rises the following sunset as a Vampire Spawn under the vampire\'s control.'
        },
        {
          name: 'Spellcasting',
          type: 'Spell',
          description: 'The vampire casts one of the following spells, using Intelligence as the spellcasting ability (spell save DC 18):\nAt Will: Detect Magic, Detect Thoughts, Dispel Magic, Fireball (level 4 version), Mage Hand, Prestidigitation\n2/Day: Scrying\n1/Day: Wall of Fire'
        }
      ]),
      bonusActions: JSON.stringify([
        {
          name: 'Shape-Shift',
          description: 'If the vampire isn\'t in sunlight or running water, it shape-shifts into a Tiny imp (Speed 20 ft., Fly Speed 40 ft.), or a Medium cloud of mist (Speed 5 ft., Fly Speed 20 ft. over]), or it returns to its vampire form. Anything it is wearing transforms with it.\nWhile in imp form, the vampire\'s game statistics, other than its size and Speed, are unchanged.\nWhile in mist form, the vampire can\'t take any actions, speak, or manipulate objects. It is weightless and can enter an enemy\'s space and stop there. If air can pass through a space, the mist can do so, but it can\'t pass through liquid. It has Resistance to all damage, except the damage it takes from sunlight.'
        }
      ]),
      legendaryActions: JSON.stringify([
        {
          name: 'Hellfire Strike',
          cost: 1,
          description: 'The vampire moves up to half its Speed, and it makes one Hellfire Claw attack.'
        },
        {
          name: 'Infernal Majesty',
          cost: 1,
          description: 'Charisma Saving Throw: DC 17, each creature in a 20-foot Emanation originating from the vampire. Failure: 9 (2d8) Psychic damage, and the target has the Frightened condition until the start of its next turn. Success: Half damage only. Failure or Success: The vampire can\'t take this action again until the start of its next turn.'
        },
        {
          name: 'Teleport',
          cost: 1,
          description: 'The vampire teleports up to 30 feet to an unoccupied space it can see.'
        }
      ]),
      reactions: JSON.stringify([]),
      lairActions: JSON.stringify([
        {
          name: 'Diabolic Beasts',
          description: 'Animals in the vampire\'s domain serve the vampire\'s will. From dusk until dawn, Medium or smaller Beasts have the Charmed condition while within 1 mile of the lair.'
        },
        {
          name: 'Drained Essence',
          description: 'Grasping shadows within 1 mile of the lair sap the body and mind. Creatures (excluding the vampire and its allies) that finish a Short or Long Rest while within 1 mile of the lair make a DC 15 Wisdom saving throw. On a failed save, a creature can\'t spend Hit Point Dice at the end of the rest and doesn\'t regain Hit Points, Hit Point Dice, or spell slots at the end of the rest.'
        },
        {
          name: 'Tenacious Lore',
          description: 'Within 1 mile of the lair, flame doesn\'t burn written material.'
        }
      ]),
      description: 'While mortal wizards tend to hesitate before bartering their souls to devils for magical power, vampire wizards often believe their immortality will exempt them from any infernal claim to their souls. The archdevil Mephistopheles happily exploits such hubris and proves that even undead aren\'t immune to the laws of the Nine Hells. The greatest hell-bound vampires are masters of hellfire called infernalists, who prey on mages.',
      habitat: 'Planar (Nine Hells), Underdark, Urban',
      treasure: 'Arcana'
    }
  })
  console.log('✓ Vampire Infernalist created')

  // Vampire Warden
  const vampireWarden = await db.monster.upsert({
    where: { name: 'Vampire Warden' },
    update: {},
    create: {
      name: 'Vampire Warden',
      type: 'Undead',
      size: 'Medium',
      alignment: 'Neutral Evil',
      cr: 10,
      xp: 5900,
      proficiencyBonus: 4,
      ac: 18,
      initiative: 6,
      hp: 190,
      hpFormula: '21d8 + 96',
      speed: '30 ft.',
      str: 21,
      strSave: 5,
      dex: 15,
      dexSave: 2,
      con: 18,
      conSave: 4,
      int: 10,
      intSave: 0,
      wis: 14,
      wisSave: 2,
      cha: 17,
      chaSave: 3,
      skills: JSON.stringify([
        { name: 'Athletics', bonus: 9 },
        { name: 'Perception', bonus: 10 }
      ]),
      resistances: JSON.stringify(['Necrotic']),
      immunities: JSON.stringify(['Exhaustion', 'Frightened']),
      senses: 'Darkvision 120 ft.; Passive Perception 20',
      languages: 'Common',
      traits: JSON.stringify([
        {
          name: 'Magic Resistance',
          description: 'The vampire has Advantage on saving throws against spells and other magical effects.'
        },
        {
          name: 'Vampire Weakness',
          description: 'Forbiddance: The vampire can\'t enter a residence without an invitation from an occupant.\nRunning Water: The vampire takes 20 Acid damage if it ends its turn in running water.\nStake to the Heart: If a weapon that deals Piercing damage is driven into the vampire\'s heart while the vampire has the Incapacitated condition, the vampire has the Paralyzed condition until the weapon is removed.\nSunlight: The vampire takes 20 Radiant damage if it starts its turn in sunlight. While in sunlight, it has Disadvantage on attack rolls and ability checks.'
        },
        {
          name: 'Immobile Restoration',
          description: 'If the vampire drops to 0 Hit Points while it doesn\'t have the Petrified condition, it turns to stone, regains 50 Hit Points, and has the Petrified condition for 1 hour.'
        }
      ]),
      actions: JSON.stringify([
        {
          name: 'Multiattack',
          description: 'The vampire makes two Claw attacks and uses Bite or Guardian\'s Command.'
        },
        {
          name: 'Claw',
          type: 'Melee Attack',
          description: 'Melee Attack Roll: +9, reach 5 ft. Hit: 14 (2d8 + 5) Slashing damage plus 7 (2d6) Necrotic damage. If the target is a Large or smaller creature, it has the Grappled condition (escape DC 16) from one of two claws.'
        },
        {
          name: 'Bite',
          type: 'Save',
          description: 'Constitution Saving Throw: DC 16, one creature within 5 feet that is willing or that has the Grappled, Incapacitated, or Restrained condition. Failure: 7 (1d4 + 5) Piercing damage plus 7 (2d6) Necrotic damage. The target\'s Hit Point maximum decreases by an amount equal to the Necrotic damage taken, and the vampire regains Hit Points equal to that amount.'
        },
        {
          name: 'Guardian\'s Command',
          type: 'Spell',
          description: 'The vampire casts Compulsion, requiring no spell components and using Charisma as the spellcasting ability (spell save DC 15).'
        }
      ]),
      bonusActions: JSON.stringify([]),
      legendaryActions: JSON.stringify([]),
      reactions: JSON.stringify([
        {
          name: 'Resilient Flesh',
          description: 'Trigger: The vampire is hit by a melee attack roll from an attacker the vampire can see. Response: The vampire reduces the damage it takes from the attack by 11 (2d6 + 4).'
        }
      ]),
      lairActions: JSON.stringify([]),
      description: 'Vampires need trusted guards for their lairs, minions, and treasures. After all, vampire familiars don\'t live for long and are inattentive while sleeping or simpering. Monstrous servants are often too unpredictable or simply unreliable. To keep their lairs safe, some vampires create more durable spawn to serve as watchful guardians. These vampire wardens appear to have the same pallid flesh as most vampires but, through sheer force of will, can shrug off blows that might fell others. When most vampires would be destroyed, a warden turns to stone, heals itself, and is ready for service once again.',
      habitat: 'Underdark, Urban',
      treasure: 'Any'
    }
  })
  console.log('✓ Vampire Warden created')

  console.log('\n✅ Seeding completed successfully!')
}

main()
  .catch((e) => {
    console.error('❌ Error during seeding:', e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })
