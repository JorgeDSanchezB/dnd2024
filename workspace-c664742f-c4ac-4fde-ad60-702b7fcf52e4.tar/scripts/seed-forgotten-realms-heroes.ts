import { db } from '../src/lib/db';

// Forgotten Realms: Heroes of Faerun - Comprehensive Seeding Script
// Contains: 8 Subclasses, 18 Backgrounds, 28 Feats, 17 Spells

async function main() {
  console.log('Starting Forgotten Realms: Heroes of Faerun seeding...');

  // =====================
  // SUBCLASSES
  // =====================
  console.log('\n--- Seeding Subclasses ---');

  const subclasses = [
    {
      name: 'College of the Moon',
      classId: await getClassId('Bard'),
      description: 'Inspire Allies with Primal Tales. The College of the Moon traces its origins to the ancient druidic circles of the Moonshae Isles, who entrusted the first Bards of this tradition with chronicling the stories of the islands and their people. Bards of this college draw from the isles\' fey magic and the primal power of the moonwells to bolster their allies, protect the natural world, and inspire their bardic works.',
      features: JSON.stringify([
        {
          level: 3,
          name: 'Moon\'s Inspiration',
          description: 'The primal and ever-changing power of the moon flows through you, granting you the following benefits. Inspired Eclipse: When you take a Bonus Action to give a creature a Bardic Inspiration die, you can have the Invisible condition and teleport up to 30 feet to an unoccupied space you can see as part of that Bonus Action. This invisibility lasts until the start of your next turn. Lunar Vitality: Once per turn when you restore Hit Points to a creature with a spell, you can expend a Bardic Inspiration die and increase the amount of Hit Points restored by a number equal to a roll of the Bardic Inspiration die. The creature\'s Speed also increases by 10 feet until the end of its next turn.'
        },
        {
          level: 3,
          name: 'Primal Lore',
          description: 'You learn Druidic and one cantrip from the Druid spell list. It counts as a Bard spell for you but doesn\'t count against the number of cantrips you know. Additionally, choose one of the following skills: Arcana, Nature, or Survival. You gain proficiency in that skill.'
        }
      ]),
      subclassSpells: JSON.stringify([])
    },
    {
      name: 'Knowledge Domain',
      classId: await getClassId('Cleric'),
      description: 'Unearth Secrets and Master the Mind. The Knowledge Domain values learning and understanding above all. Clerics who tap into this domain study esoteric lore, collect old tomes, delve into secret places, and examine the processes of the mind. To them, knowledge is more valuable than material wealth, and learning is an act of worship.',
      features: JSON.stringify([
        {
          level: 3,
          name: 'Blessings of Knowledge',
          description: 'You gain proficiency with one type of Artisan\'s Tools of your choice and in two of the following skills of your choice: Arcana, History, Nature, or Religion. You have Expertise in those two skills.'
        },
        {
          level: 3,
          name: 'Knowledge Domain Spells',
          description: 'When you reach a Cleric level specified in the Knowledge Domain Spells table, you thereafter always have the listed spells prepared. Level 3: Command, Comprehend Languages, Detect Magic, Detect Thoughts, Identify, Mind Spike. Level 5: Dispel Magic, Nondetection, Tongues. Level 7: Arcane Eye, Banishment, Confusion. Level 9: Legend Lore, Scrying, Synaptic Static.'
        },
        {
          level: 3,
          name: 'Mind Master',
          description: 'As a Magic action, you can expend one use of your Channel Divinity to manifest your magical knowledge. Choose one spell from the Divination school on the Knowledge Domain Spells table that you have prepared. As part of that action, you cast that spell without expending a spell slot or needing Material components.'
        },
        {
          level: 6,
          name: 'Unfettered Mind',
          description: 'You gain telepathy out to 60 feet. When you use this telepathy, you can simultaneously contact a number of creatures equal to your Wisdom modifier (minimum of one). Additionally, you gain proficiency in Intelligence saving throws. If you already have this proficiency, you instead gain saving throw proficiency with one ability in which you lack it.'
        },
        {
          level: 17,
          name: 'Divine Foresight',
          description: 'As a Bonus Action, you magically expand your mind to the future. For 1 hour, you have Advantage on D20 Tests. Once you use this feature, you can\'t use it again until you finish a Long Rest. You can also restore your use of this feature by expending a level 6+ spell slot (no action required).'
        }
      ]),
      subclassSpells: JSON.stringify(['Command', 'Comprehend Languages', 'Detect Magic', 'Detect Thoughts', 'Identify', 'Mind Spike', 'Dispel Magic', 'Nondetection', 'Tongues', 'Arcane Eye', 'Banishment', 'Confusion', 'Legend Lore', 'Scrying', 'Synaptic Static'])
    },
    {
      name: 'Banneret',
      classId: await getClassId('Fighter'),
      description: 'Rally Fellow Heroes with Inspiring Leadership. Bannerets are paragons of valor and leadership who protect the innocent and rally fellow adventurers to the causes of justice and freedom. Many are knights serving in Cormyr, the Silver Marches, Damara, Chessenta, or other lands across Faerûn. They wander the realms as knights errant, taking the fight against evil beyond their kingdom\'s borders.',
      features: JSON.stringify([
        {
          level: 3,
          name: 'Knightly Enfranchisement',
          description: 'You know how to conduct yourself with grace as a noble ambassador. You gain the following benefits. Comprehension: You can cast the Comprehend Languages spell but only as a Ritual. Charisma is your spellcasting ability for it. Polyglot: You learn one language from the language tables. When you finish a Long Rest, you can replace a language learned from this benefit with another language you have heard, seen signed, or read in the past 24 hours. Well Spoken: You gain proficiency in one of the following skills of your choice: Insight, Intimidation, Persuasion, or Performance.'
        },
        {
          level: 3,
          name: 'Group Recovery',
          description: 'When you use your Second Wind to regain Hit Points, you can choose a number of allies within a 30-foot Emanation originating from yourself, up to a number of allies equal to your Charisma modifier (minimum of one). Each of those allies regains Hit Points equal to 1d4 plus your Fighter level. Once you use this ability, you can\'t use it again until you finish a Short or Long Rest.'
        },
        {
          level: 7,
          name: 'To the Last',
          description: 'When you use Group Recovery, each chosen ally has Advantage on D20 Tests until the start of your next turn.'
        },
        {
          level: 10,
          name: 'Rallying Surge',
          description: 'When you use your Action Surge, you can choose allies within a 30-foot Emanation originating from yourself, up to a number of allies equal to your Charisma modifier (minimum of one). Each of those allies can immediately take a Reaction to use one of the following options: Attack (the ally makes one attack with a weapon or an Unarmed Strike) or Move (the ally moves up to half its Speed without provoking Opportunity Attack action).'
        },
        {
          level: 15,
          name: 'Stalwart Inspiration',
          description: 'When an ally you can see within 60 feet of yourself fails a saving throw, you can take a Reaction to give that ally Heroic Inspiration.'
        }
      ]),
      subclassSpells: JSON.stringify([])
    },
    {
      name: 'Oath of the Noble Genies',
      classId: await getClassId('Paladin'),
      description: 'Paladins sworn to the Oath of the Noble Genies revere the forces of the Elemental Planes. Through taking this oath, Paladins draw power from the four different types of genies—dao, masters of earth; djinn, masters of air; efreet, masters of fire; and marids, masters of water. In Faerûn, many Paladins who swear this oath hail from Calimshan, a land teeming with genies.',
      features: JSON.stringify([
        {
          level: 3,
          name: 'Elemental Smite',
          description: 'Immediately after you cast Divine Smite, you can expend one use of your Channel Divinity and invoke one of the following effects. Dao\'s Crush: Earth rises up around the target of your Divine Smite. The target has the Grappled condition (escape DC equal to your spell save DC). While Grappled, the target has the Restrained condition. Djinni\'s Escape: You teleport to an unoccupied space you can see within 30 feet of yourself and take on a semi-incorporeal form, which lasts until the end of your next turn. While in this form, you have Resistance to Bludgeoning, Piercing, and Slashing damage, and you have Immunity to the Grappled, Prone, and Restrained conditions. Efreeti\'s Fury: The target of your Divine Smite takes an extra 2d4 Fire damage, and fire jumps from the target to another creature you can see within 30 feet of yourself. The second creature also takes 2d4 Fire damage. Marid\'s Surge: The target of your Divine Smite and each creature of your choice in a 10-foot Emanation originating from you make a Strength saving throw against your spell save DC. On a failed save, a creature is pushed 15 feet straight away from you and has the Prone condition.'
        },
        {
          level: 3,
          name: 'Genie Spells',
          description: 'When you reach a Paladin level specified in the Genie Spells table, you thereafter always have the listed spells prepared. Level 3: Chromatic Orb, Elementalism, Thunderous Smite. Level 5: Mirror Image, Phantasmal Force. Level 9: Fly, Gaseous Form. Level 13: Conjure Minor Elementals, Summon Elemental. Level 17: Banishing Smite, Contact Other Plane.'
        },
        {
          level: 3,
          name: 'Genie\'s Sovereignty',
          description: 'When you aren\'t wearing any armor, your base Armor Class equals 10 plus your Dexterity and Charisma modifiers. You can use a Shield and still gain this benefit. You also gain proficiency in one of the following skills of your choice: Acrobatics, Intimidation, Performance, or Persuasion.'
        },
        {
          level: 7,
          name: 'Aura of Elemental Shielding',
          description: 'Choose one of the following damage types: Acid, Cold, Fire, Lightning, or Thunder. You and your allies have Resistance to that damage type while in your Aura of Protection. At the start of each of your turns, you can change the damage type affected by this feature to one of the other listed options (no action required).'
        },
        {
          level: 15,
          name: 'Elemental Reprisal',
          description: 'When you are hit by an attack roll, you can take a Reaction to halve the attack\'s damage against yourself (round down) and force the attacker to make a Dexterity saving throw against your spell save DC. On a failed save, the attacker takes damage equal to 2d10 plus your Charisma modifier of one of the following types (your choice): Acid, Cold, Fire, Lightning, or Thunder. On a successful save, the attacker takes half as much damage. You can use this feature a number of times equal to your Charisma modifier (minimum of once), and you regain all expended uses when you finish a Long Rest.'
        },
        {
          level: 20,
          name: 'Noble Sovereign',
          description: 'As a Bonus Action, you gain the benefits below for 10 minutes or until you end them (no action required). Once you use this feature, you can\'t use it again until you finish a Long Rest. You can also restore your use of it by expending a level 5 spell slot (no action required). Flight: You have a Fly Speed of 60 feet and can hover. Minor Wish: When you or an ally in your Aura of Protection fails a D20 Test, you can take a Reaction to make you or that ally succeed instead.'
        }
      ]),
      subclassSpells: JSON.stringify(['Chromatic Orb', 'Elementalism', 'Thunderous Smite', 'Mirror Image', 'Phantasmal Force', 'Fly', 'Gaseous Form', 'Conjure Minor Elementals', 'Summon Elemental', 'Banishing Smite', 'Contact Other Plane'])
    },
    {
      name: 'Winter Walker',
      classId: await getClassId('Ranger'),
      description: 'Withstand the Horrors of Frigid Wastelands. Winter Walkers hone their craft in the bleak and frozen wilds of places like Icewind Dale. These ruthless, rimed Rangers hunt monsters that haunt arctic wastelands, eventually becoming frigid terrors themselves. Winter Walkers are well versed in the phenomena of Icewind Dale, including the latent magic of fallen Netherese cities, endemic monsters like yetis and crag cats, and the rising threat of Underdark invaders.',
      features: JSON.stringify([
        {
          level: 3,
          name: 'Frigid Endurance',
          description: 'You gain the following benefits. Biting Cold: Damage from your weapon attacks, Ranger spells, and Ranger features ignores Resistance to Cold damage. Frost Resistance: You have Resistance to Cold damage. Polar Strikes: When you hit a creature with an attack roll using a weapon, you can deal an extra 1d4 Cold damage to the target, which can take this extra damage only once per turn. When you reach Ranger level 11, this extra damage increases to 1d6.'
        },
        {
          level: 3,
          name: 'Hunter\'s Rime',
          description: 'Ice rimes you and your prey, protecting you and hindering them. When you cast Hunter\'s Mark, you gain Temporary Hit Points equal to 1d10 plus your Ranger level. Additionally, while a creature is marked by your Hunter\'s Mark, it can\'t take the Disengage action.'
        },
        {
          level: 3,
          name: 'Winter Walker Spells',
          description: 'When you reach a Ranger level specified in the Winter Walker Spells table, you thereafter always have the listed spells prepared. Level 3: Ice Knife. Level 5: Hold Person. Level 9: Remove Curse. Level 13: Ice Storm. Level 17: Cone of Cold.'
        },
        {
          level: 7,
          name: 'Frigid Solace',
          description: 'Your experience surviving harrowing environments allows you to bolster your allies in addition to yourself. As a Magic action, choose a number of creatures you can see equal to your Wisdom modifier (minimum of one). Each chosen creature regains Hit Points equal to 1d10 plus your Ranger level and has Advantage on saving throws to avoid or end the Frightened condition for 1 hour. Once you use this feature, you can\'t use it again until you finish a Long Rest.'
        },
        {
          level: 11,
          name: 'Counterflow Reaction',
          description: 'When a creature hits you with an attack roll, you can take a Reaction to force the creature to make a Wisdom saving throw against your spell save DC. On a failed save, the target has the Stunned condition until the end of your next turn. While the target is Stunned, its Speed is reduced to 0 feet. You can use this feature a number of times equal to your Wisdom modifier (minimum of once), and you regain all expended uses when you finish a Long Rest.'
        },
        {
          level: 15,
          name: 'Frost Haunt',
          description: 'When you cast Hunter\'s Mark, you can adopt a ghostly, snowy form. This form lasts until the spell ends, and while you are in this form, you gain the following benefits. Frozen Soul: You have Immunity to Cold damage. When you first adopt this form and at the start of each of your subsequent turns, each creature of your choice in a 15-foot Emanation originating from you takes 2d4 Cold damage. Partially Incorporeal: You have Immunity to the Grappled, Prone, and Restrained conditions. You can move through creatures and objects as if they were Difficult Terrain, but you take 1d10 Force damage if you end your turn inside a creature or an object.'
        }
      ]),
      subclassSpells: JSON.stringify(['Ice Knife', 'Hold Person', 'Remove Curse', 'Ice Storm', 'Cone of Cold'])
    },
    {
      name: 'Scion of the Three',
      classId: await getClassId('Rogue'),
      description: 'Become a Gruesome Agent of Malice. A Scion of the Three draws power from a group of malevolent gods known in Baldur\'s Gate as the Dead Three: Bane, a god of tyranny; Bhaal, a god of violence and murder; and Myrkul, a god of death. While some Rogues of this subclass pledge themselves ardently to those three macabre gods, others are thrust on this path by a curse.',
      features: JSON.stringify([
        {
          level: 3,
          name: 'Bloodthirst',
          description: 'When an enemy you can see within 30 feet of yourself takes damage, you can take a Reaction to teleport to an unoccupied space you can see within 5 feet of that enemy and then make a melee attack with a weapon or an Unarmed Strike against that enemy. If the attack hits, the target takes an extra 1d6 damage of a type determined by your choice in the Dread Allegiance feature.'
        },
        {
          level: 3,
          name: 'Dread Allegiance',
          description: 'Choose one of the Dead Three to whom you have some allegiance: Bane, Bhaal, or Myrkul. Your allegiance determines the damage Resistance and cantrip you gain from the table. Bane: Psychic Resistance, Minor Illusion cantrip. Bhaal: Poison Resistance, Blade Ward cantrip. Myrkul: Necrotic Resistance, Chill Touch cantrip. Intelligence, Wisdom, or Charisma is your spellcasting ability for the cantrip (choose when you select this feat).'
        },
        {
          level: 9,
          name: 'Scion\'s Flurry',
          description: 'You gain the following Cunning Strike option. Terrify (Cost: 1d6): The target must succeed on a Wisdom saving throw, or it has the Frightened condition for 1 minute. While the target is Frightened in this way, you have Advantage on attack rolls against the target. The Frightened target repeats the save at the end of each of its turns, ending the effect on itself on a success.'
        },
        {
          level: 13,
          name: 'Aura of Malevolence',
          description: 'You radiate malignant power associated with one of the Dead Three. When you use Bloodthirst and teleport, each creature of your choice within 10 feet of either the space you left or your destination space (your choice) takes damage equal to your Intelligence modifier; the damage type is the same as the damage Resistance granted by your choice in the Dread Allegiance feature. Damage dealt by this feature ignores Resistance.'
        },
        {
          level: 17,
          name: 'Death\'s Instrument',
          description: 'You gain the following benefits. Cutthroat: You regain one expended use of Bloodthirst when you finish a Short Rest. Murderous Intent: When you roll for your Sneak Attack damage, you can treat a roll of a 1 or 2 on the die as a 3.'
        }
      ]),
      subclassSpells: JSON.stringify(['Minor Illusion', 'Blade Ward', 'Chill Touch'])
    },
    {
      name: 'Spellfire Sorcery',
      classId: await getClassId('Sorcerer'),
      description: 'Wield Raw Magic. Your innate power stems from the source of magic itself: the Weave. This connection manifests as a rare ability known as spellfire, and you surge with radiant bursts of this raw magic. Your talent with spellfire allows you to heal allies, sear enemies, and absorb powerful spells.',
      features: JSON.stringify([
        {
          level: 3,
          name: 'Spellfire Burst',
          description: 'When you spend at least 1 Sorcery Point as part of a Magic action or a Bonus Action on your turn, you can unleash one of the following magical effects of your choice. You can do so only once per turn. Bolstering Flames: You or one creature you can see within 30 feet of yourself gains Temporary Hit Points equal to 1d4 plus your Charisma modifier. Radiant Fire: One creature you can see within 30 feet of yourself takes 1d4 Fire or Radiant damage (your choice).'
        },
        {
          level: 3,
          name: 'Spellfire Spells',
          description: 'When you reach a Sorcerer level specified in the Spellfire Spells table, you thereafter always have the listed spells prepared. Level 3: Cure Wounds, Guiding Bolt, Lesser Restoration, Scorching Ray. Level 5: Aura of Vitality, Dispel Magic. Level 7: Fire Shield, Wall of Fire. Level 9: Greater Restoration, Flame Strike.'
        },
        {
          level: 6,
          name: 'Absorb Spellfire',
          description: 'You always have the Counterspell spell prepared. Additionally, whenever a target fails the saving throw against a Counterspell you cast, you regain 1d4 Sorcery Points.'
        },
        {
          level: 14,
          name: 'High Spellfire',
          description: 'Your Spellfire Burst improves. You add your Sorcerer level to the Temporary Hit Points gained from Bolstering Flames, and the damage of your Radiant Fire increases to 1d8.'
        },
        {
          level: 18,
          name: 'Core of Spellfire',
          description: 'When you use Innate Sorcery, you can alter it and infuse yourself with the essence of spellfire, gaining the following benefits while this use of Innate Sorcery is active. Burning Life Force: Once per turn, when you cast a spell using a spell slot, you can roll a number of Hit Point Dice equal to the spell slot\'s level, and you can add the total rolled to one damage roll of the spell or to the Hit Points restored by the spell. Flight: You gain a Fly Speed of 60 feet and can hover. Spell Avoidance: When you\'re subjected to a spell or magical effect that allows you to make a saving throw to take only half damage, you instead take no damage if you succeed on the save and only half damage if you fail.'
        }
      ]),
      subclassSpells: JSON.stringify(['Cure Wounds', 'Guiding Bolt', 'Lesser Restoration', 'Scorching Ray', 'Aura of Vitality', 'Dispel Magic', 'Fire Shield', 'Wall of Fire', 'Greater Restoration', 'Flame Strike'])
    },
    {
      name: 'Bladesinger',
      classId: await getClassId('Wizard'),
      description: 'Wield Weapon and Wizardry in Elegant Tandem. Bladesingers master a tradition of wizardry that incorporates swordplay and dance. In combat, a Bladesinger uses intricate, elegant maneuvers that fend off harm and allow the Bladesinger to channel magic into devastating attacks and a cunning defense.',
      features: JSON.stringify([
        {
          level: 3,
          name: 'Bladesong',
          description: 'As a Bonus Action, you invoke an elven magic called the Bladesong, provided you aren\'t wearing armor or using a Shield. The Bladesong lasts for 1 minute and ends early if you have the Incapacitated condition, if you don armor or a Shield, or if you use two hands to make an attack with a weapon. You can dismiss the Bladesong at any time (no action required). While the Bladesong is active, you gain the following benefits: Agility (you gain a bonus to your AC equal to your Intelligence modifier (minimum of +1), and your Speed increases by 10 feet. In addition, you have Advantage on Dexterity (Acrobatics) checks), Bladework (whenever you attack with a weapon with which you have proficiency, you can use your Intelligence modifier for the attack and damage rolls instead of using Strength or Dexterity), Focus (when you make a Constitution saving throw to maintain Concentration, you can add your Intelligence modifier to the total). You can invoke the Bladesong a number of times equal to your Intelligence modifier (minimum of once), and you regain all expended uses when you finish a Long Rest. You regain one expended use when you use Arcane Recovery.'
        },
        {
          level: 3,
          name: 'Training in War and Song',
          description: 'You gain proficiency with all Melee Martial weapons that don\'t have the Two-Handed or Heavy property. You can use a Melee weapon with which you have proficiency as a Spellcasting Focus for your Wizard spells. You also gain proficiency in one of the following skills of your choice: Acrobatics, Athletics, Performance, or Persuasion.'
        },
        {
          level: 6,
          name: 'Extra Attack',
          description: 'You can attack twice instead of once whenever you take the Attack action on your turn. Moreover, you can cast one of your cantrips in place of one of those attacks.'
        }
      ]),
      subclassSpells: JSON.stringify([])
    }
  ];

  for (const subclass of subclasses) {
    if (subclass.classId) {
      const existing = await db.subclass.findFirst({ where: { name: subclass.name } });
      if (!existing) {
        await db.subclass.create({ data: subclass });
        console.log(`Created subclass: ${subclass.name}`);
      } else {
        console.log(`Subclass already exists: ${subclass.name}`);
      }
    } else {
      console.log(`Skipping subclass ${subclass.name} - class not found`);
    }
  }

  // =====================
  // BACKGROUNDS
  // =====================
  console.log('\n--- Seeding Backgrounds ---');

  const backgrounds = [
    {
      name: 'Chondathan Freebooter',
      description: 'Though most youths in Chondath accept their four-year term of compulsory military service, you bristled at that authoritarian attempt to control your life. You forsook your nationhood, discarded your given name, and worked as a freebooter with the first ship that would have you. Since then, you\'ve traveled the Vilhon Reach.',
      abilityScores: '["Strength","Dexterity","Wisdom"]',
      feat: 'Skilled',
      skillProficiencies: 'Athletics, Sleight of Hand',
      toolProficiency: 'Weaver\'s Tools',
      equipment: 'Dagger, Weaver\'s Tools, Backpack, Ball Bearings, Basket, Bedroll, Bucket, Rations (3 days), Rope, Signal Whistle, Traveler\'s Clothes, 38 GP'
    },
    {
      name: 'Dead Magic Dweller',
      description: 'The dead magic zones of the Anauroch desert are anathema to spellcasters and monsters that rely on magic—which is exactly why you made your life there. After long months or years, you\'re stronger, wiser, and armed with hard-earned knowledge of desert medicine and wasteland survival.',
      abilityScores: '["Strength","Constitution","Wisdom"]',
      feat: 'Healer',
      skillProficiencies: 'Medicine, Survival',
      toolProficiency: 'Leatherworker\'s Tools',
      equipment: 'Greatclub, Leatherworker\'s Tools, Bedroll, Blanket, Healer\'s Kit, Pole, Rations (3 days), Tent, Tinderbox, 5 Torches, Traveler\'s Clothes, Waterskin, 32 GP'
    },
    {
      name: 'Dragon Cultist',
      description: 'You are an initiate of the Cult of the Dragon. You discovered or were brought to a cell cult, where you exemplified the values honored by dragon cultists: duplicity, secrecy, and determination. In exchange for your oath to serve the cult, the cult offered you the company of fellow dragon worshipers.',
      abilityScores: '["Dexterity","Constitution","Intelligence"]',
      feat: 'Cult of the Dragon Initiate',
      skillProficiencies: 'Deception, Stealth',
      toolProficiency: 'Calligrapher\'s Supplies',
      equipment: 'Calligrapher\'s Supplies, Dagger, Glass Bottle, Lamp, Manacles, Oil (5 flasks), 2 Pouches, Robe, Rope, 30 GP'
    },
    {
      name: 'Emerald Enclave Caretaker',
      description: 'As a Caretaker with the Emerald Enclave, you take care of those who care for the world. Either alongside your fellow Emerald Enclave members or by yourself, you\'ve learned essential skills for living with the land: how to track game, where to forage for useful herbs, and even how to forecast the weather.',
      abilityScores: '["Constitution","Intelligence","Wisdom"]',
      feat: 'Emerald Enclave Fledgling',
      skillProficiencies: 'Nature, Survival',
      toolProficiency: 'Herbalism Kit',
      equipment: 'Shortbow, 20 Arrows, Herbalism Kit, Bedroll, Blanket, Pouch, Tent, Traveler\'s Clothes, 13 GP'
    },
    {
      name: 'Flaming Fist Mercenary',
      description: 'The chief law enforcement branch of Baldur\'s Gate is the Flaming Fist, a brawny mercenary guild led by the city\'s grand duke. You once served as a Flaming Fist, where you learned how to preempt trouble with your intimidating stare and, when necessary, absorb deadly blows.',
      abilityScores: '["Strength","Constitution","Charisma"]',
      feat: 'Tough',
      skillProficiencies: 'Intimidation, Perception',
      toolProficiency: 'Smith\'s Tools',
      equipment: 'Mace, Smith\'s Tools, Fine Clothes, Manacles, Portable Ram, 4 GP'
    },
    {
      name: 'Genie Touched',
      description: 'Although genies no longer rule Calimshan, genie magic is still common in your homeland. Perhaps you inadvertently summoned a djinni from a magic lamp, or maybe you came upon an oasis guarded by a marid. However your fate intersected with that of a genie, the experience left you with a keen eye, a silver tongue, and more than a touch of magic.',
      abilityScores: '["Dexterity","Wisdom","Charisma"]',
      feat: 'Magic Initiate',
      skillProficiencies: 'Perception, Persuasion',
      toolProficiency: 'Glassblower\'s Tools',
      equipment: 'Light Hammer, Glassblower\'s Tools, Fine Clothes, Lamp, Oil (3 flasks), Waterskin, 2 GP'
    },
    {
      name: 'Harper',
      description: 'You accepted an invitation to join the Harpers, pledging an oath to uphold the Harper code and act in service to the common good. Like all Harpers, you understand the value of teamwork as well as when it\'s best to go it alone. Harper veterans have taught you the order\'s secrets.',
      abilityScores: '["Dexterity","Intelligence","Charisma"]',
      feat: 'Harper Agent',
      skillProficiencies: 'Performance, Sleight of Hand',
      toolProficiency: 'Disguise Kit',
      equipment: 'Disguise Kit, Bedroll, Costume, Grappling Hook, Rope, Traveler\'s Clothes, 14 GP'
    },
    {
      name: 'Ice Fisher',
      description: 'You come from a proud line of ice fishers out of Ten-Towns in Icewind Dale. Catching knucklehead trout isn\'t the most glorious trade in the North, but it\'s an honest living. You\'ve trained your senses for the slightest tug on the line, wrestled big trout out of ice-covered lakes.',
      abilityScores: '["Strength","Dexterity","Constitution"]',
      feat: 'Alert',
      skillProficiencies: 'Animal Handling, Athletics',
      toolProficiency: 'Woodcarver\'s Tools',
      equipment: 'Woodcarver\'s Tools, Basket, Block and Tackle, Bucket, Chain, Hunting Trap, Net, Pole, Rations (3 days), Rope, Traveler\'s Clothes, 32 GP'
    },
    {
      name: 'Knight of the Gauntlet',
      description: 'Not all who answer the call of a higher power are content to pore over scripture in a stuffy temple apse. You chose the path of the holy warrior by joining the Order of the Gauntlet. As a knight of the Gauntlet, you exercise righteous scorn for the forces of evil.',
      abilityScores: '["Strength","Intelligence","Wisdom"]',
      feat: 'Tyro of the Gauntlet',
      skillProficiencies: 'Athletics, Medicine',
      toolProficiency: 'Smith\'s Tools',
      equipment: 'Spear, Smith\'s Tools, Bullseye Lantern, Holy Symbol, Manacles, Oil (5 flasks), Tinderbox, Traveler\'s Clothes, 9 GP'
    },
    {
      name: 'Lords\' Alliance Vassal',
      description: 'You\'ve pledged your loyalty to a member-city of the Lords\' Alliance. As an Alliance agent, you must uphold the tenets of the Alliance and seek to increase safety and prosperity along the Sword Coast. You\'re sworn to bring honor and glory to your lord\'s house.',
      abilityScores: '["Strength","Intelligence","Charisma"]',
      feat: 'Lords\' Alliance Agent',
      skillProficiencies: 'Insight, Persuasion',
      toolProficiency: 'Calligrapher\'s Supplies',
      equipment: '2 Javelins, Calligrapher\'s Supplies, Fine Clothes, Ink, 5 Ink Pens, Parchment (9 sheets), 13 GP'
    },
    {
      name: 'Moonwell Pilgrim',
      description: 'Like many who hail from the Moonshae Isles, you grew up revering the blessed land, its unique gods, and the mysterious shrines called the moonwells. As a moonwell pilgrim, you undertook a quest to visit and commune with every moonwell on (or off) the map.',
      abilityScores: '["Constitution","Wisdom","Charisma"]',
      feat: 'Magic Initiate',
      skillProficiencies: 'Nature, Performance',
      toolProficiency: 'Painter\'s Supplies',
      equipment: 'Quarterstaff, Painter\'s Supplies, Bedroll, Bell, Pouch, Robe, String, Traveler\'s Clothes, Waterskin, 34 GP'
    },
    {
      name: 'Mulhorandi Tomb Raider',
      description: 'You grew up in a land of living god-kings, and as a child you were told countless stories of ancient empires and buried cities. In these tales, Mulhorand was a land overflowing with forgotten riches—priceless treasures awaiting anyone cunning and brave enough to seek them out.',
      abilityScores: '["Dexterity","Constitution","Intelligence"]',
      feat: 'Lucky',
      skillProficiencies: 'Investigation, Religion',
      toolProficiency: 'Mason\'s Tools',
      equipment: 'Dagger, Light Hammer, Mason\'s Tools, Backpack, Bedroll, Crowbar, Ladder, Pole, 2 Pouches, Rope, String, Tinderbox, 5 Torches, Traveler\'s Clothes, Waterskin, 26 GP'
    },
    {
      name: 'Mythalkeeper',
      description: 'Mythals are sources of great magical power that can alter the Weave or even the very nature of reality. Most were constructed in antiquity, and many have since been damaged or gone dormant. As a mythalkeeper from the Dalelands, your first experience with a mythal was likely in the ruins of Myth Drannor.',
      abilityScores: '["Intelligence","Wisdom","Charisma"]',
      feat: 'Crafter',
      skillProficiencies: 'Arcana, History',
      toolProficiency: 'Jeweler\'s Tools',
      equipment: 'Quarterstaff, Jeweler\'s Tools, Perfume, Pouch, Robe, Shovel, String, Waterskin, 16 GP'
    },
    {
      name: 'Purple Dragon Squire',
      description: 'You\'ve pledged your life to the safety of Cormyr and sought admission to that realm\'s order of elite warriors: the Purple Dragon Knights. But before you have the chance to join the ranks officially, you must first serve as a knight\'s squire.',
      abilityScores: '["Strength","Wisdom","Charisma"]',
      feat: 'Purple Dragon Rook',
      skillProficiencies: 'Animal Handling, Insight',
      toolProficiency: 'Navigator\'s Tools',
      equipment: 'Spear, Navigator\'s Tools, Fine Clothes, 9 GP'
    },
    {
      name: 'Rashemi Wanderer',
      description: 'You spent years wandering the highlands of Rashemen, a dangerous windswept heath that\'s dotted with ancient obelisks enchanted to imprison Fiends and home to dragons, gnolls, and other deadly creatures. Friendships are hard to find in such an isolated land.',
      abilityScores: '["Strength","Constitution","Charisma"]',
      feat: 'Tough',
      skillProficiencies: 'Intimidation, Perception',
      toolProficiency: 'Cartographer\'s Tools',
      equipment: 'Cartographer\'s Tools, Backpack, Bedroll, Hooded Lantern, Oil (3 flasks), Rope, Tinderbox, Traveler\'s Clothes, Waterskin, 23 GP'
    },
    {
      name: 'Shadowmasters Exile',
      description: 'You trained your whole life to become a member of the Shadowmasters, the mysterious thieves\' guild that controls the realm of Thesk from behind the scenes. Stealth and quick reflexes were just the start of your Shadowmaster education. But one wrong move led to your expulsion from the order.',
      abilityScores: '["Dexterity","Intelligence","Charisma"]',
      feat: 'Savage Attacker',
      skillProficiencies: 'Acrobatics, Stealth',
      toolProficiency: 'Thieves\' Tools',
      equipment: '2 Daggers, Thieves\' Tools, Caltrops, Costume, Grappling Hook, Iron Spikes, Mirror, 2 Pouches, Rope, Traveler\'s Clothes, 3 GP'
    },
    {
      name: 'Spellfire Initiate',
      description: 'You bear the gift of spellfire: a rare form of magic that channels the raw power of the Weave. Wielding spellfire takes a heavy toll on the body. You\'ve trained both mind and body to efficiently wield this sacred power.',
      abilityScores: '["Constitution","Intelligence","Charisma"]',
      feat: 'Spellfire Spark',
      skillProficiencies: 'Arcana, Perception',
      toolProficiency: 'Gaming Set',
      equipment: 'Gaming Set, Arcane Focus (Crystal or Wand), 2 Pouches, Traveler\'s Clothes, 36 GP'
    },
    {
      name: 'Zhentarim Mercenary',
      description: 'Maybe you needed the money. Maybe you longed for a family, no matter how dubious. Or maybe you\'re just good at getting the job done by any means necessary. Whatever your reason, you enlisted with the Zhentarim, the most notorious mercenary guild in the Realms.',
      abilityScores: '["Strength","Dexterity","Charisma"]',
      feat: 'Zhentarim Ruffian',
      skillProficiencies: 'Intimidation, Perception',
      toolProficiency: 'Forgery Kit',
      equipment: 'Club, Dagger, Forgery Kit, Fine Clothes, Hooded Lantern, Oil (3 flasks), 2 Pouches, String, Tinderbox, 11 GP'
    }
  ];

  for (const bg of backgrounds) {
    const existing = await db.background.findFirst({ where: { name: bg.name } });
    if (!existing) {
      await db.background.create({ data: bg });
      console.log(`Created background: ${bg.name}`);
    } else {
      console.log(`Background already exists: ${bg.name}`);
    }
  }

  // =====================
  // FEATS
  // =====================
  console.log('\n--- Seeding Feats ---');

  const feats = [
    // Origin Feats
    {
      name: 'Cult of the Dragon Initiate',
      category: 'Origin',
      description: 'You gain the following benefits. Dragon\'s Tongue: You know Draconic. Dragon\'s Terror: You can take a Magic action to instill terror in a creature you can see within 30 feet of yourself. The target must succeed on a Wisdom saving throw or have the Frightened condition until the end of your next turn. Inspired by Fear: When you cause a creature to have the Frightened condition and you are the source of its fear, you can gain Heroic Inspiration if you lack it.',
      benefit: 'Dragon\'s Tongue, Dragon\'s Terror, Inspired by Fear',
      repeatable: false
    },
    {
      name: 'Emerald Enclave Fledgling',
      category: 'Origin',
      description: 'You gain the following benefits. Speak with Animals: You always have the Speak with Animals spell prepared and can cast it with any spell slots you have. Tag Team: When you take the Help action, you can switch places with a willing ally within 5 feet of yourself as part of that same action.',
      benefit: 'Speak with Animals, Tag Team',
      repeatable: false
    },
    {
      name: 'Harper Agent',
      category: 'Origin',
      description: 'You gain the following benefits. Thieves\' Cant: You know Thieves\' Cant. Instrument Training: You gain proficiency with a Musical Instrument of your choice. Distracting Melody: When you take the Help action to assist an ally\'s attack roll, the enemy you\'re distracting can be within 30 feet of you, rather than within 5 feet of you.',
      benefit: 'Thieves\' Cant, Instrument Training, Distracting Melody',
      repeatable: false
    },
    {
      name: 'Lords\' Alliance Agent',
      category: 'Origin',
      description: 'You gain the following benefits. Inspiring Strike: Once per turn when you score a Critical Hit against a creature, you can choose an ally within 30 feet of yourself who can see or hear you and who lacks Heroic Inspiration. That ally gains Heroic Inspiration. Reassert Honor: When an enemy you can see deals damage to an ally of yours that is within 5 feet of you, you have Advantage on your next attack roll against that enemy.',
      benefit: 'Inspiring Strike, Reassert Honor',
      repeatable: false
    },
    {
      name: 'Spellfire Spark',
      category: 'Origin',
      description: 'You gain the following benefits. Magic Absorption: Once per turn, when you take damage from a spell or magical effect, you reduce the total damage taken by 1d4. Spellfire Flame: You learn the Sacred Flame cantrip. You can also cast this cantrip as a Bonus Action a number of times equal to your Proficiency Bonus.',
      benefit: 'Magic Absorption, Spellfire Flame',
      repeatable: false
    },
    {
      name: 'Tyro of the Gauntlet',
      category: 'Origin',
      description: 'You gain the following benefits. Stand as One: When an ally within 5 feet of you is subjected to an effect that would push or pull it, you can take a Reaction to prevent that ally from being pushed or pulled. Vigilant: When you take the Ready action, the next attack roll made against you has Disadvantage before the start of your next turn.',
      benefit: 'Stand as One, Vigilant',
      repeatable: false
    },
    {
      name: 'Purple Dragon Rook',
      category: 'Origin',
      description: 'You gain the following benefits. Exploit Opening: When you roll damage for an Opportunity Attack action, you can roll the damage dice twice and use either roll against the target. Family First: If you have Heroic Inspiration when you roll Initiative, you can expend it to give yourself and your allies Advantage on that Initiative roll.',
      benefit: 'Exploit Opening, Family First',
      repeatable: false
    },
    {
      name: 'Zhentarim Ruffian',
      category: 'Origin',
      description: 'You gain the following benefits. Exploit Opening: When you roll damage for an Opportunity Attack action, you can roll the damage dice twice and use either roll against the target. Family First: If you have Heroic Inspiration when you roll Initiative, you can expend it to give yourself and your allies Advantage on that Initiative roll.',
      benefit: 'Exploit Opening, Family First',
      repeatable: false
    },
    // General Feats
    {
      name: 'Cold Caster',
      category: 'General',
      prerequisite: 'Level 4+',
      description: 'You gain the following benefits. Ability Score Increase: Increase your Intelligence, Wisdom, or Charisma score by 1, to a maximum of 20. Cantrip: You learn the Ray of Frost cantrip. Frostbite: Once per turn when you hit a creature with an attack roll and deal Cold damage, you can temporarily negate the creature\'s defenses. The creature subtracts 1d4 from the next saving throw it makes before the end of your next turn.',
      benefit: 'Ability Score Increase, Ray of Frost cantrip, Frostbite',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Dragonscarred',
      category: 'General',
      prerequisite: 'Level 4+, Cult of the Dragon Initiate Feat',
      description: 'You gain the following benefits. Ability Score Increase: Increase your Constitution or Charisma score by 1, to a maximum of 20. Damage Resistance: Choose Acid, Cold, Fire, Lightning, or Poison. You have Resistance to the chosen damage type. Fearsome Power: When you deal damage to a creature as part of the Attack or Magic action on your turn, you can use the Dragon\'s Terror benefit of the Cult of the Dragon Initiate feat as a Bonus Action this turn.',
      benefit: 'Ability Score Increase, Damage Resistance, Fearsome Power',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Enclave Magic',
      category: 'General',
      prerequisite: 'Level 4+, Emerald Enclave Fledgling Feat',
      description: 'You gain the following benefits. Ability Score Increase: Increase your Intelligence, Wisdom, or Charisma score by 1, to a maximum of 20. Friend to Animals: You have Advantage on ability checks when taking the Influence action with Beasts. Two Hearts, One Mind: You always have the Beast Sense spell prepared. You can cast it once without a spell slot.',
      benefit: 'Ability Score Increase, Friend to Animals, Two Hearts One Mind',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Fairy Trickster',
      category: 'General',
      prerequisite: 'Level 4+',
      description: 'You gain the following benefits. Ability Score Increase: Increase your Dexterity or Charisma ability score by 1, to a maximum of 20. Faerie Trod Trotter: When you take the Disengage action on your turn, Difficult Terrain doesn\'t cost you extra movement for the rest of that turn. Flustering Strike: When you hit a creature with an attack roll, you can attempt to fluster the target.',
      benefit: 'Ability Score Increase, Faerie Trod Trotter, Flustering Strike',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Genie Magic',
      category: 'General',
      prerequisite: 'Level 4+',
      description: 'You gain the following benefits related to genie magic. You can call upon the power of genies to enhance your abilities.',
      benefit: 'Genie-related magical abilities',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Harper Teamwork',
      category: 'General',
      prerequisite: 'Level 4+, Harper Agent Feat',
      description: 'You gain the following benefits. Ability Score Increase: Increase your Dexterity or Charisma score by 1, to a maximum of 20. Withering Wordplay: When you take the Help action to assist an ally\'s attack roll against an enemy, that enemy also has Disadvantage on the first saving throw it makes before the start of your next turn. Inspiring Willpower: If you succeed on a saving throw to end the Frightened or Paralyzed condition on yourself, you can choose one ally you can see within 30 feet of yourself that has the same condition. That condition immediately ends for that ally.',
      benefit: 'Ability Score Increase, Withering Wordplay, Inspiring Willpower',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Lordly Resolve',
      category: 'General',
      prerequisite: 'Level 4+, Lords\' Alliance Agent Feat',
      description: 'You gain the following benefits. Ability Score Increase: Increase your Strength or Charisma score by 1, to a maximum of 20. Standard Bearer: As a Bonus Action, choose up to three creatures within 60 feet of yourself that can see you. Each target can immediately take a Reaction to right itself and end the Prone condition. Additionally, you bolster the targets\' resolve for 1 minute.',
      benefit: 'Ability Score Increase, Standard Bearer',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Mythal Touched',
      category: 'General',
      prerequisite: 'Level 4+',
      description: 'You gain the following benefits. Ability Score Increase: Increase your Intelligence, Wisdom, or Charisma score by 1, to a maximum of 20. Mythal Ward: If a spell attack hits you or you fail a saving throw against a spell, you can take a Reaction to roll on the Mythal-Touched Magic table to create a magical effect.',
      benefit: 'Ability Score Increase, Mythal Ward',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Order\'s Resilience',
      category: 'General',
      prerequisite: 'Level 4+, Tyro of the Gauntlet Feat',
      description: 'You gain the following benefits. Resurge: When you have the Prone condition, you can right yourself with only 5 feet of movement. Stronger Together: If you are within 5 feet of an ally that doesn\'t have the Incapacitated condition, you and that ally have Advantage on Strength saving throws.',
      benefit: 'Resurge, Stronger Together',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Purple Dragon Commandant',
      category: 'General',
      prerequisite: 'Level 4+, Purple Dragon Rook Feat or Martial Weapon Proficiency',
      description: 'You gain the following benefits. Ability Score Increase: Increase your Strength or Dexterity score by 1, to a maximum of 20. Encourage Ally: As a Bonus Action, you bolster one ally you can see within 30 feet. The ally gains Temporary Hit Points equal to 2d6 plus the modifier of the ability score increased by this feat. Last Stand: You have Advantage on attack rolls while Bloodied.',
      benefit: 'Ability Score Increase, Encourage Ally, Last Stand',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Spellfire Adept',
      category: 'General',
      prerequisite: 'Level 4+, Spellfire Spark Feat or the Spellcasting or Pact Magic Feature',
      description: 'You gain the following benefits. Ability Score Increase: Increase your Intelligence, Wisdom, or Charisma score by 1, to a maximum of 20. Fueled Spellfire: Once per turn, when a spell you cast deals Radiant damage, you can expend up to two Hit Point Dice, roll them, and add the total rolled to one damage roll of the spell. Searing Spellfire: When you make a damage roll that deals Radiant damage, it ignores Resistance to Radiant damage.',
      benefit: 'Ability Score Increase, Fueled Spellfire, Searing Spellfire',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Street Justice',
      category: 'General',
      prerequisite: 'Level 4+',
      description: 'You gain the following benefits. Ability Score Increase: Increase your Strength or Dexterity score by 1, to a maximum of 20. Headlock: Your allies have Advantage on attack rolls against a creature Grappled by you. Sturdy Knot: When you use Chain, Manacles, or Rope to bind a creature, add your Proficiency Bonus to the DC to escape. Tough Talk: A creature\'s Hostile attitude doesn\'t impose Disadvantage on your Charisma (Intimidation) checks.',
      benefit: 'Ability Score Increase, Headlock, Sturdy Knot, Tough Talk',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Zhentarim Tactics',
      category: 'General',
      prerequisite: 'Level 4+, Zhentarim Ruffian Feat',
      description: 'You gain the following benefits. Ability Score Increase: Increase your Dexterity or Charisma score by 1, to a maximum of 20. Retaliate: Immediately after a creature within 5 feet of you hits you with a melee attack, you can make an Opportunity Attack action against that creature. Versatile Merc: When you finish a Long Rest, choose a skill in which you have proficiency. You have Expertise in that skill until you finish your next Long Rest.',
      benefit: 'Ability Score Increase, Retaliate, Versatile Merc',
      repeatable: false,
      abilityScoreBonus: 1
    },
    // Epic Boon Feats
    {
      name: 'Boon of Bloodshed',
      category: 'Epic Boon',
      prerequisite: 'Level 19+',
      description: 'You gain the following benefits. Ability Score Increase: Increase one ability score of your choice by 1, to a maximum of 30. Killer\'s Fortune: When an enemy you can see is reduced to 0 Hit Points, you gain Advantage on the next attack roll you make before the end of your next turn. Power from Pain: Once per turn, when you make an attack roll while Bloodied, you can deal extra damage to the target equal to your Proficiency Bonus.',
      benefit: 'Ability Score Increase, Killer\'s Fortune, Power from Pain',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Boon of Bountiful Health',
      category: 'Epic Boon',
      prerequisite: 'Level 19+',
      description: 'You gain the following benefits. Ability Score Increase: Increase one ability score of your choice by 1, to a maximum of 30. Augmented Health: When you gain Temporary Hit Points, increase the number of Temporary Hit Points you gain by 5. Superior Recuperation: When you spend one or more Hit Point Dice to regain Hit Points, you can instead use the highest number possible for each die.',
      benefit: 'Ability Score Increase, Augmented Health, Superior Recuperation',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Boon of Communication',
      category: 'Epic Boon',
      prerequisite: 'Level 19+',
      description: 'You gain the following benefits. Ability Score Increase: Increase your Intelligence, Wisdom, or Charisma score by 1, to a maximum of 30. Cunning Speaker: You don\'t have Disadvantage on ability checks to influence Hostile creatures. Gifted Interpreter: You understand the literal meaning of any language you hear or see signed. Mental Communication: You gain telepathy with a range of 120 feet.',
      benefit: 'Ability Score Increase, Cunning Speaker, Gifted Interpreter, Mental Communication',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Boon of Desperate Resilience',
      category: 'Epic Boon',
      prerequisite: 'Level 19+',
      description: 'You gain the following benefits. Ability Score Increase: Increase your Strength or Constitution score by 1, to a maximum of 30. Defense of Body and Mind: While you are Bloodied, you have Resistance to every damage type except Force.',
      benefit: 'Ability Score Increase, Defense of Body and Mind',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Boon of Exquisite Radiance',
      category: 'Epic Boon',
      prerequisite: 'Level 19+',
      description: 'You gain the following benefits. Ability Score Increase: Increase one ability score of your choice by 1, to a maximum of 30. Eternal Rest: Creatures you reduce to 0 Hit Points can\'t become Undead. Powerful Radiance: When you make a damage roll that deals Radiant damage, you can instead use the highest number possible for each damage die.',
      benefit: 'Ability Score Increase, Eternal Rest, Powerful Radiance',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Boon of Fluid Forms',
      category: 'Epic Boon',
      prerequisite: 'Level 19+',
      description: 'You gain the following benefits. Ability Score Increase: Increase your Intelligence, Wisdom, or Charisma score by 1, to a maximum of 30. Shapechanger: You can take a Magic action to shape-shift into a Beast, Humanoid, or Monstrosity with a Challenge Rating no higher than 10. Hardy Transformation: When you gain Temporary Hit Points when you shape-shift, increase that number of Temporary Hit Points by 20.',
      benefit: 'Ability Score Increase, Shapechanger, Hardy Transformation',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Boon of Fortune\'s Favor',
      category: 'Epic Boon',
      prerequisite: 'Level 19+',
      description: 'You gain the following benefits. Ability Score Increase: Increase one ability score of your choice by 1, to a maximum of 30. Saving Throw Reroll: When you fail a saving throw, you can reroll it and must use the new roll. Once you use this benefit, you can\'t do so again until the start of your next turn.',
      benefit: 'Ability Score Increase, Saving Throw Reroll',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Boon of Poison Mastery',
      category: 'Epic Boon',
      prerequisite: 'Level 19+',
      description: 'You gain the following benefits. Ability Score Increase: Increase one ability score of your choice by 1, to a maximum of 30. Antitoxic: You have Immunity to Poison damage and the Poisoned condition. Perfect Poisoner: Once per turn, when you roll dice to determine Poison damage a creature takes from your attack, spell, or feature, you can instead use the highest number possible for each die.',
      benefit: 'Ability Score Increase, Antitoxic, Perfect Poisoner',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Boon of Revelry',
      category: 'Epic Boon',
      prerequisite: 'Level 19+',
      description: 'You gain the following benefits. Ability Score Increase: Increase your Intelligence, Wisdom, or Charisma score by 1, to a maximum of 30. Inspire Dance: You always have the Otto\'s Irresistible Dance spell prepared. You can cast it once without a spell slot, and you regain the ability to cast it that way when you finish a Long Rest.',
      benefit: 'Ability Score Increase, Inspire Dance',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Boon of Terror',
      category: 'Epic Boon',
      prerequisite: 'Level 19+',
      description: 'You gain the ability to inspire terror in your enemies. You can use your action to cause each creature of your choice within 60 feet of you that can see or hear you to make a Wisdom saving throw. On a failed save, the creature is Frightened of you for 1 minute.',
      benefit: 'Aura of Terror',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Boon of the Bright Sun',
      category: 'Epic Boon',
      prerequisite: 'Level 19+',
      description: 'You gain the following benefits. Ability Score Increase: Increase your Constitution, Wisdom, or Charisma score by 1, to a maximum of 30. Daylight Presence: As a Bonus Action, you radiate a 30-foot Emanation of Bright Light that is sunlight. Fortifying Light: When your Daylight Presence is active, at the start of each of your turns, you and allies you can see in your Daylight Presence gain 10 Temporary Hit Points.',
      benefit: 'Ability Score Increase, Daylight Presence, Fortifying Light',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Boon of the Furious Storm',
      category: 'Epic Boon',
      prerequisite: 'Level 19+, Spellcasting or Pact Magic Feature',
      description: 'You gain the following benefits. Ability Score Increase: Increase your Intelligence, Wisdom, or Charisma score by 1, to a maximum of 30. Eye of the Storm: You have Resistance to Lightning and Thunder damage. While you are Bloodied, you have Immunity to Lightning and Thunder damage. Storm\'s Strength: Creatures have Disadvantage on saving throws against your spells that deal Lightning or Thunder damage.',
      benefit: 'Ability Score Increase, Eye of the Storm, Storm\'s Strength',
      repeatable: false,
      abilityScoreBonus: 1
    },
    {
      name: 'Boon of the Soul Drinker',
      category: 'Epic Boon',
      prerequisite: 'Level 19+',
      description: 'You gain the following benefits. Ability Score Increase: Increase one ability score of your choice by 1, to a maximum of 30. Grave Resistance: You have Resistance to Cold damage and Necrotic damage. Siphon Life: When an enemy within 120 feet of you is reduced to 0 Hit Points, you can take a Reaction to regain 50 Hit Points.',
      benefit: 'Ability Score Increase, Grave Resistance, Siphon Life',
      repeatable: false,
      abilityScoreBonus: 1
    }
  ];

  for (const feat of feats) {
    const existing = await db.feat.findFirst({ where: { name: feat.name } });
    if (!existing) {
      await db.feat.create({ data: feat });
      console.log(`Created feat: ${feat.name}`);
    } else {
      console.log(`Feat already exists: ${feat.name}`);
    }
  }

  // =====================
  // SPELLS
  // =====================
  console.log('\n--- Seeding Spells ---');

  const spells = [
    {
      name: 'Alustriel\'s Moonbeam',
      level: 5,
      school: 'Abjuration',
      castingTime: 'Action',
      range: 'Self',
      components: 'V, S, M (a moonstone worth 50+ GP)',
      duration: 'Concentration, up to 1 minute',
      description: 'For the duration, moonlight fills a 20-foot Emanation originating from you with Dim Light. While in that area, you and your allies have Half Cover and Resistance to Cold, Lightning, and Radiant damage. While the spell lasts, you can use one of the following options: Liberation (when you fail a saving throw to avoid or end the Frightened, Grappled, or Restrained condition, you can take a Reaction to succeed on the save instead) or Respite (as a Magic action, you or an ally within the area regains Hit Points equal to 4d10 plus your spellcasting ability modifier).',
      concentration: true,
      classes: 'Bard, Druid, Ranger, Wizard'
    },
    {
      name: 'Bladeguard',
      level: 4,
      school: 'Abjuration',
      castingTime: 'Reaction',
      range: '60 feet',
      components: 'V',
      duration: 'Instantaneous',
      description: 'You ward yourself against destructive energy, reducing the damage taken by 4d6 plus your spellcasting ability modifier. If the triggering damage was from a creature within range, you can force the creature to make a Constitution saving throw. The creature takes 4d6 Force damage on a failed save or half as much damage on a successful one.',
      concentration: false,
      classes: 'Bard, Sorcerer, Warlock, Wizard'
    },
    {
      name: 'Blade of Disaster',
      level: 9,
      school: 'Conjuration',
      castingTime: 'Bonus Action',
      range: '60 feet',
      components: 'V, S',
      duration: 'Concentration, up to 1 minute',
      description: 'You create a 3-foot-long blade-shaped planar rift that lasts for the duration. The rift appears within range in a space of your choice, and you can immediately make up to two melee spell attacks, each one against a creature or object within 5 feet of the rift. On a hit, the target takes 10d6 Force damage. This attack scores a Critical Hit if the number on the d20 is 18 or higher. As a Bonus Action on your later turns, you can move the rift up to 60 feet and repeat the two attacks.',
      concentration: true,
      classes: 'Sorcerer, Warlock, Wizard'
    },
    {
      name: 'Clap of Thunder',
      level: 3,
      school: 'Evocation',
      castingTime: 'Action',
      range: 'Self',
      components: 'V, S',
      duration: 'Concentration, up to 10 minutes',
      description: 'Thunderous reverberations fill a 10-foot Emanation originating from you for the duration. Whenever the Emanation enters a creature\'s space and whenever a creature enters the Emanation or ends its turn there, the creature makes a Constitution saving throw. On a failed save, the creature takes 3d6 Thunder damage and has the Deafened condition until the start of your next turn. You have Resistance to Thunder damage, and ranged attack rolls against you are made with Disadvantage.',
      concentration: true,
      classes: 'Bard, Sorcerer, Wizard'
    },
    {
      name: 'Clockwork Cohort',
      level: 3,
      school: 'Conjuration',
      castingTime: 'Action',
      range: '60 feet',
      components: 'V, S, M (a brass cog)',
      duration: 'Concentration, up to 10 minutes',
      description: 'You conjure a group of intangible, orderly spirits that appear as a Medium group of modrons or other Constructs in an unoccupied space you can see within range. When you cast this spell and as a Magic action on subsequent turns, you can command the spirits to target one creature or object you can see within 5 feet of the spirits and create one of the following effects: Clockwork Force (Dexterity save, 3d6 Force damage) or Orderly Ward (1d6 + spellcasting ability modifier Temporary Hit Points).',
      concentration: true,
      classes: 'Wizard'
    },
    {
      name: 'Dark Aura',
      level: 2,
      school: 'Necromancy',
      castingTime: 'Action',
      range: 'Touch',
      components: 'V, S, M (an onyx worth 50+ GP)',
      duration: '1 hour',
      description: 'For the duration, an inky aura surrounds one creature you touch. The target has Advantage on Death Saving Throws, and once per turn, when a creature within 5 feet of the target hits it with a melee attack roll, the attacker takes 2d4 Necrotic damage.',
      concentration: false,
      classes: 'Sorcerer, Wizard'
    },
    {
      name: 'Delsenora\'s Horsemen Hoard',
      level: 2,
      school: 'Conjuration',
      castingTime: 'Action or Ritual',
      range: 'Self',
      components: 'V, S, M (powdered gemstones worth 100+ GP, one set of Artisan\'s Tools)',
      duration: 'Instantaneous',
      description: 'You conjure a set of phantom horses and tack for up to ten Medium or smaller creatures. Each horse has AC 10, 1 HP, and Speed 60 feet. A horse disappears if it drops to 0 HP or if its rider dismounts.',
      concentration: false,
      ritual: true,
      classes: 'Cleric, Wizard'
    },
    {
      name: 'Deathly Power',
      level: 3,
      school: 'Evocation',
      castingTime: 'Action',
      range: 'Self',
      components: 'V',
      duration: 'Concentration, up to 1 minute',
      description: 'Deathly power fills a 60-foot Emanation originating from you for the duration. Any creature other than those you designate can\'t regain Hit Points while in the Emanation. Whenever a creature enters the Emanation or ends its turn there, the creature makes a Constitution saving throw. On a failed save, the creature takes 3d10 Necrotic damage and has the Prone condition. Casting as a Circle Spell with two secondary casters increases duration to 10 minutes and adds 1 Exhaustion level on failed save.',
      concentration: true,
      classes: 'Cleric, Sorcerer, Wizard'
    },
    {
      name: 'Deathshroud',
      level: 4,
      school: 'Conjuration',
      castingTime: 'Action',
      range: '120 feet',
      components: 'V, S, M (soot and a dried eel)',
      duration: 'Concentration, up to 1 minute',
      description: 'You create a 20-foot-radius Sphere of inky fog within range. The fog is magical Darkness. Each creature in the Sphere when it appears makes a Wisdom saving throw. On a failed save, a creature takes 5d6 Psychic damage and subtracts 1d6 from its saving throws until the end of its next turn. The Sphere moves 10 feet away from you at the start of each of your turns.',
      concentration: true,
      classes: 'Bard, Cleric, Warlock'
    },
    {
      name: 'Elminster\'s Effulgent Spheres',
      level: 8,
      school: 'Evocation',
      castingTime: 'Bonus Action',
      range: 'Self',
      components: 'V, S',
      duration: 'Concentration, up to 1 minute',
      description: 'You create a glowing mote of energy that hovers above you for the duration. When you cast this spell and as a Bonus Action on later turns, you can unleash a shining bolt from the mote, targeting one creature within 120 feet. Make a ranged spell attack. On a hit, the target takes Force or Radiant damage equal to 4d10 plus your spellcasting ability modifier. You have Three-Quarters Cover, and if you succeed on a save against a level 7 or lower spell that targeted only you, you can deflect it back at the caster.',
      concentration: true,
      classes: 'Cleric, Wizard'
    },
    {
      name: 'Laeral\'s Silver Lance',
      level: 3,
      school: 'Evocation',
      castingTime: 'Action',
      range: 'Self',
      components: 'V, S, M (a silver pin worth 250+ GP)',
      duration: 'Instantaneous',
      description: 'Silver energy bursts out from you in a 120-foot-long, 5-foot-wide Line. Each creature of your choice in the Line makes a Strength saving throw. On a failed save, a creature takes 3d10 Force damage and has the Prone condition. On a successful save, a creature takes half as much damage only.',
      concentration: false,
      classes: 'Cleric, Sorcerer, Wizard'
    },
    {
      name: 'Simbul\'s Synostodweomer',
      level: 7,
      school: 'Transmutation',
      castingTime: 'Action',
      range: 'Touch',
      components: 'V, S',
      duration: '1 hour',
      description: 'You imbue one creature you touch with magical healing energy for the duration. Whenever the target casts a spell using a spell slot, the target can immediately roll a number of unexpended Hit Point Dice equal to the spell slot\'s level and regain Hit Points equal to the roll\'s total plus your spellcasting ability modifier; those dice are then expended.',
      concentration: false,
      classes: 'Sorcerer, Wizard'
    },
    {
      name: 'Sultana\'s Elemental Sovereignty',
      level: 5,
      school: 'Transmutation',
      castingTime: 'Action',
      range: 'Self',
      components: 'V, S, M (a pearl worth 100+ GP)',
      duration: 'Concentration, up to 1 minute',
      description: 'You imbue yourself with the elemental power of genies. You gain Elemental Immunity (choose Acid, Cold, Fire, Lightning, or Thunder; you have Resistance), Elemental Pulse (2d6 damage of chosen type in 15-foot Emanation each turn), and Flight (Fly Speed 30 feet, hover). Casting as a Circle Spell lets you grant these benefits to additional creatures.',
      concentration: true,
      classes: 'Druid, Sorcerer, Wizard'
    },
    {
      name: 'Spellfire Blast',
      level: 1,
      school: 'Evocation',
      castingTime: 'Action',
      range: '60 feet',
      components: 'V, S',
      duration: 'Instantaneous',
      description: 'You unleash a blast of brilliant fire. Make a ranged spell attack against a target within range; a target gains no benefit from Half Cover or Three-Quarters Cover for this attack roll. On a hit, the target takes 2d10 Radiant damage.',
      concentration: false,
      classes: 'Sorcerer, Wizard'
    },
    {
      name: 'Spellfire Storm',
      level: 4,
      school: 'Evocation',
      castingTime: 'Action',
      range: '60 feet',
      components: 'V, S',
      duration: 'Concentration, up to 1 minute',
      description: 'You conjure a pillar of spellfire in a 20-foot-radius, 20-foot-high Cylinder centered on a point within range. Each creature in it when it appears makes a Constitution saving throw, taking 4d10 Radiant damage on a failed save. Whenever a creature in the Cylinder casts a spell, that creature makes a Constitution saving throw. On a failed save, the spell dissipates with no effect.',
      concentration: true,
      classes: 'Sorcerer, Wizard'
    },
    {
      name: 'Stormshield',
      level: 1,
      school: 'Abjuration',
      castingTime: 'Action',
      range: '60 feet',
      components: 'V, S, M (a miniature clay hand)',
      duration: 'Instantaneous',
      description: 'You hurl a disorienting magical force toward one creature within range. The target makes a Constitution saving throw; Constructs and Undead automatically succeed. On a failed save, the target takes 2d4 Force damage, its Speed is halved until the start of your next turn, and on its next turn, it can take only an action or a Bonus Action (but not both).',
      concentration: false,
      classes: 'Bard, Cleric, Paladin, Wizard'
    }
  ];

  for (const spell of spells) {
    const existing = await db.spell.findFirst({ where: { name: spell.name } });
    if (!existing) {
      await db.spell.create({ data: spell });
      console.log(`Created spell: ${spell.name}`);
    } else {
      console.log(`Spell already exists: ${spell.name}`);
    }
  }

  console.log('\n=== Forgotten Realms: Heroes of Faerun Seeding Complete ===');
}

async function getClassId(className: string): Promise<string | null> {
  const characterClass = await db.characterClass.findFirst({
    where: { name: className }
  });
  return characterClass?.id || null;
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
