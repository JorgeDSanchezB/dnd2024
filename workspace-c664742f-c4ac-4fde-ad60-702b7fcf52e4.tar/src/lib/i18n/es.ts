export const translations = {
  // Navigation
  create: 'Crear',
  characters: 'Personajes',
  sheet: 'Hoja',
  
  // Character Creation
  characterCreation: 'Creación de Personaje',
  step: 'Paso',
  of: 'de',
  next: 'Siguiente',
  previous: 'Anterior',
  cancel: 'Cancelar',
  save: 'Guardar',
  delete: 'Eliminar',
  edit: 'Editar',
  createCharacter: 'Crear Personaje',
  
  // Step 1 - Basics
  basics: 'Datos Básicos',
  characterName: 'Nombre del Personaje',
  enterName: 'Introduce el nombre del personaje',
  startingLevel: 'Nivel Inicial',
  selectLevel: 'Selecciona el nivel inicial',
  
  // Step 2 - Species
  selectSpecies: 'Seleccionar Especie',
  species: 'Especie',
  chooseSpecies: 'Elige la especie de tu personaje',
  size: 'Tamaño',
  speed: 'Velocidad',
  traits: 'Rasgos',
  
  // Step 3 - Class
  selectClass: 'Seleccionar Clase',
  class: 'Clase',
  chooseClass: 'Elige la clase de tu personaje',
  primaryAbility: 'Habilidad Principal',
  hitDie: 'Dado de Golpe',
  savingThrows: 'Tiradas de Salvación',
  skillProficiencies: 'Competencias en Habilidades',
  armorTraining: 'Entrenamiento en Armadura',
  weaponProficiencies: 'Competencias en Armas',
  startingEquipment: 'Equipo Inicial',
  features: 'Características',
  spellcasting: 'Conjuración',
  subclasses: 'Subclases',
  
  // Step 4 - Background
  selectBackground: 'Seleccionar Trasfondo',
  background: 'Trasfondo',
  chooseBackground: 'Elige el trasfondo de tu personaje',
  feat: 'Dote',
  toolProficiency: 'Competencia en Herramientas',
  equipment: 'Equipo',
  
  // Step 5 - Details
  details: 'Detalles',
  alignment: 'Alineamiento',
  selectAlignment: 'Selecciona alineamiento',
  appearance: 'Apariencia',
  describeAppearance: 'Describe la apariencia física de tu personaje',
  history: 'Historia',
  describeHistory: 'Describe la historia y personalidad de tu personaje',
  
  // Alignments
  lawfulGood: 'Legal Bueno',
  neutralGood: 'Neutral Bueno',
  chaoticGood: 'Caótico Bueno',
  lawfulNeutral: 'Legal Neutral',
  neutral: 'Neutral',
  chaoticNeutral: 'Caótico Neutral',
  lawfulEvil: 'Legal Malvado',
  neutralEvil: 'Neutral Malvado',
  chaoticEvil: 'Caótico Malvado',
  
  // Character Sheet
  characterSheet: 'Hoja de Personaje',
  level: 'Nivel',
  xp: 'XP',
  levelUp: 'Subir Nivel',
  shop: 'Tienda',
  spellbook: 'Grimorio',
  exportPDF: 'Exportar PDF',
  
  // Ability Scores
  abilityScores: 'Puntuaciones de Característica',
  strength: 'Fuerza',
  dexterity: 'Destreza',
  constitution: 'Constitución',
  intelligence: 'Inteligencia',
  wisdom: 'Sabiduría',
  charisma: 'Carisma',
  str: 'FUE',
  dex: 'DES',
  con: 'CON',
  int: 'INT',
  wis: 'SAB',
  cha: 'CAR',
  
  // Combat
  combat: 'Combate',
  hitPoints: 'Puntos de Golpe',
  current: 'Actual',
  max: 'Máximo',
  temp: 'Temporal',
  armorClass: 'Clase de Armadura',
  initiative: 'Iniciativa',
  proficiencyBonus: 'Bonificador de Competencia',
  hitDice: 'Dados de Golpe',
  deathSaves: 'Salvaciones de Muerte',
  successes: 'Éxitos',
  failures: 'Fallos',
  
  // Skills
  skills: 'Habilidades',
  proficient: 'Competente',
  expertise: 'Experto',
  acrobatics: 'Acróbatas',
  animalHandling: 'Trato con Animales',
  arcana: 'Arcano',
  athletics: 'Atletismo',
  deception: 'Engaño',
  history: 'Historia',
  insight: 'Perspicacia',
  intimidation: 'Intimidación',
  investigation: 'Investigación',
  medicine: 'Medicina',
  nature: 'Naturaleza',
  perception: 'Percepción',
  performance: 'Interpretación',
  persuasion: 'Persuasión',
  religion: 'Religión',
  sleightOfHand: 'Juego de Manos',
  stealth: 'Sigilo',
  survival: 'Supervivencia',
  
  // Saving Throws
  savingThrowsTitle: 'Tiradas de Salvación',
  
  // Money
  money: 'Moneda',
  copper: 'PC',
  silver: 'PP',
  electrum: 'PE',
  gold: 'PO',
  platinum: 'PP',
  
  // Proficiencies
  proficiencies: 'Competencias',
  languages: 'Idiomas',
  tools: 'Herramientas',
  armor: 'Armaduras',
  weapons: 'Armas',
  
  // Inventory
  inventory: 'Inventario',
  item: 'Objeto',
  quantity: 'Cantidad',
  equipped: 'Equipado',
  attuned: 'Sintonizado',
  weight: 'Peso',
  cost: 'Coste',
  damage: 'Daño',
  damageType: 'Tipo de Daño',
  properties: 'Propiedades',
  rarity: 'Rareza',
  type: 'Tipo',
  
  // Damage Types
  acid: 'Ácido',
  bludgeoning: 'Contundente',
  cold: 'Frío',
  fire: 'Fuego',
  force: 'Fuerza',
  lightning: 'Rayo',
  necrotic: 'Necrótico',
  piercing: 'Perforante',
  poison: 'Veneno',
  psychic: 'Psíquico',
  radiant: 'Radiante',
  slashing: 'Cortante',
  thunder: 'Trueno',
  
  // Spells
  spells: 'Conjuros',
  cantrips: 'Trucos',
  level1: 'Nivel 1',
  level2: 'Nivel 2',
  level3: 'Nivel 3',
  level4: 'Nivel 4',
  level5: 'Nivel 5',
  level6: 'Nivel 6',
  level7: 'Nivel 7',
  level8: 'Nivel 8',
  level9: 'Nivel 9',
  castingTime: 'Tiempo de Lanzamiento',
  range: 'Alcance',
  components: 'Componentes',
  duration: 'Duración',
  concentration: 'Concentración',
  ritual: 'Ritual',
  prepared: 'Preparado',
  known: 'Conocido',
  spellcastingAbility: 'Habilidad de Conjuración',
  spellSaveDC: 'CD de Hechizo',
  spellAttackBonus: 'Bon. Ataque de Hechizo',
  addSpell: 'Añadir Hechizo',
  removeSpell: 'Eliminar Hechizo',
  
  // Spell Schools
  abjuration: 'Abjuración',
  conjuration: 'Conjuro',
  divination: 'Adivinación',
  enchantment: 'Encantamiento',
  evocation: 'Evocación',
  illusion: 'Ilusión',
  necromancy: 'Nigromancia',
  transmutation: 'Transmutación',
  
  // Feats
  feats: 'Dotes',
  addFeat: 'Añadir Dote',
  removeFeat: 'Eliminar Dote',
  category: 'Categoría',
  prerequisite: 'Prerrequisito',
  benefit: 'Beneficio',
  repeatable: 'Repetible',
  
  // Class Features
  classFeatures: 'Rasgos de Clase',
  speciesTraits: 'Rasgos de Especie',
  subclassFeatures: 'Rasgos de Subclase',
  
  // Character Details
  characterDetails: 'Detalles del Personaje',
  personalityTraits: 'Rasgos de Personalidad',
  ideals: 'Ideales',
  bonds: 'Vínculos',
  flaws: 'Defectos',
  backstory: 'Trasfondo',
  
  // Shop
  buy: 'Comprar',
  sell: 'Vender',
  price: 'Precio',
  shopWeapons: 'Armas',
  shopArmor: 'Armaduras',
  shopItems: 'Objetos',
  shopMagic: 'Mágicos',
  
  // Actions
  roll: 'Tirar',
  attack: 'Atacar',
  cast: 'Lanzar',
  use: 'Usar',
  copy: 'Copiar',
  duplicate: 'Duplicar',
  
  // Messages
  selectCharacterToView: 'Selecciona un personaje para ver su hoja.',
  viewCharacters: 'Ver Personajes',
  noCharactersYet: 'Aún no hay personajes. ¡Crea tu primer personaje!',
  characterCreated: '¡Personaje creado con éxito!',
  characterUpdated: '¡Personaje actualizado con éxito!',
  characterDeleted: '¡Personaje eliminado con éxito!',
  confirmDelete: '¿Estás seguro de que quieres eliminar este personaje?',
  
  // Level Up
  levelUpAvailable: '¡Subir de Nivel Disponible!',
  chooseASIOrFeat: 'Elige Mejora de Puntuación o Dote',
  abilityScoreImprovement: 'Mejora de Puntuación de Característica',
  selectFeat: 'Seleccionar Dote',
  newLevel: 'Nuevo Nivel',
  
  // Multiclass
  multiclass: 'Multiclase',
  newClass: 'Nueva Clase',
  
  // Misc
  name: 'Nombre',
  description: 'Descripción',
  notes: 'Notas',
  addNote: 'Añadir Nota',
  editNote: 'Editar Nota',
  noteTitle: 'Título',
  noteContent: 'Contenido',
  pinned: 'Fijado',
  
  // Sizes
  tiny: 'Diminuto',
  small: 'Pequeño',
  medium: 'Mediano',
  large: 'Grande',
  huge: 'Enorme',
  gargantuan: 'Gigantesco',
  
  // Rarity
  common: 'Común',
  uncommon: 'Poco Común',
  rare: 'Raro',
  veryRare: 'Muy Raro',
  legendary: 'Legendario',
  artifact: 'Artefacto',
  
  // PDF Export
  characterSheetPDF: 'Hoja de Personaje',
  allRightsReserved: 'Todos los derechos reservados',
  
  // Search and Filter
  search: 'Buscar',
  filter: 'Filtrar',
  all: 'Todos',
  none: 'Ninguno',
  
  // Encyclopedias
  monsters: 'Monstruos',
  rules: 'Reglas',
  
  // Summary
  summary: 'Resumen',
  summaryCharacter: 'Resumen del Personaje',
  
  // Error/Success
  error: 'Error',
  success: 'Éxito',
  loading: 'Cargando...',
  noData: 'No hay datos disponibles',
  
  // Toggle Language
  language: 'Idioma',
  spanish: 'Español',
  english: 'Inglés',
  
  // Armor Properties
  light: 'Ligera',
  medium: 'Media',
  heavy: 'Pesada',
  shield: 'Escudo',
  stealthDisadvantage: 'Desventaja en Sigilo',
  dexBonus: 'Bonificación DES',
  maxDexBonus: 'Bonificación DES Máxima',
  strRequired: 'FUE Requerido',
  
  // Weapon Properties
  simple: 'Simple',
  martial: 'Marcial',
  melee: 'Cuerpo a Cuerpo',
  ranged: 'A Distancia',
  twoHanded: 'A Dos Manos',
  versatile: 'Versátil',
  finesse: 'Precisión',
  reach: 'Alcance',
  thrown: 'Arrojadiza',
  ammunition: 'Munición',
  loadingWeapon: 'Carga',
  heavyWeapon: 'Pesada',
  lightWeapon: 'Ligera',
  lance: 'Lanza',
  net: 'Red',
  pike: 'Pica',
  
  // Mastery
  mastery: 'Maestría',
  
  // Attunement
  attunement: 'Sintonización',
  requiresAttunement: 'Requiere Sintonización',
  attunementRequirements: 'Requisitos de Sintonización',
  
  // Background Descriptions (Spanish)
  backgroundDescriptions: {
    'Acolyte': 'Has pasado tu vida en el servicio de un templo a un dios o panteón específico. Actúas como intermediario entre el reino sagrado y el mundo mortal, realizando ritos sagrados y ofreciendo sacrificios para conducir a los fieles a la presencia de lo divino. No eres un clérigo ni un paladín, sino un sirviente devoto que sostiene la fe a través de ceremonias, enseñanzas y el cuidado del templo.',
    'Criminal': 'Eres un criminal experimentado con contactos en el bajo mundo. Has vivido fuera de la ley, sobreviviendo mediante tu ingenio, sigilo y la red de aliados poco fiables que has cultivado. Conoces los secretos oscuros de las calles y cómo moverte en las sombras.',
    'Entertainer': 'Vives para cautivar a tu audiencia. Ya sea como músico, actor, poeta o acróbata, tu arte es tu vida. Has viajado por doquier, actuando en tabernas, teatros y cortes nobles, siempre buscando nuevos horizontes y nuevas historias que contar.',
    'Sage': 'Has dedicado tu vida al estudio y la investigación. Pasaste años en bibliotecas, universidades o archivos, acumulando conocimiento sobre temas arcanos, historia antigua o ciencias naturales. Tu curiosidad insaciable te ha llevado a buscar respuestas más allá de los libros.',
    'Soldier': 'Has servido en un ejército, ya sea como soldado raso o oficial. La guerra te ha forjado, enseñándote disciplina, táctica y el valor de la vida. Ahora, con tu servicio terminado, buscas un nuevo propósito para las habilidades que has adquirido.',
    'Artisan': 'Eres un artesano experto que ha perfeccionado un oficio específico. Ya sea trabajando metal, madera, cuero o tejido, tus manos crean objetos de belleza y utilidad. Tu taller ha sido tu segundo hogar, y tus creaciones hablan de tu dedicación.',
    'Charlatan': 'Eres un maestro del engaño y la manipulación. Has sobrevivido gracias a tu labia, encanto y la capacidad de convencer a otros de cosas que no son ciertas. Desde pociones milagrosas hasta esquemas de inversión, siempre tienes un as bajo la manga.',
    'Far Traveler': 'Proviene de una tierra lejana y exótica. Tu apariencia, costumbres y forma de hablar te distinguen de los habitantes locales. Buscas aventuras por razones que solo tú conoces, quizás huyendo de algo o buscando algo preciado.',
    'Guardian': 'Has dedicado tu vida a proteger a otros. Ya sea como guardia de ciudad, guardaespaldas o defensor de un lugar sagrado, tu deber es estar siempre alerta. Has visto el peligro de cerca y sabes el valor de una vida protegida.',
    'Hermit': 'Has vivido en aislamiento, alejado de la sociedad. Quizás buscabas iluminación espiritual, huías de un pasado oscuro o simplemente preferías la soledad. Los años de retiro te han dado una perspectiva única sobre el mundo.',
    'Noble': 'Naciste en la realeza o la aristocracia. La riqueza, el poder y la influencia siempre han sido parte de tu vida, pero también las responsabilidades y expectativas que conllevan. Llevas en la sangre el arte de gobernar.',
    'Outlander': 'Creciste en los terrenos salvajes, lejos de la civilización. Conoces los secretos de la naturaleza, cómo sobrevivir en el bosque y leer las señales del clima. Los caminos de la ciudad te son extraños, pero el campo salvaje es tu hogar.',
    'Sailor': 'El mar ha sido tu vida. Has navegado aguas tranquilas y tormentosas, conocido puertos lejanos y enfrentado criaturas de las profundidades. El llamado del océano corre por tus venas, y siempre añoras el siguiente horizonte.',
    'Urban Investigator': 'Eres un detective urbano que resuelve misterios en las calles de la ciudad. Tu perspicacia y atención al detalle te han ayudado a resolver crímenes que otros no pudieron. Conoces los secretos que se esconden en cada callejón.',
    'Wayfarer': 'Eres un viajero incansable que recorre el mundo sin rumbo fijo. Has visto tierras lejanas, conocido culturas diversas y acumulado historias innumerables. El camino es tu hogar, y cada nuevo día trae nuevas aventuras.',
    // Expansion Backgrounds - Astarion's Book of Hungers
    'Carouser': 'Creciste hasta la adultez en el corazón palpitante de una gran ciudad, como Baldur\'s Gate. Pasaste innumerables noches en tabernas, teatros, salones y casas de juego, saboreando todo lo que la ciudad tenía para ofrecer. Eres un natural interactuando con personas para aprender sus secretos, ya sea en un juego de altas apuestas o en una sofisticada velada. Puede que te hayan echado de algún establecimiento, pero solo de personas que no saben cómo festejar.',
    'Vampire Devotee': 'Estuviste al servicio de un vampiro o un pequeño grupo de vampiros que acechan juntos. Los no muertos bebieron tu sangre más veces de las que puedes contar. Pudiste haber servido voluntariamente, quizás con aspiraciones de convertirte en vampiro algún día. O pudiste haber sido encantado mágicamente y conservar solo unos pocos recuerdos confusos de tu tiempo como familiar de vampiro. En cualquier caso, tu tiempo en el cubil de vampiros ha terminado.',
    'Vampire Survivor': 'Presenciaste o sobreviviste a un ataque de vampiros. Pudiste haber estado directamente involucrado en esta confrontación, o quizás quedaste paralizado por el terror ante lo que viste. Independientemente, permaneces alerta ante los ataques de monstruos y te enorgulleces estar preparado para cualquier cosa. Ningún vampiro te tomará por sorpresa a ti o a tus aliados otra vez.',
    // Expansion Backgrounds - Forge of the Artificer (Eberron)
    'Aberrant Heir': 'Tu marca de dragón aberrante ha hecho la vida desafiante desde que se manifestó. Pudiste haberla ocultado exitosamente durante la mayor parte de tu vida o logrado evitar ser notado. Alternativamente, pudiste haber encontrado sospechas y miedo, quizás junto con la antagonía abierta de una o más casas con marca de dragón.',
    'Archaeologist': 'Has hecho un estudio de por vida de las culturas perdidas y caídas del pasado, visitando sus ruinas, descifrando sus registros escritos y examinando sus obras maestras sobrevivientes. Quizás estudiaste en la Universidad Morgrave o una institución similar, complementando tu tiempo en la biblioteca con trabajo de campo entre ruinas antiguas en ubicaciones remotas.',
    'House Agent': 'Estás conectado a una de las casas con marca de dragón, pero aún no has manifestado una marca de dragón. Puedes ser un miembro de la familia por nacimiento o un empleado de la casa sin conexión familiar. Has ganado tu vida haciendo los negocios de la casa, sirviendo como las manos, pies y ojos del liderazgo de la casa en el mundo.',
    'House Cannith Heir': 'Como vástago de la Casa Cannith, cargas con un legado orgullosos. Cannith crea maravillas del mundo moderno, y se espera que contribuyas al éxito continuo de la casa a través de la invención, erudición, negocios o diplomacia.',
    'House Deneith Heir': 'Como heredero de la Casa Deneith, has sido entrenado para el combate, no para buscarlo, pero tampoco para rehuirlo. Has aprendido la importancia del deber, el honor y las leyes usadas para gobernar la sociedad cuando el deber y el honor fallan.',
    'House Ghallanda Heir': 'Gracias a tus conexiones con la Casa Ghallanda, creciste acostumbrado a las comodidades, conversaciones animadas, buena bebida y comida deliciosa. Puedes ser un encantador y ingenioso vástago de la casa a quien no le gusta nada más que una velada agradable junto a un fuego cálido.',
    'House Jorasco Heir': 'La Casa Jorasco enseña que la enfermedad y las lesiones acechan a los vivos como fantasmas, robándoles salud y longevidad. Se te han enseñado formas de combatir estos azotes, tanto mágica como médicamente. Estás entrenado para usar esas habilidades al servicio de otros.',
    'House Kundarak Heir': 'Como heredero de la Casa Kundarak, sientes gran orgullo por tu familia y su trabajo de salvaguardar los valores de Khorvaire. Tu casa siempre ha sido líder entre los clanes de los Sror Holds.',
    'House Lyrandar Heir': 'Como heredero de la Casa Lyrandar, el viento es tu aliado, el mar y el cielo tu dominio. A pesar de la devastación de la Última Guerra, tu casa está en ascenso, impulsada por su dominio de la nueva tecnología de naves aéreas.',
    'House Medani Heir': 'Como miembro de la Casa Medani, tu vida gira en torno a la intriga, no participando en ella, sino impidiendo que otros lo hagan. Ves el mundo a tu alrededor como una intrincada red de esquemas, conspiraciones y contraconspiraciones.',
    'House Orien Heir': 'Antes de la Última Guerra, la influencia de Orien cubría Khorvaire, y sus carreteras comerciales y rieles relámpago eran el fluido vital de un reino vibrante. Pero la guerra cortó esas arterias, dejando a Galifar muerto y a la Casa Orien herida.',
    'House Phiarlan Heir': 'Aunque has visto riqueza, fama y belleza como hijo de la Casa Phiarlan, consideras el conocimiento (y el poder que trae) el mayor tesoro de todos. Puedes perseguir ese poder como artista o intérprete.',
    'House Sivis Heir': 'Durante casi treinta siglos, tu familia ha trabajado para mantener el orden. La comunicación es el cordón que une a la civilización, y tus ancestros resolvieron disputas de soberanos y ayudaron a las casas con marca de dragón a encontrar su lugar en el mundo.',
    'House Tharashk Heir': 'Los herederos de otras casas llevan vidas de lujo, pero en la Casa Tharashk aprendiste autosuficiencia desde temprana edad. Lo que a tu joven casa le falta en recursos, lo compensa con espíritu y determinación.',
    'House Thuranni Heir': 'Dada la corta historia de la Casa Thuranni y su enfoque en el espionaje, sus líderes esperan que promuevas los intereses de la casa en cada oportunidad. Durante los años formativos de la casa como entidad independiente, cada movimiento que haces ha sido observado de cerca.',
    'House Vadalis Heir': 'Has crecido con respeto tanto por la familia como por la naturaleza. Entiendes la cultura de las Cinco Naciones, pero no te dejas arrastrar en los juegos de ambición y estatus que otros juegan.',
    'Inquisitive': 'Has perfeccionado tus talentos de investigación y deducción, alimentados por una curiosidad infinita, para explorar misterios, encontrar personas desaparecidas, recuperar bienes robados, descubrir corrupción y conspiraciones, y resolver crímenes.',
    // Expansion Backgrounds - Forgotten Realms Heroes of Faerun
    'Chondathan Freebooter': 'Aunque la mayoría de los jóvenes en Chondath aceptan su período de cuatro años de servicio militar obligatorio, tú te rebelaste contra ese intento autoritario de controlar tu vida. Renunciaste a tu nacionalidad, descartaste tu nombre dado, y trabajaste como filibustero en el primer barco que te aceptara. Desde entonces, has viajado por el Vilhon Reach.',
    'Dead Magic Dweller': 'Las zonas de magia muerta del desierto de Anauroch son anatema para los conjuradores y monstruos que dependen de la magia, exactamente por eso hiciste tu vida allí. Después de largos meses o años, eres más fuerte, más sabio, y armado con conocimiento duramente ganado de medicina del desierto y supervivencia en páramos.',
    'Dragon Cultist': 'Eres un iniciado del Culto del Dragón. Descubriste o fuiste llevado a una célula del culto, donde ejemplificaste los valores honrados por los cultistas del dragón: duplicidad, secreto y determinación. A cambio de tu juramento de servir al culto, el culto te ofreció la compañía de compañeros adoradores de dragones.',
    'Emerald Enclave Caretaker': 'Como Custodio del Enclave Esmeralda, cuidas de aquellos que cuidan del mundo. Ya sea junto a tus compañeros miembros del Enclave Esmeralda o por tu cuenta, has aprendido habilidades esenciales para vivir con la tierra: cómo rastrear presa, dónde forrajear hierbas útiles, e incluso cómo pronosticar el clima.',
    'Flaming Fist Mercenary': 'La principal rama de aplicación de la ley de Baldur\'s Gate es el Puño Flamígero, un gremio mercenario musculoso liderado por el gran duque de la ciudad. Una vez serviste como Puño Flamígero, donde aprendiste cómo prevenir problemas con tu mirada intimidante y, cuando era necesario, absorber golpes mortales.',
    'Genie Touched': 'Aunque los genios ya no gobiernan Calimshan, la magia de los genios sigue siendo común en tu tierra natal. Quizás invocaste inadvertidamente un djinni de una lámpara mágica, o quizás encontraste un oasis custodiado por un marid. Sin embargo tu destino se cruzó con el de un genio, la experiencia te dejó con un ojo agudo, una lengua de plata y más que un toque de magia.',
    'Harper': 'Aceptaste una invitación para unirte a los Arpistas, jurando un juramento para mantener el código Arpista y actuar al servicio del bien común. Como todos los Arpistas, entiendes el valor del trabajo en equipo así como cuándo es mejor actuar solo. Los veteranos Arpistas te han enseñado los secretos de la orden.',
    'Ice Fisher': 'Proviene de una orgullosa línea de pescadores de hielo de Ten-Towns en Icewind Dale. Atrapar truchas de nudillos no es el comercio más glorioso en el Norte, pero es una vida honesta. Has entrenado tus sentidos para el menor tirón en la línea, sacado grandes truchas de lagos cubiertos de hielo.',
    'Knight of the Gauntlet': 'No todos los que responden al llamado de un poder superior están contentos con examinar las escrituras en un ápside de templo sofocante. Elegiste el camino del guerrero sagrado al unirte a la Orden del Guantelete. Como caballero del Guantelete, ejerces desdén recto por las fuerzas del mal.',
    'Lords\' Alliance Vassal': 'Has comprometido tu lealtad a una ciudad miembro de la Alianza de los Señores. Como agente de la Alianza, debes mantener los principios de la Alianza y buscar aumentar la seguridad y prosperidad a lo largo de la Costa de la Espada. Has jurado traer honor y gloria a la casa de tu señor.',
    'Moonwell Pilgrim': 'Como muchos que provienen de las Islas Moonshae, creciste reverenciendo la tierra bendita, sus dioses únicos, y los misteriosos santuarios llamados moonwells. Como peregrino de moonwell, emprendiste una búsqueda para visitar y comulgar con cada moonwell en (o fuera de) el mapa.',
    'Mulhorandi Tomb Raider': 'Creciste en una tierra de dioses-reyes vivientes, y cuando eras niño te contaron innumerables historias de imperios antiguos y ciudades enterradas. En estos cuentos, Mulhorand era una tierra desbordante de riquezas olvidadas, tesoros invaluables esperando a cualquiera lo suficientemente astuto y valiente para buscarlos.',
    'Mythalkeeper': 'Los mythals son fuentes de gran poder mágico que pueden alterar la Trama o incluso la propia naturaleza de la realidad. La mayoría fueron construidos en la antigüedad, y muchos han sido dañados o están inactivos. Como guardián de mythal de los Dalelands, tu primera experiencia con un mythal fue probablemente en las ruinas de Myth Drannor.',
    'Purple Dragon Squire': 'Has comprometido tu vida a la seguridad de Cormyr y buscaste admisión a la orden de guerreros de élite de ese reino: los Caballeros Dragón Púrpura. Pero antes de tener la oportunidad de unirte oficialmente a las filas, primero debes servir como escudero de un caballero.',
    'Rashemi Wanderer': 'Pasaste años vagando por las tierras altas de Rashemen, un páramo ventoso y peligroso salpicado de obeliscos antiguos encantados para aprisionar Demonios y hogar de dragones, gnolls y otras criaturas mortales. Las amistades son difíciles de encontrar en una tierra tan aislada.',
    'Shadowmasters Exile': 'Entrenaste toda tu vida para convertirte en miembro de los Amos de las Sombras, el misterioso gremio de ladrones que controla el reino de Thesk desde detrás de escena. El sigilo y los reflejos rápidos fueron solo el comienzo de tu educación como Amo de las Sombras. Pero un movimiento equivocado llevó a tu expulsión de la orden.',
    'Spellfire Initiate': 'Llevas el don del fuego de hechizo: una rara forma de magia que canaliza el poder crudo de la Trama. Manejar el fuego de hechizo tiene un gran costo para el cuerpo. Has entrenado tanto mente como cuerpo para manejar eficientemente este poder sagrado.',
    'Zhentarim Mercenary': 'Quizás necesitabas el dinero. Quizás anhelabas una familia, sin importar lo dudosa. O quizás simplemente eres bueno en terminar el trabajo por cualquier medio necesario. Sea cual sea tu razón, te alistaste con los Zhentarim, el gremio de mercenarios más notorio en los Reinos.'
  },
  
  // Class Descriptions (Spanish)
  classDescriptions: {
    'Barbarian': 'Un guerrero feroz de la civilización primitiva que puede entrar en una furia de batalla, desatando poderes primordiales y una resistencia sobrehumana al daño. Los bárbaros son combatientes cuerpo a cuerpo temibles que confían en su fuerza bruta e instintos.',
    'Bard': 'Un artista consumado que usa la música y la magia para tejer conjuros de inspiración y encantamiento. Los bardos son versátiles, capaces de sanar, atacar y apoyar a sus aliados con su magia arcana y su carisma irresistible.',
    'Cleric': 'Un sacerdote devoto que sirve a una deidad superior, canalizando poder divino para sanar a los heridos, proteger a los débiles y castigar a los enemigos de la fe. Los clérigos son la columna vertebral de cualquier grupo de aventureros.',
    'Druid': 'Un guardián de la naturaleza que puede transformarse en animales y manipular los elementos naturales. Los druidas protegen los bosques y la vida salvaje, equilibrando los ciclos de la naturaleza con su magia primitiva.',
    'Fighter': 'Un maestro del combate marcial, entrenado en una variedad de armas y armaduras. Los guerreros son combatientes versátiles que pueden servir como protectores, destructores o líderes tácticos en el campo de batalla.',
    'Monk': 'Un artista marcial que perfecciona su cuerpo y mente a través de la disciplina espiritual. Los monjes son combatientes ágiles que pueden realizar proezas físicas imposibles y canalizar energía mística llamada ki.',
    'Paladin': 'Un campeón sagrado vinculado a un juramento sagrado, que combina habilidad marcial con poder divino. Los paladines son defensores de la justicia y la virtud, capaces de sanar, proteger y destruir el mal con igual fervor.',
    'Ranger': 'Un explorador experto en supervivencia y combate en los terrenos salvajes. Los exploradores son cazadores y rastreadores que protegen la frontera entre la civilización y lo salvaje, usando tanto armas como magia natural.',
    'Rogue': 'Un especialista en sigilo, engaño y ataques precisos. Los pícaros son ágiles y letales, capaces de encontrar puntos débiles y esquivar el peligro con reflejos sobrenaturales. Sobresalen en el combate táctico y la exploración.',
    'Sorcerer': 'Un lanzador de conjuros nato que posee magia en su sangre. Los hechiceros no estudian magia, sino que la heredan de un linaje mágico o un evento sobrenatural, permitiéndoles manipular la magia de forma instintiva.',
    'Warlock': 'Un conjurador que ha forjado un pacto con un ser sobrenatural a cambio de poder arcano. Los brujos poseen magia única otorgada por sus patronos, combinando conjuros con habilidades misteriosas.',
    'Wizard': 'Un erudito arcano que ha dedicado años al estudio de la magia. Los magos son los lanzadores de conjuros más versátiles, capaces de aprender y preparar una amplia variedad de conjuros de su grimorio personal.',
    'Artificer': 'Un inventor maestro que combina magia e ingeniería para crear objetos mágicos y dispositivos. Los artífices son genios prácticos que infunden magia en sus creaciones, desde armas encantadas hasta constructos mecánicos.'
  },
  
  // Species Descriptions (Spanish)
  speciesDescriptions: {
    'Human': 'Los humanos son la especie más versátil y adaptable de todas. No poseen las habilidades especiales de otras razas, pero su capacidad para aprender cualquier oficio y su corta vida les da una ambición que otras razas no tienen. Son la raza más común y diversa.',
    'Elf': 'Los elfos son seres mágicos de gran longevidad que habitan en armonía con el mundo natural. Poseen gracia sobrenatural, sentidos agudizados y una conexión profunda con la magia. Su vida de siglos les da una perspectiva única del mundo.',
    'Dwarf': 'Los enanos son un pueblo robusto y resistente que habita en grandes ciudades subterráneas. Son maestros artesanos, especialmente en metal y piedra, y valoran el honor, la tradición y el clan por encima de todo. Son famosos por su resistencia y fuerza.',
    'Halfling': 'Los medianos son un pueblo pequeño y amable que valora la paz, el hogar y la familia. A pesar de su tamaño, poseen una suerte extraordinaria y una agilidad sorprendente. Prefieren evitar la aventura, pero cuando se ven envueltos en ella, demuestran un coraje inesperado.',
    'Gnome': 'Los gnomos son un pueblo pequeño conocido por su curiosidad insaciable y su ingenio brillante. Son inventores naturales, ilusionistas y amantes de la vida. Su energía entusiasta y su mente ágil les hacen excelentes en cualquier campo que requiera creatividad.',
    'Tiefling': 'Los tiflin son humanos con herencia infernal, marcados por la sangre de demonios o diablos en su linaje. A menudo son rechazados por su apariencia, pero poseen una resistencia innata al fuego y magia infernal. Muchos luchan contra los prejuicios con carisma y determinación.',
    'Dragonborn': 'Los nacidos del dragón son una raza orgullosa y noble que afirma descender de los dragones. Poseen aliento elemental y escamas resistentes, combinando el poder de los dragones con la forma humanoide. Valoran el honor y la gloria ancestral.',
    'Orc': 'Los orcos son un pueblo fuerte y feroz que valora la fuerza por encima de todo. A menudo incomprendidos como salvajes, poseen una cultura rica basada en la supervivencia y el honor tribal. Su fuerza y resistencia los hacen guerreros temibles.',
    'Aasimar': 'Los asimares son mortales con herencia celestial, marcados por la luz divina en su sangre. A menudo son guías de bondad y justicia, aunque algunos pueden caer en la oscuridad. Poseen resistencia a la energía radiante y habilidades curativas.',
    'Goliath': 'Los goliaths son gigantes musculosos que habitan en las cimas de las montañas más altas. Son competitivos por naturaleza y valoran la fuerza, la resistencia y la habilidad. Su cultura se basa en la supervivencia en los ambientes más hostiles.',
    // Expansion Species - Astarion's Book of Hungers
    'Dhampir': 'Los dhampirs son personas vivas que poseen destreza vampírica pero están malditas con un hambre macabra. La mayoría de los dhampirs seducen sangre, pero algunos obtienen sustento de sueños, energía vital u otras fuentes vitales. Los dhampirs deben elegir si luchar por controlar su hambre o ceder a los impulsos depredadores. A menudo surgen de encuentros con vampiros; algunos son descendientes de un vampiro poderoso, mientras que otros fueron transformados parcialmente por la mordedura de un vampiro.',
    // Expansion Species - Forge of the Artificer (Eberron)
    'Changeling': 'Con apariencias siempre cambiantes, los changelings residen en muchas sociedades sin ser detectados. Cada changeling puede adoptar sobrenaturalmente cualquier rostro que desee. Para algunos changelings, un nuevo rostro puede revelar un aspecto de su alma. Los primeros changelings en el multiverso aparecieron en el Feérico, y la esencia maravillosa y mutable de ese plano perdura en los changelings hoy.',
    'Kalashtar': 'Los kalashtar son creados de la unión de la humanidad y espíritus renegados llamados quori del plano de los sueños. Los kalashtar parecen humanos, pero su conexión espiritual los afecta de diversas maneras. Tienen rasgos simétricos y ligeramente angulares, y sus ojos a menudo brillan cuando se concentran o expresan emociones fuertes.',
    'Khoravar': 'A lo largo de siglos, aquellos descendientes de humanos y elfos han desarrollado sus propias comunidades y tradiciones en Khorvaire. El ascenso de la Casa Lyrandar y la Casa Medani ha fortalecido esta identidad. Los miembros de estas comunidades se llaman a sí mismos Khoravar, un término élfico que significa "hijos de Khorvaire", ya que no les gusta el término "semi-elfo".',
    'Shifter': 'Los shifters, a veces llamados "tocados por hombres lobo", descienden de personas que contrajeron licantropía completa o parcial. Humanoides con un aspecto bestial, los shifters no pueden cambiar de forma completamente, pero pueden mejorar sus características animales temporalmente en un proceso que llaman "cambio".',
    'Warforged': 'Los warforged son seres mecánicos construidos como armas para luchar en la Última Guerra. Un avance inesperado produjo seres sensibles hechos de madera y metal que sin embargo pueden sentir dolor y emoción. Los warforged comprenden una mezcla de materiales orgánicos e inorgánicos. Cuerdas similares a raíces infundidas con fluidos alquímicos sirven como sus músculos, envueltos alrededor de un marco de acero, madera oscura o piedra.'
  },
  
  // Feat Descriptions (Spanish) - abbreviated for common ones
  featDescriptions: {
    'Alert': 'Siempre estás atento a las amenazas. Ganas +5 a la iniciativa, no puedes ser sorprendido mientras estés consciente, y otras criaturas no ganan ventaja en sus ataques contra ti por estar ocultas.',
    'Athlete': 'Has entrenado tu cuerpo para realizar hazañas atléticas increíbles. Puedes trepar a tu velocidad de movimiento, levantarte más rápido, y mejorar tu Fuerza o Destreza.',
    'Charger': 'Eres un guerrero de embestida. Cuando corres al menos 3 metros hacia un enemigo, puedes realizar un ataque poderoso o empujarlo con fuerza.',
    'Crossbow Expert': 'Eres un experto en el uso de ballestas. Puedes ignorar la propiedad de carga, usar ballestas a corta distancia sin desventaja, y disparar como ataque adicional.',
    'Defensive Duelist': 'Eres experto en esgrima defensiva. Cuando un enemigo te ataca con un arma cuerpo a cuerpo, puedes usar tu reacción para añadir tu bonificador de Destreza a tu CA.',
    'Dual Wielder': 'Eres maestro en el combate con dos armas. Puedes usar armas de dos manos, +1 a CA, y puedes desenvainar dos armas a la vez.',
    'Dungeon Delver': 'Alerta a los peligros de las mazmorras. Ventaja en pruebas para detectar trampas y puertas secretas, resistencia a daños de trampas, y evitación de desventaja.',
    'Durable': 'Tu constitución es robusta. Mejoras tu Constitución y cuando usas dados de vida para recuperar puntos de golpe, recuperas el doble de tu modificador de Constitución como mínimo.',
    'Elemental Adept': 'Los conjuros que usas ignoran la resistencia a un tipo de daño elemental de tu elección. Los dados de daño no pueden ser 1.',
    'Grappler': 'Especialista en combate cuerpo a cuerpo. Ventaja en ataques contra criaturas agarradas, puedes inmovilizarlas, y no sufres desventaja por atacar a criaturas agarradas.',
    'Great Weapon Master': 'Eres un maestro del combate con armas grandes. Puedes realizar ataques adicionales cuando derrotas a enemigos o con críticos, y sacrificas precisión por poder.',
    'Healer': 'Conoces medicina práctica. Puedes usar un kit de sanador para restaurar puntos de golpe y estabilizar moribundos sin conjuros.',
    'Heavily Armored': 'Entrenado en armadura pesada. Mejoras tu Fuerza y ganas competencia con armaduras pesadas.',
    'Heavy Armor Master': 'Maestro de la armadura pesada. Mejoras Fuerza y reduces el daño no mágico de armas en 3.',
    'Inspiring Leader': 'Líder que inspira. Puedes pasar 10 minutos inspirando a criaturas para darles puntos de golpe temporales igual a tu nivel + tu modificador de Carisma.',
    'Keen Mind': 'Mente aguda. Mejoras Inteligencia, recuerdas todo lo que has visto o escuchado en el último mes, y siempre conoces el norte.',
    'Lightly Armored': 'Entrenado en armadura ligera. Mejoras Fuerza o Destreza y ganas competencia con armaduras ligeras.',
    'Linguist': 'Erudito en idiomas. Mejoras Inteligencia, aprendes 3 idiomas, y puedes crear cifrados que solo tú y tus aliados pueden leer.',
    'Lucky': 'Increíblemente afortunado. Tienes 3 puntos de suerte para repetir tiradas de ataque, pruebas o salvaciones.',
    'Mage Slayer': 'Cazador de magos. Ventaja en salvaciones contra conjuros, puedes reaccionar cuando te lanzan conjuros, y tus ataques interrumpen la concentración.',
    'Magic Initiate': 'Iniciado en la magia. Aprendes dos trucos y un hechizo de nivel 1 de una clase de tu elección.',
    'Martial Adept': 'Adepto en las artes marciales. Aprendes dos maniobras de combate y ganas un dado de superioridad.',
    'Medium Armor Master': 'Maestro de armadura media. Mejoras Destreza, la bonificación máxima de Destreza aumenta a 3, y no tienes desventaja en Sigilo.',
    'Mobile': 'Ágil y rápido. Mejoras tu velocidad en 3 metros, el terreno difícil no te ralentiza, y puedes alejarte de enemigos sin provocar ataques de oportunidad.',
    'Moderately Armored': 'Entrenado en armadura media. Mejoras Fuerza o Destreza y ganas competencia con armaduras medias y escudos.',
    'Mounted Combatant': 'Jinete experto. Ventaja en ataques contra criaturas desmontadas, puedes redirigir ataques hacia ti, y evitas ataques con éxitos si tu montura falla la salvación.',
    'Observant': 'Observador agudo. Mejoras Inteligencia o Sabiduría, +5 a Pasiva Percepción e Investigación, y puedes leer los labios.',
    'Polearm Master': 'Maestro de armas de asta. Puedes realizar ataques adicionales con el extremo del arma y reaccionar cuando enemigos entran en tu alcance.',
    'Resilient': 'Resistente. Mejoras una puntuación de característica y ganas competencia en salvaciones de esa característica.',
    'Ritual Caster': 'Conjurador de rituales. Puedes lanzar conjuros rituales de una clase, aprendiendo nuevos de pergaminos.',
    'Savage Attacker': 'Atacante salvaje. Una vez por turno puedes repetir el daño de un ataque cuerpo a cuerpo y usar el resultado más alto.',
    'Sentinel': 'Guardián alerta. Reduces la velocidad a 0 con ataques de oportunidad, puedes atacar como reacción cuando enemigos atacan a aliados, y reaccionas cuando enemigos se alejan.',
    'Sharpshooter': 'Tirador preciso. Ignoras penalizaciones por alcance largo y coberturas, y puedes sacrificar precisión por daño adicional.',
    'Shield Master': 'Maestro del escudo. Bonificación en acción para empujar o tirar, puedes agregar la CA del escudo a salvaciones de Dex contra conjuros, y no sufres daño si fallas la salvación.',
    'Skilled': 'Habilidoso. Ganas competencia en 3 habilidades o herramientas de tu elección.',
    'Skulker': 'Acechador de las sombras. Mejoras Destreza, puedes ocultarte cuando estás ligeramente oscurecido, y fallar ataques a distancia no revela tu posición.',
    'Spell Sniper': 'Francotirador arcano. Duplicas el alcance de conjuros de ataque, ignoras coberturas, y aprendes un truco ofensivo.',
    'Tavern Brawler': 'Peleador de taberna. Mejoras Fuerza o Constitución, eres competente en combate desarmado, y puedes usar tu acción adicional para agarrar tras un golpe.',
    'Tough': 'Resistente. Aumentos tus puntos de golpe máximos en 2 por cada nivel.',
    'War Caster': 'Conjurador de guerra. Ventaja en salvaciones de Concentración, puedes usar componentes somáticos con armas, y puedes lanzar conjuros como ataque de oportunidad.',
    'Weapon Master': 'Maestro de armas. Mejoras Fuerza o Destreza y ganas competencia con cuatro armas de tu elección.',
    // Expansion Feats - Astarion's Book of Hungers
    'Tireless Reveler': 'Cuando un aliado que puedes ver dentro de 18 metros de ti gasta Inspiración Heroica, puedes ganar Inspiración Heroica si careces de ella. Puedes usar este beneficio un número de veces igual a tu Bonificador de Competencia, y recuperas todos los usos gastados cuando terminas un Descanso Corto o Largo.',
    'Vampire Hunter': 'Ganas los siguientes beneficios: Escape Adreto: Tienes Ventaja en pruebas para escapar de ataduras no mágicas o la condición Agarrado. Resguardo de Vitalidad: Cuando recibes daño Necrótico, puedes usar una Reacción para mitigar el daño. Tira un número de d6 igual a tu Bonificador de Competencia y réstalos del daño.',
    'Vampire\'s Plaything': 'Ganas los siguientes beneficios: Decantación: Cuando terminas un Descanso Largo, puedes crear una Poción de Curación o un Antídoto, si tienes un vial o frasco vacío. Retirada Oportuna: Puedes usar una Acción Adicional para tomar la acción de Carrera o Desenganche.',
    'Bloodlust': 'Aumento de Puntuación de Característica: Aumenta tu Fuerza, Destreza o Constitución en 1. Recuperación Poderosa: Cuando tiras un Dado de Puntos de Golpe para recuperar Puntos de Golpe, puedes tratar cualquier tirada de 1 o 2 como un 3. Festín Sanguíneo: Una vez por turno cuando golpeas una criatura Sangrada que no es Constructo o No Muerto, puedes gastar un Dado de Puntos de Golpe para recuperar Puntos de Golpe.',
    'Bomber': 'Aumento de Puntuación de Característica: Aumenta tu Destreza en 1. Lanzador Lejano: Cuando usas la acción de Ataque para lanzar un vial o frasco, puedes apuntar a un objeto o criatura dentro de 12 metros. Tiros Largos: Atacar a largo alcance no impone Desventaja en tus tiradas de ataque con armas Arrojadizas.',
    'Cloying Mists': 'Aumento de Puntuación de Característica: Aumenta tu Inteligencia, Sabiduría o Carisma en 1. Siempre tienes el conjuro Nube de Niebla preparado. Puedes lanzarlo sin ranura de hechizo una vez por Descanso Largo.',
    'Delicious Pain': 'Aumento de Puntuación de Característica: Aumenta una puntuación de característica a tu elección en 1. Carne Endurecida: Inmediatamente después de recibir daño Contundente, Perforante o Cortante, puedes usar una Reacción para ganar Resistencia a esos daños hasta el inicio de tu siguiente turno.',
    'Light Bringer': 'Aumento de Puntuación de Característica: Aumenta tu Inteligencia, Sabiduría o Carisma en 1. Magia Sagrada: Aprendes el conjuro Luz. Luminosidad Solar: Cuando lanzas Luz, puedes hacer que la luz del conjuro sea luz solar.',
    'Love Bites': 'Aumento de Puntuación de Característica: Aumenta una puntuación de característica a tu elección en 1. Dolor Cautivador: Inmediatamente después de dañar a una criatura con un arma cuerpo a cuerpo, puedes usar una Acción Adicional para darle la condición Encantado hasta el inicio de tu siguiente turno.',
    'Putrefy': 'Aumento de Puntuación de Característica: Aumenta una puntuación de característica a tu elección en 1. Necrosis: Cuando haces una tirada de daño que inflige daño Necrótico, puedes hacer que una criatura tenga la condición Envenenado hasta el inicio de tu siguiente turno.',
    'Rebuke': 'Aumento de Puntuación de Característica: Aumenta una puntuación de característica a tu elección en 1. Golpe Radiante: Cuando haces una tirada de daño que inflige daño Radiante, puedes hacer que una criatura Grande o menor tenga la condición Derribado.',
    'Treacherous Allure': 'Aumento de Puntuación de Característica: Aumenta tu Inteligencia, Sabiduría o Carisma en 1. Presencia Encantadora: Siempre tienes el conjuro Encantar Persona preparado. Traición Inevitable: Tienes Ventaja en tiradas de ataque contra criaturas con la condición Encantado.',
    'Vampire Touched': 'Aumento de Puntuación de Característica: Aumenta tu Inteligencia, Sabiduría o Carisma en 1. Magia Vampírica: Elige un hechizo de nivel 1 de la escuela de Encantamiento o Ilusión. Siempre tienes ese hechizo y el conjuro Trepar como Araña preparados.',
    'Boon of Blazing Dawn': 'Aumento de Puntuación de Característica: Aumenta una puntuación de característica a tu elección en 1. Amado del Sol: Tienes Inmunidad al daño Radiante. Golpe Ardiente: Cuando golpeas a una criatura con un ataque de arma, el daño puede ser Radiante o del tipo normal del arma.',
    'Boon of Looming Shadows': 'Aumento de Puntuación de Característica: Aumenta una puntuación de característica a tu elección en 1. Estiramiento Sombrío: Cuando tomas la acción de Ataque, tu alcance para ataques cuerpo a cuerpo aumenta en 3 metros hasta el final de tu turno. Silueta Danzante: Puedes tomar la acción de Esquivar como Acción Adicional.',
    'Boon of Misty Escape': 'Aumento de Puntuación de Característica: Aumenta tu Inteligencia, Sabiduría o Carisma en 1. Forma Gaseosa: Si bajas a 0 Puntos de Golpe pero no mueres, puedes en cambio bajar a 1 Punto de Golpe y lanzar Forma Gaseosa sin gastar ranura de hechizo.',
    // Expansion Feats - Forge of the Artificer (Dragonmarks)
    'Aberrant Dragonmark': 'Fortaleza Aberrante: Cuando fallas una salvación de Constitución, puedes usar una Reacción para tirar 1d4 y añadirlo a la salvación. Magia Aberrante: Conoces un truco de la lista de Hechicero y un hechizo de nivel 1. Oleada Aberrante: Cuando lanzas el hechizo de nivel 1, puedes gastar un Dado de Puntos de Golpe para ganar Puntos de Golpe Temporales o infligir daño de Fuerza.',
    'Mark of Detection': 'Intuición Deductiva: Cuando haces una prueba de Investigación o Perspicacia, puedes tirar 1d4 y añadirlo. Detección Mágica: Siempre tienes Detectar Magia y Detectar Veneno y Enfermedad preparados. Al nivel 3, también tienes Ver Invisibilidad preparado.',
    'Mark of Finding': 'Intuición del Cazador: Cuando haces una prueba de Percepción o Supervivencia, puedes tirar 1d4 y añadirlo. Magia del Buscador: Siempre tienes Marca del Cazador preparado. Al nivel 3, también tienes Localizar Objeto preparado.',
    'Mark of Handling': 'Intuición Salvaje: Cuando haces una prueba de Naturaleza o Trato con Animales, puedes tirar 1d4 y añadirlo. Conexión Primitiva: Siempre tienes Amistad Animal y Hablar con Animales preparados. Conexiones Monstruosas: Al nivel 3, puedes afectar Monstruosidades con estos conjuros.',
    'Mark of Healing': 'Intuición Médica: Cuando haces una prueba de Medicina o usando un Kit de Herboristería, puedes tirar 1d4 y añadirlo. Toque Curativo: Siempre tienes Curar Heridas preparado. Al nivel 3, también tienes Restauración Menor preparado.',
    'Mark of Hospitality': 'Siempre Hospitalario: Cuando haces una prueba de Persuasión o usando Utensilios de Cocina, puedes tirar 1d4 y añadirlo. Magia de Posadero: Siempre tienes Purificar Comida y Bebida y Sirviente Invisible preparados. Al nivel 3, también tienes Calmar Emociones preparado.',
    'Mark of Making': 'Intuición Artesana: Cuando haces una prueba de Arcana o usando Herramientas de Artesano, puedes tirar 1d4 y añadirlo. Herrero de Conjuros: Conoces el truco Reparar. Siempre tienes Arma Mágica preparado.',
    'Mark of Passage': 'Velocidad de Mensajero: Tu Velocidad aumenta en 1.5 metros. Movimiento Intuitivo: Cuando haces una prueba de Atletismo o Acrobacias, puedes tirar 1d4 y añadirlo. Pasaje Mágico: Siempre tienes Paso Brumoso preparado.',
    'Mark of Scribing': 'Escriba Dotado: Cuando haces una prueba de Historia o usando Utensilios de Calígrafo, puedes tirar 1d4 y añadirlo. Perspicacia del Escriba: Conoces el truco Mensaje. Siempre tienes Comprender Idiomas preparado. Al nivel 3, también tienes Boca Mágica preparado.',
    'Mark of Sentinel': 'Intuición del Centinela: Cuando haces una prueba de Perspicacia o Percepción, puedes tirar 1d4 y añadirlo. Escudo del Guardián: Siempre tienes Escudo preparado. Guardián Vigilante: Puedes intercambiar lugares con una criatura dentro de 1.5 metros cuando es atacada.',
    'Mark of Shadow': 'Intuición Astuta: Cuando haces una prueba de Sigilo o Interpretación, puedes tirar 1d4 y añadirlo. Formar Sombras: Conoces el truco Ilusión Menor. Siempre tienes Invisibilidad preparado.',
    'Mark of Storm': 'Intuición del Navegante: Cuando haces una prueba de Acrobacias o usando Herramientas de Navegante, puedes tirar 1d4 y añadirlo. Bendición de la Tormenta: Tienes Resistencia al daño de Rayo. Magia de Tormenta: Conoces el truco Estruendo. Al nivel 3, también tienes Viento de Vendaval preparado.',
    'Mark of Warding': 'Intuición del Guardián: Cuando haces una prueba de Investigación o usando Herramientas de Ladrón, puedes tirar 1d4 y añadirlo. Guardas y Sellos: Siempre tienes Alarma y Armadura de Mago preparados. Al nivel 3, también tienes Cierre Arcano preparado.',
    // Expansion Feats - Forgotten Realms Heroes of Faerun
    'Cult of the Dragon Initiate': 'Lengua de Dragón: Conoces Dracónico. Terror de Dragón: Puedes usar una acción mágica para infundir terror en una criatura dentro de 9 metros. Inspirado por el Miedo: Cuando causas que una criatura tenga la condición Asustado y eres la fuente de su miedo, puedes ganar Inspiración Heroica.',
    'Emerald Enclave Fledgling': 'Hablar con Animales: Siempre tienes el conjuro Hablar con Animales preparado. Equipo Etiquetado: Cuando tomas la acción de Ayudar, puedes intercambiar lugares con un aliado dentro de 1.5 metros.',
    'Harper Agent': 'Jerga de Ladrones: Conoces la Jerga de Ladrones. Entrenamiento con Instrumentos: Ganas competencia con un Instrumento Musical. Melodía Distractora: Cuando tomas la acción de Ayudar para asistir la tirada de ataque de un aliado, el enemigo puede estar hasta a 9 metros de ti.',
    'Lords\' Alliance Agent': 'Golpe Inspirador: Una vez por turno cuando logras un Golpe Crítico, puedes elegir un aliado dentro de 9 metros que carezca de Inspiración Heroica para que la gane. Reafirmar Honor: Cuando un enemigo daña a un aliado tuyo dentro de 1.5 metros, tienes Ventaja en tu siguiente tirada de ataque contra ese enemigo.',
    'Spellfire Spark': 'Chispa de Fuego de Hechizo: Cuando lanzas un conjuro de nivel 1+, puedes curarte o dañar a una criatura. Dado de Fuego de Hechizo: Cuando lanzas un conjuro con una ranura de hechizo, puedes tirar un Dado de Puntos de Golpe igual al nivel de la ranura para añadir al daño o curación.',
    'Tyro of the Gauntlet': 'Golpe Sagrado: Una vez por turno cuando logras un Golpe Crítico, puedes elegir un aliado dentro de 9 metros para que gane Inspiración Heroica si carece de ella. Escudo de Fe: Como Acción Adicional, puedes darte a ti mismo o a una criatura dentro de 18 metros +2 a CA durante 1 minuto.',
    'Purple Dragon Rook': 'Devoción Púrpura: Como Acción Adicional, puedes ganarte Ventaja en la próxima tirada de ataque, prueba de característica o salvación. Resolución de Cormyr: Cuando fallas una salvación, puedes ganar Inspiración Heroica.',
    'Zhentarim Ruffian': 'Intimidación de Zhentarim: Cuando usas la acción de Ayudar para asistir una prueba de Intimidación, el aliado tiene Ventaja en esa prueba. Enviado de las Sombras: Conoces la Jerga de Ladrones.'
  },
  
  // Condition Descriptions (Spanish)
  conditionDescriptions: {
    'Blinded': 'No puedes ver. Fallas automáticamente en pruebas que requieran vista, los atacantes tienen ventaja contra ti, y tú tienes desventaja en tus ataques.',
    'Charmed': 'No puedes atacar al encantador ni afectarlo con habilidades hostiles. El encantador tiene ventaja en habilidades sociales contra ti.',
    'Deafened': 'No puedes oír. Fallas automáticamente en pruebas que requieran oído.',
    'Exhaustion': 'Acumulas niveles de agotamiento con efectos progresivos: desventaja en pruebas, velocidad reducida, desventaja en ataques y salvaciones, puntos de golpe máximos reducidos, velocidad 0, y finalmente la muerte.',
    'Frightened': 'Tienes desventaja en pruebas de característica y ataques mientras la fuente de tu miedo esté en tu línea de visión. No puedes acercarte voluntariamente a ella.',
    'Grappled': 'Tu velocidad se vuelve 0 y no puedes beneficiarte de bonificaciones a la velocidad. La condición termina si el que te agarra queda incapacitado o si te alejas más de su alcance.',
    'Incapacitated': 'No puedes realizar acciones ni reacciones.',
    'Invisible': 'No puedes ser visto. Tienes ventaja en ataques y los atacantes tienen desventaja contra ti.',
    'Paralyzed': 'Estás incapacitado y no puedes moverte ni hablar. Fallas automáticamente salvaciones de Fuerza y Destreza. Los ataques contra ti tienen ventaja y son críticos si están a 1,5 metros.',
    'Petrified': 'Estás transformado en sustancia inerte junto con tus objetos. Estás incapacitado, no consciente del entorno, y fallas salvaciones de Fuerza y Destreza. Tienes resistencia a todo daño e inmunidad a enfermedades y venenos.',
    'Poisoned': 'Tienes desventaja en ataques y pruebas de característica mientras estés envenenado.',
    'Prone': 'Estás tumbado en el suelo. Tu único movimiento es arrastrarte. Tienes desventaja en ataques y los ataques cuerpo a cuerpo contra ti tienen ventaja, pero los ataques a distancia tienen desventaja si estás a más de 1,5 metros.',
    'Restrained': 'Tu velocidad se vuelve 0 y no puede aumentarse. Tienes desventaja en ataques y salvaciones de Destreza. Los ataques contra ti tienen ventaja y tú tienes desventaja.',
    'Stunned': 'Estás incapacitado, no puedes moverte, y puedes hablar solo con dificultad. Fallas automáticamente salvaciones de Fuerza y Destreza. Los ataques contra ti tienen ventaja.',
    'Unconscious': 'Estás incapacitado, no puedes moverte ni hablar, y no consciente del entorno. Fallas automáticamente salvaciones de Fuerza y Destreza. Los ataques contra ti tienen ventaja y son críticos si están a 1,5 metros.'
  },
  
  // Size translations
  sizeTranslations: {
    'Tiny': 'Diminuto',
    'Small': 'Pequeño',
    'Medium': 'Mediano',
    'Large': 'Grande',
    'Huge': 'Enorme',
    'Gargantuan': 'Gigantesco'
  },
  
  // Ability translations
  abilityTranslations: {
    'Strength': 'Fuerza',
    'Dexterity': 'Destreza',
    'Constitution': 'Constitución',
    'Intelligence': 'Inteligencia',
    'Wisdom': 'Sabiduría',
    'Charisma': 'Carisma'
  }
};
