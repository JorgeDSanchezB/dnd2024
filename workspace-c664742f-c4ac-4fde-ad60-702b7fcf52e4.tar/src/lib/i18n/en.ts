export const translations = {
  // Navigation
  create: 'Create',
  characters: 'Characters',
  sheet: 'Sheet',
  
  // Character Creation
  characterCreation: 'Character Creation',
  step: 'Step',
  of: 'of',
  next: 'Next',
  previous: 'Previous',
  cancel: 'Cancel',
  save: 'Save',
  delete: 'Delete',
  edit: 'Edit',
  createCharacter: 'Create Character',
  
  // Step 1 - Basics
  basics: 'Basics',
  characterName: 'Character Name',
  enterName: 'Enter character name',
  startingLevel: 'Starting Level',
  selectLevel: 'Select starting level',
  
  // Step 2 - Species
  selectSpecies: 'Select Species',
  species: 'Species',
  chooseSpecies: 'Choose your character\'s species',
  size: 'Size',
  speed: 'Speed',
  traits: 'Traits',
  
  // Step 3 - Class
  selectClass: 'Select Class',
  class: 'Class',
  chooseClass: 'Choose your character\'s class',
  primaryAbility: 'Primary Ability',
  hitDie: 'Hit Die',
  savingThrows: 'Saving Throws',
  skillProficiencies: 'Skill Proficiencies',
  armorTraining: 'Armor Training',
  weaponProficiencies: 'Weapon Proficiencies',
  startingEquipment: 'Starting Equipment',
  features: 'Features',
  spellcasting: 'Spellcasting',
  subclasses: 'Subclasses',
  
  // Step 4 - Background
  selectBackground: 'Select Background',
  background: 'Background',
  chooseBackground: 'Choose your character\'s background',
  feat: 'Feat',
  toolProficiency: 'Tool Proficiency',
  equipment: 'Equipment',
  
  // Step 5 - Details
  details: 'Details',
  alignment: 'Alignment',
  selectAlignment: 'Select alignment',
  appearance: 'Appearance',
  describeAppearance: 'Describe your character\'s physical appearance',
  history: 'History',
  describeHistory: 'Describe your character\'s backstory and personality',
  
  // Alignments
  lawfulGood: 'Lawful Good',
  neutralGood: 'Neutral Good',
  chaoticGood: 'Chaotic Good',
  lawfulNeutral: 'Lawful Neutral',
  neutral: 'Neutral',
  chaoticNeutral: 'Chaotic Neutral',
  lawfulEvil: 'Lawful Evil',
  neutralEvil: 'Neutral Evil',
  chaoticEvil: 'Chaotic Evil',
  
  // Character Sheet
  characterSheet: 'Character Sheet',
  level: 'Level',
  xp: 'XP',
  levelUp: 'Level Up',
  shop: 'Shop',
  spellbook: 'Spellbook',
  exportPDF: 'Export PDF',
  
  // Ability Scores
  abilityScores: 'Ability Scores',
  strength: 'Strength',
  dexterity: 'Dexterity',
  constitution: 'Constitution',
  intelligence: 'Intelligence',
  wisdom: 'Wisdom',
  charisma: 'Charisma',
  str: 'STR',
  dex: 'DEX',
  con: 'CON',
  int: 'INT',
  wis: 'WIS',
  cha: 'CHA',
  
  // Combat
  combat: 'Combat',
  hitPoints: 'Hit Points',
  current: 'Current',
  max: 'Max',
  temp: 'Temp',
  armorClass: 'Armor Class',
  initiative: 'Initiative',
  proficiencyBonus: 'Proficiency Bonus',
  hitDice: 'Hit Dice',
  deathSaves: 'Death Saves',
  successes: 'Successes',
  failures: 'Failures',
  
  // Skills
  skills: 'Skills',
  proficient: 'Proficient',
  expertise: 'Expertise',
  acrobatics: 'Acrobatics',
  animalHandling: 'Animal Handling',
  arcana: 'Arcana',
  athletics: 'Athletics',
  deception: 'Deception',
  history: 'History',
  insight: 'Insight',
  intimidation: 'Intimidation',
  investigation: 'Investigation',
  medicine: 'Medicine',
  nature: 'Nature',
  perception: 'Perception',
  performance: 'Performance',
  persuasion: 'Persuasion',
  religion: 'Religion',
  sleightOfHand: 'Sleight of Hand',
  stealth: 'Stealth',
  survival: 'Survival',
  
  // Saving Throws
  savingThrowsTitle: 'Saving Throws',
  
  // Money
  money: 'Money',
  copper: 'CP',
  silver: 'SP',
  electrum: 'EP',
  gold: 'GP',
  platinum: 'PP',
  
  // Proficiencies
  proficiencies: 'Proficiencies',
  languages: 'Languages',
  tools: 'Tools',
  armor: 'Armor',
  weapons: 'Weapons',
  
  // Inventory
  inventory: 'Inventory',
  item: 'Item',
  quantity: 'Quantity',
  equipped: 'Equipped',
  attuned: 'Attuned',
  weight: 'Weight',
  cost: 'Cost',
  damage: 'Damage',
  damageType: 'Damage Type',
  properties: 'Properties',
  rarity: 'Rarity',
  type: 'Type',
  
  // Damage Types
  acid: 'Acid',
  bludgeoning: 'Bludgeoning',
  cold: 'Cold',
  fire: 'Fire',
  force: 'Force',
  lightning: 'Lightning',
  necrotic: 'Necrotic',
  piercing: 'Piercing',
  poison: 'Poison',
  psychic: 'Psychic',
  radiant: 'Radiant',
  slashing: 'Slashing',
  thunder: 'Thunder',
  
  // Spells
  spells: 'Spells',
  cantrips: 'Cantrips',
  level1: '1st Level',
  level2: '2nd Level',
  level3: '3rd Level',
  level4: '4th Level',
  level5: '5th Level',
  level6: '6th Level',
  level7: '7th Level',
  level8: '8th Level',
  level9: '9th Level',
  castingTime: 'Casting Time',
  range: 'Range',
  components: 'Components',
  duration: 'Duration',
  concentration: 'Concentration',
  ritual: 'Ritual',
  prepared: 'Prepared',
  known: 'Known',
  spellcastingAbility: 'Spellcasting Ability',
  spellSaveDC: 'Spell Save DC',
  spellAttackBonus: 'Spell Attack Bonus',
  addSpell: 'Add Spell',
  removeSpell: 'Remove Spell',
  
  // Spell Schools
  abjuration: 'Abjuration',
  conjuration: 'Conjuration',
  divination: 'Divination',
  enchantment: 'Enchantment',
  evocation: 'Evocation',
  illusion: 'Illusion',
  necromancy: 'Necromancy',
  transmutation: 'Transmutation',
  
  // Feats
  feats: 'Feats',
  addFeat: 'Add Feat',
  removeFeat: 'Remove Feat',
  category: 'Category',
  prerequisite: 'Prerequisite',
  benefit: 'Benefit',
  repeatable: 'Repeatable',
  
  // Class Features
  classFeatures: 'Class Features',
  speciesTraits: 'Species Traits',
  subclassFeatures: 'Subclass Features',
  
  // Character Details
  characterDetails: 'Character Details',
  personalityTraits: 'Personality Traits',
  ideals: 'Ideals',
  bonds: 'Bonds',
  flaws: 'Flaws',
  backstory: 'Backstory',
  
  // Shop
  buy: 'Buy',
  sell: 'Sell',
  price: 'Price',
  shopWeapons: 'Weapons',
  shopArmor: 'Armor',
  shopItems: 'Items',
  shopMagic: 'Magic Items',
  
  // Actions
  roll: 'Roll',
  attack: 'Attack',
  cast: 'Cast',
  use: 'Use',
  copy: 'Copy',
  duplicate: 'Duplicate',
  
  // Messages
  selectCharacterToView: 'Select a character to view its sheet.',
  viewCharacters: 'View Characters',
  noCharactersYet: 'No characters yet. Create your first character!',
  characterCreated: 'Character created successfully!',
  characterUpdated: 'Character updated successfully!',
  characterDeleted: 'Character deleted successfully!',
  confirmDelete: 'Are you sure you want to delete this character?',
  
  // Level Up
  levelUpAvailable: 'Level Up Available!',
  chooseASIOrFeat: 'Choose Ability Score Improvement or Feat',
  abilityScoreImprovement: 'Ability Score Improvement',
  selectFeat: 'Select Feat',
  newLevel: 'New Level',
  
  // Multiclass
  multiclass: 'Multiclass',
  newClass: 'New Class',
  
  // Misc
  name: 'Name',
  description: 'Description',
  notes: 'Notes',
  addNote: 'Add Note',
  editNote: 'Edit Note',
  noteTitle: 'Title',
  noteContent: 'Content',
  pinned: 'Pinned',
  
  // Sizes
  tiny: 'Tiny',
  small: 'Small',
  medium: 'Medium',
  large: 'Large',
  huge: 'Huge',
  gargantuan: 'Gargantuan',
  
  // Rarity
  common: 'Common',
  uncommon: 'Uncommon',
  rare: 'Rare',
  veryRare: 'Very Rare',
  legendary: 'Legendary',
  artifact: 'Artifact',
  
  // PDF Export
  characterSheetPDF: 'Character Sheet',
  allRightsReserved: 'All rights reserved',
  
  // Search and Filter
  search: 'Search',
  filter: 'Filter',
  all: 'All',
  none: 'None',
  
  // Encyclopedias
  monsters: 'Monsters',
  rules: 'Rules',
  
  // Summary
  summary: 'Summary',
  summaryCharacter: 'Character Summary',
  
  // Error/Success
  error: 'Error',
  success: 'Success',
  loading: 'Loading...',
  noData: 'No data available',
  
  // Toggle Language
  language: 'Language',
  spanish: 'Spanish',
  english: 'English',
  
  // Armor Properties
  light: 'Light',
  medium: 'Medium',
  heavy: 'Heavy',
  shield: 'Shield',
  stealthDisadvantage: 'Stealth Disadvantage',
  dexBonus: 'DEX Bonus',
  maxDexBonus: 'Max DEX Bonus',
  strRequired: 'STR Required',
  
  // Weapon Properties
  simple: 'Simple',
  martial: 'Martial',
  melee: 'Melee',
  ranged: 'Ranged',
  twoHanded: 'Two-Handed',
  versatile: 'Versatile',
  finesse: 'Finesse',
  reach: 'Reach',
  thrown: 'Thrown',
  ammunition: 'Ammunition',
  loadingWeapon: 'Loading',
  heavyWeapon: 'Heavy',
  lightWeapon: 'Light',
  lance: 'Lance',
  net: 'Net',
  pike: 'Pike',
  
  // Mastery
  mastery: 'Mastery',
  
  // Attunement
  attunement: 'Attunement',
  requiresAttunement: 'Requires Attunement',
  attunementRequirements: 'Attunement Requirements',
};
