'use client'

import { useState, useEffect, useCallback, useRef } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { ScrollArea } from '@/components/ui/scroll-area'
import { Separator } from '@/components/ui/separator'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Switch } from '@/components/ui/switch'
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover'
import {
  Dices, User, Sword, Shield, Scroll, Sparkles, Save, Plus, Trash2, Edit,
  ChevronRight, ChevronLeft, Eye, Heart, Brain, Zap, Users, BookOpen,
  ArrowUpCircle, Package, Wand2, AlertCircle, Check, Info, RefreshCw,
  Star, Flame, Wind, Droplet, Sun, Moon, Skull, Globe, Lock, Unlock,
  Footprints, Move, Eye as EyeIcon, Ear, Hand, TreePine, Cat, Bird,
  Fish, Bug, Ghost, Crown, ShieldQuestion, Sparkle, FlameKindling, CircleDot,
  Zap as Lightning, Snowflake, Radiation, CloudRain, AlertTriangle,
  Gauge, Activity, Timer, Repeat, Infinity, ChevronDown, ChevronUp,
  Feather, Radar, Scan, Compass, Sunrise, Sunset, Waves, GitBranch, Award,
  Copy, Search, ShoppingBag, Coins, Library
} from 'lucide-react'

// Types
interface Species {
  id: string
  name: string
  description: string
  size: string
  speed: number
  traits: string
}

interface CharacterClass {
  id: string
  name: string
  description: string
  primaryAbility: string
  hitDie: number
  savingThrows: string
  skillProficiencies: string
  armorTraining: string
  weaponProficiencies: string
  startingEquipment: string
  features: string
  spellcasting: boolean
  subclasses: Subclass[]
}

interface Subclass {
  id: string
  name: string
  description: string
  features: string
  subclassSpells?: string | null
}

interface Background {
  id: string
  name: string
  description: string
  abilityScores: string
  feat: string
  skillProficiencies: string
  toolProficiency: string
  equipment: string
}

interface Spell {
  id: string
  name: string
  level: number
  school: string
  castingTime: string
  range: string
  components: string
  duration: string
  description: string
  concentration: boolean
  ritual: boolean
  damageType: string | null
  damageDice: string | null
  classes: string
}

interface SpellSlot {
  level: number
  total: number
  used: number
}

interface Weapon {
  id: string
  name: string
  category: string
  damage: string
  damageType: string
  weight: number
  cost: number
  properties: string
  mastery: string | null
  range: string | null
}

interface Armor {
  id: string
  name: string
  category: string
  baseAC: number
  dexBonus: boolean
  maxDexBonus: number | null
  strRequired: number | null
  stealthDisadv: boolean
  weight: number
  cost: number
}

interface Item {
  id: string
  name: string
  category: string
  subcategory: string | null
  description: string | null
  weight: number
  cost: number
}

interface Character {
  id: string
  name: string
  level: number
  xp: number
  strength: number
  dexterity: number
  constitution: number
  intelligence: number
  wisdom: number
  charisma: number
  currentHp: number
  maxHp: number
  tempHp: number
  hitDiceCurrent: number
  hitDiceMax: number
  hitDiceType: number
  armorClass: number
  initiative: number
  speed: number
  proficiencyBonus: number
  alignment: string | null
  backgroundStory: string | null
  appearance: string | null
  languages: string
  toolProficiencies: string
  armorProficiencies: string
  weaponProficiencies: string
  cp: number
  sp: number
  ep: number
  gp: number
  pp: number
  classFeatures: string
  speciesTraits: string
  spellcastingAbility: string | null
  species: Species | null
  characterClass: CharacterClass | null
  subclass: Subclass | null
  background: Background | null
  inventoryItems: any[]
  characterSpells: any[]
  characterFeats: any[]
  classLevels?: any[] // For multiclass support
  // Skills
  skillAcrobatics: boolean
  skillAnimalHandling: boolean
  skillArcana: boolean
  skillAthletics: boolean
  skillDeception: boolean
  skillHistory: boolean
  skillInsight: boolean
  skillIntimidation: boolean
  skillInvestigation: boolean
  skillMedicine: boolean
  skillNature: boolean
  skillPerception: boolean
  skillPerformance: boolean
  skillPersuasion: boolean
  skillReligion: boolean
  skillSleightOfHand: boolean
  skillStealth: boolean
  skillSurvival: boolean
  // Skills Expertise
  expertAcrobatics: boolean
  expertAnimalHandling: boolean
  expertArcana: boolean
  expertAthletics: boolean
  expertDeception: boolean
  expertHistory: boolean
  expertInsight: boolean
  expertIntimidation: boolean
  expertInvestigation: boolean
  expertMedicine: boolean
  expertNature: boolean
  expertPerception: boolean
  expertPerformance: boolean
  expertPersuasion: boolean
  expertReligion: boolean
  expertSleightOfHand: boolean
  expertStealth: boolean
  expertSurvival: boolean
  // Saving Throws
  saveStr: boolean
  saveDex: boolean
  saveCon: boolean
  saveInt: boolean
  saveWis: boolean
  saveCha: boolean
}

interface SpellSlotData {
  slots: SpellSlot[]
  spellcastingAbility: string | null
  pactSlots?: {
    level: number
    total: number
    used: number
  } | null
  effectiveCasterLevel?: number
  isMulticlass?: boolean
  warlockLevel?: number
}

interface Note {
  id: string
  characterId: string
  title: string
  content: string
  color: string
  pinned: boolean
  createdAt: string
  updatedAt: string
}

// Helper functions
const getModifier = (score: number): number => Math.floor((score - 10) / 2)

const getModifierString = (score: number): string => {
  const mod = getModifier(score)
  return mod >= 0 ? `+${mod}` : `${mod}`
}

// Spell School Icons
const getSchoolIcon = (school: string) => {
  const icons: Record<string, React.ReactNode> = {
    'Abjuration': <Shield className="h-4 w-4" />,
    'Conjuration': <Globe className="h-4 w-4" />,
    'Divination': <Eye className="h-4 w-4" />,
    'Enchantment': <Sparkles className="h-4 w-4" />,
    'Evocation': <Flame className="h-4 w-4" />,
    'Illusion': <Moon className="h-4 w-4" />,
    'Necromancy': <Skull className="h-4 w-4" />,
    'Transmutation': <Wind className="h-4 w-4" />,
  }
  return icons[school] || <Star className="h-4 w-4" />
}

// Spell School Colors
const getSchoolColor = (school: string) => {
  const colors: Record<string, string> = {
    'Abjuration': 'bg-blue-500/20 text-gray-900 border-blue-500/30',
    'Conjuration': 'bg-orange-500/20 text-gray-900 border-orange-500/30',
    'Divination': 'bg-cyan-500/20 text-gray-900 border-cyan-500/30',
    'Enchantment': 'bg-pink-500/20 text-gray-900 border-pink-500/30',
    'Evocation': 'bg-red-500/20 text-gray-900 border-red-500/30',
    'Illusion': 'bg-purple-500/20 text-gray-900 border-purple-500/30',
    'Necromancy': 'bg-gray-500/20 text-gray-900 border-gray-500/30',
    'Transmutation': 'bg-green-500/20 text-gray-900 border-green-500/30',
  }
  return colors[school] || 'bg-muted text-gray-900'
}

// Species Visual Configuration
const getSpeciesIcon = (speciesName: string): React.ReactNode => {
  const name = speciesName?.toLowerCase() || ''
  if (name.includes('dragon') || name.includes('dracón')) return <Flame className="h-5 w-5" />
  if (name.includes('elf') || name.includes('elfo')) return <Star className="h-5 w-5" />
  if (name.includes('dwarf') || name.includes('enano')) return <Shield className="h-5 w-5" />
  if (name.includes('halfling') || name.includes('median')) return <Footprints className="h-5 w-5" />
  if (name.includes('human') || name.includes('humano')) return <User className="h-5 w-5" />
  if (name.includes('tiefling')) return <Sparkles className="h-5 w-5" />
  if (name.includes('gnome')) return <Sparkle className="h-5 w-5" />
  if (name.includes('orc') || name.includes('orco')) return <Skull className="h-5 w-5" />
  if (name.includes('aasimar')) return <Sun className="h-5 w-5" />
  if (name.includes('goliath')) return <Shield className="h-5 w-5" />
  if (name.includes('fairy') || name.includes('hada')) return <Sparkles className="h-5 w-5" />
  if (name.includes('kenku') || name.includes('bird')) return <Bird className="h-5 w-5" />
  if (name.includes('tabaxi') || name.includes('cat')) return <Cat className="h-5 w-5" />
  if (name.includes('lizard') || name.includes('lagart')) return <Bug className="h-5 w-5" />
  if (name.includes('tortle')) return <Shield className="h-5 w-5" />
  return <CircleDot className="h-5 w-5" />
}

const getSpeciesColor = (speciesName: string): string => {
  const name = speciesName?.toLowerCase() || ''
  if (name.includes('dragon') || name.includes('dracón')) return 'from-red-500/20 to-orange-500/20 border-red-500/30'
  if (name.includes('elf') || name.includes('elfo')) return 'from-emerald-500/20 to-green-500/20 border-emerald-500/30'
  if (name.includes('dwarf') || name.includes('enano')) return 'from-amber-500/20 to-yellow-500/20 border-amber-500/30'
  if (name.includes('halfling') || name.includes('median')) return 'from-lime-500/20 to-green-500/20 border-lime-500/30'
  if (name.includes('human') || name.includes('humano')) return 'from-slate-500/20 to-gray-500/20 border-slate-500/30'
  if (name.includes('tiefling')) return 'from-purple-500/20 to-pink-500/20 border-purple-500/30'
  if (name.includes('gnome')) return 'from-cyan-500/20 to-blue-500/20 border-cyan-500/30'
  if (name.includes('orc') || name.includes('orco')) return 'from-gray-600/20 to-gray-700/20 border-gray-600/30'
  if (name.includes('aasimar')) return 'from-yellow-400/20 to-amber-400/20 border-yellow-400/30'
  if (name.includes('goliath')) return 'from-stone-500/20 to-gray-600/20 border-stone-500/30'
  return 'from-primary/20 to-secondary/20 border-primary/30'
}

// Helper to get class display string (handles multiclass)
const getClassDisplayString = (char: any): string => {
  const classLevels = char.classLevels
  if (classLevels && classLevels.length > 0) {
    // Sort: primary first, then by level
    const sortedLevels = [...classLevels].sort((a: any, b: any) => {
      if (a.isPrimary) return -1
      if (b.isPrimary) return 1
      return b.level - a.level
    })
    return sortedLevels.map((cl: any) => 
      `${cl.class?.name || 'Clase'} ${cl.level}`
    ).join(' / ')
  }
  // Fallback to single class display
  return `${char.characterClass?.name || 'Sin clase'} ${char.level}`
}

const getSpeciesTraitIcon = (traitName: string): React.ReactNode => {
  const name = traitName?.toLowerCase() || ''
  // Sentidos y Visión
  if (name.includes('vision') || name.includes('vista') || name.includes('darkvision')) return <Eye className="h-4 w-4" />
  if (name.includes('sense') || name.includes('sentido')) return <Radar className="h-4 w-4" />
  
  // Velocidad y Movimiento
  if (name.includes('speed') || name.includes('velocidad') || name.includes('mov')) return <Gauge className="h-4 w-4" />
  if (name.includes('fly') || name.includes('vuelo')) return <Feather className="h-4 w-4" />
  if (name.includes('swim') || name.includes('nadar')) return <Waves className="h-4 w-4" />
  
  // Resistencias y Daño
  if (name.includes('resist') || name.includes('resistencia')) return <Shield className="h-4 w-4" />
  if (name.includes('damage') || name.includes('daño')) return <Flame className="h-4 w-4" />
  if (name.includes('fire') || name.includes('fuego')) return <Flame className="h-4 w-4" />
  if (name.includes('cold') || name.includes('frío') || name.includes('frio')) return <Snowflake className="h-4 w-4" />
  if (name.includes('lightning') || name.includes('eléctric') || name.includes('electric') || name.includes('rayo')) return <Lightning className="h-4 w-4" />
  if (name.includes('poison') || name.includes('veneno')) return <Droplet className="h-4 w-4" />
  if (name.includes('acid') || name.includes('ácido') || name.includes('acido')) return <Droplet className="h-4 w-4" />
  if (name.includes('necrotic') || name.includes('necrót')) return <Skull className="h-4 w-4" />
  if (name.includes('radiant') || name.includes('radiant')) return <Sun className="h-4 w-4" />
  
  // Magia y Hechizos
  if (name.includes('magic') || name.includes('magia') || name.includes('spell')) return <Wand2 className="h-4 w-4" />
  if (name.includes('cantrip') || name.includes('truco')) return <Sparkle className="h-4 w-4" />
  if (name.includes('enchant') || name.includes('encant')) return <Sparkles className="h-4 w-4" />
  
  // Aliento y Ataques
  if (name.includes('breath') || name.includes('aliento')) return <Wind className="h-4 w-4" />
  if (name.includes('attack') || name.includes('ataque')) return <Sword className="h-4 w-4" />
  
  // Habilidades Especiales
  if (name.includes('lucky') || name.includes('suerte') || name.includes('fortune')) return <Star className="h-4 w-4" />
  if (name.includes('brave') || name.includes('valent')) return <Shield className="h-4 w-4" />
  if (name.includes('stealth') || name.includes('sigilo')) return <Moon className="h-4 w-4" />
  if (name.includes('skill') || name.includes('habilidad')) return <Brain className="h-4 w-4" />
  if (name.includes('heal') || name.includes('curaci')) return <Heart className="h-4 w-4" />
  if (name.includes('revelation') || name.includes('revelación')) return <Sunrise className="h-4 w-4" />
  if (name.includes('ancestry') || name.includes('ancestro') || name.includes('linaje')) return <TreePine className="h-4 w-4" />
  if (name.includes('trance')) return <Moon className="h-4 w-4" />
  if (name.includes('toughness') || name.includes('fortaleza')) return <Shield className="h-4 w-4" />
  if (name.includes('cunning') || name.includes('astucia')) return <Brain className="h-4 w-4" />
  if (name.includes('nimbleness') || name.includes('agilidad')) return <Footprints className="h-4 w-4" />
  if (name.includes('endurance') || name.includes('resistencia')) return <Activity className="h-4 w-4" />
  if (name.includes('fury') || name.includes('furia')) return <Flame className="h-4 w-4" />
  if (name.includes('light') || name.includes('luz') || name.includes('bearer')) return <Sun className="h-4 w-4" />
  
  // Transformaciones
  if (name.includes('transform') || name.includes('transformación')) return <RefreshCw className="h-4 w-4" />
  
  return <CircleDot className="h-4 w-4" />
}

const getSpeciesTraitColor = (traitName: string): string => {
  const name = traitName?.toLowerCase() || ''
  
  // === SENTIDOS (Morados/Violetas) ===
  if (name.includes('vision') || name.includes('vista') || name.includes('darkvision')) 
    return 'bg-violet-500/20 text-gray-900 border-violet-500/40 hover:bg-violet-500/30'
  if (name.includes('sense') || name.includes('sentido')) 
    return 'bg-purple-500/20 text-gray-900 border-purple-500/40 hover:bg-purple-500/30'
  
  // === VELOCIDAD/MOVIMIENTO (Azules) ===
  if (name.includes('speed') || name.includes('velocidad') || name.includes('mov')) 
    return 'bg-blue-500/20 text-gray-900 border-blue-500/40 hover:bg-blue-500/30'
  if (name.includes('fly') || name.includes('vuelo')) 
    return 'bg-sky-500/20 text-gray-900 border-sky-500/40 hover:bg-sky-500/30'
  if (name.includes('swim') || name.includes('nadar')) 
    return 'bg-cyan-500/20 text-gray-900 border-cyan-500/40 hover:bg-cyan-500/30'
  
  // === RESISTENCIAS/DAÑO (Rojos/Naranjas) ===
  if (name.includes('resist') || name.includes('resistencia')) 
    return 'bg-red-500/20 text-gray-900 border-red-500/40 hover:bg-red-500/30'
  if (name.includes('damage') || name.includes('daño')) 
    return 'bg-orange-500/20 text-gray-900 border-orange-500/40 hover:bg-orange-500/30'
  if (name.includes('fire') || name.includes('fuego')) 
    return 'bg-red-600/20 text-gray-900 border-red-600/40 hover:bg-red-600/30'
  if (name.includes('cold') || name.includes('frío') || name.includes('frio')) 
    return 'bg-sky-400/20 text-gray-900 border-sky-400/40 hover:bg-sky-400/30'
  if (name.includes('lightning') || name.includes('eléctric') || name.includes('electric') || name.includes('rayo')) 
    return 'bg-orange-500/20 text-gray-900 border-orange-500/40 hover:bg-orange-500/30'
  if (name.includes('poison') || name.includes('veneno')) 
    return 'bg-green-600/20 text-gray-900 border-green-600/40 hover:bg-green-600/30'
  if (name.includes('acid') || name.includes('ácido') || name.includes('acido')) 
    return 'bg-lime-600/20 text-gray-900 border-lime-600/40 hover:bg-lime-600/30'
  if (name.includes('necrotic') || name.includes('necrót')) 
    return 'bg-gray-600/20 text-gray-900 border-gray-600/40 hover:bg-gray-600/30'
  if (name.includes('radiant') || name.includes('radiante')) 
    return 'bg-orange-400/20 text-gray-900 border-orange-400/40 hover:bg-orange-400/30'
  
  // === MAGIA/HECHIZOS (Naranjas) ===
  if (name.includes('magic') || name.includes('magia') || name.includes('spell')) 
    return 'bg-orange-600/20 text-gray-900 border-orange-600/40 hover:bg-orange-600/30'
  if (name.includes('cantrip') || name.includes('truco')) 
    return 'bg-orange-600/20 text-gray-900 border-orange-600/40 hover:bg-orange-600/30'
  if (name.includes('enchant') || name.includes('encant')) 
    return 'bg-pink-500/20 text-gray-900 border-pink-500/40 hover:bg-pink-500/30'
  
  // === ALIENTO Y ATAQUES (Rojos intensos) ===
  if (name.includes('breath') || name.includes('aliento')) 
    return 'bg-red-600/20 text-gray-900 border-red-600/40 hover:bg-red-600/30'
  if (name.includes('attack') || name.includes('ataque')) 
    return 'bg-rose-500/20 text-gray-900 border-rose-500/40 hover:bg-rose-500/30'
  
  // === HABILIDADES ESPECIALES (Verdes) ===
  if (name.includes('lucky') || name.includes('suerte') || name.includes('fortune')) 
    return 'bg-emerald-500/20 text-gray-900 border-emerald-500/40 hover:bg-emerald-500/30'
  if (name.includes('brave') || name.includes('valent')) 
    return 'bg-green-500/20 text-gray-900 border-green-500/40 hover:bg-green-500/30'
  if (name.includes('stealth') || name.includes('sigilo')) 
    return 'bg-slate-600/20 text-gray-900 border-slate-600/40 hover:bg-slate-600/30'
  if (name.includes('skill') || name.includes('habilidad')) 
    return 'bg-teal-500/20 text-gray-900 border-teal-500/40 hover:bg-teal-500/30'
  if (name.includes('heal') || name.includes('curaci')) 
    return 'bg-green-400/20 text-gray-900 border-green-400/40 hover:bg-green-400/30'
  if (name.includes('revelation') || name.includes('revelación')) 
    return 'bg-orange-500/20 text-gray-900 border-orange-500/40 hover:bg-orange-500/30'
  if (name.includes('ancestry') || name.includes('ancestro') || name.includes('linaje')) 
    return 'bg-orange-600/20 text-gray-900 border-orange-600/40 hover:bg-orange-600/30'
  if (name.includes('trance')) 
    return 'bg-indigo-500/20 text-gray-900 border-indigo-500/40 hover:bg-indigo-500/30'
  if (name.includes('toughness') || name.includes('fortaleza')) 
    return 'bg-orange-600/20 text-gray-900 border-orange-600/40 hover:bg-orange-600/30'
  if (name.includes('cunning') || name.includes('astucia')) 
    return 'bg-purple-400/20 text-gray-900 border-purple-400/40 hover:bg-purple-400/30'
  if (name.includes('nimbleness') || name.includes('agilidad')) 
    return 'bg-cyan-400/20 text-gray-900 border-cyan-400/40 hover:bg-cyan-400/30'
  if (name.includes('endurance') || name.includes('resistencia inquebrantable')) 
    return 'bg-orange-500/20 text-gray-900 border-orange-500/40 hover:bg-orange-500/30'
  if (name.includes('fury') || name.includes('furia')) 
    return 'bg-red-500/20 text-gray-900 border-red-500/40 hover:bg-red-500/30'
  if (name.includes('light') || name.includes('luz') || name.includes('bearer')) 
    return 'bg-orange-500/20 text-gray-900 border-orange-500/40 hover:bg-orange-500/30'
  
  // === TRANSFORMACIONES ===
  if (name.includes('transform') || name.includes('transformación')) 
    return 'bg-fuchsia-500/20 text-gray-900 border-fuchsia-500/40 hover:bg-fuchsia-500/30'
  
  // === RASGOS GENERALES (Grises/Neutrales) ===
  return 'bg-slate-500/20 text-gray-900 border-slate-500/40 hover:bg-slate-500/30'
}

const getSizeInfo = (size: string): { icon: React.ReactNode; color: string; label: string } => {
  const sizeLower = size?.toLowerCase() || 'medium'
  const sizeMap: Record<string, { icon: React.ReactNode; color: string; label: string }> = {
    'tiny': { icon: <span className="text-xs">●</span>, color: 'bg-violet-500/20 text-gray-900', label: 'Diminuto' },
    'small': { icon: <span className="text-sm">●</span>, color: 'bg-blue-500/20 text-gray-900', label: 'Pequeño' },
    'medium': { icon: <span className="text-base">●</span>, color: 'bg-green-500/20 text-gray-900', label: 'Mediano' },
    'large': { icon: <span className="text-lg">●</span>, color: 'bg-amber-500/20 text-gray-900', label: 'Grande' },
    'huge': { icon: <span className="text-xl">●</span>, color: 'bg-orange-500/20 text-gray-900', label: 'Enorme' },
    'gargantuan': { icon: <span className="text-2xl">●</span>, color: 'bg-red-500/20 text-gray-900', label: 'Gigantesco' },
  }
  return sizeMap[sizeLower] || sizeMap['medium']
}

// Species Trait Card Component
const SpeciesTraitCard = ({ traitName, traitValue, index }: { traitName: string; traitValue: any; index: number }) => {
  const traitIcon = getSpeciesTraitIcon(traitName)
  const traitColor = getSpeciesTraitColor(traitName)
  const [isExpanded, setIsExpanded] = useState(true)
  
  // Check if traitValue is a JSON object (for complex traits like Celestial Revelation)
  let parsedValue: any = traitValue
  let isComplexTrait = false
  
  // If it's already an object, use it directly
  if (typeof traitValue === 'object' && traitValue !== null && !Array.isArray(traitValue)) {
    isComplexTrait = true
    parsedValue = traitValue
  } else if (typeof traitValue === 'string' && (traitValue.startsWith('{') || traitValue.startsWith('['))) {
    try {
      parsedValue = JSON.parse(traitValue)
      isComplexTrait = typeof parsedValue === 'object' && parsedValue !== null && !Array.isArray(parsedValue)
    } catch {
      // Keep as string if parsing fails
    }
  }
  
  // Render complex trait with uses and options
  if (isComplexTrait && parsedValue.options) {
    return (
      <div 
        className={`group rounded-xl border backdrop-blur-sm transition-all duration-300 
          hover:scale-[1.02] hover:shadow-lg hover:shadow-current/10 cursor-pointer ${traitColor}`}
        style={{ animationDelay: `${index * 50}ms` }}
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="p-3">
          {/* Header con icono, nombre y badge de usos */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-1.5 bg-background/40 rounded-lg backdrop-blur-sm 
                group-hover:bg-background/60 transition-colors duration-300
                shadow-sm group-hover:shadow-md">
                {traitIcon}
              </div>
              <div className="flex flex-col">
                <span className="font-semibold text-sm tracking-wide">
                  {parsedValue.name || formatTraitName(traitName)}
                </span>
                {parsedValue.description && (
                  <span className="text-[10px] opacity-70 line-clamp-1">{parsedValue.description}</span>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2">
              {parsedValue.uses && (
                <Badge 
                  variant="outline" 
                  className="text-[10px] px-2 py-0.5 border-current/50 bg-current/10 
                    font-medium uppercase tracking-wider animate-pulse"
                >
                  <Timer className="h-2.5 w-2.5 mr-1" />
                  {parsedValue.uses}
                </Badge>
              )}
              <div className={`transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`}>
                <ChevronDown className="h-4 w-4 opacity-60" />
              </div>
            </div>
          </div>
          
          {/* Opciones expandibles */}
          {isExpanded && parsedValue.options && parsedValue.options.length > 0 && (
            <div className="mt-3 ml-9 space-y-2 animate-in slide-in-from-top-2 duration-200">
              {parsedValue.options.map((opt: any, optIndex: number) => (
                <div 
                  key={optIndex} 
                  className="relative pl-3 pr-2 py-2 bg-background/30 rounded-lg 
                    border border-current/10 backdrop-blur-sm
                    hover:bg-background/40 transition-colors duration-200
                    before:absolute before:left-0 before:top-1/2 before:-translate-y-1/2
                    before:w-1 before:h-1 before:rounded-full before:bg-current/60"
                >
                  <div className="flex items-start gap-2">
                    <span className="font-semibold text-xs text-current/90">{opt.name}</span>
                  </div>
                  <p className="text-[11px] opacity-75 mt-0.5 leading-relaxed">{opt.description}</p>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    )
  }
  
  // Convert to string for display if it's an object without options
  const displayValue = typeof traitValue === 'object' ? JSON.stringify(traitValue) : String(traitValue)
  
  // Detectar si tiene usos limitados en el texto
  const hasLimitedUses = displayValue.toLowerCase().includes('descanso') || 
                         displayValue.toLowerCase().includes('rest') ||
                         displayValue.toLowerCase().includes('por día') ||
                         displayValue.toLowerCase().includes('per day')
  
  return (
    <div 
      className={`group rounded-xl border backdrop-blur-sm transition-all duration-300 
        hover:scale-[1.02] hover:shadow-lg hover:shadow-current/10 ${traitColor}`}
      style={{ animationDelay: `${index * 50}ms` }}
    >
      <div className="p-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-background/40 rounded-lg backdrop-blur-sm 
              group-hover:bg-background/60 transition-colors duration-300
              shadow-sm group-hover:shadow-md">
              {traitIcon}
            </div>
            <span className="font-semibold text-sm tracking-wide">{formatTraitName(traitName)}</span>
          </div>
          {hasLimitedUses && (
            <Badge 
              variant="outline" 
              className="text-[10px] px-2 py-0.5 border-current/50 bg-current/10 
                font-medium uppercase tracking-wider"
            >
              <Timer className="h-2.5 w-2.5 mr-1" />
              Limitado
            </Badge>
          )}
        </div>
        <p className="text-xs mt-2 ml-9 opacity-80 leading-relaxed">{displayValue}</p>
      </div>
    </div>
  )
}

// Helper function to format trait names
const formatTraitName = (name: string): string => {
  const nameMap: Record<string, string> = {
    // Aasimar
    'celestialResistance': 'Resistencia Celestial',
    'darkvision': 'Visión en la Oscuridad',
    'lightBearer': 'Portador de Luz',
    'celestialRevelation': 'Revelación Celestial',
    'healingHands': 'Manos Curativas',
    'radiantSoul': 'Alma Radiante',
    'necroticShroud': 'Manto Necrótico',
    'celestialWings': 'Alas Celestiales',
    'innerRadiance': 'Radiancia Interior',
    
    // Dragonborn
    'draconicAncestry': 'Ancestro Dracónico',
    'breathWeapon': 'Arma de Aliento',
    'damageResistance': 'Resistencia al Daño',
    'draconicFlight': 'Vuelo Dracónico',
    'chromaticWard': 'Resistencia Cromática',
    'metallicWard': 'Resistencia Metálica',
    
    // Dwarf
    'dwarvenResilience': 'Resistencia Enana',
    'dwarvenToughness': 'Fortaleza Enana',
    'stonecunning': 'Conocimiento de la Piedra',
    'dwarvenArmorTraining': 'Entrenamiento en Armadura Enana',
    'dwarvenCombatTraining': 'Entrenamiento de Combate Enano',
    
    // Elf
    'elvenLineage': 'Linaje Élfico',
    'feyAncestry': 'Ancestro Feérico',
    'keenSenses': 'Sentidos Agudos',
    'trance': 'Trance',
    'elfWeaponTraining': 'Entrenamiento con Armas Élficas',
    'maskOfTheWild': 'Máscara del Salvaje',
    'sunlightSensitivity': 'Sensibilidad a la Luz Solar',
    'drowMagic': 'Magia Drow',
    'superiorDarkvision': 'Visión en la Oscuridad Superior',
    
    // Gnome
    'gnomishCunning': 'Astucia Gnómica',
    'gnomeLineage': 'Linaje Gnómico',
    'speakWithSmallBeasts': 'Hablar con Bestias Pequeñas',
    'artificersLore': 'Sabiduría del Artífice',
    'tinker': 'Herrero',
    
    // Halfling
    'halfingLuck': 'Suerte Halfling',
    'halflingLuck': 'Suerte Halfling',
    'brave': 'Valiente',
    'halflingNimbleness': 'Agilidad Halfling',
    'naturallyStealthy': 'Naturalmente Sigiloso',
    'stoutResilience': 'Resistencia Robusta',
    
    // Human
    'humanVersatility': 'Versatilidad Humana',
    'humanResourcefulness': 'Ingenio Humano',
    'skillVersatility': 'Versatilidad de Habilidades',
    
    // Tiefling
    'infernalLegacy': 'Legado Infernal',
    'hellishResistance': 'Resistencia Infernal',
    'thaumaturgy': 'Taumaturgia',
    'darknessSpell': 'Oscuridad',
    'hellishRebuke': 'Reprensión Infernal',
    
    // Goliath
    'giantAncestry': 'Ancestro Gigante',
    'stonesEndurance': 'Resistencia de Piedra',
    'powerfulBuild': 'Complexión Poderosa',
    'mountainBorn': 'Nacido de la Montaña',
    'cloudGiant': 'Gigante de las Nubes',
    'fireGiant': 'Gigante de Fuego',
    'frostGiant': 'Gigante de Escarcha',
    'hillGiant': 'Gigante de las Colinas',
    'stoneGiant': 'Gigante de Piedra',
    'stormGiant': 'Gigante de Tormentas',
    
    // Orc
    'orcishFury': 'Furia Orca',
    'relentlessEndurance': 'Resistencia Inquebrantable',
    'savageAttacks': 'Ataques Salvajes',
    'aggressive': 'Agresivo',
    'primalIntuition': 'Intuición Primitiva',
    
    // Otros
    'speed': 'Velocidad',
    'size': 'Tamaño',
    'languages': 'Idiomas',
    'proficiencies': 'Competencias',
    'skills': 'Habilidades',
    'armorProficiency': 'Competencia en Armadura',
    'weaponProficiency': 'Competencia en Armas',
    'toolProficiency': 'Competencia en Herramientas',
    'savingThrows': 'Tiradas de Salvación',
  }
  return nameMap[name] || name.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())
}

// Spellcasting ability by class
const SPELLCASTING_ABILITY: Record<string, string> = {
  'Bard': 'charisma',
  'Cleric': 'wisdom',
  'Druid': 'wisdom',
  'Sorcerer': 'charisma',
  'Wizard': 'intelligence',
  'Paladin': 'charisma',
  'Ranger': 'wisdom',
  'Warlock': 'charisma',
}

// Species Subtype Configuration for D&D 2024
interface SpeciesSubtypeOption {
  id: string
  name: string
  description: string
  benefits: string[]
  damageResistance?: string
  breathWeapon?: { type: string; damageType: string; shape: string }
  spells?: { level: number; spellName: string }[]
  cantrip?: string
  darkvision?: number
  otherBenefits?: string
}

interface SpeciesSubtypeConfig {
  requiresSelection: boolean
  selectionName: string
  selectionType?: 'subtype' | 'feat'
  options: SpeciesSubtypeOption[]
}

const SPECIES_SUBTYPES: Record<string, SpeciesSubtypeConfig> = {
  'Dragonborn': {
    requiresSelection: true,
    selectionName: 'Ancestro Dracónico',
    options: [
      { id: 'black', name: 'Dragón Negro', description: 'Dragón cromático de las ciénagas', benefits: ['Resistencia al daño ácido', 'Aliento de ácido (cono de 15 pies)'], damageResistance: 'Acid', breathWeapon: { type: 'acid', damageType: 'Acid', shape: 'cone' } },
      { id: 'blue', name: 'Dragón Azul', description: 'Dragón cromático de los desiertos', benefits: ['Resistencia al daño eléctrico', 'Aliento de rayo (línea de 30 pies)'], damageResistance: 'Lightning', breathWeapon: { type: 'lightning', damageType: 'Lightning', shape: 'line' } },
      { id: 'brass', name: 'Dragón Latón', description: 'Dragón metálico de los desiertos', benefits: ['Resistencia al daño de fuego', 'Aliento de fuego (línea de 30 pies)'], damageResistance: 'Fire', breathWeapon: { type: 'fire', damageType: 'Fire', shape: 'line' } },
      { id: 'bronze', name: 'Dragón Bronce', description: 'Dragón metálico de las costas', benefits: ['Resistencia al daño eléctrico', 'Aliento de rayo (línea de 30 pies)'], damageResistance: 'Lightning', breathWeapon: { type: 'lightning', damageType: 'Lightning', shape: 'line' } },
      { id: 'copper', name: 'Dragón Cobre', description: 'Dragón metálico de las colinas', benefits: ['Resistencia al daño ácido', 'Aliento de ácido (línea de 30 pies)'], damageResistance: 'Acid', breathWeapon: { type: 'acid', damageType: 'Acid', shape: 'line' } },
      { id: 'gold', name: 'Dragón Oro', description: 'Dragón metálico noble y poderoso', benefits: ['Resistencia al daño de fuego', 'Aliento de fuego (cono de 15 pies)'], damageResistance: 'Fire', breathWeapon: { type: 'fire', damageType: 'Fire', shape: 'cone' } },
      { id: 'green', name: 'Dragón Verde', description: 'Dragón cromático de los bosques', benefits: ['Resistencia al daño de veneno', 'Aliento de veneno (cono de 15 pies)'], damageResistance: 'Poison', breathWeapon: { type: 'poison', damageType: 'Poison', shape: 'cone' } },
      { id: 'red', name: 'Dragón Rojo', description: 'Dragón cromático más poderoso', benefits: ['Resistencia al daño de fuego', 'Aliento de fuego (cono de 15 pies)'], damageResistance: 'Fire', breathWeapon: { type: 'fire', damageType: 'Fire', shape: 'cone' } },
      { id: 'silver', name: 'Dragón Plata', description: 'Dragón metálico benévolo', benefits: ['Resistencia al daño de frío', 'Aliento de frío (cono de 15 pies)'], damageResistance: 'Cold', breathWeapon: { type: 'cold', damageType: 'Cold', shape: 'cone' } },
      { id: 'white', name: 'Dragón Blanco', description: 'Dragón cromático de los glaciares', benefits: ['Resistencia al daño de frío', 'Aliento de frío (cono de 15 pies)'], damageResistance: 'Cold', breathWeapon: { type: 'cold', damageType: 'Cold', shape: 'cone' } }
    ]
  },
  'Elf': {
    requiresSelection: true,
    selectionName: 'Linaje Élfico',
    options: [
      { 
        id: 'drow', 
        name: 'Drow (Elfos Oscuros)', 
        description: 'Elfos del submundo con herencia feérica oscura',
        benefits: ['Visión en la oscuridad superior (120 pies)', 'Trucos: Luces danzantes', 'Hechizos adicionales al subir de nivel'],
        darkvision: 120,
        cantrip: 'Dancing Lights',
        spells: [
          { level: 3, spellName: 'Faerie Fire' },
          { level: 5, spellName: 'Darkness' }
        ],
        otherBenefits: 'Sensibilidad a la luz solar'
      },
      { 
        id: 'high', 
        name: 'Alto Elfo', 
        description: 'Elfos estudioso con afinidad mágica',
        benefits: ['Truco de prestidigitación', 'Hechizos adicionales al subir de nivel', 'Idioma adicional'],
        cantrip: 'Prestidigitation',
        spells: [
          { level: 3, spellName: 'Detect Magic' },
          { level: 5, spellName: 'Misty Step' }
        ]
      },
      { 
        id: 'wood', 
        name: 'Elfo del Bosque', 
        description: 'Elfos selváticos con conexión natural',
        benefits: ['Velocidad aumentada (35 pies)', 'Truco de druidismo', 'Hechizos adicionales al subir de nivel'],
        cantrip: 'Druidcraft',
        spells: [
          { level: 3, spellName: 'Longstrider' },
          { level: 5, spellName: 'Pass without Trace' }
        ],
        otherBenefits: 'Velocidad: 35 pies'
      }
    ]
  },
  'Tiefling': {
    requiresSelection: true,
    selectionName: 'Legado Infernal',
    options: [
      { 
        id: 'abyssal', 
        name: 'Abismal', 
        description: 'Herencia demoníaca de las profundidades',
        benefits: ['Resistencia al veneno', 'Truco: Rociada de veneno', 'Hechizos de veneno/necrosis'],
        damageResistance: 'Poison',
        cantrip: 'Poison Spray',
        spells: [
          { level: 3, spellName: 'Ray of Sickness' },
          { level: 5, spellName: 'Hold Person' }
        ]
      },
      { 
        id: 'chthonic', 
        name: 'Ctónico', 
        description: 'Poder de los mundos infernales oscuros',
        benefits: ['Resistencia a necrótico', 'Truco: Toque helado', 'Hechizos de sombra'],
        damageResistance: 'Necrotic',
        cantrip: 'Chill Touch',
        spells: [
          { level: 3, spellName: 'False Life' },
          { level: 5, spellName: 'Ray of Enfeeblement' }
        ]
      },
      { 
        id: 'infernal', 
        name: 'Infernal', 
        description: 'Sangre de diablos clásicos',
        benefits: ['Resistencia al fuego', 'Truco: Rayo de fuego', 'Hechizos de fuego/oscuro'],
        damageResistance: 'Fire',
        cantrip: 'Fire Bolt',
        spells: [
          { level: 3, spellName: 'Hellish Rebuke' },
          { level: 5, spellName: 'Darkness' }
        ]
      }
    ]
  },
  'Gnome': {
    requiresSelection: true,
    selectionName: 'Linaje Gnómico',
    options: [
      { 
        id: 'forest', 
        name: 'Gnomo del Bosque', 
        description: 'Gnomos con conexión feérica natural',
        benefits: ['Truco: Ilusión menor', 'Hablar con animales', 'Velocidad sigilosa'],
        cantrip: 'Minor Illusion',
        otherBenefits: 'Puede usar Hablar con Animales (usos = bonificador de competencia)'
      },
      { 
        id: 'rock', 
        name: 'Gnomo de Roca', 
        description: 'Gnomos artesanos e inventores',
        benefits: ['Trucos: Reparar y Prestidigitación', 'Artesanía de dispositivos diminutos', 'Visión en la oscuridad'],
        cantrip: 'Mending',
        spells: [{ level: 1, spellName: 'Prestidigitation' }],
        otherBenefits: 'Puede crear dispositivos diminutos de relojería'
      }
    ]
  },
  'Goliath': {
    requiresSelection: true,
    selectionName: 'Ancestro Gigante',
    options: [
      { id: 'cloud', name: 'Gigante de las Nubes', description: 'Poder de los gigantes celestiales', benefits: ['Teletransporte corto como acción bonus', 'Elegancia y gracia'] },
      { id: 'fire', name: 'Gigante de Fuego', description: 'Fuego ancestral arde en ti', benefits: ['+1d10 de daño de fuego en ataques', 'Resistencia parcial al fuego'] },
      { id: 'frost', name: 'Gigante de Escarcha', description: 'Frío glacial de los nevados', benefits: ['+1d6 de daño de frío y reducir velocidad', 'Resistencia parcial al frío'] },
      { id: 'hill', name: 'Gigante de las Colinas', description: 'Fuerza bruta primitiva', benefits: ['Derribar enemigos al golpear', 'Constitución robusta'] },
      { id: 'stone', name: 'Gigante de Piedra', description: 'Piel como la roca', benefits: ['Reducir daño como reacción', 'Resistencia física'] },
      { id: 'storm', name: 'Gigante de Tormentas', description: 'Poder eléctrico ancestral', benefits: ['+1d8 de daño de trueno como reacción', 'Conexión con las tormentas'] }
    ]
  },
  'Aasimar': {
    requiresSelection: false,
    // Celestial Revelation is NOT a permanent choice - it's a 1/Long Rest ability
    // where the player chooses each time they use it
    abilityInfo: {
      name: 'Revelación Celestial',
      uses: '1 por Descanso Largo',
      description: 'Al nivel 3, puedes transformarte como Acción Bonus durante 1 minuto. Cada vez que usas esta habilidad, elige una:',
      options: [
        { name: 'Alas Celestiales', description: 'Velocidad de vuelo igual a tu velocidad.' },
        { name: 'Radiancia Interior', description: 'Emite luz brillante 10 pies y luz tenue 10 más. Causas 1d10 + nivel de daño radiante a criaturas adyacentes.' },
        { name: 'Manto Necrótico', description: 'Velocidad de vuelo. Enemigos deben salvar Sabiduría o asustarse. Ataques causan daño necrótico adicional igual a tu bonificador de competencia.' }
      ]
    }
  },
  'Human': {
    requiresSelection: true,
    selectionName: 'Dote de Origen (Versátil)',
    selectionType: 'feat',
    options: [] // Humans select from Origin feats dynamically
  }
}

// Function to get feat reminder note content
const getFeatReminderNote = (featName: string): string | null => {
  const featReminders: Record<string, string> = {
    'Magic Initiate (Cleric)': `✨ **Acciones requeridas:**
• Elige **2 trucos** de la lista de hechizos de Clérigo
• Elige **1 hechizo de nivel 1** de la lista de Clérigo
• Puedes lanzar el hechizo de nivel 1 una vez por descanso largo sin usar ranura

📖 Consulta la sección de hechizos para seleccionarlos.`,
    
    'Magic Initiate (Druid)': `✨ **Acciones requeridas:**
• Elige **2 trucos** de la lista de hechizos de Druida
• Elige **1 hechizo de nivel 1** de la lista de Druida
• Puedes lanzar el hechizo de nivel 1 una vez por descanso largo sin usar ranura

📖 Consulta la sección de hechizos para seleccionarlos.`,
    
    'Magic Initiate (Wizard)': `✨ **Acciones requeridas:**
• Elige **2 trucos** de la lista de hechizos de Mago
• Elige **1 hechizo de nivel 1** de la lista de Mago
• Puedes lanzar el hechizo de nivel 1 una vez por descanso largo sin usar ranura

📖 Consulta la sección de hechizos para seleccionarlos.`,
    
    'Skilled': `✨ **Acciones requeridas:**
• Elige **3 habilidades** en las que quieras ganar competencia
• Marca estas habilidades en la hoja de personaje

💡 Sugerencia: Elige habilidades que complementen tu clase y trasfondo.`,
    
    'Tough': `✨ **Beneficio automático:**
• Tu punto de golpe máximo aumenta en **2 por cada nivel**
• Nivel 1: +2 PG, Nivel 2: +4 PG, etc.

📝 Actualiza tus puntos de golpe máximos: 2 puntos adicionales por nivel.`,
    
    'Crafter': `✨ **Acciones requeridas:**
• Ganas competencia con **3 tipos de herramientas de artesano**
• Registra estas competencias en tu hoja
• Puedes fabricar objetos más rápido (4 horas en lugar de 1 semana para objetos pequeños)

💡 Sugerencia: Elige herramientas relacionadas con tu trasfondo.`,
    
    'Tavern Brawler': `✨ **Beneficios:**
• Puedes usar tu **acción bonus** para hacer un golpe sin armas después de un ataque exitoso
• Puedes usar **Destreza** en lugar de Fuerza para golpes sin armas
• El daño es 1 + tu modificador de Fuerza o Destreza

📝 No requiere acción adicional, ya está activo.`,
    
    'Savage Attacker': `✨ **Beneficio automático:**
• Una vez por turno, puedes volver a tirar los dados de daño de un ataque cuerpo a cuerpo
• Debes usar el total nuevo o el original

📝 No requiere configuración, ya está activo.`,
    
    'Lucky': `✨ **Beneficio automático:**
• Tienes **3 puntos de suerte** por descanso largo
• Gasta 1 punto para tirar un d20 adicional en:
  - Tiradas de ataque
  - Pruebas de característica
  - Tiradas de salvación
• Puedes elegir qué resultado usar

📝 Registra tus puntos de suerte (3/descanso largo).`,
    
    'Alert': `✨ **Beneficios automáticos:**
• +5 de bonificador a la **iniciativa**
• No puedes ser sorprendido mientras estés consciente

📝 Actualiza tu iniciativa en la hoja de personaje.`,
    
    'Great Weapon Master': `✨ **Beneficios:**
• **Golpe bonus:** Cuando reduces a 0 PG a una criatura o haces crítico con arma pesada
• **-5/+10:** Puedes elegir -5 al ataque por +10 de daño con armas pesadas

📝 Tú decides cuándo aplicar cada beneficio.`,
    
    'Sharpshooter': `✨ **Beneficios:**
• Ignoras media y tres cuartos de cobertura
• No tienes desventaja a distancia larga
• **-5/+10:** Puedes elegir -5 al ataque por +10 de daño

📝 Tú decides cuándo aplicar el bonificador de daño.`,
    
    'War Caster': `✨ **Beneficios automáticos:**
• Ventaja en salvaciones de Constitución para mantener concentración
• Puedes hacer gestos con armas/escudos
• Puedes lanzar hechizos como ataque de oportunidad

📝 No requiere configuración.`,
    
    'Sentinel': `✨ **Beneficios automáticos:**
• Reacción: Atacar a criaturas dentro de 5 pies que ataquen a otros
• Las criaturas no pueden usar Desengancharte contigo

📝 No requiere configuración.`
  }
  
  // Check for exact match first
  if (featReminders[featName]) {
    return featReminders[featName]
  }
  
  // Check for partial match
  for (const [key, value] of Object.entries(featReminders)) {
    if (featName.toLowerCase().includes(key.toLowerCase()) || key.toLowerCase().includes(featName.toLowerCase())) {
      return value
    }
  }
  
  // Default reminder for unknown feats
  return `✨ Revisa la descripción del dote en la sección de dotes para ver qué beneficios otorga y si requieren acciones manuales.`
}

const getSpeciesSubtypeConfig = (speciesName: string): SpeciesSubtypeConfig | null => {
  return SPECIES_SUBTYPES[speciesName] || null
}

// Comprehensive Class Features by Level (D&D 2024)
interface ClassFeature {
  name: string
  description: string
  type: 'feature' | 'improvement' | 'choice' | 'spell' | 'asi'
}

interface ClassLevelData {
  level: number
  proficiencyBonus: number
  features: ClassFeature[]
}

const CLASS_FEATURES_BY_LEVEL: Record<string, ClassLevelData[]> = {
  'Barbarian': [
    { level: 1, proficiencyBonus: 2, features: [
      { name: 'Rage', description: 'Como acción bonus, entras en furia durante 1 minuto. Obtienes ventaja en pruebas de Fuerza y bonificador de daño cuerpo a cuerpo (+2). Resistencia al daño físico. 2 usos por descanso largo.', type: 'feature' },
      { name: 'Defensa sin Armadura', description: 'Mientras no llevas armadura, tu CA = 10 + modificador de Des + modificador de Con.', type: 'feature' },
      { name: 'Dados de Golpe', description: '1d12 por nivel de Bárbaro. Recuperas la mitad tras un descanso corto.', type: 'feature' }
    ]},
    { level: 2, proficiencyBonus: 2, features: [
      { name: 'Reckless Attack', description: 'Al hacer tu primer ataque en tu turno, puedes decidir atacar temerariamente. Obtienes ventaja en todas las tiradas de ataque cuerpo a cuerpo con Fuerza este turno, pero los enemigos también tienen ventaja contra ti.', type: 'feature' },
      { name: 'Danger Sense', description: 'Tienes ventaja en tiradas de salvación contra trampas, hechizos y efectos que puedas ver y que te obliguen a hacer una tirada de salvación de Destreza.', type: 'feature' }
    ]},
    { level: 3, proficiencyBonus: 2, features: [
      { name: 'Primal Path', description: 'Eliges una senda primitiva que te otorga características adicionales. Opciones: Path of the Berserker, Path of the Wild Magic, Path of the Beast, Path of the Zealot, Path of the Ancestral Guardian.', type: 'choice' }
    ]},
    { level: 4, proficiencyBonus: 2, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 5, proficiencyBonus: 3, features: [
      { name: 'Extra Attack', description: 'Puedes atacar dos veces en lugar de una cuando tomas la acción de Ataque en tu turno.', type: 'improvement' },
      { name: 'Fast Movement', description: 'Tu velocidad aumenta en 10 pies mientras no lleves armadura pesada.', type: 'improvement' }
    ]},
    { level: 6, proficiencyBonus: 3, features: [
      { name: 'Característica de Senda Primitiva', description: 'Obtienes una característica adicional de tu Senda Primitiva elegida a nivel 3.', type: 'feature' }
    ]},
    { level: 7, proficiencyBonus: 3, features: [
      { name: 'Feral Instinct', description: 'Tienes ventaja en las tiradas de iniciativa. Si te sorprenden al inicio del combate, puedes actuar normalmente en tu primer turno si entras en furia inmediatamente.', type: 'feature' }
    ]},
    { level: 8, proficiencyBonus: 3, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 9, proficiencyBonus: 4, features: [
      { name: 'Brutal Critical', description: 'Cuando golpeas un crítico con un ataque cuerpo a cuerpo, añades un dado de arma adicional al daño (total 3 dados).', type: 'improvement' }
    ]},
    { level: 10, proficiencyBonus: 4, features: [
      { name: 'Característica de Senda Primitiva', description: 'Obtienes una característica adicional de tu Senda Primitiva elegida.', type: 'feature' }
    ]},
    { level: 11, proficiencyBonus: 4, features: [
      { name: 'Relentless Rage', description: 'Si tu vida cae a 0 mientras estás en furia, puedes hacer una tirada de salvación de Constitución (CD 10) para caer a 1 pg en su lugar. La CD aumenta en 5 cada uso exitoso.', type: 'feature' }
    ]},
    { level: 12, proficiencyBonus: 4, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 13, proficiencyBonus: 5, features: [
      { name: 'Brutal Critical (mejora)', description: 'Ahora añades dos dados de arma adicionales en críticos (total 4 dados).', type: 'improvement' }
    ]},
    { level: 14, proficiencyBonus: 5, features: [
      { name: 'Característica de Senda Primitiva', description: 'Obtienes la característica final de tu Senda Primitiva elegida.', type: 'feature' }
    ]},
    { level: 15, proficiencyBonus: 5, features: [
      { name: 'Persistent Rage', description: 'Tu furia solo termina prematuramente si caes inconsciente o eliges terminarla.', type: 'improvement' }
    ]},
    { level: 16, proficiencyBonus: 5, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 17, proficiencyBonus: 6, features: [
      { name: 'Brutal Critical (mejora final)', description: 'Ahora añades tres dados de arma adicionales en críticos (total 5 dados).', type: 'improvement' }
    ]},
    { level: 18, proficiencyBonus: 6, features: [
      { name: 'Indomitable Might', description: 'Si tu tirada de Fuerza es menor que tu puntuación de Fuerza, puedes usar esa puntuación en su lugar.', type: 'feature' }
    ]},
    { level: 19, proficiencyBonus: 6, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 20, proficiencyBonus: 6, features: [
      { name: 'Primal Champion', description: 'Tu Fuerza y Constitución aumentan en 4 cada una, hasta un máximo de 24. Tu furia es ilimitada.', type: 'feature' }
    ]}
  ],
  'Bard': [
    { level: 1, proficiencyBonus: 2, features: [
      { name: 'Spellcasting', description: 'Puedes lanzar hechizos de bardo usando Carisma como característica de conjuración. Conoces 2 trucos y 4 hechizos de nivel 1. Tienes 2 ranuras de nivel 1.', type: 'spell' },
      { name: 'Bardic Inspiration', description: 'Como acción bonus, puedes dar un dado de inspiración (d6) a una criatura dentro de 60 pies. Puede añadirlo a una tirada de ataque, prueba de característica o tirada de salvación. Usos igual a tu modificador de Carisma por descanso largo.', type: 'feature' }
    ]},
    { level: 2, proficiencyBonus: 2, features: [
      { name: 'Jack of All Trades', description: 'Añades la mitad de tu bonificador de competencia a cualquier prueba de característica que no use tu competencia.', type: 'feature' },
      { name: 'Song of Rest', description: 'Tú o cualquier aliado que pueda oírte recupera 1d6 puntos de vida adicionales al gastar dados de golpe durante un descanso corto.', type: 'feature' }
    ]},
    { level: 3, proficiencyBonus: 2, features: [
      { name: 'Bard College', description: 'Eliges un colegio de bardo. Opciones: College of Lore, College of Valor, College of Glamour, College of Swords, College of Whispers.', type: 'choice' },
      { name: 'Expertise', description: 'Eliges dos de tus competencias en habilidades. Tu bonificador de competencia se duplica para cualquier prueba que use esas habilidades.', type: 'feature' }
    ]},
    { level: 4, proficiencyBonus: 2, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 5, proficiencyBonus: 3, features: [
      { name: 'Font of Inspiration', description: 'Recuperas todos los usos de Inspiración Bardica tras un descanso corto o largo.', type: 'improvement' },
      { name: 'Song of Rest (mejora)', description: 'La curación de Song of Rest aumenta a 1d8.', type: 'improvement' }
    ]},
    { level: 6, proficiencyBonus: 3, features: [
      { name: 'Característica de Colegio de Bardo', description: 'Obtienes una característica adicional de tu Colegio de Bardo elegido a nivel 3.', type: 'feature' },
      { name: 'Countercharm', description: 'Como acción, puedes dar a aliados dentro de 30 pies ventaja en salvaciones contra encantamientos y estar encantados durante 1 minuto.', type: 'feature' }
    ]},
    { level: 7, proficiencyBonus: 3, features: [
      { name: 'Song of Rest (mejora)', description: 'La curación de Song of Rest aumenta a 1d10.', type: 'improvement' }
    ]},
    { level: 8, proficiencyBonus: 3, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 9, proficiencyBonus: 4, features: [
      { name: 'Song of Rest (mejora)', description: 'La curación de Song of Rest aumenta a 1d12.', type: 'improvement' }
    ]},
    { level: 10, proficiencyBonus: 4, features: [
      { name: 'Bardic Inspiration (mejora)', description: 'El dado de Inspiración Bardica aumenta a d10.', type: 'improvement' },
      { name: 'Expertise', description: 'Eliges dos competencias más. Tu bonificador de competencia se duplica para cualquier prueba que use esas habilidades.', type: 'feature' },
      { name: 'Magical Secrets', description: 'Puedes aprender 2 hechizos de cualquier clase. Cuentan como hechizos de bardo para ti.', type: 'feature' }
    ]},
    { level: 11, proficiencyBonus: 4, features: [
      { name: 'Song of Rest (mejora final)', description: 'La curación de Song of Rest aumenta a 2d6.', type: 'improvement' }
    ]},
    { level: 12, proficiencyBonus: 4, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 13, proficiencyBonus: 5, features: [
      { name: 'Song of Rest (mejora)', description: 'La curación de Song of Rest aumenta a 2d8.', type: 'improvement' }
    ]},
    { level: 14, proficiencyBonus: 5, features: [
      { name: 'Característica de Colegio de Bardo', description: 'Obtienes la característica final de tu Colegio de Bardo elegido.', type: 'feature' }
    ]},
    { level: 15, proficiencyBonus: 5, features: [
      { name: 'Bardic Inspiration (mejora)', description: 'El dado de Inspiración Bardica aumenta a d12.', type: 'improvement' }
    ]},
    { level: 16, proficiencyBonus: 5, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 17, proficiencyBonus: 6, features: []},
    { level: 18, proficiencyBonus: 6, features: [
      { name: 'Magical Secrets', description: 'Aprendes 2 hechizos más de cualquier clase.', type: 'feature' }
    ]},
    { level: 19, proficiencyBonus: 6, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 20, proficiencyBonus: 6, features: [
      { name: 'Superior Inspiration', description: 'Cuando tiras iniciativa y no tienes usos de Inspiración Bardica, recuperas un uso.', type: 'feature' }
    ]}
  ],
  'Cleric': [
    { level: 1, proficiencyBonus: 2, features: [
      { name: 'Spellcasting', description: 'Puedes lanzar hechizos de clérigo usando Sabiduría como característica de conjuración. Conoces 3 trucos y preparas Sabiduría + nivel hechizos.', type: 'spell' },
      { name: 'Divine Domain', description: 'Eliges un dominio divino. Opciones: Knowledge, Life, Light, Nature, Tempest, Trickery, War, Order, Peace, Twilight.', type: 'choice' },
      { name: 'Domain Spells', description: 'Obtienes hechizos de dominio automáticamente preparados sin contar en tu límite.', type: 'feature' }
    ]},
    { level: 2, proficiencyBonus: 2, features: [
      { name: 'Channel Divinity', description: 'Obtienes la capacidad de usar Channel Divinity (1 uso por descanso corto/largo). Cada dominio otorga una opción única.', type: 'feature' }
    ]},
    { level: 3, proficiencyBonus: 2, features: [
      { name: 'Channel Divinity (mejora)', description: 'Algunos dominios otorgan una segunda opción de Channel Divinity.', type: 'improvement' }
    ]},
    { level: 4, proficiencyBonus: 2, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 5, proficiencyBonus: 3, features: [
      { name: 'Destroy Undead', description: 'Cuando un hechizo de clérigo afecta a muertos vivientes, puedes destruir instantáneamente aquellos de CR 1/2 o inferior. (CR aumenta con el nivel)', type: 'feature' }
    ]},
    { level: 6, proficiencyBonus: 3, features: [
      { name: 'Channel Divinity (mejora)', description: 'Puedes usar Channel Divinity 2 veces por descanso corto/largo.', type: 'improvement' },
      { name: 'Característica de Dominio', description: 'Obtienes una característica adicional de tu Dominio Divino elegido.', type: 'feature' }
    ]},
    { level: 7, proficiencyBonus: 3, features: []},
    { level: 8, proficiencyBonus: 3, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' },
      { name: 'Destroy Undead (mejora)', description: 'Ahora destruye muertos vivientes de CR 1 o inferior.', type: 'improvement' }
    ]},
    { level: 9, proficiencyBonus: 4, features: []},
    { level: 10, proficiencyBonus: 4, features: [
      { name: 'Divine Intervention', description: 'Puedes invocar a tu deidad para ayuda. 100% de probabilidad. Tras uso exitoso, no puedes usarlo de nuevo durante 7 días.', type: 'feature' }
    ]},
    { level: 11, proficiencyBonus: 4, features: [
      { name: 'Destroy Undead (mejora)', description: 'Ahora destruye muertos vivientes de CR 2 o inferior.', type: 'improvement' }
    ]},
    { level: 12, proficiencyBonus: 4, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 13, proficiencyBonus: 5, features: []},
    { level: 14, proficiencyBonus: 5, features: [
      { name: 'Destroy Undead (mejora)', description: 'Ahora destruye muertos vivientes de CR 3 o inferior.', type: 'improvement' }
    ]},
    { level: 15, proficiencyBonus: 5, features: []},
    { level: 16, proficiencyBonus: 5, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 17, proficiencyBonus: 6, features: [
      { name: 'Destroy Undead (mejora)', description: 'Ahora destruye muertos vivientes de CR 4 o inferior.', type: 'improvement' },
      { name: 'Característica de Dominio', description: 'Obtienes la característica final de tu Dominio Divino elegido.', type: 'feature' }
    ]},
    { level: 18, proficiencyBonus: 6, features: [
      { name: 'Channel Divinity (mejora)', description: 'Puedes usar Channel Divinity 3 veces por descanso corto/largo.', type: 'improvement' }
    ]},
    { level: 19, proficiencyBonus: 6, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 20, proficiencyBonus: 6, features: [
      { name: 'Divine Intervention (mejora)', description: 'Tu invocación divina tiene éxito automáticamente, pero no puedes usarla de nuevo durante 2d6 días.', type: 'improvement' }
    ]}
  ],
  'Fighter': [
    { level: 1, proficiencyBonus: 2, features: [
      { name: 'Fighting Style', description: 'Eliges un estilo de combate. Opciones: Archery (+2 ataque a distancia), Defense (+1 CA), Dueling (+2 daño arma una mano), Great Weapon Fighting (reroll 1s y 2s en daño a dos manos), Protection (reacción para desventaja a enemigo), Two-Weapon Fighting (añade mod Des al daño de segunda arma).', type: 'choice' },
      { name: 'Second Wind', description: 'Como acción bonus, recuperas 1d10 + nivel de luchador puntos de vida. 1 uso por descanso corto/largo.', type: 'feature' }
    ]},
    { level: 2, proficiencyBonus: 2, features: [
      { name: 'Action Surge', description: 'Puedes tomar una acción adicional en tu turno. 1 uso por descanso corto/largo.', type: 'feature' }
    ]},
    { level: 3, proficiencyBonus: 2, features: [
      { name: 'Martial Archetype', description: 'Eliges un arquetipo marcial. Opciones: Champion, Battle Master, Eldritch Knight, Purple Dragon Knight, Arcane Archer, Cavalier, Samurai, Echo Knight.', type: 'choice' }
    ]},
    { level: 4, proficiencyBonus: 2, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 5, proficiencyBonus: 3, features: [
      { name: 'Extra Attack', description: 'Puedes atacar dos veces en lugar de una cuando tomas la acción de Ataque en tu turno.', type: 'improvement' }
    ]},
    { level: 6, proficiencyBonus: 3, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 7, proficiencyBonus: 3, features: [
      { name: 'Característica de Arquetipo Marcial', description: 'Obtienes una característica adicional de tu Arquetipo Marcial elegido.', type: 'feature' }
    ]},
    { level: 8, proficiencyBonus: 3, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 9, proficiencyBonus: 4, features: [
      { name: 'Indomitable', description: 'Puedes rerrollear una salvación que falles. 1 uso por descanso largo.', type: 'feature' }
    ]},
    { level: 10, proficiencyBonus: 4, features: [
      { name: 'Característica de Arquetipo Marcial', description: 'Obtienes una característica adicional de tu Arquetipo Marcial elegido.', type: 'feature' }
    ]},
    { level: 11, proficiencyBonus: 4, features: [
      { name: 'Extra Attack (mejora)', description: 'Puedes atacar tres veces en lugar de una cuando tomas la acción de Ataque en tu turno.', type: 'improvement' }
    ]},
    { level: 12, proficiencyBonus: 4, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 13, proficiencyBonus: 5, features: [
      { name: 'Indomitable (mejora)', description: 'Ahora puedes usar Indomitable 2 veces por descanso largo.', type: 'improvement' }
    ]},
    { level: 14, proficiencyBonus: 5, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 15, proficiencyBonus: 5, features: [
      { name: 'Característica de Arquetipo Marcial', description: 'Obtienes una característica adicional de tu Arquetipo Marcial elegido.', type: 'feature' }
    ]},
    { level: 16, proficiencyBonus: 5, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 17, proficiencyBonus: 6, features: [
      { name: 'Action Surge (mejora)', description: 'Ahora puedes usar Action Surge 2 veces por descanso corto/largo.', type: 'improvement' },
      { name: 'Indomitable (mejora final)', description: 'Ahora puedes usar Indomitable 3 veces por descanso largo.', type: 'improvement' }
    ]},
    { level: 18, proficiencyBonus: 6, features: [
      { name: 'Característica de Arquetipo Marcial', description: 'Obtienes la característica final de tu Arquetipo Marcial elegido.', type: 'feature' }
    ]},
    { level: 19, proficiencyBonus: 6, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 20, proficiencyBonus: 6, features: [
      { name: 'Extra Attack (mejora final)', description: 'Puedes atacar cuatro veces en lugar de una cuando tomas la acción de Ataque en tu turno.', type: 'improvement' }
    ]}
  ],
  'Monk': [
    { level: 1, proficiencyBonus: 2, features: [
      { name: 'Unarmored Defense', description: 'Mientras no llevas armadura ni escudo, tu CA = 10 + modificador de Des + modificador de Sab.', type: 'feature' },
      { name: 'Martial Arts', description: 'Puedes usar Des en lugar de Fuerza para ataques desarmados. Daño desarmado = d4 (aumenta con nivel). Puedes hacer un ataque desarmado como acción bonus tras usar la acción de Ataque.', type: 'feature' }
    ]},
    { level: 2, proficiencyBonus: 2, features: [
      { name: 'Ki', description: 'Obtienes acceso a puntos de Ki = nivel de monje. Puedes usarlos para: Flurry of Blows (2 ataques desarmados bonus), Patient Defense (esquiva como bonus), Step of the Wind (Desengaged o Dash como bonus).', type: 'feature' },
      { name: 'Unarmored Movement', description: 'Tu velocidad aumenta en 10 pies mientras no llevas armadura ni escudo.', type: 'improvement' }
    ]},
    { level: 3, proficiencyBonus: 2, features: [
      { name: 'Monastic Tradition', description: 'Eliges una tradición monástica. Opciones: Way of the Open Hand, Way of Shadow, Way of the Four Elements, Way of the Drunken Master, Way of the Kensei, Way of the Sun Soul.', type: 'choice' },
      { name: 'Deflect Missiles', description: 'Como reacción, puedes reducir el daño de un proyectil en 1d10 + Des + nivel. Si lo reduces a 0, puedes lanzarlo de vuelta.', type: 'feature' }
    ]},
    { level: 4, proficiencyBonus: 2, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' },
      { name: 'Slow Fall', description: 'Puedes usar tu reacción para reducir el daño de caída en 5 × nivel de monje.', type: 'feature' }
    ]},
    { level: 5, proficiencyBonus: 3, features: [
      { name: 'Extra Attack', description: 'Puedes atacar dos veces en lugar de una cuando tomas la acción de Ataque en tu turno.', type: 'improvement' },
      { name: 'Stunning Strike', description: 'Cuando golpeas con un ataque cuerpo a cuerpo, puedes gastar 1 ki para obligar al objetivo a hacer una salvación de Con. Falla = aturdido hasta final de tu siguiente turno.', type: 'feature' }
    ]},
    { level: 6, proficiencyBonus: 3, features: [
      { name: 'Ki-Empowered Strikes', description: 'Tus ataques desarmados cuentan como mágicos para superar resistencias e inmunidades.', type: 'improvement' },
      { name: 'Característica de Tradición Monástica', description: 'Obtienes una característica adicional de tu Tradición Monástica elegida.', type: 'feature' }
    ]},
    { level: 7, proficiencyBonus: 3, features: [
      { name: 'Evasion', description: 'Cuando fallas una salvación de Des que haría la mitad de daño, tomas 0 daño en su lugar. Éxito = mitad de daño.', type: 'feature' },
      { name: 'Stillness of Mind', description: 'Puedes usar tu acción para terminar un efecto que te esté encantando o asustando.', type: 'feature' }
    ]},
    { level: 8, proficiencyBonus: 3, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 9, proficiencyBonus: 4, features: [
      { name: 'Unarmored Movement (mejora)', description: 'Velocidad +20 pies (total +30). Puedes correr por superficies verticales y líquidas.', type: 'improvement' }
    ]},
    { level: 10, proficiencyBonus: 4, features: [
      { name: 'Purity of Body', description: 'Eres inmune a enfermedades y venenos.', type: 'feature' }
    ]},
    { level: 11, proficiencyBonus: 4, features: [
      { name: 'Característica de Tradición Monástica', description: 'Obtienes una característica adicional de tu Tradición Monástica elegida.', type: 'feature' }
    ]},
    { level: 12, proficiencyBonus: 4, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 13, proficiencyBonus: 5, features: [
      { name: 'Tongue of the Sun and Moon', description: 'Puedes entender y hablar cualquier idioma que escuches.', type: 'feature' }
    ]},
    { level: 14, proficiencyBonus: 5, features: [
      { name: 'Diamond Soul', description: 'Tienes competencia en todas las salvaciones. Puedes gastar 1 ki para rerrollear una salvación fallida.', type: 'feature' }
    ]},
    { level: 15, proficiencyBonus: 5, features: [
      { name: 'Timeless Body', description: 'No envejeces y no puedes envejecer mágicamente. No necesitas comer ni beber.', type: 'feature' }
    ]},
    { level: 16, proficiencyBonus: 5, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 17, proficiencyBonus: 6, features: [
      { name: 'Característica de Tradición Monástica', description: 'Obtienes la característica final de tu Tradición Monástica elegida.', type: 'feature' }
    ]},
    { level: 18, proficiencyBonus: 6, features: [
      { name: 'Empty Body', description: 'Puedes gastar 4 ki para volverte invisible por 1 minuto. Como reacción, puedes gastar 1 ki para resistir un ataque con ventaja en la salvación.', type: 'feature' }
    ]},
    { level: 19, proficiencyBonus: 6, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 20, proficiencyBonus: 6, features: [
      { name: 'Perfect Self', description: 'Cuando tiras iniciativa y no tienes ki, recuperas 4 puntos de ki.', type: 'feature' }
    ]}
  ],
  'Paladin': [
    { level: 1, proficiencyBonus: 2, features: [
      { name: 'Divine Sense', description: 'Como acción, detectas celestiales, infernales, elementales y no-muertos dentro de 60 pies. Usos = 1 + mod Car por descanso largo.', type: 'feature' },
      { name: 'Lay on Hands', description: 'Tienes un depósito de curación = 5 × nivel de paladín. Como acción, tocas una criatura y curas cualquier cantidad del depósito. 5 pg = curar una enfermedad o veneno.', type: 'feature' },
      { name: 'Fighting Style', description: 'Eliges un estilo de combate. Opciones: Defense, Dueling, Great Weapon Fighting, Protection.', type: 'choice' }
    ]},
    { level: 2, proficiencyBonus: 2, features: [
      { name: 'Spellcasting', description: 'Puedes lanzar hechizos de paladín usando Carisma como característica de conjuración.', type: 'spell' },
      { name: 'Divine Smite', description: 'Cuando golpeas con un ataque cuerpo a cuerpo, puedes gastar una ranura de hechizo para añadir 2d8 de daño radiante (+1d8 por nivel de ranura). +1d8 extra contra no-muertos y infernales.', type: 'feature' }
    ]},
    { level: 3, proficiencyBonus: 2, features: [
      { name: 'Sacred Oath', description: 'Eliges un juramento sagrado. Opciones: Oath of Devotion, Oath of the Ancients, Oath of Vengeance, Oath of the Crown, Oath of Conquest, Oath of Redemption.', type: 'choice' },
      { name: 'Channel Divinity', description: 'Obtienes opciones de Channel Divinity basadas en tu Juramento Sagrado.', type: 'feature' }
    ]},
    { level: 4, proficiencyBonus: 2, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 5, proficiencyBonus: 3, features: [
      { name: 'Extra Attack', description: 'Puedes atacar dos veces en lugar de una cuando tomas la acción de Ataque en tu turno.', type: 'improvement' }
    ]},
    { level: 6, proficiencyBonus: 3, features: [
      { name: 'Aura of Protection', description: 'Tú y aliados dentro de 10 pies obtenéis +mod Car a todas las salvaciones. Tú siempre lo tienes.', type: 'feature' }
    ]},
    { level: 7, proficiencyBonus: 3, features: [
      { name: 'Característica de Juramento Sagrado', description: 'Obtienes una característica adicional de tu Juramento Sagrado elegido.', type: 'feature' }
    ]},
    { level: 8, proficiencyBonus: 3, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 9, proficiencyBonus: 4, features: []},
    { level: 10, proficiencyBonus: 4, features: [
      { name: 'Aura of Courage', description: 'Tú y aliados dentro de 10 pies sois inmunes a estar asustados.', type: 'feature' }
    ]},
    { level: 11, proficiencyBonus: 4, features: [
      { name: 'Improved Divine Smite', description: 'Tus ataques cuerpo a cuerpo hacen 1d8 de daño radiante adicional extra.', type: 'improvement' }
    ]},
    { level: 12, proficiencyBonus: 4, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 13, proficiencyBonus: 5, features: []},
    { level: 14, proficiencyBonus: 5, features: [
      { name: 'Cleansing Touch', description: 'Como acción, puedes terminar un hechizo en ti o en una criatura voluntaria que toques. Usos = mod Car por descanso largo.', type: 'feature' }
    ]},
    { level: 15, proficiencyBonus: 5, features: [
      { name: 'Característica de Juramento Sagrado', description: 'Obtienes una característica adicional de tu Juramento Sagrado elegido.', type: 'feature' }
    ]},
    { level: 16, proficiencyBonus: 5, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 17, proficiencyBonus: 6, features: []},
    { level: 18, proficiencyBonus: 6, features: [
      { name: 'Aura of Protection (mejora)', description: 'El aura aumenta a 30 pies de radio.', type: 'improvement' },
      { name: 'Aura of Courage (mejora)', description: 'El aura aumenta a 30 pies de radio.', type: 'improvement' }
    ]},
    { level: 19, proficiencyBonus: 6, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 20, proficiencyBonus: 6, features: [
      { name: 'Característica de Juramento Sagrado', description: 'Obtienes la característica final de tu Juramento Sagrado elegido.', type: 'feature' }
    ]}
  ],
  'Ranger': [
    { level: 1, proficiencyBonus: 2, features: [
      { name: 'Favored Enemy', description: 'Tienes ventaja en pruebas de Sabiduría (Supervivencia) para rastrear y en tiradas de Inteligencia para recordar información sobre tu enemigo favorito. +2 de daño contra ellos.', type: 'feature' },
      { name: 'Natural Explorer', description: 'Eres experto en navegación en tu terreno favorito. Ventaja en iniciativa, ignoras terreno difícil, sigiloso a velocidad normal.', type: 'feature' },
      { name: 'Fighting Style', description: 'Eliges un estilo de combate. Opciones: Archery, Defense, Dueling, Two-Weapon Fighting.', type: 'choice' }
    ]},
    { level: 2, proficiencyBonus: 2, features: [
      { name: 'Spellcasting', description: 'Puedes lanzar hechizos de explorador usando Sabiduría como característica de conjuración.', type: 'spell' }
    ]},
    { level: 3, proficiencyBonus: 2, features: [
      { name: 'Ranger Archetype', description: 'Eliges un arquetipo de explorador. Opciones: Hunter, Beast Master, Gloom Stalker, Horizon Walker, Monster Slayer, Swarmkeeper.', type: 'choice' },
      { name: 'Primeval Awareness', description: 'Puedes usar tu acción para detectar la presencia de aberraciones, celestiales, dragones, elementales, fey, infernales y no-muertos dentro de 6 millas.', type: 'feature' }
    ]},
    { level: 4, proficiencyBonus: 2, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 5, proficiencyBonus: 3, features: [
      { name: 'Extra Attack', description: 'Puedes atacar dos veces en lugar de una cuando tomas la acción de Ataque en tu turno.', type: 'improvement' }
    ]},
    { level: 6, proficiencyBonus: 3, features: [
      { name: 'Favored Enemy (mejora)', description: 'Eliges un segundo enemigo favorito y un terreno favorito adicional.', type: 'improvement' }
    ]},
    { level: 7, proficiencyBonus: 3, features: [
      { name: 'Característica de Arquetipo de Explorador', description: 'Obtienes una característica adicional de tu Arquetipo de Explorador elegido.', type: 'feature' }
    ]},
    { level: 8, proficiencyBonus: 3, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' },
      { name: 'Land\'s Stride', description: 'Ignoras terreno difícil no mágico. No puedes ser ralentizado por plantas mágicas.', type: 'feature' }
    ]},
    { level: 9, proficiencyBonus: 4, features: []},
    { level: 10, proficiencyBonus: 4, features: [
      { name: 'Natural Explorer (mejora)', description: 'Eliges un terreno favorito adicional.', type: 'improvement' },
      { name: 'Hide in Plain Sight', description: 'Puedes pasar 1 minuto creando un escondite. +10 a sigilo mientras permaneces inmóvil.', type: 'feature' }
    ]},
    { level: 11, proficiencyBonus: 4, features: [
      { name: 'Característica de Arquetipo de Explorador', description: 'Obtienes una característica adicional de tu Arquetipo de Explorador elegido.', type: 'feature' }
    ]},
    { level: 12, proficiencyBonus: 4, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 13, proficiencyBonus: 5, features: []},
    { level: 14, proficiencyBonus: 5, features: [
      { name: 'Favored Enemy (mejora)', description: 'Eliges un tercer enemigo favorito y un terreno favorito adicional.', type: 'improvement' },
      { name: 'Vanish', description: 'Puedes usar la acción de Esconderse como acción bonus. No puedes ser rastreado por medios mágicos.', type: 'feature' }
    ]},
    { level: 15, proficiencyBonus: 5, features: [
      { name: 'Característica de Arquetipo de Explorador', description: 'Obtienes una característica adicional de tu Arquetipo de Explorador elegido.', type: 'feature' }
    ]},
    { level: 16, proficiencyBonus: 5, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 17, proficiencyBonus: 6, features: []},
    { level: 18, proficiencyBonus: 6, features: [
      { name: 'Feral Senses', description: 'Tienes sentido ciego de 30 pies contra criaturas que no están detrás de cobertura total.', type: 'feature' }
    ]},
    { level: 19, proficiencyBonus: 6, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 20, proficiencyBonus: 6, features: [
      { name: 'Foe Slayer', description: 'Una vez por turno, puedes añadir tu modificador de Sabiduría al ataque o daño contra tu enemigo favorito.', type: 'feature' }
    ]}
  ],
  'Rogue': [
    { level: 1, proficiencyBonus: 2, features: [
      { name: 'Expertise', description: 'Eliges dos de tus competencias en habilidades. Tu bonificador de competencia se duplica para cualquier prueba que use esas habilidades.', type: 'feature' },
      { name: 'Sneak Attack', description: 'Una vez por turno, puedes añadir daño adicional (1d6) cuando golpeas con un ataque con un arma con la que tienes competencia. El ataque debe tener ventaja o un aliado debe estar adyacente al objetivo. Aumenta 1d6 cada nivel impar.', type: 'feature' },
      { name: 'Thieves\' Cant', description: 'Conoces el lenguaje secreto de los ladrones. Puedes comunicarte mensajes ocultos.', type: 'feature' }
    ]},
    { level: 2, proficiencyBonus: 2, features: [
      { name: 'Cunning Action', description: 'Puedes usar tu acción bonus para Desengaged, Dash o Esconderse.', type: 'feature' }
    ]},
    { level: 3, proficiencyBonus: 2, features: [
      { name: 'Roguish Archetype', description: 'Eliges un arquetipo pícaro. Opciones: Thief, Assassin, Arcane Trickster, Inquisitive, Mastermind, Scout, Swashbuckler.', type: 'choice' }
    ]},
    { level: 4, proficiencyBonus: 2, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 5, proficiencyBonus: 3, features: [
      { name: 'Uncanny Dodge', description: 'Como reacción, puedes reducir a la mitad el daño de un ataque que puedas ver.', type: 'feature' },
      { name: 'Sneak Attack (mejora)', description: 'Daño adicional aumenta a 3d6.', type: 'improvement' }
    ]},
    { level: 6, proficiencyBonus: 3, features: [
      { name: 'Expertise', description: 'Eliges dos competencias más. Tu bonificador de competencia se duplica para cualquier prueba que use esas habilidades.', type: 'feature' }
    ]},
    { level: 7, proficiencyBonus: 3, features: [
      { name: 'Evasion', description: 'Cuando fallas una salvación de Des que haría la mitad de daño, tomas 0 daño en su lugar. Éxito = mitad de daño.', type: 'feature' },
      { name: 'Característica de Arquetipo Pícaro', description: 'Obtienes una característica adicional de tu Arquetipo Pícaro elegido.', type: 'feature' }
    ]},
    { level: 8, proficiencyBonus: 3, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 9, proficiencyBonus: 4, features: [
      { name: 'Sneak Attack (mejora)', description: 'Daño adicional aumenta a 5d6.', type: 'improvement' }
    ]},
    { level: 10, proficiencyBonus: 4, features: [
      { name: 'Característica de Arquetipo Pícaro', description: 'Obtienes una característica adicional de tu Arquetipo Pícaro elegido.', type: 'feature' }
    ]},
    { level: 11, proficiencyBonus: 4, features: [
      { name: 'Reliable Talent', description: 'Cuando haces una prueba de habilidad con competencia, un 9 o menos cuenta como 10.', type: 'feature' }
    ]},
    { level: 12, proficiencyBonus: 4, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 13, proficiencyBonus: 5, features: [
      { name: 'Sneak Attack (mejora)', description: 'Daño adicional aumenta a 7d6.', type: 'improvement' }
    ]},
    { level: 14, proficiencyBonus: 5, features: [
      { name: 'Blindsense', description: 'Si eres capaz de oír, eres consciente de la ubicación de cualquier criatura invisible u oculta dentro de 10 pies.', type: 'feature' }
    ]},
    { level: 15, proficiencyBonus: 5, features: [
      { name: 'Slippery Mind', description: 'Obtienes competencia en salvaciones de Sabiduría.', type: 'feature' },
      { name: 'Característica de Arquetipo Pícaro', description: 'Obtienes una característica adicional de tu Arquetipo Pícaro elegido.', type: 'feature' }
    ]},
    { level: 16, proficiencyBonus: 5, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 17, proficiencyBonus: 6, features: [
      { name: 'Sneak Attack (mejora final)', description: 'Daño adicional aumenta a 9d6.', type: 'improvement' }
    ]},
    { level: 18, proficiencyBonus: 6, features: [
      { name: 'Elusive', description: 'Ningún ataque puede tener ventaja contra ti mientras no estés incapacitado.', type: 'feature' }
    ]},
    { level: 19, proficiencyBonus: 6, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 20, proficiencyBonus: 6, features: [
      { name: 'Stroke of Luck', description: 'Si fallas un ataque o prueba de habilidad, puedes gastar tu reacción para tratar la tirada como un 20. 1 uso por descanso corto/largo.', type: 'feature' }
    ]}
  ],
  'Sorcerer': [
    { level: 1, proficiencyBonus: 2, features: [
      { name: 'Spellcasting', description: 'Puedes lanzar hechizos de hechicero usando Carisma como característica de conjuración. Conoces 4 trucos y 2 hechizos de nivel 1.', type: 'spell' },
      { name: 'Sorcerous Origin', description: 'Eliges un origen hechicero. Opciones: Draconic Bloodline, Wild Magic, Divine Soul, Shadow Magic, Storm Sorcery, Aberrant Mind, Clockwork Soul.', type: 'choice' },
      { name: 'Font of Magic', description: 'Obtienes puntos de hechicería = nivel de hechicero. Puedes usarlos para crear ranuras de hechizo o puntos de hechicería.', type: 'feature' }
    ]},
    { level: 2, proficiencyBonus: 2, features: [
      { name: 'Metamagic', description: 'Aprendes 2 opciones de Metamagia. Opciones: Careful Spell, Distant Spell, Empowered Spell, Extended Spell, Heightened Spell, Quickened Spell, Subtle Spell, Twinned Spell.', type: 'feature' }
    ]},
    { level: 3, proficiencyBonus: 2, features: [
      { name: 'Metamagic', description: 'Aprendes 1 opción adicional de Metamagia.', type: 'feature' }
    ]},
    { level: 4, proficiencyBonus: 2, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 5, proficiencyBonus: 3, features: []},
    { level: 6, proficiencyBonus: 3, features: [
      { name: 'Característica de Origen Hechicero', description: 'Obtienes una característica adicional de tu Origen Hechicero elegido.', type: 'feature' }
    ]},
    { level: 7, proficiencyBonus: 3, features: []},
    { level: 8, proficiencyBonus: 3, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 9, proficiencyBonus: 4, features: []},
    { level: 10, proficiencyBonus: 4, features: [
      { name: 'Metamagic', description: 'Aprendes 1 opción adicional de Metamagia.', type: 'feature' }
    ]},
    { level: 11, proficiencyBonus: 4, features: []},
    { level: 12, proficiencyBonus: 4, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 13, proficiencyBonus: 5, features: []},
    { level: 14, proficiencyBonus: 5, features: [
      { name: 'Característica de Origen Hechicero', description: 'Obtienes una característica adicional de tu Origen Hechicero elegido.', type: 'feature' }
    ]},
    { level: 15, proficiencyBonus: 5, features: []},
    { level: 16, proficiencyBonus: 5, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 17, proficiencyBonus: 6, features: [
      { name: 'Metamagic', description: 'Aprendes 1 opción adicional de Metamagia.', type: 'feature' }
    ]},
    { level: 18, proficiencyBonus: 6, features: [
      { name: 'Sorcerous Restoration', description: 'Recuperas 5 puntos de hechicería tras un descanso corto. Una vez por día.', type: 'feature' }
    ]},
    { level: 19, proficiencyBonus: 6, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 20, proficiencyBonus: 6, features: [
      { name: 'Sorcerous Restoration (mejora)', description: 'Recuperas 4 puntos de hechicería al inicio de cada turno si no tienes ninguno.', type: 'improvement' }
    ]}
  ],
  'Warlock': [
    { level: 1, proficiencyBonus: 2, features: [
      { name: 'Otherworldly Patron', description: 'Eliges un patrón sobrenatural. Opciones: The Archfey, The Fiend, The Great Old One, The Celestial, The Hexblade, The Undying, Fathomless, Genie.', type: 'choice' },
      { name: 'Pact Magic', description: 'Puedes lanzar hechizos de brujo usando Carisma como característica de conjuración. Conoces 2 trucos y 2 hechizos. Ranuras de Pacto: todas del nivel más alto disponible.', type: 'spell' },
      { name: 'Eldritch Invocations', description: 'Aprendes 2 invocaciones eldritch. Opciones variadas que otorgan habilidades únicas.', type: 'feature' }
    ]},
    { level: 2, proficiencyBonus: 2, features: [
      { name: 'Eldritch Invocations', description: 'Aprendes 1 invocación eldritch adicional.', type: 'feature' },
      { name: 'Pact Boon', description: 'Eliges un beneficio de pacto. Opciones: Pact of the Chain (familiar mejorado), Pact of the Blade (arma conjurada), Pact of the Tome (libro de sombras).', type: 'choice' }
    ]},
    { level: 3, proficiencyBonus: 2, features: []},
    { level: 4, proficiencyBonus: 2, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 5, proficiencyBonus: 3, features: [
      { name: 'Eldritch Invocations', description: 'Aprendes 1 invocación eldritch adicional.', type: 'feature' }
    ]},
    { level: 6, proficiencyBonus: 3, features: [
      { name: 'Característica de Patrón Sobrenatural', description: 'Obtienes una característica adicional de tu Patrón Sobrenatural elegido.', type: 'feature' }
    ]},
    { level: 7, proficiencyBonus: 3, features: []},
    { level: 8, proficiencyBonus: 3, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 9, proficiencyBonus: 4, features: []},
    { level: 10, proficiencyBonus: 4, features: [
      { name: 'Característica de Patrón Sobrenatural', description: 'Obtienes una característica adicional de tu Patrón Sobrenatural elegido.', type: 'feature' }
    ]},
    { level: 11, proficiencyBonus: 4, features: [
      { name: 'Mystic Arcanum', description: 'Eliges 1 hechizo de nivel 6. Puedes lanzarlo una vez por descanso largo sin usar ranura.', type: 'feature' }
    ]},
    { level: 12, proficiencyBonus: 4, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 13, proficiencyBonus: 5, features: [
      { name: 'Mystic Arcanum', description: 'Eliges 1 hechizo de nivel 7. Puedes lanzarlo una vez por descanso largo sin usar ranura.', type: 'feature' }
    ]},
    { level: 14, proficiencyBonus: 5, features: [
      { name: 'Característica de Patrón Sobrenatural', description: 'Obtienes la característica final de tu Patrón Sobrenatural elegido.', type: 'feature' }
    ]},
    { level: 15, proficiencyBonus: 5, features: [
      { name: 'Mystic Arcanum', description: 'Eliges 1 hechizo de nivel 8. Puedes lanzarlo una vez por descanso largo sin usar ranura.', type: 'feature' }
    ]},
    { level: 16, proficiencyBonus: 5, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 17, proficiencyBonus: 6, features: [
      { name: 'Mystic Arcanum', description: 'Eliges 1 hechizo de nivel 9. Puedes lanzarlo una vez por descanso largo sin usar ranura.', type: 'feature' }
    ]},
    { level: 18, proficiencyBonus: 6, features: []},
    { level: 19, proficiencyBonus: 6, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 20, proficiencyBonus: 6, features: [
      { name: 'Eldritch Master', description: 'Puedes recuperar todas tus ranuras de pacto expandidas como acción. Una vez por descanso largo.', type: 'feature' }
    ]}
  ],
  'Wizard': [
    { level: 1, proficiencyBonus: 2, features: [
      { name: 'Spellcasting', description: 'Puedes lanzar hechizos de mago usando Inteligencia como característica de conjuración. Conoces 3 trucos y tienes un grimorio con 6 hechizos de nivel 1.', type: 'spell' },
      { name: 'Arcane Recovery', description: 'Una vez por día durante un descanso corto, puedes recuperar ranuras de hechizo con un nivel combinado igual a la mitad de tu nivel de mago (redondeado hacia arriba).', type: 'feature' }
    ]},
    { level: 2, proficiencyBonus: 2, features: [
      { name: 'Arcane Tradition', description: 'Eliges una tradición arcana. Opciones: School of Abjuration, School of Conjuration, School of Divination, School of Enchantment, School of Evocation, School of Illusion, School of Necromancy, School of Transmutation, Order of Scribes.', type: 'choice' }
    ]},
    { level: 3, proficiencyBonus: 2, features: []},
    { level: 4, proficiencyBonus: 2, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 5, proficiencyBonus: 3, features: []},
    { level: 6, proficiencyBonus: 3, features: [
      { name: 'Característica de Tradición Arcana', description: 'Obtienes una característica adicional de tu Tradición Arcana elegida.', type: 'feature' }
    ]},
    { level: 7, proficiencyBonus: 3, features: []},
    { level: 8, proficiencyBonus: 3, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 9, proficiencyBonus: 4, features: []},
    { level: 10, proficiencyBonus: 4, features: [
      { name: 'Característica de Tradición Arcana', description: 'Obtienes una característica adicional de tu Tradición Arcana elegida.', type: 'feature' }
    ]},
    { level: 11, proficiencyBonus: 4, features: []},
    { level: 12, proficiencyBonus: 4, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 13, proficiencyBonus: 5, features: []},
    { level: 14, proficiencyBonus: 5, features: [
      { name: 'Característica de Tradición Arcana', description: 'Obtienes una característica adicional de tu Tradición Arcana elegida.', type: 'feature' }
    ]},
    { level: 15, proficiencyBonus: 5, features: []},
    { level: 16, proficiencyBonus: 5, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 17, proficiencyBonus: 6, features: []},
    { level: 18, proficiencyBonus: 6, features: [
      { name: 'Spell Mastery', description: 'Eliges un hechizo de nivel 1 o 2 de tu grimorio. Puedes lanzarlo a su nivel mínimo sin usar ranura.', type: 'feature' }
    ]},
    { level: 19, proficiencyBonus: 6, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 20, proficiencyBonus: 6, features: [
      { name: 'Signature Spells', description: 'Eliges 2 hechizos de nivel 3 de tu grimorio. Siempre están preparados y puedes lanzar cada uno una vez a nivel 3 sin ranura.', type: 'feature' }
    ]}
  ],
  'Druid': [
    { level: 1, proficiencyBonus: 2, features: [
      { name: 'Spellcasting', description: 'Puedes lanzar hechizos de druida usando Sabiduría como característica de conjuración. Conoces 2 trucos y preparas Sabiduría + nivel hechizos.', type: 'spell' },
      { name: 'Druidic', description: 'Conoces el idioma druídico y puedes usarlo para dejar mensajes ocultos.', type: 'feature' }
    ]},
    { level: 2, proficiencyBonus: 2, features: [
      { name: 'Wild Shape', description: 'Puedes transformarte en una bestia de CR 1/4 o inferior (sin nadadores ni voladores hasta nivel 8). Duración = horas igual a la mitad de tu nivel. 2 usos por descanso corto/largo.', type: 'feature' },
      { name: 'Druid Circle', description: 'Eliges un círculo druídico. Opciones: Circle of the Land, Circle of the Moon, Circle of Dreams, Circle of the Shepherd, Circle of Spores, Circle of Stars.', type: 'choice' }
    ]},
    { level: 3, proficiencyBonus: 2, features: []},
    { level: 4, proficiencyBonus: 2, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' },
      { name: 'Wild Shape (mejora)', description: 'Puedes transformarte en bestias de CR 1/2 o inferior.', type: 'improvement' }
    ]},
    { level: 5, proficiencyBonus: 3, features: []},
    { level: 6, proficiencyBonus: 3, features: [
      { name: 'Característica de Círculo Druídico', description: 'Obtienes una característica adicional de tu Círculo Druídico elegido.', type: 'feature' }
    ]},
    { level: 7, proficiencyBonus: 3, features: []},
    { level: 8, proficiencyBonus: 3, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' },
      { name: 'Wild Shape (mejora)', description: 'Puedes transformarte en bestias de CR 1 o inferior. Puedes usar formas nadadoras y voladoras.', type: 'improvement' }
    ]},
    { level: 9, proficiencyBonus: 4, features: []},
    { level: 10, proficiencyBonus: 4, features: [
      { name: 'Característica de Círculo Druídico', description: 'Obtienes una característica adicional de tu Círculo Druídico elegido.', type: 'feature' }
    ]},
    { level: 11, proficiencyBonus: 4, features: []},
    { level: 12, proficiencyBonus: 4, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 13, proficiencyBonus: 5, features: []},
    { level: 14, proficiencyBonus: 5, features: [
      { name: 'Característica de Círculo Druídico', description: 'Obtienes la característica final de tu Círculo Druídico elegido.', type: 'feature' }
    ]},
    { level: 15, proficiencyBonus: 5, features: []},
    { level: 16, proficiencyBonus: 5, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 17, proficiencyBonus: 6, features: []},
    { level: 18, proficiencyBonus: 6, features: [
      { name: 'Timeless Body', description: 'No envejeces y no puedes envejecer mágicamente.', type: 'feature' },
      { name: 'Beast Spells', description: 'Puedes lanzar hechizos en forma de bestia si la forma es apropiada.', type: 'feature' }
    ]},
    { level: 19, proficiencyBonus: 6, features: [
      { name: 'Mejora de Puntuación de Característica', description: 'Puedes aumentar una puntuación de característica en 2, o dos puntuaciones en 1 cada una. Alternativamente, puedes elegir un feat.', type: 'asi' }
    ]},
    { level: 20, proficiencyBonus: 6, features: [
      { name: 'Archdruid', description: 'Puedes usar Wild Shape un número ilimitado de veces. Puedes transformarte en bestias de CR 6 o inferior.', type: 'feature' }
    ]}
  ]
}

// Spells Known by Class and Level (D&D 2024)
const SPELLS_KNOWN_TABLE: Record<string, number[]> = {
  'Bard': [0, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 14, 15, 16, 17, 18, 18, 19, 20, 20],
  'Sorcerer': [0, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 11, 12, 12, 13, 13, 14, 14, 15, 15, 16],
  'Warlock': [0, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 11, 11, 12, 12, 13, 13, 14, 14, 15, 15],
  'Ranger': [0, 0, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11],
  // Cleric, Druid, Wizard, Paladin prepare spells instead
}

const CANTRIPS_KNOWN_TABLE: Record<string, number[]> = {
  'Bard': [0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4],
  'Cleric': [0, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5],
  'Druid': [0, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4],
  'Sorcerer': [0, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4],
  'Warlock': [0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4],
  'Wizard': [0, 3, 3, 3, 3, 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5],
  // Paladin and Ranger don't have cantrips by default
}

// Get max spell level accessible by class and character level
const getMaxSpellLevel = (className: string, characterLevel: number): number => {
  // Paladins and Rangers get spells later
  if (className === 'Paladin' || className === 'Ranger') {
    if (characterLevel < 2) return 0
    if (characterLevel < 5) return 1
    if (characterLevel < 9) return 2
    if (characterLevel < 13) return 3
    if (characterLevel < 17) return 4
    return 5
  }
  // Full casters
  if (['Bard', 'Cleric', 'Druid', 'Sorcerer', 'Wizard', 'Warlock'].includes(className)) {
    if (characterLevel < 3) return 1
    if (characterLevel < 5) return 2
    if (characterLevel < 7) return 3
    if (characterLevel < 9) return 4
    if (characterLevel < 11) return 5
    if (characterLevel < 13) return 6
    if (characterLevel < 15) return 7
    if (characterLevel < 17) return 8
    return 9
  }
  return 0
}

// Get spellcasting type for a class
type SpellcastingType = 'known' | 'prepared' | 'book' | 'pact' | 'none'
const getSpellcastingType = (className: string): SpellcastingType => {
  switch(className) {
    case 'Bard':
    case 'Sorcerer':
    case 'Ranger':
      return 'known'
    case 'Warlock':
      return 'pact'
    case 'Wizard':
      return 'book' // Wizard prepares from spellbook
    case 'Cleric':
    case 'Druid':
    case 'Paladin':
      return 'prepared'
    default:
      return 'none'
  }
}

// Get max spells known for classes with fixed spells known
const getMaxSpellsKnown = (className: string, level: number): number => {
  const table = SPELLS_KNOWN_TABLE[className]
  if (!table) return 0
  return table[level] || 0
}

// Get max cantrips known
const getMaxCantripsKnown = (className: string, level: number): number => {
  const table = CANTRIPS_KNOWN_TABLE[className]
  if (!table) return 0
  return table[level] || 0
}

// Max spells prepared by class and level (D&D 2024)
const getMaxPreparedSpells = (className: string, level: number, abilityScore: number): number => {
  const modifier = getModifier(abilityScore)
  switch(className) {
    case 'Cleric':
    case 'Druid':
    case 'Wizard':
      return level + modifier // Wisdom or Intelligence + level
    case 'Paladin':
      return Math.max(1, Math.floor(level / 2) + modifier) // Half level + Charisma
    case 'Bard':
      return Math.max(1, level + modifier) // Can prepare from known spells in 2024
    case 'Ranger':
      return Math.max(1, Math.floor(level / 2) + modifier) // Half level + Wisdom
    case 'Sorcerer':
    case 'Warlock':
      return 0 // These classes don't prepare, they have fixed spells known
    default:
      return 0
  }
}

// Get spells known breakdown by spell level for a character
interface SpellKnowledge {
  cantripsKnown: number
  cantripsMax: number
  spellsKnown: number
  spellsMax: number
  spellsPrepared: number
  spellsPreparedMax: number
  maxSpellLevel: number
  spellcastingType: SpellcastingType
  // For each spell level, how many they know
  spellsByLevel: { level: number; known: number; max: number }[]
  // Multiclass breakdown
  isMulticlass: boolean
  classBreakdown: { className: string; level: number; cantrips: number; spellsKnown: number; spellsPrepared: number; type: SpellcastingType }[]
}

const calculateSpellKnowledge = (
  className: string,
  level: number,
  abilityScore: number,
  characterSpells: any[],
  classLevels?: any[], // For multiclass support
  character?: any // For ability score access in multiclass
): SpellKnowledge => {
  // Check if character is multiclass
  const isMulticlass = classLevels && classLevels.length > 0
  
  // If multiclass, calculate sums from all classes
  if (isMulticlass && classLevels) {
    let totalCantripsMax = 0
    let totalSpellsKnownMax = 0
    let totalSpellsPreparedMax = 0
    let maxSpellLevel = 0
    const classBreakdown: { className: string; level: number; cantrips: number; spellsKnown: number; spellsPrepared: number; type: SpellcastingType }[] = []
    
    // Track which classes are which type for display purposes
    let primaryType: SpellcastingType = 'none'
    
    for (const cl of classLevels) {
      const cls = cl.class
      if (!cls) continue
      
      const classLevel = cl.level || 0
      const classType = getSpellcastingType(cls.name)
      
      // Skip non-spellcasting classes
      if (classType === 'none') continue
      
      // Get ability score for this class
      let classAbilityScore = 10
      if (character) {
        const classAbility = SPELLCASTING_ABILITY[cls.name]
        switch (classAbility) {
          case 'intelligence': classAbilityScore = character.intelligence || 10; break
          case 'wisdom': classAbilityScore = character.wisdom || 10; break
          case 'charisma': classAbilityScore = character.charisma || 10; break
        }
      }
      
      // Cantrips from this class
      const classCantrips = getMaxCantripsKnown(cls.name, classLevel)
      totalCantripsMax += classCantrips
      
      // Spells known or prepared from this class
      let classSpellsKnown = 0
      let classSpellsPrepared = 0
      
      if (classType === 'known' || classType === 'pact') {
        classSpellsKnown = getMaxSpellsKnown(cls.name, classLevel)
        totalSpellsKnownMax += classSpellsKnown
      } else if (classType === 'prepared' || classType === 'book') {
        // For prepared casters, calculate based on their spellcasting ability
        classSpellsPrepared = getMaxPreparedSpells(cls.name, classLevel, classAbilityScore)
        totalSpellsPreparedMax += classSpellsPrepared
      }
      
      // Track max spell level
      const classMaxSpell = getMaxSpellLevel(cls.name, classLevel)
      if (classMaxSpell > maxSpellLevel) {
        maxSpellLevel = classMaxSpell
      }
      
      // Set primary type based on primary class
      if (cl.isPrimary) {
        primaryType = classType
      }
      
      classBreakdown.push({
        className: cls.name,
        level: classLevel,
        cantrips: classCantrips,
        spellsKnown: classSpellsKnown,
        spellsPrepared: classSpellsPrepared,
        type: classType
      })
    }
    
    // Count current spells
    const cantripsKnown = characterSpells.filter(cs => cs.spell?.level === 0 && cs.known !== false).length
    const preparedSpells = characterSpells.filter(cs => cs.prepared && cs.spell?.level > 0 && cs.source === 'class').length
    const spellsKnown = characterSpells.filter(cs => cs.spell?.level > 0 && cs.known !== false).length
    
    // Build spells by level
    const spellsByLevel = []
    for (let lvl = 1; lvl <= maxSpellLevel; lvl++) {
      const knownAtLevel = characterSpells.filter(cs => cs.spell?.level === lvl && cs.known !== false).length
      const preparedAtLevel = characterSpells.filter(cs => cs.spell?.level === lvl && cs.prepared && cs.source === 'class').length
      spellsByLevel.push({
        level: lvl,
        known: preparedSpells,
        max: totalSpellsKnownMax + totalSpellsPreparedMax
      })
    }
    
    return {
      cantripsKnown,
      cantripsMax: totalCantripsMax,
      spellsKnown,
      spellsMax: totalSpellsKnownMax || totalSpellsPreparedMax,
      spellsPrepared: preparedSpells,
      spellsPreparedMax: totalSpellsPreparedMax,
      maxSpellLevel,
      spellcastingType: primaryType,
      spellsByLevel,
      isMulticlass: true,
      classBreakdown
    }
  }
  
  // Single class calculation (original logic)
  const spellcastingType = getSpellcastingType(className)
  const maxSpellLevel = getMaxSpellLevel(className, level)
  const cantripsMax = getMaxCantripsKnown(className, level)
  const spellsPreparedMax = getMaxPreparedSpells(className, level, abilityScore)
  
  // Count current spells (exclude non-class spells from prepared count - they don't count toward limit)
  // Sources 'domain', 'species', 'feat' don't count toward limits
  const cantripsKnown = characterSpells.filter(cs => cs.spell?.level === 0 && cs.known !== false).length
  const preparedSpells = characterSpells.filter(cs => cs.prepared && cs.spell?.level > 0 && cs.source === 'class').length
  
  // For classes with fixed spells known
  let spellsKnown = 0
  let spellsMax = 0
  
  if (spellcastingType === 'known' || spellcastingType === 'pact') {
    spellsMax = getMaxSpellsKnown(className, level)
    spellsKnown = characterSpells.filter(cs => cs.spell?.level > 0 && cs.known !== false).length
  } else if (spellcastingType === 'prepared') {
    // For prepared casters, "max" is the prepared limit
    spellsMax = spellsPreparedMax
    spellsKnown = characterSpells.filter(cs => cs.spell?.level > 0 && cs.known !== false).length
  } else if (spellcastingType === 'book') {
    // Wizards: show prepared limit, and indicate book
    spellsMax = spellsPreparedMax
    spellsKnown = preparedSpells
  }
  
  // Build spells by level breakdown
  const spellsByLevel = []
  for (let lvl = 1; lvl <= maxSpellLevel; lvl++) {
    const knownAtLevel = characterSpells.filter(cs => cs.spell?.level === lvl && cs.known !== false).length
    const preparedAtLevel = characterSpells.filter(cs => cs.spell?.level === lvl && cs.prepared && cs.source === 'class').length
    spellsByLevel.push({
      level: lvl,
      known: spellcastingType === 'book' ? preparedAtLevel : knownAtLevel,
      max: spellsMax // Total max, not per level
    })
  }
  
  return {
    cantripsKnown,
    cantripsMax,
    spellsKnown,
    spellsMax,
    spellsPrepared: preparedSpells,
    spellsPreparedMax,
    maxSpellLevel,
    spellcastingType,
    spellsByLevel,
    isMulticlass: false,
    classBreakdown: []
  }
}

// Comprehensive Choice Options Data
interface ChoiceOption {
  name: string
  description: string
  benefits: string[]
  source?: string
}

interface ChoiceCategory {
  name: string
  description: string
  options: ChoiceOption[]
}

const CLASS_CHOICE_OPTIONS: Record<string, Record<string, ChoiceCategory>> = {
  'Barbarian': {
    'Primal Path': {
      name: 'Senda Primitiva',
      description: 'Eliges una senda primitiva que te otorga características adicionales a niveles 3, 6, 10 y 14.',
      options: [
        {
          name: 'Path of the Berserker',
          description: 'Un guerrero furioso impulsado por un frenesí incontrolable.',
          benefits: [
            'Nivel 3 - Frenzy: Puedes entrar en frenesí durante tu furia, haciendo un ataque adicional como bonus cada turno. Sufris un nivel de agotamiento cuando termina.',
            'Nivel 6 - Mindless Rage: No puedes ser encantado o asustado mientras estás en furia.',
            'Nivel 10 - Intimidating Presence: Puedes aterrorizar criaturas cercanas como acción.',
            'Nivel 14 - Retaliation: Puedes responder a ser golpeado con un ataque como reacción.'
          ]
        },
        {
          name: 'Path of the Wild Magic',
          description: 'Canaliza la magia salvaje que fluye a través de ti.',
          benefits: [
            'Nivel 3 - Magic Awareness: Puedes detectar magia cercana.',
            'Nivel 3 - Wild Surge: Efectos mágicos aleatorios ocurren cuando entras en furia.',
            'Nivel 6 - Bolstering Magic: Puedes dar bonificaciones a aliados con magia salvaje.',
            'Nivel 10 - Unstable Backlash: Efectos defensivos aleatorios cuando te golpean.',
            'Nivel 14 - Controlled Surge: Puedes elegir el resultado de tu Wild Surge.'
          ]
        },
        {
          name: 'Path of the Beast',
          description: 'Te transformas en una bestia salvaje durante la furia.',
          benefits: [
            'Nivel 3 - Form of the Beast: Elige garras, colmillos o cola para ataques naturales.',
            'Nivel 6 - Bestial Soul: Mejoras a tu forma de bestia.',
            'Nivel 10 - Infectious Fury: Tus ataques pueden causar efectos mentales.',
            'Nivel 14 - Call the Hunt: Puedes dar furia temporal a aliados.'
          ]
        },
        {
          name: 'Path of the Zealot',
          description: 'Un guerrero divino que canaliza la ira de los dioses.',
          benefits: [
            'Nivel 3 - Divine Fury: Tus ataques hacen daño radiante o necrótico adicional.',
            'Nivel 3 - Warrior of the Gods: Puedes ser revivido sin componentes costosos.',
            'Nivel 6 - Fanatical Focus: Puedes rerrollear una salvación fallida.',
            'Nivel 10 - Divine Fury (mejora): Daño adicional aumenta.',
            'Nivel 14 - Rage Beyond Death: Puedes seguir luchando incluso a 0 PG en furia.'
          ]
        },
        {
          name: 'Path of the Ancestral Guardian',
          description: 'Canaliza los espíritus de tus ancestros para proteger a tus aliados.',
          benefits: [
            'Nivel 3 - Ancestral Protectors: Los enemigos que golpeas tienen desventaja contra otros.',
            'Nivel 6 - Spirit Shield: Puedes reducir daño a aliados como reacción.',
            'Nivel 10 - Consult the Spirits: Puedes ver cosas invisibles y obtener ventaja en percepción.',
            'Nivel 14 - Vengeful Ancestors: Tu Spirit Shield también hace daño al atacante.'
          ]
        }
      ]
    }
  },
  'Bard': {
    'Bard College': {
      name: 'Colegio de Bardo',
      description: 'Eliges un colegio de bardo que define tu estilo de actuación y magia.',
      options: [
        {
          name: 'College of Lore',
          description: 'Un erudito que recopila conocimientos y secretos.',
          benefits: [
            'Nivel 3 - Bonus Proficiencies: Ganas 3 competencias adicionales.',
            'Nivel 3 - Cutting Words: Puedes reducir tiradas de enemigos con Inspiración Bardica.',
            'Nivel 6 - Additional Magical Secrets: Aprendes 2 hechizos adicionales de cualquier clase.',
            'Nivel 14 - Peerless Skill: Puedes usar Inspiración Bardica en ti mismo.'
          ]
        },
        {
          name: 'College of Valor',
          description: 'Un skaldo que inspira héroes en el campo de batalla.',
          benefits: [
            'Nivel 3 - Bonus Proficiencies: Ganas competencia con armadura media, escudos y armas marciales.',
            'Nivel 3 - Combat Inspiration: Los aliados pueden añadir Inspiración a daño o CA.',
            'Nivel 6 - Extra Attack: Puedes atacar dos veces por turno.',
            'Nivel 14 - Battle Magic: Puedes hacer un ataque como bonus tras lanzar un hechizo.'
          ]
        },
        {
          name: 'College of Glamour',
          description: 'Un artista que encanta con belleza feérica.',
          benefits: [
            'Nivel 3 - Mantle of Inspiration: Das velocidad temporal y CA bonus a aliados.',
            'Nivel 3 - Enthralling Performance: Encantas audiencias fácilmente.',
            'Nivel 6 - Unbreakable Majesty: Los enemigos tienen desventaja contra tus hechizos.',
            'Nivel 14 - Unbreaking Spirit: Recuperas Inspiración Bardica con descanso corto.'
          ]
        },
        {
          name: 'College of Swords',
          description: 'Un artista marcial que mezcla combate y actuación.',
          benefits: [
            'Nivel 3 - Bonus Proficiencies: Ganas competencia con armadura media y escudos.',
            'Nivel 3 - Blade Flourish: Haces maniestras especiales con tu arma.',
            'Nivel 6 - Extra Attack: Puedes atacar dos veces por turno.',
            'Nivel 14 - Masters Flourish: Tus flourishes son más poderosos.'
          ]
        },
        {
          name: 'College of Whispers',
          description: 'Un manipulador que usa secretos como armas.',
          benefits: [
            'Nivel 3 - Psychic Blades: Tu Inspiración hace daño psíquico adicional.',
            'Nivel 3 - Words of Terror: Puedes aterrorizar criaturas con tu voz.',
            'Nivel 6 - Mantle of Whispers: Puedes adoptar la apariencia de otros.',
            'Nivel 14 - Shadow Lore: Puedes dominar criaturas temporalmente.'
          ]
        }
      ]
    }
  },
  'Cleric': {
    'Divine Domain': {
      name: 'Dominio Divino',
      description: 'Eliges un dominio que representa la naturaleza de tu deidad patrona.',
      options: [
        {
          name: 'Knowledge Domain',
          description: 'Guardián del conocimiento y los secretos.',
          benefits: [
            'Nivel 1 - Blessings of Knowledge: Ganas 2 idiomas y 2 competencias dobles.',
            'Nivel 2 - Channel Divinity: Knowledge of the Ages - Das competencia temporal.',
            'Nivel 6 - Channel Divinity: Read Thoughts - Lees mentes.',
            'Nivel 17 - Visions of the Past: Ves el pasado de objetos y lugares.'
          ]
        },
        {
          name: 'Life Domain',
          description: 'Sanador y protector de los vivos.',
          benefits: [
            'Nivel 1 - Disciple of Life: Tus hechizos de curación son más efectivos.',
            'Nivel 1 - Bonus Proficiency: Ganas competencia con armadura pesada.',
            'Nivel 2 - Channel Divinity: Preserve Life - Curas múltiples criaturas.',
            'Nivel 6 - Blessed Healer: Te curas cuando curas a otros.',
            'Nivel 17 - Supreme Healing: Tus hechizos de curación siempre hacen máximo daño.'
          ]
        },
        {
          name: 'Light Domain',
          description: 'Portador de la luz que ahuyenta las tinieblas.',
          benefits: [
            'Nivel 1 - Light Cantrip: Puedes iluminar objetos.',
            'Nivel 1 - Warding Flare: Puedes dar desventaja a atacantes.',
            'Nivel 2 - Channel Divinity: Radiance of the Dawn - Daño radiante en área.',
            'Nivel 6 - Corona of Light: Emanas luz que daña enemigos.',
            'Nivel 17 - Sunburst: Puedes lanzar Sunburst gratis una vez por día.'
          ]
        },
        {
          name: 'Tempest Domain',
          description: 'Canaliza la furia de las tormentas.',
          benefits: [
            'Nivel 1 - Wrath of the Storm: Dañas enemigos que te golpean.',
            'Nivel 1 - Bonus Proficiencies: Armadura pesada y armas marciales.',
            'Nivel 2 - Channel Divinity: Destructive Wrath - Maximizas daño de rayos/trueno.',
            'Nivel 6 - Thunderbolt Strike: Empujas enemigos con daño de rayos.',
            'Nivel 17 - Stormborn: Puedes volar.'
          ]
        },
        {
          name: 'Trickery Domain',
          description: 'Maestro del engaño y la intriga.',
          benefits: [
            'Nivel 1 - Blessing of the Trickster: Ayudas a otros a ser sigilosos.',
            'Nivel 2 - Channel Divinity: Invoke Duplicity - Creas una ilusión de ti mismo.',
            'Nivel 6 - Channel Divinity: Cloak of Shadows - Te vuelves invisible.',
            'Nivel 17 - Improved Duplicity: Puedes crear múltiples duplicados.'
          ]
        },
        {
          name: 'War Domain',
          description: 'Guerrero sagrado que lidera la batalla.',
          benefits: [
            'Nivel 1 - War Priest: Puedes atacar como bonus acción.',
            'Nivel 1 - Bonus Proficiencies: Armadura pesada, escudos, armas marciales.',
            'Nivel 2 - Channel Divinity: Guided Strike: +10 a un ataque.',
            'Nivel 6 - War Gods Blessing: Aliados hacen ataques adicionales.',
            'Nivel 17 - Avatar of Battle: Resistencia a daño no psíquico.'
          ]
        }
      ]
    }
  },
  'Fighter': {
    'Fighting Style': {
      name: 'Estilo de Combate',
      description: 'Eliges un estilo de combate que define tu técnica marcial.',
      options: [
        {
          name: 'Archery',
          description: 'Maestro del combate a distancia.',
          benefits: ['+2 a las tiradas de ataque con armas a distancia.']
        },
        {
          name: 'Defense',
          description: 'Enfoque defensivo en combate.',
          benefits: ['+1 a la Clase de Armadura mientras llevas armadura.']
        },
        {
          name: 'Dueling',
          description: 'Especialista en combate con una sola arma.',
          benefits: ['+2 al daño cuando empuñas un arma cuerpo a cuerpo en una mano.']
        },
        {
          name: 'Great Weapon Fighting',
          description: 'Maestro de armas a dos manos.',
          benefits: ['Puedes repetir tiradas de 1 y 2 en daño con armas a dos manos.']
        },
        {
          name: 'Protection',
          description: 'Protector de aliados en combate.',
          benefits: ['Puedes usar tu reacción para dar desventaja a un ataque contra un aliado adyacente.']
        },
        {
          name: 'Two-Weapon Fighting',
          description: 'Especialista en combate con dos armas.',
          benefits: ['Puedes añadir tu modificador de característica al daño del ataque bonus con segunda arma.']
        }
      ]
    },
    'Martial Archetype': {
      name: 'Arquetipo Marcial',
      description: 'Eliges un arquetipo marcial que define tu estilo de combate avanzado.',
      options: [
        {
          name: 'Champion',
          description: 'El luchador más simple pero efectivo.',
          benefits: [
            'Nivel 3 - Improved Critical: Tus críticos ocurren con 19-20.',
            'Nivel 7 - Remarkable Athlete: +1/2 competencia a pruebas físicas.',
            'Nivel 10 - Additional Fighting Style: Otro estilo de combate.',
            'Nivel 15 - Superior Critical: Críticos con 18-20.',
            'Nivel 18 - Survivor: Regeneras PG cada turno en combate.'
          ]
        },
        {
          name: 'Battle Master',
          description: 'Maestro táctico con superiores habilidades marciales.',
          benefits: [
            'Nivel 3 - Combat Superiority: Ganas dados de superioridad y maniobras.',
            'Nivel 3 - Student of War: Ganas competencia con herramientas de artesano.',
            'Nivel 7 - Know Your Enemy: Puedes analizar las capacidades de un enemigo.',
            'Nivel 10 - Improved Combat Superiority: Más dados de superioridad.',
            'Nivel 15 - Relentless: Recuperas 1 dado de superioridad al inicio del turno.'
          ]
        },
        {
          name: 'Eldritch Knight',
          description: 'Guerrero que combina armas y magia arcana.',
          benefits: [
            'Nivel 3 - Spellcasting: Puedes lanzar hechizos de mago.',
            'Nivel 3 - War Magic: Ataque bonus tras lanzar un cantrip.',
            'Nivel 7 - War Magic (mejora): Ventaja en concentración.',
            'Nivel 10 - Eldritch Strike: Enemigos tienen desventaja contra tus hechizos.',
            'Nivel 15 - Arcane Charge: Teletransporte con Action Surge.'
          ]
        },
        {
          name: 'Arcane Archer',
          description: 'Arquero que imbuye flechas con magia.',
          benefits: [
            'Nivel 3 - Arcane Lore: Ganas un idioma y competencia con Arcano.',
            'Nivel 3 - Arcane Shots: Flechas mágicas con efectos especiales.',
            'Nivel 7 - Magic Arrow: Tus flechas son mágicas.',
            'Nivel 10 - Curving Shot: Puedes redirigir ataques fallidos.',
            'Nivel 15 - Ever-Ready Shot: Tienes ventaja en iniciativa con arco.'
          ]
        },
        {
          name: 'Cavalier',
          description: 'Jinete y protector del campo de batalla.',
          benefits: [
            'Nivel 3 - Bonus Proficiencies: Animales de montura y armaduras.',
            'Nivel 3 - Unwavering Mark: Proteges a aliados y castigas enemigos.',
            'Nivel 7 - Wardens Maneuver: Reduces daño a aliados.',
            'Nivel 10 - Hold the Line: Ataques de oportunidad inmovilizan.',
            'Nivel 15 - Ferocious Charger: Cargas más poderosas.',
            'Nivel 18 - Vigilant Defender: Ataques de oportunidad adicionales.'
          ]
        },
        {
          name: 'Samurai',
          description: 'Guerrero honorable con determinación inquebrantable.',
          benefits: [
            'Nivel 3 - Bonus Proficiency: Un idioma y una habilidad.',
            'Nivel 3 - Fighting Spirit: Ventaja en ataques y CA temporal.',
            'Nivel 7 - Elegant Courtier: Bonificación en interacciones sociales.',
            'Nivel 10 - Tireless Spirit: Recuperas Fighting Spirit.',
            'Nivel 15 - Strength Before Death: Actúas antes de morir.',
            'Nivel 18 - Rapid Strike: Ataques adicionales con ventaja.'
          ]
        }
      ]
    }
  },
  'Monk': {
    'Monastic Tradition': {
      name: 'Tradición Monástica',
      description: 'Eliges una tradición que define tu camino espiritual y marcial.',
      options: [
        {
          name: 'Way of the Open Hand',
          description: 'El camino clásico del monje guerrero.',
          benefits: [
            'Nivel 3 - Open Hand Technique: Efectos especiales con Flurry of Blows.',
            'Nivel 6 - Wholeness of Body: Te curas con ki.',
            'Nivel 11 - Tranquility: Aura de calma y protección.',
            'Nivel 17 - Quivering Palm: Ataque devastador que puede matar.'
          ]
        },
        {
          name: 'Way of Shadow',
          description: 'Monje sigiloso que manipula las sombras.',
          benefits: [
            'Nivel 3 - Shadow Arts: Hechizos de sombra con ki.',
            'Nivel 6 - Shadow Step: Teletransporte entre sombras.',
            'Nivel 11 - Cloak of Shadows: Invisibilidad con ki.',
            'Nivel 17 - Opportunist: Ataque bonus contra enemigos golpeados.'
          ]
        },
        {
          name: 'Way of the Four Elements',
          description: 'Canaliza los elementos en combate.',
          benefits: [
            'Nivel 3 - Elemental Disciplines: Habilidades elementales con ki.',
            'Nivel 6 - Elemental Disciplines adicionales.',
            'Nivel 11 - Elemental Disciplines adicionales.',
            'Nivel 17 - Elemental Disciplines adicionales.'
          ]
        },
        {
          name: 'Way of the Drunken Master',
          description: 'Estilo de combate impredecible y engañoso.',
          benefits: [
            'Nivel 3 - Drunken Technique: Movimiento adicional y CA en Flurry.',
            'Nivel 6 - Tipsy Sway: Puedes atacar a enemigos que te golpean.',
            'Nivel 11 - Drunkards Luck: Modificas tiradas con ki.',
            'Nivel 17 - Intoxicated Frenzy: Ataques múltiples a diferentes enemigos.'
          ]
        },
        {
          name: 'Way of the Kensei',
          description: 'Monje guerrero que perfecciona el uso de armas.',
          benefits: [
            'Nivel 3 - Path of the Kensei: Armas elegidas con bonificaciones.',
            'Nivel 6 - One with the Blade: Armas mágicas y curación.',
            'Nivel 11 - Sharpen the Blade: Bonificación de daño con ki.',
            'Nivel 17 - Unerring Accuracy: Re-rolls de ataques fallidos.'
          ]
        },
        {
          name: 'Way of the Sun Soul',
          description: 'Canaliza energía solar en combate.',
          benefits: [
            'Nivel 3 - Radiant Sun Bolt: Proyectiles de energía solar.',
            'Nivel 6 - Searing Arc Strike: Conos de fuego con ki.',
            'Nivel 11 - Searing Sunburst: Explosión de luz solar.',
            'Nivel 17 - Sun Shield: Aura de luz que daña enemigos.'
          ]
        }
      ]
    }
  },
  'Paladin': {
    'Fighting Style': {
      name: 'Estilo de Combate',
      description: 'Eliges un estilo de combate paladinesco.',
      options: [
        {
          name: 'Defense',
          description: 'Enfoque defensivo.',
          benefits: ['+1 a la Clase de Armadura.']
        },
        {
          name: 'Dueling',
          description: 'Especialista en combate con una sola arma.',
          benefits: ['+2 al daño con arma en una mano.']
        },
        {
          name: 'Great Weapon Fighting',
          description: 'Maestro de armas a dos manos.',
          benefits: ['Re-roll de 1s y 2s en daño.']
        },
        {
          name: 'Protection',
          description: 'Protector de aliados.',
          benefits: ['Reacción para dar desventaja a ataques contra aliados.']
        },
        {
          name: 'Blessed Warrior',
          description: 'Paladín con trucos sagrados.',
          benefits: ['Ganas 2 trucos de clérigo que usan Carisma.']
        }
      ]
    },
    'Sacred Oath': {
      name: 'Juramento Sagrado',
      description: 'Eliges un juramento que define tu misión divina.',
      options: [
        {
          name: 'Oath of Devotion',
          description: 'El paladín clásico de la luz y la justicia.',
          benefits: [
            'Nivel 3 - Tenets: Honestidad, Coraje, Compasión, Honor.',
            'Nivel 3 - Sacred Weapon: Tu arma brilla y tiene bonificación.',
            'Nivel 3 - Turn the Unholy: Ahuyentas no-muertos e infernales.',
            'Nivel 7 - Aura of Devotion: Inmunidad a encantos para ti y aliados.',
            'Nivel 15 - Purity of Spirit: Protección constante.',
            'Nivel 20 - Holy Nimbus: Aura de luz que daña enemigos.'
          ]
        },
        {
          name: 'Oath of the Ancients',
          description: 'Protector de la luz y la naturaleza.',
          benefits: [
            'Nivel 3 - Tenets: Encender la Luz, Refugio de la Luz, Preservar la Luz.',
            'Nivel 3 - Natures Wrath: Enredaderas que inmovilizan.',
            'Nivel 3 - Turn the Faithless: Ahuyentas fey e infernales.',
            'Nivel 7 - Aura of Warding: Resistencia a daño de hechizos.',
            'Nivel 15 - Undying Sentinel: No mueres fácilmente.',
            'Nivel 20 - Elder Champion: Te transformas en un guardián feérico.'
          ]
        },
        {
          name: 'Oath of Vengeance',
          description: 'Cazador implacable del mal.',
          benefits: [
            'Nivel 3 - Tenets: Lucha al Mal, Sin Cuartel, Justicia sobre Compasión.',
            'Nivel 3 - Vow of Enmity: Ventaja contra un enemigo.',
            'Nivel 3 - Relentless Avenger: Movimiento extra tras ataques de oportunidad.',
            'Nivel 7 - Relentless Avenger (mejora): Ataques de oportunidad mejorados.',
            'Nivel 15 - Soul of Vengeance: Ataques bonus contra tu objetivo.',
            'Nivel 20 - Angel of Vengeance: Te transformas en un ángel vengador.'
          ]
        },
        {
          name: 'Oath of Conquest',
          description: 'Conquistador que impone orden mediante la fuerza.',
          benefits: [
            'Nivel 3 - Tenets: Fuerza Superior, Fuego Purificador, Fuerza en Miedo.',
            'Nivel 3 - Conquering Presence: Asustas enemigos en área.',
            'Nivel 3 - Guided Strike: +10 a un ataque.',
            'Nivel 7 - Aura of Conquest: Enemigos asustados no pueden moverse.',
            'Nivel 15 - Scornful Rebuke: Enemigos sufren daño al golpearte.',
            'Nivel 20 - Invincible Conqueror: Eres inmune a casi todo temporalmente.'
          ]
        },
        {
          name: 'Oath of Redemption',
          description: 'Pacificador que busca redimir incluso a los malvados.',
          benefits: [
            'Nivel 3 - Tenets: Paz, Inocencia, Paciencia, Sabiduría.',
            'Nivel 3 - Emissary of Peace: Ventaja en carisma.',
            'Nivel 3 - Rebuke the Violent: Daño reflejado a atacantes.',
            'Nivel 7 - Aura of the Guardian: Absorbes daño de aliados.',
            'Nivel 15 - Protective Spirit: Te curas automáticamente.',
            'Nivel 20 - Emissary of Redemption: Resistencia y curación mejorada.'
          ]
        }
      ]
    }
  },
  'Ranger': {
    'Fighting Style': {
      name: 'Estilo de Combate',
      description: 'Eliges un estilo de combate para el explorador.',
      options: [
        {
          name: 'Archery',
          description: 'Maestro del arco.',
          benefits: ['+2 a ataques a distancia.']
        },
        {
          name: 'Defense',
          description: 'Protección adicional.',
          benefits: ['+1 a CA.']
        },
        {
          name: 'Dueling',
          description: 'Combate con una mano.',
          benefits: ['+2 al daño.']
        },
        {
          name: 'Two-Weapon Fighting',
          description: 'Dos armas.',
          benefits: ['Modificador de daño al ataque bonus.']
        },
        {
          name: 'Druidic Warrior',
          description: 'Explorador con trucos druídicos.',
          benefits: ['Ganas 2 trucos de druida que usan Sabiduría.']
        }
      ]
    },
    'Ranger Archetype': {
      name: 'Arquetipo de Explorador',
      description: 'Eliges un arquetipo que define tu método de exploración.',
      options: [
        {
          name: 'Hunter',
          description: 'El explorador versátil y adaptativo.',
          benefits: [
            'Nivel 3 - Hunters Prey: Elige entre Colossus Slayer, Giant Killer, o Horde Breaker.',
            'Nivel 7 - Defensive Tactics: Escape the Horde, Multiattack Defense, o Steel Will.',
            'Nivel 11 - Multiattack: Volley o Whirlwind Attack.',
            'Nivel 15 - Superior Hunters Defense: Evasion, Stand Against the Tide, o Uncanny Dodge.'
          ]
        },
        {
          name: 'Beast Master',
          description: 'Explorador con un compañero animal.',
          benefits: [
            'Nivel 3 - Rangers Companion: Una bestia leal te obedece.',
            'Nivel 7 - Exceptional Training: Tu bestia es más efectiva.',
            'Nivel 11 - Bestial Fury: Tu bestia hace múltiples ataques.',
            'Nivel 15 - Share Spells: Tus hechizos afectan a tu bestia.'
          ]
        },
        {
          name: 'Gloom Stalker',
          description: 'Cazador de la oscuridad.',
          benefits: [
            'Nivel 3 - Dread Ambusher: Velocidad y ataques extra en primera ronda.',
            'Nivel 3 - Umbral Sight: Visión en la oscuridad superior.',
            'Nivel 7 - Iron Mind: Salvaciones mejoradas.',
            'Nivel 11 - Stalkers Flurry: Ataques adicionales.',
            'Nivel 15 - Shadowy Dodge: Evitas ataques en oscuridad.'
          ]
        },
        {
          name: 'Horizon Walker',
          description: 'Viajero entre planos.',
          benefits: [
            'Nivel 3 - Detect Portal: Detectas portales planares.',
            'Nivel 3 - Planar Warrior: Daño extra planar.',
            'Nivel 7 - Ethereal Step: Teletransporte etéreo.',
            'Nivel 11 - Distant Strike: Múltiples ataques con teletransporte.',
            'Nivel 15 - Spectral Defense: Reducción de daño.'
          ]
        },
        {
          name: 'Monster Slayer',
          description: 'Especialista en cazar monstruos.',
          benefits: [
            'Nivel 3 - Hunters Sense: Conoces vulnerabilidades.',
            'Nivel 3 - Slayers Prey: Daño extra contra tu presa.',
            'Nivel 7 - Supernatural Defense: Bonificaciones defensivas.',
            'Nivel 11 - Magic-Users Nemesis: Contrarrestas magia.',
            'Nivel 15 - Slayers Counter: Ataque cuando te atacan.'
          ]
        },
        {
          name: 'Swarmkeeper',
          description: 'Rodeado de espíritus naturales diminutos.',
          benefits: [
            'Nivel 3 - Swarm: Espíritus te rodean y ayudan.',
            'Nivel 3 - Gathered Swarm: Controlas tu enjambre.',
            'Nivel 7 - Writhing Tide: Defensa mejorada.',
            'Nivel 11 - Storm of Minions: Daño en área.',
            'Nivel 15 - Swarming Dispersal: Teletransporte con enjambre.'
          ]
        }
      ]
    }
  },
  'Rogue': {
    'Roguish Archetype': {
      name: 'Arquetipo Pícaro',
      description: 'Eliges un arquetipo que define tu estilo de pícaro.',
      options: [
        {
          name: 'Thief',
          description: 'El ladrón clásico y hábil.',
          benefits: [
            'Nivel 3 - Fast Hands: Acción adicional para usar objetos.',
            'Nivel 3 - Second-Story Work: Trepar y saltar mejorado.',
            'Nivel 9 - Supreme Sneak: Ventaja en sigilo.',
            'Nivel 13 - Use Magic Device: Usas cualquier objeto mágico.',
            'Nivel 17 - Thiefs Reflexes: Dos turnos en primera ronda.'
          ]
        },
        {
          name: 'Assassin',
          description: 'Asesino profesional que mata desde las sombras.',
          benefits: [
            'Nivel 3 - Bonus Proficiencies: Venenos y kits de disfraz.',
            'Nivel 3 - Assassinate: Ventaja y críticos contra sorprendidos.',
            'Nivel 9 - Infiltration Expertise: Creas identidades falsas.',
            'Nivel 13 - Impostor: Imitas a otros perfectamente.',
            'Nivel 17 - Death Strike: Doble daño o muerte instantánea.'
          ]
        },
        {
          name: 'Arcane Trickster',
          description: 'Pícaro que usa magia arcana.',
          benefits: [
            'Nivel 3 - Mage Hand Legerdemain: Mano espectral para robos.',
            'Nivel 3 - Spellcasting: Hechizos de mago.',
            'Nivel 9 - Magical Ambush: Hechizos con ventaja desde sigilo.',
            'Nivel 13 - Versatile Trickster: Ayuda con Mano Espectral.',
            'Nivel 17 - Spell Thief: Robas hechizos a enemigos.'
          ]
        },
        {
          name: 'Inquisitive',
          description: 'Detective y cazador de la verdad.',
          benefits: [
            'Nivel 3 - Ear for Deceit: Detectas mentiras fácilmente.',
            'Nivel 3 - Eye for Detail: Percepción mejorada.',
            'Nivel 3 - Insightful Fighting: Sneak attack sin ventaja.',
            'Nivel 9 - Steady Eye: Percepción perfecta.',
            'Nivel 13 - Unerring Eye: Detectas ilusiones.',
            'Nivel 17 - Eye for Weakness: Sneak attack mejorado.'
          ]
        },
        {
          name: 'Mastermind',
          description: 'Manipulador estratégico.',
          benefits: [
            'Nivel 3 - Master of Intrigue: Idiomas y habilidades sociales.',
            'Nivel 3 - Master of Tactics: Ayudas a aliados.',
            'Nivel 9 - Insightful Manipulator: Lees a los oponentes.',
            'Nivel 13 - Misdirection: Desvías ataques.',
            'Nivel 17 - Soul of Deceit: Inmune a detección de mentiras.'
          ]
        },
        {
          name: 'Scout',
          description: 'Explorador ágil y mortal.',
          benefits: [
            'Nivel 3 - Skirmisher: Movimiento cuando otros se acercan.',
            'Nivel 3 - Survivalist: Naturaleza y supervivencia.',
            'Nivel 9 - Superior Mobility: +15 pies de velocidad.',
            'Nivel 13 - Ambush Master: Iniciativa mejorada.',
            'Nivel 17 - Sudden Strike: Sneak attack adicional.'
          ]
        },
        {
          name: 'Swashbuckler',
          description: 'Duelista carismático y ágil.',
          benefits: [
            'Nivel 3 - Fancy Footwork: No provocas ataques de oportunidad.',
            'Nivel 3 - Rakish Audacity: Sneak attack en duelos.',
            'Nivel 9 - Panache: Distracción carismática.',
            'Nivel 13 - Elegant Maneuver: Bonificaciones en acrobacias.',
            'Nivel 17 - Masters Duelist: Re-roll de ataques.'
          ]
        }
      ]
    }
  },
  'Sorcerer': {
    'Sorcerous Origin': {
      name: 'Origen Hechicero',
      description: 'Eliges el origen de tu poder mágico innato.',
      options: [
        {
          name: 'Draconic Bloodline',
          description: 'Tu sangre tiene un dragón ancestral.',
          benefits: [
            'Nivel 1 - Dragon Ancestor: Un tipo de dragón te otorga poderes.',
            'Nivel 1 - Draconic Resilience: CA mejorada y más PG.',
            'Nivel 6 - Elemental Affinity: Daño extra de tu elemento.',
            'Nivel 14 - Dragon Wings: Alas de dragón.',
            'Nivel 18 - Draconic Presence: Aura de miedo o encanto.'
          ]
        },
        {
          name: 'Wild Magic',
          description: 'Magia caótica e impredecible.',
          benefits: [
            'Nivel 1 - Wild Magic Surge: Efectos mágicos aleatorios.',
            'Nivel 1 - Tides of Chaos: Ventaja con riesgo de oleada.',
            'Nivel 6 - Bend Luck: Modificas tiradas.',
            'Nivel 14 - Controlled Chaos: Controlas las oleadas.',
            'Nivel 18 - Spell Bombardment: Daño extra aleatorio.'
          ]
        },
        {
          name: 'Divine Soul',
          description: 'Conexión con poder divino.',
          benefits: [
            'Nivel 1 - Divine Magic: Hechizos de clérigo adicionales.',
            'Nivel 1 - Favored by the Gods: Protección divina.',
            'Nivel 6 - Empowered Healing: Curación mejorada.',
            'Nivel 14 - Otherworldly Wings: Alas divinas.',
            'Nivel 18 - Unearthly Recovery: Curación masiva.'
          ]
        },
        {
          name: 'Shadow Magic',
          description: 'Canalizas la oscuridad primordial.',
          benefits: [
            'Nivel 1 - Superior Darkvision: Visión en la oscuridad.',
            'Nivel 1 - Strength of the Grave: Sobrevives a golpes mortales.',
            'Nivel 6 - Hound of Ill Omen: Sombra que ataca.',
            'Nivel 14 - Shadow Walk: Teletransporte en sombras.',
            'Nivel 18 - Umbral Form: Forma de sombra.'
          ]
        },
        {
          name: 'Storm Sorcery',
          description: 'Heredero del poder de los elementos.',
          benefits: [
            'Nivel 1 - Tempestuous Magic: Vuelo después de hechizos.',
            'Nivel 1 - Wind Speaker: Idioma Primordial.',
            'Nivel 6 - Heart of the Storm: Resistencia y daño elemental.',
            'Nivel 14 - Storm Guide: Control del clima.',
            'Nivel 18 - Wind Soul: Inmunidad a rayos y trueno, vuelo.'
          ]
        },
        {
          name: 'Aberrant Mind',
          description: 'Mente tocada por el Lejano Reino.',
          benefits: [
            'Nivel 1 - Telepathic Speech: Telepatía.',
            'Nivel 1 - Psionic Spells: Hechizos psiónicos.',
            'Nivel 6 - Psionic Sorcery: Hechizos con puntos de hechicería.',
            'Nivel 14 - Revelation in Flesh: Mutaciones beneficiosas.',
            'Nivel 18 - Warping Implosion: Explosión psiónica.'
          ]
        },
        {
          name: 'Clockwork Soul',
          description: 'Conectado al orden mecánico del universo.',
          benefits: [
            'Nivel 1 - Clockwork Magic: Hechizos de orden.',
            'Nivel 1 - Restore Balance: Neutralizas ventaja/desventaja.',
            'Nivel 6 - Bastion of Law: Escudo protector.',
            'Nivel 14 - Trance of Order: Perfecta eficiencia.',
            'Nivel 18 - Clockwork Cavalcade: Restauración masiva.'
          ]
        }
      ]
    }
  },
  'Warlock': {
    'Otherworldly Patron': {
      name: 'Patrón Sobrenatural',
      description: 'Eliges un patrón que te otorga tu poder arcano.',
      options: [
        {
          name: 'The Archfey',
          description: 'Tu patrón es un señor feérico.',
          benefits: [
            'Nivel 1 - Fey Presence: Encantas o asustas en área.',
            'Nivel 6 - Misty Escape: Teletransporte cuando te dañan.',
            'Nivel 10 - Beguiling Defenses: Inmune a encantos, reflejas.',
            'Nivel 14 - Dark Delirium: Ilusiones en la mente de otros.'
          ]
        },
        {
          name: 'The Fiend',
          description: 'Tu patrón es un diablo u otro ser inferiornal.',
          benefits: [
            'Nivel 1 - Dark Ones Blessing: PG temporales al matar.',
            'Nivel 6 - Dark Ones Own Luck: Bonificación a tiradas.',
            'Nivel 10 - Fiendish Resilience: Resistencia a un tipo de daño.',
            'Nivel 14 - Hurl Through Hell: Destierro y daño masivo.'
          ]
        },
        {
          name: 'The Great Old One',
          description: 'Tu patrón es una entidad alienígena.',
          benefits: [
            'Nivel 1 - Awakened Mind: Telepatía.',
            'Nivel 6 - Entropic Ward: Protección caótica.',
            'Nivel 10 - Thought Shield: Inmune a lectura mental.',
            'Nivel 14 - Create Thrall: Esclavizas criaturas.'
          ]
        },
        {
          name: 'The Celestial',
          description: 'Tu patrón es un ser celestial.',
          benefits: [
            'Nivel 1 - Bonus Cantrips: Trucos de sanación.',
            'Nivel 1 - Healing Light: Curación con bonificador.',
            'Nivel 6 - Radiant Soul: Resistencia y daño radiante.',
            'Nivel 10 - Celestial Resistance: PG temporales en descanso.',
            'Nivel 14 - Searing Vengeance: Revives con explosión de luz.'
          ]
        },
        {
          name: 'The Hexblade',
          description: 'Tu patrón es una entidad de la espada viviente.',
          benefits: [
            'Nivel 1 - Hexblades Curse: Maldición contra un enemigo.',
            'Nivel 1 - Hex Warrior: Usas Carisma para armas.',
            'Nivel 6 - Accursed Specter: Espectro esclavo.',
            'Nivel 10 - Armor of Hexes: Protección contra malditos.',
            'Nivel 14 - Master of Hexes: Múltiples maldiciones.'
          ]
        },
        {
          name: 'The Undying',
          description: 'Tu patrón es un no-muerto eterno.',
          benefits: [
            'Nivel 1 - Among the Dead: Ventaja contra no-muertos.',
            'Nivel 1 - Defy Death: Sobrevives a muerte.',
            'Nivel 6 - Undying Nature: Envejecimiento detenido.',
            'Nivel 10 - Indestructible Life: Regeneración.',
            'Nivel 14 - Exalted Resilience: Resistencias mejoradas.'
          ]
        }
      ]
    },
    'Pact Boon': {
      name: 'Beneficio de Pacto',
      description: 'Eliges un beneficio que tu patrón te otorga a nivel 2.',
      options: [
        {
          name: 'Pact of the Chain',
          description: 'Ganas un familiar especial.',
          benefits: [
            'Encuentras un familiar mejorado (imp, pseudodragon, quasit, sprite).',
            'Tu familiar puede atacar cuando tú atacas.',
            'Puedes comunicarte telepáticamente con tu familiar.',
            'Tu familiar puede usar tu bonificador de hechizos.'
          ]
        },
        {
          name: 'Pact of the Blade',
          description: 'Puedes conjurar un arma mágica.',
          benefits: [
            'Conjuras un arma cuerpo a cuerpo como acción.',
            'Eres competente con el arma conjurada.',
            'El arma cuenta como mágica.',
            'Puedes transformar un arma mágica en tu arma de pacto.',
            'Nivel 5+: Puedes atacar dos veces con arma de pacto.',
            'Nivel 12+: Puedes usar Carisma para ataque y daño.'
          ]
        },
        {
          name: 'Pact of the Tome',
          description: 'Ganas un libro de sombras.',
          benefits: [
            'Un grimorio que contiene 3 trucos de cualquier clase.',
            'Puedes lanzar esos trucos a voluntad.',
            'El libro es tu foco arcano.',
            'Nivel 5+: Puedes invocar el libro de la nada.',
            'Nivel 12+: Puedes añadir rituales de cualquier clase.'
          ]
        },
        {
          name: 'Pact of the Talisman',
          description: 'Un amuleto que mejora tus habilidades.',
          benefits: [
            'Un amuleto que te da +1d4 a pruebas de habilidad.',
            'Puedes usarlo un número de veces igual a tu bonificador de competencia.',
            'Nivel 5+: Puedes teletransportarte con el talismán.',
            'Nivel 12+: Aliados pueden usar el talismán.'
          ]
        }
      ]
    }
  },
  'Wizard': {
    'Arcane Tradition': {
      name: 'Tradición Arcana',
      description: 'Eliges una escuela de magia para especializarte.',
      options: [
        {
          name: 'School of Abjuration',
          description: 'Especialista en magia protectora.',
          benefits: [
            'Nivel 2 - Abjuration Savant: Tiempo y coste reducido.',
            'Nivel 2 - Arcane Ward: Escudo de absorción de daño.',
            'Nivel 6 - Projected Ward: Proteges a aliados.',
            'Nivel 10 - Improved Abjuration: Bonificación a salvaciones.',
            'Nivel 14 - Spell Resistance: Ventaja contra hechizos.'
          ]
        },
        {
          name: 'School of Conjuration',
          description: 'Maestro de la creación y teletransporte.',
          benefits: [
            'Nivel 2 - Conjuration Savant: Tiempo y coste reducido.',
            'Nivel 2 - Minor Conjuration: Creas objetos pequeños.',
            'Nivel 6 - Benign Transposition: Teletransporte gratuito.',
            'Nivel 10 - Focused Conjuration: Concentración mejorada.',
            'Nivel 14 - Durable Summons: Invocaciones resistentes.'
          ]
        },
        {
          name: 'School of Divination',
          description: 'Vidente del pasado, presente y futuro.',
          benefits: [
            'Nivel 2 - Divination Savant: Tiempo y coste reducido.',
            'Nivel 2 - Portent: Predices y cambias tiradas.',
            'Nivel 6 - Expert Divination: Recuperas ranuras.',
            'Nivel 10 - The Third Eye: Visión mágica.',
            'Nivel 14 - Greater Portent: Portent mejorado.'
          ]
        },
        {
          name: 'School of Enchantment',
          description: 'Manipulador de mentes.',
          benefits: [
            'Nivel 2 - Enchantment Savant: Tiempo y coste reducido.',
            'Nivel 2 - Hypnotic Gaze: Hipnotizas enemigos.',
            'Nivel 6 - Instinctive Charm: Desvías ataques.',
            'Nivel 10 - Split Enchantment: Afetas a dos objetivos.',
            'Nivel 14 - Alter Memories: Borras recuerdos.'
          ]
        },
        {
          name: 'School of Evocation',
          description: 'Maestro del daño elemental.',
          benefits: [
            'Nivel 2 - Evocation Savant: Tiempo y coste reducido.',
            'Nivel 2 - Sculpt Spells: Proteges aliados de tus hechizos.',
            'Nivel 6 - Potent Cantrip: Cantrips siempre hacen daño.',
            'Nivel 10 - Empowered Evocation: Daño extra con hechizos.',
            'Nivel 14 - Overchannel: Máximo daño garantizado.'
          ]
        },
        {
          name: 'School of Illusion',
          description: 'Artista de la decepción.',
          benefits: [
            'Nivel 2 - Illusion Savant: Tiempo y coste reducido.',
            'Nivel 2 - Improved Minor Illusion: Ilusiones mejores.',
            'Nivel 6 - Malleable Illusions: Modificas ilusiones.',
            'Nivel 10 - Illusory Self: Evitas daño con ilusión.',
            'Nivel 14 - Illusory Reality: Tus ilusiones se vuelven reales.'
          ]
        },
        {
          name: 'School of Necromancy',
          description: 'Amo de la vida y la muerte.',
          benefits: [
            'Nivel 2 - Necromancy Savant: Tiempo y coste reducido.',
            'Nivel 2 - Grim Harvest: Recuperas PG al matar.',
            'Nivel 6 - Undead Thralls: Esqueletos y zombis mejorados.',
            'Nivel 10 - Inured to Undeath: Resistencia a necrótico.',
            'Nivel 14 - Command Undead: Controlas no-muertos.'
          ]
        },
        {
          name: 'School of Transmutation',
          description: 'Transformador de la realidad.',
          benefits: [
            'Nivel 2 - Transmutation Savant: Tiempo y coste reducido.',
            'Nivel 2 - Minor Alchemy: Transmutación menor.',
            'Nivel 6 - Transmuters Stone: Piedra con poderes.',
            'Nivel 10 - Shapechanger: Polimorfia.',
            'Nivel 14 - Master Transmuter: Transmutación mayor.'
          ]
        }
      ]
    }
  },
  'Druid': {
    'Druid Circle': {
      name: 'Círculo Druídico',
      description: 'Eliges un círculo que define tu conexión con la naturaleza.',
      options: [
        {
          name: 'Circle of the Land',
          description: 'Druida conectado a un tipo de terreno específico.',
          benefits: [
            'Nivel 2 - Bonus Cantrip: Un truco adicional.',
            'Nivel 2 - Natural Recovery: Recuperas ranuras en descanso corto.',
            'Nivel 2 - Circle Spells: Hechizos adicionales por terreno.',
            'Nivel 6 - Lands Stride: Ignoras terreno difícil.',
            'Nivel 10 - Natures Ward: Inmunidad a encantos y miedo.',
            'Nivel 14 - Natures Sanctuary: Bestias y plantas no te atacan.'
          ]
        },
        {
          name: 'Circle of the Moon',
          description: 'Druida que domina la forma salvaje.',
          benefits: [
            'Nivel 2 - Combat Wild Shape: Formas más poderosas.',
            'Nivel 2 - Circle Forms: CR más alto para Wild Shape.',
            'Nivel 6 - Primal Strike: Ataques mágicos en forma bestial.',
            'Nivel 10 - Elemental Wild Shape: Te transformas en elementales.',
            'Nivel 14 - Thousand Forms: Puedes lanzar Alter Self a voluntad.'
          ]
        },
        {
          name: 'Circle of Dreams',
          description: 'Guardián del reino feérico.',
          benefits: [
            'Nivel 2 - Balm of the Summer Court: Curación feérica.',
            'Nivel 6 - Hearth of Moonlight and Shadow: Reposo mejorado.',
            'Nivel 10 - Hidden Paths: Teletransporte.',
            'Nivel 14 - Walker in Dreams: Viajes oníricos.'
          ]
        },
        {
          name: 'Circle of the Shepherd',
          description: 'Protector de los espíritus animales.',
          benefits: [
            'Nivel 2 - Speech of the Woods: Hablas con bestias.',
            'Nivel 2 - Spirit Totem: Tótems de espíritu.',
            'Nivel 6 - Mighty Summoner: Invocaciones mejoradas.',
            'Nivel 10 - Guardian Spirit: Espíritus protectores.',
            'Nivel 14 - Faithful Summons: Invocación de emergencia.'
          ]
        },
        {
          name: 'Circle of Spores',
          description: 'Druida que canaliza el ciclo de la vida y muerte.',
          benefits: [
            'Nivel 2 - Circle Spells: Hechizos de muerte.',
            'Nivel 2 - Halo of Spores: Daño de esporas.',
            'Nivel 6 - Fungal Infestation: Zombis temporales.',
            'Nivel 10 - Spreading Spores: Esporas en área.',
            'Nivel 14 - Fungal Body: Inmunidades mejoradas.'
          ]
        },
        {
          name: 'Circle of Stars',
          description: 'Druida que lee los astros.',
          benefits: [
            'Nivel 2 - Star Map: Mapa estelar con beneficios.',
            'Nivel 2 - Starry Form: Formas constelares.',
            'Nivel 6 - Cosmic Omen: Presagios.',
            'Nivel 10 - Twinkling Constellations: Formas mejoradas.',
            'Nivel 14 - Full of Stars: Resistencia a daño.'
          ]
        }
      ]
    }
  }
}

// Class Feature Card Component - Shows each feature directly visible
function ClassFeatureCard({ 
  feature, 
  level, 
  isObtained, 
  choiceOptions,
  proficiencyBonus
}: { 
  feature: ClassFeature
  level: number
  isObtained: boolean
  choiceOptions: ChoiceCategory | null
  proficiencyBonus: number
}) {
  const [isChoiceExpanded, setIsChoiceExpanded] = useState(false)
  
  const getFeatureTypeIcon = (type: string) => {
    switch(type) {
      case 'feature': return <Star className="h-4 w-4" />
      case 'improvement': return <ArrowUpCircle className="h-4 w-4" />
      case 'choice': return <ChevronRight className="h-4 w-4" />
      case 'spell': return <Wand2 className="h-4 w-4" />
      case 'asi': return <Zap className="h-4 w-4" />
      default: return <Info className="h-4 w-4" />
    }
  }

  const getFeatureTypeColor = (type: string) => {
    switch(type) {
      case 'feature': return 'bg-orange-500/20 text-gray-900 border-orange-500/40 hover:bg-orange-500/30'
      case 'improvement': return 'bg-green-500/20 text-gray-900 border-green-500/40 hover:bg-green-500/30'
      case 'choice': return 'bg-blue-500/20 text-gray-900 border-blue-500/40 hover:bg-blue-500/30'
      case 'spell': return 'bg-purple-500/20 text-gray-900 border-purple-500/40 hover:bg-purple-500/30'
      case 'asi': return 'bg-amber-500/20 text-gray-900 border-amber-500/40 hover:bg-amber-500/30'
      default: return 'bg-slate-500/20 text-gray-900 border-slate-500/40 hover:bg-slate-500/30'
    }
  }

  const getFeatureTypeLabel = (type: string) => {
    switch(type) {
      case 'feature': return 'Característica'
      case 'improvement': return 'Mejora'
      case 'choice': return 'Elección'
      case 'spell': return 'Conjuración'
      case 'asi': return 'ASI'
      default: return 'Otro'
    }
  }

  return (
    <div 
      className={`group rounded-xl border backdrop-blur-sm transition-all duration-300 
        hover:scale-[1.01] hover:shadow-lg hover:shadow-current/10 
        ${getFeatureTypeColor(feature.type)} 
        ${!isObtained ? 'opacity-50' : ''}`}
    >
      <div className="p-3">
        {/* Header with level badge, icon, and name */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 bg-background/40 rounded-lg backdrop-blur-sm 
              group-hover:bg-background/60 transition-colors duration-300
              shadow-sm group-hover:shadow-md">
              {getFeatureTypeIcon(feature.type)}
            </div>
            <div className="flex flex-col">
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="text-[10px] px-1.5 py-0 h-4 border-current/50 bg-current/10">
                  Nv.{level}
                </Badge>
                <span className="font-semibold text-sm tracking-wide">{feature.name}</span>
              </div>
            </div>
          </div>
          <Badge variant="outline" className="text-[10px] px-2 py-0.5 border-current/50 bg-current/10">
            {getFeatureTypeLabel(feature.type)}
          </Badge>
        </div>
        
        {/* Description */}
        <p className="text-xs mt-2 ml-9 opacity-80 leading-relaxed">{feature.description}</p>
        
        {/* Choice Options - Expandable */}
        {choiceOptions && (
          <div className="mt-2 ml-9">
            <button
              className="flex items-center gap-1 text-xs text-blue-400 hover:text-blue-300 transition-colors"
              onClick={() => setIsChoiceExpanded(!isChoiceExpanded)}
            >
              <Info className="h-3 w-3" />
              <span>{isChoiceExpanded ? 'Ocultar' : 'Ver'} {choiceOptions.options.length} opciones</span>
              <ChevronDown className={`h-3 w-3 transition-transform ${isChoiceExpanded ? 'rotate-180' : ''}`} />
            </button>
            
            {isChoiceExpanded && (
              <div className="mt-2 space-y-2 animate-in slide-in-from-top-2 duration-200">
                <p className="text-[10px] text-muted-foreground italic">{choiceOptions.description}</p>
                <div className="grid gap-1.5">
                  {choiceOptions.options.map((option, optIdx) => (
                    <div 
                      key={optIdx}
                      className="p-2 rounded-lg border border-blue-400/20 bg-blue-500/5 
                        hover:bg-blue-500/10 transition-colors duration-200"
                    >
                      <div className="flex items-center gap-2 mb-0.5">
                        <Badge variant="outline" className="text-[10px] bg-blue-500/10 h-4">
                          {optIdx + 1}
                        </Badge>
                        <span className="font-medium text-xs">{option.name}</span>
                      </div>
                      <p className="text-[10px] text-muted-foreground">{option.description}</p>
                      <ul className="text-[10px] text-muted-foreground mt-1 space-y-0.5">
                        {option.benefits.slice(0, 2).map((benefit, benIdx) => (
                          <li key={benIdx} className="flex items-start gap-1">
                            <span className="text-blue-400">•</span>
                            <span>{benefit}</span>
                          </li>
                        ))}
                        {option.benefits.length > 2 && (
                          <li className="text-blue-400">+{option.benefits.length - 2} más...</li>
                        )}
                      </ul>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

// Class Features Table Component - Redesigned to show all features visible
function ClassFeaturesTable({ className, currentLevel }: { className: string, currentLevel: number }) {
  const [filterType, setFilterType] = useState<string>('all')
  
  const classData = CLASS_FEATURES_BY_LEVEL[className]
  const classChoices = CLASS_CHOICE_OPTIONS[className] || {}
  
  if (!classData) {
    return (
      <div className="text-sm text-muted-foreground p-4 text-center">
        Selecciona una clase para ver sus características
      </div>
    )
  }

  // Find matching choice category for a feature name
  const getChoiceOptions = (featureName: string): ChoiceCategory | null => {
    const featureToChoiceMap: Record<string, string> = {
      'Primal Path': 'Primal Path',
      'Bard College': 'Bard College',
      'Divine Domain': 'Divine Domain',
      'Fighting Style': 'Fighting Style',
      'Martial Archetype': 'Martial Archetype',
      'Monastic Tradition': 'Monastic Tradition',
      'Sacred Oath': 'Sacred Oath',
      'Ranger Archetype': 'Ranger Archetype',
      'Roguish Archetype': 'Roguish Archetype',
      'Sorcerous Origin': 'Sorcerous Origin',
      'Otherworldly Patron': 'Otherworldly Patron',
      'Pact Boon': 'Pact Boon',
      'Arcane Tradition': 'Arcane Tradition',
      'Druid Circle': 'Druid Circle',
    }
    
    const choiceKey = featureToChoiceMap[featureName]
    return choiceKey ? classChoices[choiceKey] || null : null
  }

  // Get all features up to current level, flattened
  const allFeatures = classData
    .filter(levelData => levelData.level <= currentLevel)
    .flatMap(levelData => 
      levelData.features
        .filter(f => filterType === 'all' || f.type === filterType)
        .map(feature => ({
          feature,
          level: levelData.level,
          proficiencyBonus: levelData.proficiencyBonus,
          isObtained: levelData.level <= currentLevel
        }))
    )

  return (
    <div className="space-y-3">
      {/* Class Header */}
      <div className="flex items-center justify-between px-1">
        <div className="flex items-center gap-2">
          <Badge variant="default" className="bg-slate-700">
            {className}
          </Badge>
          <Badge variant="outline" className="text-xs">
            Nivel {currentLevel}
          </Badge>
        </div>
        <Badge variant="secondary" className="text-xs">
          {allFeatures.length} características
        </Badge>
      </div>

      {/* Filter Buttons */}
      <div className="flex gap-1 flex-wrap">
        <Button 
          variant={filterType === 'all' ? 'default' : 'outline'} 
          size="sm" 
          className="h-6 text-[10px] px-2"
          onClick={() => setFilterType('all')}
        >
          Todos
        </Button>
        <Button 
          variant={filterType === 'feature' ? 'default' : 'outline'} 
          size="sm" 
          className="h-6 text-[10px] px-2"
          onClick={() => setFilterType('feature')}
        >
          <Star className="h-2.5 w-2.5 mr-1 text-orange-400" /> Características
        </Button>
        <Button 
          variant={filterType === 'improvement' ? 'default' : 'outline'} 
          size="sm" 
          className="h-6 text-[10px] px-2"
          onClick={() => setFilterType('improvement')}
        >
          <ArrowUpCircle className="h-2.5 w-2.5 mr-1 text-green-500" /> Mejoras
        </Button>
        <Button 
          variant={filterType === 'choice' ? 'default' : 'outline'} 
          size="sm" 
          className="h-6 text-[10px] px-2"
          onClick={() => setFilterType('choice')}
        >
          <ChevronRight className="h-2.5 w-2.5 mr-1 text-blue-500" /> Elecciones
        </Button>
        <Button 
          variant={filterType === 'asi' ? 'default' : 'outline'} 
          size="sm" 
          className="h-6 text-[10px] px-2"
          onClick={() => setFilterType('asi')}
        >
          <Zap className="h-2.5 w-2.5 mr-1 text-amber-500" /> ASI
        </Button>
      </div>

      {/* All Features - Directly Visible */}
      <ScrollArea className="h-72">
        {allFeatures.length === 0 ? (
          <div className="text-center py-6 text-muted-foreground text-sm">
            No hay características que coincidan con el filtro
          </div>
        ) : (
          <div className="space-y-2 pr-2">
            {allFeatures.map(({ feature, level, proficiencyBonus, isObtained }, idx) => (
              <ClassFeatureCard
                key={`${level}-${feature.name}-${idx}`}
                feature={feature}
                level={level}
                isObtained={isObtained}
                choiceOptions={feature.type === 'choice' ? getChoiceOptions(feature.name) : null}
                proficiencyBonus={proficiencyBonus}
              />
            ))}
          </div>
        )}
      </ScrollArea>

      {/* Legend */}
      <div className="flex gap-2 flex-wrap text-[10px] text-muted-foreground pt-1 border-t">
        <span className="flex items-center gap-1"><Star className="h-2.5 w-2.5 text-orange-400" /> Característica</span>
        <span className="flex items-center gap-1"><ArrowUpCircle className="h-2.5 w-2.5 text-green-500" /> Mejora</span>
        <span className="flex items-center gap-1"><ChevronRight className="h-2.5 w-2.5 text-blue-500" /> Elección</span>
        <span className="flex items-center gap-1"><Wand2 className="h-2.5 w-2.5 text-purple-500" /> Conjuración</span>
        <span className="flex items-center gap-1"><Zap className="h-2.5 w-2.5 text-amber-500" /> ASI</span>
      </div>
    </div>
  )
}

export default function DnDCharacterCreator() {
  // State
  const [activeTab, setActiveTab] = useState('create')
  const [species, setSpecies] = useState<Species[]>([])
  const [classes, setClasses] = useState<CharacterClass[]>([])
  const [backgrounds, setBackgrounds] = useState<Background[]>([])
  const [spells, setSpells] = useState<Spell[]>([])
  const [weapons, setWeapons] = useState<Weapon[]>([])
  const [armor, setArmor] = useState<Armor[]>([])
  const [items, setItems] = useState<Item[]>([])
  const [magicItems, setMagicItems] = useState<any[]>([])
  const [characters, setCharacters] = useState<Character[]>([])
  const [selectedCharacter, setSelectedCharacter] = useState<Character | null>(null)
  const [spellSlots, setSpellSlots] = useState<SpellSlotData | null>(null)
  const [loading, setLoading] = useState(true)
  
  // Character creation state
  const [creationStep, setCreationStep] = useState(1)
  const [creationLevel, setCreationLevel] = useState(1)
  const [newCharacter, setNewCharacter] = useState({
    name: '',
    speciesId: '',
    speciesSubtype: '',
    classId: '',
    subclassId: '',
    backgroundId: '',
    backgroundEquipmentChoice: 'A' as 'A' | 'B',
    classEquipmentChoice: 'A' as 'A' | 'B',
    strength: 15,
    dexterity: 14,
    constitution: 13,
    intelligence: 12,
    wisdom: 10,
    charisma: 8,
    alignment: '',
    backgroundStory: '',
    appearance: '',
    selectedClassSkills: [] as string[],
    humanFeatId: '' as string
  })
  
  // Ability score generation mode
  const [abilityScoreMode, setAbilityScoreMode] = useState<'rolled' | 'standard' | 'pointbuy'>('standard')
  const [pointBuyPoints, setPointBuyPoints] = useState(27)
  
  // Point buy cost table
  const POINT_BUY_COST: Record<number, number> = {
    8: 0,
    9: 1,
    10: 2,
    11: 3,
    12: 4,
    13: 5,
    14: 7,
    15: 9
  }
  
  // Calculate total points spent in point buy
  const calculatePointsSpent = () => {
    const baseScores = {
      strength: Math.max(8, Math.min(15, newCharacter.strength)),
      dexterity: Math.max(8, Math.min(15, newCharacter.dexterity)),
      constitution: Math.max(8, Math.min(15, newCharacter.constitution)),
      intelligence: Math.max(8, Math.min(15, newCharacter.intelligence)),
      wisdom: Math.max(8, Math.min(15, newCharacter.wisdom)),
      charisma: Math.max(8, Math.min(15, newCharacter.charisma))
    }
    return Object.values(baseScores).reduce((total, score) => total + (POINT_BUY_COST[score] || 0), 0)
  }
  
  // Point buy functions
  const increaseAbilityScore = (ability: 'strength' | 'dexterity' | 'constitution' | 'intelligence' | 'wisdom' | 'charisma') => {
    const currentScore = newCharacter[ability] as number
    if (currentScore >= 15) return // Max 15 in point buy
    
    const currentCost = POINT_BUY_COST[currentScore] || 0
    const newCost = POINT_BUY_COST[currentScore + 1] || 0
    const costDifference = newCost - currentCost
    
    const pointsSpent = calculatePointsSpent()
    if (pointsSpent + costDifference > 27) return // Not enough points
    
    setNewCharacter({ ...newCharacter, [ability]: currentScore + 1 })
  }
  
  const decreaseAbilityScore = (ability: 'strength' | 'dexterity' | 'constitution' | 'intelligence' | 'wisdom' | 'charisma') => {
    const currentScore = newCharacter[ability] as number
    if (currentScore <= 8) return // Min 8 in point buy
    
    setNewCharacter({ ...newCharacter, [ability]: currentScore - 1 })
  }
  
  // Reset to standard array (for point buy)
  const resetToPointBuyDefault = () => {
    const baseScores = {
      strength: 8,
      dexterity: 8,
      constitution: 8,
      intelligence: 8,
      wisdom: 8,
      charisma: 8
    }
    setNewCharacter({ ...newCharacter, ...baseScores })
    setAbilityScoreMode('pointbuy')
  }
  
  // Dialogs
  const [infoDialog, setInfoDialog] = useState<{ open: boolean, title: string, content: string }>({
    open: false,
    title: '',
    content: ''
  })
  const [inventoryDialog, setInventoryDialog] = useState(false)
  const [spellsDialog, setSpellsDialog] = useState(false)
  const [grimorioDialog, setGrimorioDialog] = useState(false) // Grimorio - view all spells
  const [shopDialog, setShopDialog] = useState(false) // Shop - view all items
  const [encyclopediaDialog, setEncyclopediaDialog] = useState(false) // Encyclopedia - view all game data
  const [encyclopediaCategory, setEncyclopediaCategory] = useState<'classes' | 'species' | 'backgrounds' | 'feats'>('classes')
  const [encyclopediaSearchTerm, setEncyclopediaSearchTerm] = useState('')
  const [encyclopediaDetailItem, setEncyclopediaDetailItem] = useState<{ open: boolean, item: any, type: string }>({
    open: false,
    item: null,
    type: ''
  })
  const [subclassDetailDialog, setSubclassDetailDialog] = useState<{ open: boolean, subclass: any, parentClass: any }>({
    open: false,
    subclass: null,
    parentClass: null
  })
  const [levelUpDialog, setLevelUpDialog] = useState(false)
  const [levelUpOptions, setLevelUpOptions] = useState<any>(null)
  const [levelUpChoices, setLevelUpChoices] = useState<{
    asiChoice: 'asi' | 'feat' | null
    asiPoints: { str: number; dex: number; con: number; int: number; wis: number; cha: number }
    featId: string | null
    subclassId: string | null
    spellId: string | null
    multiclassClassId: string | null
    levelUpType: 'advance' | 'multiclass' | 'existingClass'
    advanceClassId: string | null // For multiclass characters to choose which class to advance
  }>({
    asiChoice: null,
    asiPoints: { str: 0, dex: 0, con: 0, int: 0, wis: 0, cha: 0 },
    featId: null,
    subclassId: null,
    spellId: null,
    multiclassClassId: null,
    levelUpType: 'advance',
    advanceClassId: null
  })
  const [spellDetailDialog, setSpellDetailDialog] = useState<{ open: boolean, spell: Spell | null }>({
    open: false,
    spell: null
  })
  const [itemDetailDialog, setItemDetailDialog] = useState<{ open: boolean, item: any }>({
    open: false,
    item: null
  })
  const [spellLevelFilter, setSpellLevelFilter] = useState<string>('all')
  const [spellSchoolFilter, setSpellSchoolFilter] = useState<string>('all')
  const [grimorioSearchTerm, setGrimorioSearchTerm] = useState<string>('')
  const [shopSearchTerm, setShopSearchTerm] = useState<string>('')
  const [shopCategoryFilter, setShopCategoryFilter] = useState<string>('all')
  const [shopItemDetailDialog, setShopItemDetailDialog] = useState<{ open: boolean, item: any }>({
    open: false,
    item: null
  })
  
  // Inventory search state
  const [inventorySearchTerm, setInventorySearchTerm] = useState('')
  
  // Notes state
  const [notes, setNotes] = useState<Note[]>([])
  const [noteDialog, setNoteDialog] = useState<{ open: boolean, note: Note | null }>({
    open: false,
    note: null
  })
  
  // Feats state
  const [allFeats, setAllFeats] = useState<any[]>([])
  const [featSearchTerm, setFeatSearchTerm] = useState('')
  const [featCategoryFilter, setFeatCategoryFilter] = useState('all')
  const [featDialog, setFeatDialog] = useState<{ open: boolean, feat: any }>({
    open: false,
    feat: null
  })
  const [featAbilityDialog, setFeatAbilityDialog] = useState<{ open: boolean, feat: any, abilityOptions: string[] }>({
    open: false,
    feat: null,
    abilityOptions: []
  })
  const [featSpellDialog, setFeatSpellDialog] = useState<{ open: boolean, feat: any, spellOptions: any[] }>({
    open: false,
    feat: null,
    spellOptions: []
  })
  const [featDetailDialog, setFeatDetailDialog] = useState<{ open: boolean, characterFeat: any }>({
    open: false,
    characterFeat: null
  })
  const [featSkillDialog, setFeatSkillDialog] = useState<{ 
    open: boolean, 
    feat: any, 
    skillCount: number, 
    grantsExpertise: boolean,
    selectedSkills: string[] 
  }>({
    open: false,
    feat: null,
    skillCount: 0,
    grantsExpertise: false,
    selectedSkills: []
  })
  
  // Edit dialogs state
  const [editNameDialog, setEditNameDialog] = useState(false)
  const [editXpDialog, setEditXpDialog] = useState(false)
  const [editingXp, setEditingXp] = useState(0)
  const [editAbilityDialog, setEditAbilityDialog] = useState(false)
  const [editHpDialog, setEditHpDialog] = useState(false)
  const [editDetailsDialog, setEditDetailsDialog] = useState(false)
  const [editCurrencyDialog, setEditCurrencyDialog] = useState(false)
  const [editingName, setEditingName] = useState('')
  const [editingAbilities, setEditingAbilities] = useState({ str: 10, dex: 10, con: 10, int: 10, wis: 10, cha: 10 })
  const [editingHp, setEditingHp] = useState({ current: 0, max: 0, temp: 0 })
  const [editingDetails, setEditingDetails] = useState({ appearance: '', backgroundStory: '', alignment: '' })
  const [editingCurrency, setEditingCurrency] = useState({ cp: 0, sp: 0, ep: 0, gp: 0, pp: 0 })
  
  // Duplicate character dialog state
  const [duplicateDialog, setDuplicateDialog] = useState<{ open: boolean, character: Character | null, newName: string }>({
    open: false,
    character: null,
    newName: ''
  })
  
  // Proficiencies dialog state
  const [proficienciesDialog, setProficienciesDialog] = useState<'tools' | 'weapons' | 'armor' | null>(null)
  const [editingProficiencies, setEditingProficiencies] = useState<string[]>([])
  const [newProficiency, setNewProficiency] = useState('')
  
  // Background ability score selection dialog
  const [backgroundAsiDialog, setBackgroundAsiDialog] = useState(false)
  const [backgroundAsiChoice, setBackgroundAsiChoice] = useState<'plus2plus1' | 'plus1all'>('plus2plus1')
  const [backgroundAsiSelection, setBackgroundAsiSelection] = useState<{
    plus2Ability: string | null
    plus1Ability: string | null
  }>({ plus2Ability: null, plus1Ability: null })
  const [backgroundBonusesApplied, setBackgroundBonusesApplied] = useState(false)
  
  // Species subtype selection dialog
  const [speciesSubtypeDialog, setSpeciesSubtypeDialog] = useState(false)
  const [selectedSpeciesSubtype, setSelectedSpeciesSubtype] = useState<string | null>(null)
  
  const noteSaveTimeoutRef = useRef<{ [key: string]: NodeJS.Timeout }>({})

  // Fetch initial data
  useEffect(() => {
    const fetchData = async () => {
      try {
        const [speciesRes, classesRes, backgroundsRes, spellsRes, weaponsRes, armorRes, itemsRes, charactersRes, featsRes, magicItemsRes] = await Promise.all([
          fetch('/api/species'),
          fetch('/api/classes'),
          fetch('/api/backgrounds'),
          fetch('/api/spells'),
          fetch('/api/weapons'),
          fetch('/api/armor'),
          fetch('/api/items'),
          fetch('/api/characters'),
          fetch('/api/feats'),
          fetch('/api/magic-items')
        ])
        
        const [speciesData, classesData, backgroundsData, spellsData, weaponsData, armorData, itemsData, charactersData, featsData, magicItemsData] = await Promise.all([
          speciesRes.json(),
          classesRes.json(),
          backgroundsRes.json(),
          spellsRes.json(),
          weaponsRes.json(),
          armorRes.json(),
          itemsRes.json(),
          charactersRes.json(),
          featsRes.json(),
          magicItemsRes.json()
        ])
        
        setSpecies(speciesData)
        setClasses(classesData)
        setBackgrounds(backgroundsData)
        setSpells(spellsData)
        setWeapons(weaponsData)
        setArmor(armorData)
        setItems(itemsData)
        setCharacters(charactersData)
        setAllFeats(featsData)
        setMagicItems(magicItemsData)
        setLoading(false)
      } catch (error) {
        console.error('Error fetching data:', error)
        setLoading(false)
      }
    }
    
    fetchData()
  }, [])

  // Sync subclass spells for characters with spell-granting subclasses
  // These spells are always prepared, cannot be removed, and don't count toward limits
  const syncSubclassSpells = useCallback(async (characterId: string, subclassId: string, characterLevel: number, className: string) => {
    try {
      // Validate inputs
      if (!characterId || !subclassId || !className || characterLevel < 1) {
        console.warn('Invalid parameters for syncSubclassSpells')
        return
      }

      // Use the backend endpoint to sync subclass spells (more robust)
      const res = await fetch(`/api/characters/${characterId}/sync-subclass-spells`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subclassId,
          characterLevel,
          className
        })
      })

      if (!res.ok) {
        console.warn('Failed to sync subclass spells via API')
        return
      }

      const result = await res.json()
      console.log('Subclass spells sync result:', result)

      // Refresh character data to show new spells
      try {
        const refreshRes = await fetch(`/api/characters/${characterId}`)
        if (refreshRes.ok) {
          const refreshedData = await refreshRes.json()
          if (refreshedData && refreshedData.id) {
            setSelectedCharacter(refreshedData)
          }
        }
      } catch (refreshError) {
        console.warn('Failed to refresh character after sync:', refreshError)
      }
    } catch (error) {
      console.error('Error syncing subclass spells:', error)
      // Don't throw - let the app continue
    }
  }, [])

  // Fetch selected character details
  const fetchCharacterDetails = useCallback(async (id: string) => {
    try {
      // Clear previous notes first
      setNotes([])
      
      const res = await fetch(`/api/characters/${id}`)
      if (!res.ok) {
        console.error('Failed to fetch character:', res.status)
        return
      }
      const data = await res.json()
      
      // Validate character data has required fields
      if (!data || !data.id) {
        console.error('Invalid character data received')
        return
      }
      
      setSelectedCharacter(data)
      
      // Fetch spell slots if spellcasting class
      if (data.characterClass?.spellcasting) {
        const slotsRes = await fetch(`/api/characters/${id}/spell-slots`)
        const slotsData = await slotsRes.json()
        setSpellSlots(slotsData)
      }
      
      // Fetch notes for this character
      const notesRes = await fetch(`/api/characters/${id}/notes`)
      const notesData = await notesRes.json()
      setNotes(notesData)
      
      // Sync subclass spells for characters with spell-granting subclasses
      if (data.subclassId && data.characterClass?.name) {
        await syncSubclassSpells(id, data.subclassId, data.level, data.characterClass.name)
      }
    } catch (error) {
      console.error('Error fetching character:', error)
    }
  }, [syncSubclassSpells])

  // Create pending notes for higher level character creation
  const createPendingNotesForLevel = async (characterId: string, level: number) => {
    const selectedClassData = classes.find(c => c.id === newCharacter.classId)
    const asiLevels = [4, 8, 12, 16, 19]
    const notes: string[] = []
    
    // Header note
    notes.push(`📋 PERSONAJE CREADO A NIVEL ${level}`)
    notes.push(`Este personaje fue creado a un nivel superior. Las siguientes decisiones están pendientes:`)
    notes.push('')
    
    // ASI/Feat decisions
    const asiLevelsNeeded = asiLevels.filter(l => level >= l)
    if (asiLevelsNeeded.length > 0) {
      notes.push(`⬆️ MEJORA DE CARACTERÍSTICAS/DOTES:`)
      asiLevelsNeeded.forEach(lvl => {
        notes.push(`  • Nivel ${lvl}: Pendiente elegir +2 en una característica, +1 en dos, o una dote`)
      })
      notes.push('')
    }
    
    // Class features for each level
    if (selectedClassData) {
      try {
        const classFeatures = JSON.parse(selectedClassData.features || '{}')
        const featuresByLevel: string[] = []
        
        for (let lvl = 2; lvl <= level; lvl++) {
          const featureKey = `level${lvl}`
          if (classFeatures[featureKey]) {
            featuresByLevel.push(`  • Nivel ${lvl}: ${classFeatures[featureKey]}`)
          }
        }
        
        if (featuresByLevel.length > 0) {
          notes.push(`⚔️ RASGOS DE CLASE:`)
          notes.push(...featuresByLevel)
          notes.push('')
        }
      } catch (e) {
        console.error('Error parsing class features:', e)
      }
    }
    
    // Hit dice reminder
    notes.push(`🎲 DADOS DE GOLPE:`)
    notes.push(`  • Total: ${level}d${selectedClassData?.hitDie || 8}`)
    notes.push(`  • HP calculado con promedio de dado`)
    notes.push('')
    
    // Subclass features (if level >= 3)
    if (level >= 3 && newCharacter.subclassId) {
      const subclass = selectedClassData?.subclasses?.find(s => s.id === newCharacter.subclassId)
      if (subclass) {
        try {
          const subclassFeatures = JSON.parse(subclass.features || '{}')
          const subclassFeaturesByLevel: string[] = []
          
          for (let lvl = 3; lvl <= level; lvl++) {
            const featureKey = `level${lvl}`
            if (subclassFeatures[featureKey]) {
              subclassFeaturesByLevel.push(`  • Nivel ${lvl}: ${subclassFeatures[featureKey]}`)
            }
          }
          
          if (subclassFeaturesByLevel.length > 0) {
            notes.push(`🔷 RASGOS DE SUBCLASE (${subclass.name}):`)
            notes.push(...subclassFeaturesByLevel)
            notes.push('')
          }
        } catch (e) {
          console.error('Error parsing subclass features:', e)
        }
      }
    }
    
    // Spellcasting reminder
    if (selectedClassData?.spellcasting) {
      notes.push(`✨ LANZAMIENTO DE CONJUROS:`)
      notes.push(`  • Revisa y selecciona los conjuros conocidos para nivel ${level}`)
      notes.push(`  • Los espacios de conjuros se calculan automáticamente`)
      notes.push('')
    }
    
    // Proficiency bonus reminder
    const profBonus = level < 5 ? 2 : level < 9 ? 3 : level < 13 ? 4 : level < 17 ? 5 : 6
    notes.push(`🎯 BONO DE COMPETENCIA: +${profBonus}`)
    
    // Create the note
    const noteContent = notes.join('\n')
    
    try {
      await fetch(`/api/characters/${characterId}/notes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          title: `⚠️ Pendiente: Nivel ${level}`, 
          content: noteContent, 
          color: 'yellow',
          pinned: true
        })
      })
    } catch (error) {
      console.error('Error creating pending note:', error)
    }
  }

  // Create character
  const handleCreateCharacter = async () => {
    try {
      // Include HP choice and level in the character data
      const characterData = {
        ...newCharacter,
        hpChoice: hpChoice,
        level: creationLevel
      }
      
      const res = await fetch('/api/characters', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(characterData)
      })
      
      if (res.ok) {
        const character = await res.json()
        setCharacters([...characters, character])
        setSelectedCharacter(character)
        setNotes([]) // Clear notes - new character has no notes
        setActiveTab('sheet')
        setCreationStep(1)
        
        // If level > 1, update HP and create pending notes
        if (creationLevel > 1) {
          // Calculate and update HP for higher level
          const calculatedHp = calculateHpForLevel()
          await fetch(`/api/characters/${character.id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
              maxHp: calculatedHp, 
              currentHp: calculatedHp,
              hitDiceMax: creationLevel,
              hitDiceCurrent: creationLevel
            })
          })
          
          // Create pending notes for higher level decisions
          await createPendingNotesForLevel(character.id, creationLevel)
        }
        
        // Sync subclass spells for characters with spell-granting subclasses
        if (newCharacter.subclassId && selectedClass?.name) {
          await syncSubclassSpells(character.id, newCharacter.subclassId, creationLevel, selectedClass.name)
        }
        
        // Add background equipment and gold to character
        let totalGold = 0
        const allItems: string[] = []
        
        if (selectedBackground) {
          try {
            const equipment = JSON.parse(selectedBackground.equipment)
            const selectedEquipment = equipment[newCharacter.backgroundEquipmentChoice] || equipment.A
            
            // Collect gold
            if (selectedEquipment.gold > 0) {
              totalGold += selectedEquipment.gold
            }
            
            // Collect items
            allItems.push(...(selectedEquipment.items || []))
          } catch (error) {
            console.error('Error processing background equipment:', error)
          }
        }
        
        // Add class equipment and gold
        const selectedClassData = classes.find(c => c.id === newCharacter.classId)
        if (selectedClassData) {
          try {
            const classEquipment = JSON.parse(selectedClassData.startingEquipment)
            const selectedClassEquipment = classEquipment[newCharacter.classEquipmentChoice] || classEquipment.A
            
            // Collect gold
            if (selectedClassEquipment.gold > 0) {
              totalGold += selectedClassEquipment.gold
            }
            
            // Collect items
            allItems.push(...(selectedClassEquipment.items || []))
          } catch (error) {
            console.error('Error processing class equipment:', error)
          }
        }
        
        // Add combined gold to character
        if (totalGold > 0) {
          await fetch(`/api/characters/${character.id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ gp: totalGold })
          })
        }
        
        // Add all items to inventory
        const notFoundItems: string[] = []
        
        for (const itemName of allItems) {
          // Extract quantity if present (e.g., "4 Handaxes" -> quantity: 4, name: "Handaxe")
          const quantityMatch = itemName.match(/^(\d+)\s+(.+)$/)
          const quantity = quantityMatch ? parseInt(quantityMatch[1]) : 1
          const cleanName = quantityMatch ? quantityMatch[2] : itemName
          
          let found = false
          
          // Try to find in weapons
          try {
            const weaponRes = await fetch(`/api/weapons?search=${encodeURIComponent(cleanName)}`)
            const weapons = await weaponRes.json()
            if (Array.isArray(weapons)) {
              const matchingWeapon = weapons.find((w: any) => 
                w.name.toLowerCase() === cleanName.toLowerCase() ||
                cleanName.toLowerCase().includes(w.name.toLowerCase()) ||
                w.name.toLowerCase().includes(cleanName.toLowerCase())
              )
              
              if (matchingWeapon) {
                await fetch(`/api/characters/${character.id}/inventory`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    weaponId: matchingWeapon.id,
                    quantity: quantity
                  })
                })
                found = true
              }
            }
          } catch (e) {
            console.error('Error searching weapons:', e)
          }
          
          // Try to find in armor
          if (!found) {
            try {
              const armorRes = await fetch(`/api/armor?search=${encodeURIComponent(cleanName)}`)
              const armors = await armorRes.json()
              if (Array.isArray(armors)) {
                const matchingArmor = armors.find((a: any) => 
                  a.name.toLowerCase() === cleanName.toLowerCase() ||
                  cleanName.toLowerCase().includes(a.name.toLowerCase()) ||
                  a.name.toLowerCase().includes(cleanName.toLowerCase())
                )
                
                if (matchingArmor) {
                  await fetch(`/api/characters/${character.id}/inventory`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                      armorId: matchingArmor.id,
                      quantity: quantity
                    })
                  })
                  found = true
                }
              }
            } catch (e) {
              console.error('Error searching armor:', e)
            }
          }
          
          // Try to find in items
          if (!found) {
            try {
              const itemRes = await fetch(`/api/items?search=${encodeURIComponent(cleanName)}`)
              const items = await itemRes.json()
              if (Array.isArray(items)) {
                const matchingItem = items.find((i: any) => 
                  i.name.toLowerCase() === cleanName.toLowerCase() ||
                  cleanName.toLowerCase().includes(i.name.toLowerCase()) ||
                  i.name.toLowerCase().includes(cleanName.toLowerCase())
                )
                
                if (matchingItem) {
                  await fetch(`/api/characters/${character.id}/inventory`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                      itemId: matchingItem.id,
                      quantity: quantity
                    })
                  })
                  found = true
                }
              }
            } catch (e) {
              console.error('Error searching items:', e)
            }
          }
          
          if (!found) {
            notFoundItems.push(itemName)
          }
        }
        
        // Create a note with items that couldn't be found in the database
        if (notFoundItems.length > 0) {
          await fetch(`/api/characters/${character.id}/notes`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              title: 'Equipamiento Pendiente',
              content: `Los siguientes items no se encontraron en la base de datos y deben añadirse manualmente:\n\n${notFoundItems.map(i => '• ' + i).join('\n')}`,
              color: 'amber'
            })
          })
        }
        
        // Refresh character to show updated inventory and gold
        if (totalGold > 0 || allItems.length > 0) {
          fetchCharacterDetails(character.id)
        }
        
        // Add background feat to character
        if (selectedBackground && selectedBackground.feat) {
          try {
            // Find the feat by name
            const backgroundFeat = allFeats.find(f => 
              f.name.toLowerCase() === selectedBackground.feat.toLowerCase() ||
              f.name.toLowerCase().includes(selectedBackground.feat.toLowerCase()) ||
              selectedBackground.feat.toLowerCase().includes(f.name.toLowerCase())
            )
            
            if (backgroundFeat) {
              await fetch(`/api/characters/${character.id}/feats`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  featId: backgroundFeat.id,
                  source: `Background (${selectedBackground.name})`
                })
              })
              
              // Create a reminder note about what the feat grants
              const featReminder = getFeatReminderNote(backgroundFeat.name)
              if (featReminder) {
                await fetch(`/api/characters/${character.id}/notes`, {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({
                    title: `Dote: ${backgroundFeat.name}`,
                    content: `📜 **${backgroundFeat.name}**\n\n${featReminder}`,
                    color: 'blue'
                  })
                })
              }
              
              // Refresh character to show the new feat
              fetchCharacterDetails(character.id)
            } else {
              // Create a note if feat not found
              await fetch(`/api/characters/${character.id}/notes`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  title: 'Dote Pendiente',
                  content: `⚠️ Tu trasfondo **${selectedBackground.name}** otorga el dote "${selectedBackground.feat}" que no se encontró en la base de datos.\n\nAñádelo manualmente desde la sección de dotes.`,
                  color: 'amber'
                })
              })
            }
          } catch (error) {
            console.error('Error adding background feat:', error)
          }
        }
        
        // Handle Human Versatile feat
        const selectedSpeciesName = selectedSpecies?.name
        if (selectedSpeciesName === 'Human') {
          if (newCharacter.humanFeatId) {
            // Add the selected feat to the character
            try {
              await fetch(`/api/characters/${character.id}/feats`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  featId: newCharacter.humanFeatId,
                  source: 'Versatile (Human)'
                })
              })
              // Refresh character to show the new feat
              fetchCharacterDetails(character.id)
            } catch (error) {
              console.error('Error adding human feat:', error)
            }
          } else {
            // Create a reminder note for the human feat
            try {
              await fetch(`/api/characters/${character.id}/notes`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  content: '⚠️ RECORDATORIO: Como Humano, tienes el rasgo Versátil que te permite elegir un dote de origen adicional. Visita la sección de dotes para seleccionarlo.',
                  color: 'amber'
                })
              })
              // Refresh notes
              const notesRes = await fetch(`/api/characters/${character.id}/notes`)
              const notesData = await notesRes.json()
              setNotes(notesData)
            } catch (error) {
              console.error('Error creating reminder note:', error)
            }
          }
        }
        
        setNewCharacter({
          name: '',
          speciesId: '',
          speciesSubtype: '',
          classId: '',
          subclassId: '',
          backgroundId: '',
          backgroundEquipmentChoice: 'A',
          classEquipmentChoice: 'A',
          strength: 15,
          dexterity: 14,
          constitution: 13,
          intelligence: 12,
          wisdom: 10,
          charisma: 8,
          alignment: '',
          backgroundStory: '',
          appearance: '',
          selectedClassSkills: [],
          humanFeatId: ''
        })
        setSelectedSpeciesSubtype(null)
        setHpChoice('max')
        setCreationLevel(1)
        setBackgroundBonusesApplied(false)
        setBackgroundAsiChoice('plus2plus1')
        setBackgroundAsiSelection({ plus2Ability: null, plus1Ability: null })
        setAbilityScoreMode('standard')
      }
    } catch (error) {
      console.error('Error creating character:', error)
    }
  }

  // Delete character
  const handleDeleteCharacter = async (id: string) => {
    if (!confirm('¿Estás seguro de que quieres eliminar este personaje?')) return
    
    try {
      const res = await fetch(`/api/characters/${id}`, { method: 'DELETE' })
      if (res.ok) {
        setCharacters(characters.filter(c => c.id !== id))
        if (selectedCharacter?.id === id) {
          setSelectedCharacter(null)
          setNotes([]) // Clear notes when deleting selected character
        }
      }
    } catch (error) {
      console.error('Error deleting character:', error)
    }
  }

  // Duplicate character
  const handleDuplicateCharacter = async () => {
    if (!duplicateDialog.character || !duplicateDialog.newName.trim()) return
    
    try {
      const res = await fetch(`/api/characters/${duplicateDialog.character.id}/duplicate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: duplicateDialog.newName.trim() })
      })
      
      if (res.ok) {
        const newCharacter = await res.json()
        setCharacters([newCharacter, ...characters])
        setDuplicateDialog({ open: false, character: null, newName: '' })
      } else {
        const error = await res.json()
        console.error('Error duplicating character:', error)
      }
    } catch (error) {
      console.error('Error duplicating character:', error)
    }
  }

  // Delete inventory item
  const handleDeleteInventoryItem = async (itemId: string) => {
    if (!confirm('¿Eliminar este objeto del inventario?')) return
    
    try {
      const res = await fetch(`/api/characters/${selectedCharacter?.id}/inventory?itemId=${itemId}`, { 
        method: 'DELETE' 
      })
      if (res.ok) {
        fetchCharacterDetails(selectedCharacter?.id || '')
      }
    } catch (error) {
      console.error('Error deleting inventory item:', error)
    }
  }

  // Toggle equip item
  const handleToggleEquip = async (itemId: string, currentlyEquipped: boolean, item: any) => {
    try {
      const res = await fetch(`/api/characters/${selectedCharacter?.id}/inventory`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          itemId, 
          equipped: !currentlyEquipped,
          armorId: item.armor?.id 
        })
      })
      if (res.ok) {
        fetchCharacterDetails(selectedCharacter?.id || '')
      }
    } catch (error) {
      console.error('Error toggling equip:', error)
    }
  }

  // Notes functions
  const handleCreateNote = async (title: string = 'Nueva Nota', content: string = '', color: string = 'default') => {
    try {
      const res = await fetch(`/api/characters/${selectedCharacter?.id}/notes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, content, color })
      })
      if (res.ok) {
        const newNote = await res.json()
        setNotes(prevNotes => [newNote, ...prevNotes])
        setNoteDialog({ open: true, note: newNote })
      }
    } catch (error) {
      console.error('Error creating note:', error)
    }
  }

  // Update note in database
  const saveNoteToDatabase = async (noteId: string, updates: { title?: string, content?: string, color?: string, pinned?: boolean }) => {
    if (!selectedCharacter?.id || !noteId) {
      console.error('Missing required data:', { characterId: selectedCharacter?.id, noteId })
      return null
    }
    
    try {
      const res = await fetch(`/api/characters/${selectedCharacter.id}/notes`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ noteId, ...updates })
      })
      
      if (res.ok) {
        const updatedNote = await res.json()
        setNotes(prevNotes => prevNotes.map(n => n.id === noteId ? updatedNote : n))
        return updatedNote
      } else {
        console.error('Failed to update note:', await res.text())
        return null
      }
    } catch (error) {
      console.error('Error updating note:', error)
      return null
    }
  }

  // Debounced update for title and content (waits 800ms after user stops typing)
  const handleDebouncedUpdateNote = (noteId: string, updates: { title?: string, content?: string }) => {
    // Clear existing timeout for this note
    if (noteSaveTimeoutRef.current[noteId]) {
      clearTimeout(noteSaveTimeoutRef.current[noteId])
    }
    
    // Set new timeout - save after 800ms of no typing
    noteSaveTimeoutRef.current[noteId] = setTimeout(() => {
      saveNoteToDatabase(noteId, updates)
    }, 800)
  }

  // Immediate update for color and pinned
  const handleUpdateNote = async (noteId: string, updates: { title?: string, content?: string, color?: string, pinned?: boolean }) => {
    const updatedNote = await saveNoteToDatabase(noteId, updates)
    if (updatedNote) {
      // Update dialog state if this note is currently open
      setNoteDialog(prev => prev.note?.id === noteId ? { open: true, note: updatedNote } : prev)
    }
  }

  const handleDeleteNote = async (noteId: string) => {
    if (!confirm('¿Eliminar esta nota?')) return
    
    try {
      const res = await fetch(`/api/characters/${selectedCharacter?.id}/notes?noteId=${noteId}`, {
        method: 'DELETE'
      })
      if (res.ok) {
        setNotes(prevNotes => prevNotes.filter(n => n.id !== noteId))
        setNoteDialog({ open: false, note: null })
      }
    } catch (error) {
      console.error('Error deleting note:', error)
    }
  }

  const handleDeleteAllNotes = async () => {
    if (!selectedCharacter?.id) return
    if (!confirm('¿Eliminar TODAS las notas? Esta acción no se puede deshacer.')) return
    
    try {
      // Delete all notes one by one
      for (const note of notes) {
        await fetch(`/api/characters/${selectedCharacter.id}/notes?noteId=${note.id}`, {
          method: 'DELETE'
        })
      }
      setNotes([])
      setNoteDialog({ open: false, note: null })
    } catch (error) {
      console.error('Error deleting all notes:', error)
    }
  }

  // Character update functions
  const handleUpdateCharacterName = async (name: string) => {
    if (!selectedCharacter?.id) return
    try {
      const res = await fetch(`/api/characters/${selectedCharacter.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name })
      })
      if (res.ok) {
        const updated = await res.json()
        setSelectedCharacter(updated)
        setCharacters(prev => prev.map(c => c.id === updated.id ? updated : c))
      }
    } catch (error) {
      console.error('Error updating name:', error)
    }
  }

  const handleUpdateCharacterXp = async (xp: number) => {
    if (!selectedCharacter?.id) return
    try {
      const res = await fetch(`/api/characters/${selectedCharacter.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ xp })
      })
      if (res.ok) {
        const updated = await res.json()
        setSelectedCharacter(updated)
        setCharacters(prev => prev.map(c => c.id === updated.id ? updated : c))
      }
    } catch (error) {
      console.error('Error updating XP:', error)
    }
  }

  const handleUpdateAbilityScores = async (abilities: { str: number, dex: number, con: number, int: number, wis: number, cha: number }) => {
    if (!selectedCharacter?.id) return
    try {
      const res = await fetch(`/api/characters/${selectedCharacter.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          strength: abilities.str,
          dexterity: abilities.dex,
          constitution: abilities.con,
          intelligence: abilities.int,
          wisdom: abilities.wis,
          charisma: abilities.cha
        })
      })
      if (res.ok) {
        const updated = await res.json()
        setSelectedCharacter(updated)
        setCharacters(prev => prev.map(c => c.id === updated.id ? updated : c))
      }
    } catch (error) {
      console.error('Error updating abilities:', error)
    }
  }

  // Update proficiencies
  const handleUpdateProficiencies = async (type: 'tools' | 'weapons' | 'armor', proficiencies: string[]) => {
    if (!selectedCharacter?.id) return
    try {
      const fieldMap = {
        'tools': 'toolProficiencies',
        'weapons': 'weaponProficiencies',
        'armor': 'armorProficiencies'
      }
      const res = await fetch(`/api/characters/${selectedCharacter.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          [fieldMap[type]]: JSON.stringify(proficiencies)
        })
      })
      if (res.ok) {
        const updated = await res.json()
        setSelectedCharacter(updated)
        setCharacters(prev => prev.map(c => c.id === updated.id ? updated : c))
      }
    } catch (error) {
      console.error('Error updating proficiencies:', error)
    }
  }

  const handleUpdateHp = async (hp: { current: number, max: number, temp: number }) => {
    if (!selectedCharacter?.id) return
    try {
      const res = await fetch(`/api/characters/${selectedCharacter.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          currentHp: hp.current,
          maxHp: hp.max,
          tempHp: hp.temp
        })
      })
      if (res.ok) {
        const updated = await res.json()
        setSelectedCharacter(updated)
        setCharacters(prev => prev.map(c => c.id === updated.id ? updated : c))
      }
    } catch (error) {
      console.error('Error updating HP:', error)
    }
  }

  const handleUpdateDetails = async (details: { appearance: string, backgroundStory: string, alignment: string }) => {
    if (!selectedCharacter?.id) return
    try {
      const res = await fetch(`/api/characters/${selectedCharacter.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          appearance: details.appearance,
          backgroundStory: details.backgroundStory,
          alignment: details.alignment
        })
      })
      if (res.ok) {
        const updated = await res.json()
        setSelectedCharacter(updated)
        setCharacters(prev => prev.map(c => c.id === updated.id ? updated : c))
      }
    } catch (error) {
      console.error('Error updating details:', error)
    }
  }

  // Level up functions
  const openLevelUpDialog = async () => {
    if (!selectedCharacter?.id) return
    try {
      const res = await fetch(`/api/characters/${selectedCharacter.id}/level-up`)
      if (res.ok) {
        const options = await res.json()
        setLevelUpOptions(options)
        
        // Check if character is multiclass (has multiple class levels)
        const isMulticlass = options.currentClassLevels && options.currentClassLevels.length > 1
        
        // Set default advanceClassId to primary class or first class
        const primaryClassLevel = options.currentClassLevels?.find((cl: any) => cl.isPrimary)
        const defaultAdvanceClassId = primaryClassLevel?.classId || options.currentClassLevels?.[0]?.classId || null
        
        setLevelUpChoices({
          asiChoice: null,
          asiPoints: { str: 0, dex: 0, con: 0, int: 0, wis: 0, cha: 0 },
          featId: null,
          subclassId: null,
          spellId: null,
          multiclassClassId: null,
          levelUpType: isMulticlass ? 'existingClass' : 'advance',
          advanceClassId: isMulticlass ? defaultAdvanceClassId : null
        })
        setLevelUpDialog(true)
      }
    } catch (error) {
      console.error('Error fetching level up options:', error)
    }
  }

  const handleLevelUp = async () => {
    if (!selectedCharacter?.id) return
    try {
      const body: any = {}
      
      // If multiclassing into a new class
      if (levelUpChoices.levelUpType === 'multiclass' && levelUpChoices.multiclassClassId) {
        body.multiclassClassId = levelUpChoices.multiclassClassId
      }
      
      // If advancing in an existing class (for multiclass characters)
      if (levelUpChoices.levelUpType === 'existingClass' && levelUpChoices.advanceClassId) {
        body.advanceClassId = levelUpChoices.advanceClassId
      }
      
      // If ASI choice, calculate new ability scores
      if (levelUpChoices.asiChoice === 'asi') {
        const currentChar = selectedCharacter
        body.abilityScores = {
          strength: currentChar.strength + levelUpChoices.asiPoints.str,
          dexterity: currentChar.dexterity + levelUpChoices.asiPoints.dex,
          constitution: currentChar.constitution + levelUpChoices.asiPoints.con,
          intelligence: currentChar.intelligence + levelUpChoices.asiPoints.int,
          wisdom: currentChar.wisdom + levelUpChoices.asiPoints.wis,
          charisma: currentChar.charisma + levelUpChoices.asiPoints.cha
        }
      }
      
      // If feat chosen
      if (levelUpChoices.featId) {
        body.featId = levelUpChoices.featId
      }
      
      // If subclass chosen
      if (levelUpChoices.subclassId) {
        body.subclassId = levelUpChoices.subclassId
      }
      
      // If spell chosen
      if (levelUpChoices.spellId) {
        body.spellId = levelUpChoices.spellId
      }
      
      const res = await fetch(`/api/characters/${selectedCharacter.id}/level-up`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      })
      
      if (res.ok) {
        const updated = await res.json()
        setSelectedCharacter(updated)
        setLevelUpDialog(false)
        fetchCharacterDetails(selectedCharacter.id)
      }
    } catch (error) {
      console.error('Error leveling up:', error)
    }
  }

  // Feats functions
  const handleOpenFeatDialog = (feat: any) => {
    setFeatDialog({ open: true, feat })
  }

  const handleAddFeat = async (feat: any) => {
    if (!selectedCharacter?.id) return
    
    // Check if feat has ability score options
    const abilityOptions = feat.abilityScoreOptions ? JSON.parse(feat.abilityScoreOptions) : null
    const spellOptions = feat.spellOptions ? JSON.parse(feat.spellOptions) : null
    const skillProficienciesGranted = feat.skillProficienciesGranted || 0
    const expertiseGranted = feat.expertiseGranted || false
    
    // If feat grants skill proficiencies, open the skill selection dialog
    if (skillProficienciesGranted > 0) {
      setFeatDialog({ open: false, feat: null })
      setFeatSkillDialog({ 
        open: true, 
        feat, 
        skillCount: skillProficienciesGranted, 
        grantsExpertise: expertiseGranted,
        selectedSkills: []
      })
      return
    }
    
    // If feat has ability score options, open the ability selection dialog
    if (abilityOptions && abilityOptions.length > 0) {
      setFeatDialog({ open: false, feat: null })
      setFeatAbilityDialog({ open: true, feat, abilityOptions })
      return
    }
    
    // If feat has spell options, open the spell selection dialog
    if (spellOptions) {
      setFeatDialog({ open: false, feat: null })
      // Get available spells based on spell options
      let availableSpells = spells
      if (spellOptions.schools) {
        availableSpells = spells.filter((s: Spell) => 
          spellOptions.schools.includes(s.school) && s.level === 1
        )
      }
      setFeatSpellDialog({ open: true, feat, spellOptions: availableSpells })
      return
    }
    
    // No special selections needed, add the feat directly
    await addFeatToCharacter(feat.id, feat.name, null, null, null)
  }

  const handleSelectAbilityForFeat = async (ability: string) => {
    const feat = featAbilityDialog.feat
    const spellOptions = feat.spellOptions ? JSON.parse(feat.spellOptions) : null
    const selectedSkills = feat.selectedSkills || null
    
    // Close ability dialog
    setFeatAbilityDialog({ open: false, feat: null, abilityOptions: [] })
    
    // If feat also has spell options, open spell selection
    if (spellOptions) {
      let availableSpells = spells
      if (spellOptions.schools) {
        availableSpells = spells.filter((s: Spell) => 
          spellOptions.schools.includes(s.school) && s.level === 1
        )
      }
      // Store the selected ability temporarily
      setFeatSpellDialog({ open: true, feat: { ...feat, selectedAbility: ability }, spellOptions: availableSpells })
      return
    }
    
    // Add feat with ability selection (and skills if selected)
    await addFeatToCharacter(feat.id, feat.name, ability, null, selectedSkills)
  }

  const handleSelectSpellForFeat = async (spellId: string) => {
    const feat = featSpellDialog.feat
    
    // Close spell dialog
    setFeatSpellDialog({ open: false, feat: null, spellOptions: [] })
    
    // Add feat with spell selection (and ability if selected)
    await addFeatToCharacter(feat.id, feat.name, feat.selectedAbility || null, spellId)
  }

  const handleSkipAbilitySelection = async () => {
    const feat = featAbilityDialog.feat
    const spellOptions = feat.spellOptions ? JSON.parse(feat.spellOptions) : null
    
    // Create a reminder note
    await createNote(
      `⚠️ Pendiente: Subir característica`,
      `El dote "${feat.name}" permite subir una característica de entre: ${featAbilityDialog.abilityOptions.join(', ')}. Recuerda subir la característica cuando sea posible.`
    )
    
    // Close ability dialog
    setFeatAbilityDialog({ open: false, feat: null, abilityOptions: [] })
    
    // If feat also has spell options, open spell selection
    if (spellOptions) {
      let availableSpells = spells
      if (spellOptions.schools) {
        availableSpells = spells.filter((s: Spell) => 
          spellOptions.schools.includes(s.school) && s.level === 1
        )
      }
      setFeatSpellDialog({ open: true, feat, spellOptions: availableSpells })
      return
    }
    
    // Add feat without ability selection
    await addFeatToCharacter(feat.id, feat.name, null, null)
  }

  const handleSkipSpellSelection = async () => {
    const feat = featSpellDialog.feat
    
    // Create a reminder note
    await createNote(
      `⚠️ Pendiente: Añadir hechizo`,
      `El dote "${feat.name}" permite añadir un hechizo. Recuerda añadir el hechizo cuando sea posible.`
    )
    
    // Close spell dialog
    setFeatSpellDialog({ open: false, feat: null, spellOptions: [] })
    
    // Add feat without spell selection
    await addFeatToCharacter(feat.id, feat.name, feat.selectedAbility || null, null)
  }

  // Handle skill selection for feat
  const handleToggleSkillForFeat = (skillName: string) => {
    const currentSelected = featSkillDialog.selectedSkills
    const skillCount = featSkillDialog.skillCount
    
    if (currentSelected.includes(skillName)) {
      // Remove skill
      setFeatSkillDialog(prev => ({
        ...prev,
        selectedSkills: currentSelected.filter(s => s !== skillName)
      }))
    } else if (currentSelected.length < skillCount) {
      // Add skill if under limit
      setFeatSkillDialog(prev => ({
        ...prev,
        selectedSkills: [...currentSelected, skillName]
      }))
    }
  }

  const handleConfirmSkillSelection = async () => {
    const feat = featSkillDialog.feat
    const selectedSkills = featSkillDialog.selectedSkills
    const abilityOptions = feat.abilityScoreOptions ? JSON.parse(feat.abilityScoreOptions) : null
    
    // Close skill dialog
    setFeatSkillDialog({ open: false, feat: null, skillCount: 0, grantsExpertise: false, selectedSkills: [] })
    
    // If feat also has ability score options, open ability selection
    if (abilityOptions && abilityOptions.length > 0) {
      // Store selected skills temporarily
      setFeatAbilityDialog({ open: true, feat: { ...feat, selectedSkills }, abilityOptions })
      return
    }
    
    // Add feat with skill selections
    await addFeatToCharacter(feat.id, feat.name, null, null, selectedSkills)
  }

  const handleSkipSkillSelection = async () => {
    const feat = featSkillDialog.feat
    const skillCount = featSkillDialog.skillCount
    
    // Create a reminder note
    await createNote(
      `⚠️ Pendiente: Seleccionar habilidades`,
      `El dote "${feat.name}" permite ganar proficiencia en ${skillCount} habilidad${skillCount > 1 ? 'es' : ''}. Recuerda seleccionar las habilidades cuando sea posible.`
    )
    
    // Close skill dialog
    setFeatSkillDialog({ open: false, feat: null, skillCount: 0, grantsExpertise: false, selectedSkills: [] })
    
    // Check if feat also has ability score options
    const abilityOptions = feat.abilityScoreOptions ? JSON.parse(feat.abilityScoreOptions) : null
    if (abilityOptions && abilityOptions.length > 0) {
      setFeatAbilityDialog({ open: true, feat, abilityOptions })
      return
    }
    
    // Add feat without skill selection
    await addFeatToCharacter(feat.id, feat.name, null, null, null)
  }

  const addFeatToCharacter = async (featId: string, featName: string, chosenAbility: string | null, chosenSpellId: string | null, chosenSkills: string[] | null = null) => {
    try {
      const res = await fetch(`/api/characters/${selectedCharacter?.id}/feats`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          featId,
          source: 'Level',
          chosenAbilityScore: chosenAbility,
          chosenSpellId,
          chosenSkills
        })
      })
      
      if (res.ok) {
        // Refresh character data
        fetchCharacterDetails(selectedCharacter?.id || '')
        
        // Create a note about the feat
        let noteContent = `Se ha añadido el dote "${featName}" al personaje.`
        if (chosenAbility) {
          const abilityName = chosenAbility.charAt(0).toUpperCase() + chosenAbility.slice(1)
          noteContent += ` Se ha aumentado ${abilityName} en +1.`
        }
        if (chosenSpellId) {
          const spell = spells.find((s: Spell) => s.id === chosenSpellId)
          if (spell) {
            noteContent += ` Se ha añadido el hechizo "${spell.name}".`
          }
        }
        if (chosenSkills && chosenSkills.length > 0) {
          noteContent += ` Se han añadido proficiencias en: ${chosenSkills.join(', ')}.`
        }
        
        await createNote(`✅ Dote añadido: ${featName}`, noteContent)
        
        // Close feat dialog
        setFeatDialog({ open: false, feat: null })
      }
    } catch (error) {
      console.error('Error adding feat:', error)
    }
  }

  const handleDeleteFeat = async (characterFeatId: string, featName: string) => {
    if (!confirm(`¿Eliminar el dote "${featName}"? Esto revertirá cualquier bonificación de característica o hechizo asociado.`)) return
    
    try {
      const res = await fetch(`/api/characters/${selectedCharacter?.id}/feats?characterFeatId=${characterFeatId}`, {
        method: 'DELETE'
      })
      
      if (res.ok) {
        // Refresh character data
        fetchCharacterDetails(selectedCharacter?.id || '')
        
        // Create a note about the deletion
        await createNote(
          `❌ Dote eliminado: ${featName}`,
          `Se ha eliminado el dote "${featName}" del personaje. Se han revertido los cambios asociados.`
        )
        
        // Close detail dialog
        setFeatDetailDialog({ open: false, characterFeat: null })
      }
    } catch (error) {
      console.error('Error deleting feat:', error)
    }
  }

  const createNote = async (title: string, content: string) => {
    try {
      const res = await fetch(`/api/characters/${selectedCharacter?.id}/notes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, content, color: 'default' })
      })
      if (res.ok) {
        const newNote = await res.json()
        setNotes(prevNotes => [newNote, ...prevNotes])
      }
    } catch (error) {
      console.error('Error creating note:', error)
    }
  }

  // Roll ability scores (4d6 drop lowest, limited to 8-15)
  const rollAbilityScores = () => {
    setAbilityScoreMode('rolled')
    const roll = () => Math.floor(Math.random() * 6) + 1
    const roll4d6 = () => {
      const rolls = [roll(), roll(), roll(), roll()]
      rolls.sort((a, b) => b - a)
      const sum = rolls[0] + rolls[1] + rolls[2]
      // Limit result between 8 and 15
      return Math.max(8, Math.min(15, sum))
    }
    
    // Generate base scores (8-15)
    const baseScores = {
      strength: roll4d6(),
      dexterity: roll4d6(),
      constitution: roll4d6(),
      intelligence: roll4d6(),
      wisdom: roll4d6(),
      charisma: roll4d6()
    }
    
    setNewCharacter({
      ...newCharacter,
      ...baseScores
    })
  }

  // Standard array (base values only, background bonuses applied separately)
  const useStandardArray = () => {
    setAbilityScoreMode('standard')
    // Base scores (standard array)
    const baseScores = {
      strength: 15,
      dexterity: 14,
      constitution: 13,
      intelligence: 12,
      wisdom: 10,
      charisma: 8
    }
    
    setNewCharacter({
      ...newCharacter,
      ...baseScores
    })
  }

  // Get selected class and background for calculations
  const selectedClass = classes.find(c => c.id === newCharacter.classId)
  const selectedBackground = backgrounds.find(b => b.id === newCharacter.backgroundId)
  const selectedSpecies = species.find(s => s.id === newCharacter.speciesId)

  // HP calculation choice state
  const [hpChoice, setHpChoice] = useState<'max' | 'average'>('max')

  // Calculate HP based on choice for level 1
  const calculateHp = () => {
    if (!selectedClass) return 0
    const conMod = getModifier(newCharacter.constitution)
    if (hpChoice === 'max') {
      return selectedClass.hitDie + conMod
    } else {
      // Average: half die (rounded down) + 1
      return Math.floor(selectedClass.hitDie / 2) + 1 + conMod
    }
  }

  // Calculate HP for a specific level (used for higher level character creation)
  const calculateHpForLevel = () => {
    if (!selectedClass) return 0
    const conMod = getModifier(newCharacter.constitution)
    const hitDie = selectedClass.hitDie
    const avgHpPerLevel = Math.floor(hitDie / 2) + 1
    
    if (creationLevel === 1) {
      return calculateHp()
    }
    
    // Level 1: max die + conMod
    // Levels 2-N: average + conMod (using average for simplicity in creation)
    const firstLevelHp = hitDie + conMod
    const higherLevelHp = (creationLevel - 1) * (avgHpPerLevel + conMod)
    
    return firstLevelHp + higherLevelHp
  }

  // Get HP range for display
  const getHpRange = () => {
    if (!selectedClass) return { max: 0, avg: 0 }
    const conMod = getModifier(newCharacter.constitution)
    return {
      max: selectedClass.hitDie + conMod,
      avg: Math.floor(selectedClass.hitDie / 2) + 1 + conMod
    }
  }

  // Open background ability score dialog
  const openBackgroundAsiDialog = () => {
    if (!selectedBackground) return
    setBackgroundAsiChoice('plus2plus1')
    setBackgroundAsiSelection({ plus2Ability: null, plus1Ability: null })
    setBackgroundAsiDialog(true)
  }
  
  // Open species subtype dialog
  const openSpeciesSubtypeDialog = () => {
    if (!selectedSpecies) return
    
    const subtypeConfig = getSpeciesSubtypeConfig(selectedSpecies.name)
    if (subtypeConfig && subtypeConfig.requiresSelection) {
      setSelectedSpeciesSubtype(null)
      setSpeciesSubtypeDialog(true)
    } else {
      // No selection needed, proceed to next step (Ability Scores)
      setCreationStep(4)
    }
  }
  
  // Confirm species subtype selection
  const confirmSpeciesSubtype = () => {
    if (!selectedSpeciesSubtype) return
    setNewCharacter({ ...newCharacter, speciesSubtype: selectedSpeciesSubtype })
    setSpeciesSubtypeDialog(false)
    setCreationStep(4)
  }
  
  // Get selected species subtype option
  const getSelectedSubtypeOption = (): SpeciesSubtypeOption | null => {
    if (!selectedSpecies || !selectedSpeciesSubtype) return null
    const config = getSpeciesSubtypeConfig(selectedSpecies.name)
    if (!config) return null
    return config.options.find(opt => opt.id === selectedSpeciesSubtype) || null
  }
  
  // Apply background ability score improvements (now in step 4)
  const applyBackgroundAsi = () => {
    if (!selectedBackground) return
    
    const allowedAbilities = JSON.parse(selectedBackground.abilityScores)
    const abilityMap: Record<string, string> = {
      'Strength': 'strength',
      'Dexterity': 'dexterity',
      'Constitution': 'constitution',
      'Intelligence': 'intelligence',
      'Wisdom': 'wisdom',
      'Charisma': 'charisma'
    }
    
    const updates: any = {}
    
    if (backgroundAsiChoice === 'plus2plus1' && backgroundAsiSelection.plus2Ability && backgroundAsiSelection.plus1Ability) {
      // Apply +2 to one and +1 to another
      const plus2Key = abilityMap[backgroundAsiSelection.plus2Ability]
      const plus1Key = abilityMap[backgroundAsiSelection.plus1Ability]
      
      if (plus2Key) {
        updates[plus2Key] = Math.min(20, (newCharacter as any)[plus2Key] + 2)
      }
      if (plus1Key) {
        updates[plus1Key] = Math.min(20, (newCharacter as any)[plus1Key] + 1)
      }
    } else if (backgroundAsiChoice === 'plus1all') {
      // Apply +1 to all three abilities
      allowedAbilities.forEach((ability: string) => {
        const key = abilityMap[ability]
        if (key) {
          updates[key] = Math.min(20, (newCharacter as any)[key] + 1)
        }
      })
    }
    
    setNewCharacter({ ...newCharacter, ...updates })
    setBackgroundAsiDialog(false)
    setBackgroundBonusesApplied(true)
  }
  
  // Auto-apply background bonuses (for skipping selection in step 4)
  const autoApplyBackgroundBonuses = () => {
    if (!selectedBackground) return
    
    const allowedAbilities = JSON.parse(selectedBackground.abilityScores)
    const abilityMap: Record<string, string> = {
      'Strength': 'strength',
      'Dexterity': 'dexterity',
      'Constitution': 'constitution',
      'Intelligence': 'intelligence',
      'Wisdom': 'wisdom',
      'Charisma': 'charisma'
    }
    
    // Auto-apply: +2 to first ability, +1 to second
    const updates: any = {}
    if (allowedAbilities.length >= 2) {
      const plus2Key = abilityMap[allowedAbilities[0]]
      const plus1Key = abilityMap[allowedAbilities[1]]
      
      if (plus2Key) {
        updates[plus2Key] = Math.min(20, (newCharacter as any)[plus2Key] + 2)
      }
      if (plus1Key) {
        updates[plus1Key] = Math.min(20, (newCharacter as any)[plus1Key] + 1)
      }
    }
    
    // Set default selection for display purposes
    if (allowedAbilities.length >= 2) {
      setBackgroundAsiSelection({
        plus2Ability: allowedAbilities[0],
        plus1Ability: allowedAbilities[1]
      })
    }
    
    setNewCharacter({ ...newCharacter, ...updates })
    setBackgroundAsiDialog(false)
    setBackgroundBonusesApplied(true)
  }
  
  // Get background bonus display for an ability
  const getBackgroundBonus = (abilityName: string): number => {
    if (!selectedBackground) return 0
    
    const allowedAbilities = JSON.parse(selectedBackground.abilityScores)
    const abilityMap: Record<string, string> = {
      'strength': 'Strength',
      'dexterity': 'Dexterity',
      'constitution': 'Constitution',
      'intelligence': 'Intelligence',
      'wisdom': 'Wisdom',
      'charisma': 'Charisma'
    }
    
    const fullName = abilityMap[abilityName]
    if (!allowedAbilities.includes(fullName)) return 0
    
    if (backgroundAsiChoice === 'plus2plus1') {
      if (backgroundAsiSelection.plus2Ability === fullName) return 2
      if (backgroundAsiSelection.plus1Ability === fullName) return 1
    } else if (backgroundAsiChoice === 'plus1all') {
      return 1
    }
    
    return 0
  }

  // Calculate AC
  const calculateAC = () => {
    const dexMod = getModifier(newCharacter.dexterity)
    return 10 + dexMod
  }

  // Calculate spellcasting stats
  const calculateSpellcastingStats = (char: Character | null) => {
    if (!char || !char.characterClass?.spellcasting) return null
    
    const ability = SPELLCASTING_ABILITY[char.characterClass.name]
    if (!ability) return null
    
    let abilityScore = 10
    let abilityName = ''
    
    switch(ability) {
      case 'intelligence': abilityScore = char.intelligence; abilityName = 'Inteligencia'; break
      case 'wisdom': abilityScore = char.wisdom; abilityName = 'Sabiduría'; break
      case 'charisma': abilityScore = char.charisma; abilityName = 'Carisma'; break
    }
    
    const modifier = getModifier(abilityScore)
    const prof = char.proficiencyBonus || 2
    const spellSaveDC = 8 + prof + modifier
    const spellAttackBonus = prof + modifier
    
    return {
      ability,
      abilityName,
      abilityScore,
      modifier,
      spellSaveDC,
      spellAttackBonus
    }
  }

  // Render character creation wizard
  const renderCreationWizard = () => (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Crear Nuevo Personaje</h2>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Paso {creationStep} de 5</span>
          <Progress value={(creationStep / 5) * 100} className="w-32" />
        </div>
      </div>

      {/* Step 1: Background Selection */}
      {creationStep === 1 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5" />
              1. Elige tu Trasfondo
            </CardTitle>
            <CardDescription>
              Tu trasfondo determina tu historia y habilidades previas
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {backgrounds.map((bg) => (
                <Card 
                  key={bg.id}
                  className={`cursor-pointer transition-all hover:border-primary ${
                    newCharacter.backgroundId === bg.id ? 'border-2 border-primary bg-primary/5' : ''
                  }`}
                  onClick={() => setNewCharacter({ ...newCharacter, backgroundId: bg.id })}
                >
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">{bg.name}</CardTitle>
                    <CardDescription className="line-clamp-2">{bg.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="space-y-2 text-sm">
                      <div>
                        <strong>Puntuaciones:</strong>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {JSON.parse(bg.abilityScores).map((score: string) => (
                            <Badge key={score} variant="outline" className="text-xs">
                              {score.substring(0, 3).toUpperCase()}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div>
                        <strong>Dote:</strong> {bg.feat}
                      </div>
                      <div>
                        <strong>Habilidades:</strong>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {JSON.parse(bg.skillProficiencies).map((skill: string) => (
                            <Badge key={skill} variant="secondary" className="text-xs">
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      {bg.toolProficiency && bg.toolProficiency !== 'None' && (
                        <div>
                          <strong>Herramienta:</strong> {bg.toolProficiency}
                        </div>
                      )}
                    </div>
                  </CardContent>
                  <CardFooter className="pt-0">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation()
                        const equipment = JSON.parse(bg.equipment)
                        const equipmentA = equipment.A ? `${equipment.A.items.join(', ')} + ${equipment.A.gold} GP` : 'N/A'
                        const equipmentB = equipment.B ? `${equipment.B.items.length > 0 ? equipment.B.items.join(', ') + ' + ' : ''}${equipment.B.gold} GP` : 'N/A'
                        setInfoDialog({
                          open: true,
                          title: bg.name,
                          content: `
                            <div class="space-y-2">
                              <p><strong>Descripción:</strong> ${bg.description}</p>
                              <p><strong>Puntuaciones de Característica:</strong> ${JSON.parse(bg.abilityScores).join(', ')}</p>
                              <p><strong>Dote:</strong> ${bg.feat}</p>
                              <p><strong>Habilidades:</strong> ${JSON.parse(bg.skillProficiencies).join(', ')}</p>
                              <p><strong>Herramienta:</strong> ${bg.toolProficiency}</p>
                              <p><strong>Opción de Equipo A:</strong> ${equipmentA}</p>
                              <p><strong>Opción de Equipo B:</strong> ${equipmentB}</p>
                            </div>
                          `
                        })
                      }}
                    >
                      <Info className="h-4 w-4 mr-1" />
                      Ver detalles
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
            
            {/* Equipment Choice Section */}
            {selectedBackground && (
              <div className="mt-6 p-4 bg-muted/50 rounded-lg border">
                <h3 className="font-semibold mb-2 flex items-center gap-2">
                  <Package className="h-4 w-4" />
                  Elige tu Equipamiento Inicial
                </h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Tu trasfondo {selectedBackground.name} te ofrece dos opciones de equipamiento
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {(() => {
                    const equipment = JSON.parse(selectedBackground.equipment)
                    return (
                      <>
                        {/* Option A */}
                        <div 
                          className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                            newCharacter.backgroundEquipmentChoice === 'A' 
                              ? 'border-primary bg-primary/10' 
                              : 'border-border hover:border-primary/50'
                          }`}
                          onClick={() => setNewCharacter(prev => ({ ...prev, backgroundEquipmentChoice: 'A' }))}
                        >
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant={newCharacter.backgroundEquipmentChoice === 'A' ? 'default' : 'outline'}>
                              Opción A
                            </Badge>
                            {newCharacter.backgroundEquipmentChoice === 'A' && (
                              <Check className="h-4 w-4 text-green-500" />
                            )}
                          </div>
                          <div className="space-y-1 text-sm">
                            {equipment.A?.items?.map((item: string, idx: number) => (
                              <div key={idx} className="flex items-center gap-2">
                                <Package className="h-3 w-3 text-muted-foreground" />
                                <span>{item}</span>
                              </div>
                            ))}
                            {equipment.A?.gold > 0 && (
                              <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 font-medium mt-2">
                                <span>💰 {equipment.A.gold} Piezas de Oro</span>
                              </div>
                            )}
                          </div>
                        </div>
                        
                        {/* Option B */}
                        <div 
                          className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                            newCharacter.backgroundEquipmentChoice === 'B' 
                              ? 'border-primary bg-primary/10' 
                              : 'border-border hover:border-primary/50'
                          }`}
                          onClick={() => setNewCharacter(prev => ({ ...prev, backgroundEquipmentChoice: 'B' }))}
                        >
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant={newCharacter.backgroundEquipmentChoice === 'B' ? 'default' : 'outline'}>
                              Opción B
                            </Badge>
                            {newCharacter.backgroundEquipmentChoice === 'B' && (
                              <Check className="h-4 w-4 text-green-500" />
                            )}
                          </div>
                          <div className="space-y-1 text-sm">
                            {equipment.B?.items?.length > 0 ? (
                              equipment.B.items.map((item: string, idx: number) => (
                                <div key={idx} className="flex items-center gap-2">
                                  <Package className="h-3 w-3 text-muted-foreground" />
                                  <span>{item}</span>
                                </div>
                              ))
                            ) : (
                              <div className="text-muted-foreground italic">
                                Sin objetos adicionales
                              </div>
                            )}
                            {equipment.B?.gold > 0 && (
                              <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 font-medium mt-2">
                                <span>💰 {equipment.B.gold} Piezas de Oro</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </>
                    )
                  })()}
                </div>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-end">
            <Button 
              disabled={!newCharacter.backgroundId}
              onClick={() => setCreationStep(2)}
            >
              Siguiente <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </CardFooter>
        </Card>
      )}

      {/* Background Ability Score Selection Dialog */}
      <Dialog open={backgroundAsiDialog} onOpenChange={(open) => {
        if (!open) {
          // Just close the dialog without auto-applying
          setBackgroundAsiDialog(false)
        }
      }}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5 text-amber-500" />
              Bonificaciones de Trasfondo
            </DialogTitle>
            <DialogDescription>
              Tu trasfondo <strong>{selectedBackground?.name}</strong> te permite mejorar ciertas características. Elige cómo distribuir las bonificaciones:
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {/* Choice Type Selection */}
            <div className="flex gap-2">
              <Button
                variant={backgroundAsiChoice === 'plus2plus1' ? 'default' : 'outline'}
                className="flex-1"
                onClick={() => {
                  setBackgroundAsiChoice('plus2plus1')
                  setBackgroundAsiSelection({ plus2Ability: null, plus1Ability: null })
                }}
              >
                <span className="text-lg mr-2">+2 / +1</span>
                <span className="text-xs text-muted-foreground">Dos habilidades</span>
              </Button>
              <Button
                variant={backgroundAsiChoice === 'plus1all' ? 'default' : 'outline'}
                className="flex-1"
                onClick={() => setBackgroundAsiChoice('plus1all')}
              >
                <span className="text-lg mr-2">+1 / +1 / +1</span>
                <span className="text-xs text-muted-foreground">Las tres habilidades</span>
              </Button>
            </div>
            
            {/* Allowed Abilities Display */}
            {selectedBackground && (
              <div className="p-3 bg-muted rounded-lg">
                <p className="text-sm text-muted-foreground mb-2">Habilidades permitidas por tu trasfondo:</p>
                <div className="flex gap-2 flex-wrap">
                  {JSON.parse(selectedBackground.abilityScores).map((ability: string) => (
                    <Badge key={ability} variant="secondary" className="text-sm">
                      {ability === 'Strength' ? 'Fuerza' :
                       ability === 'Dexterity' ? 'Destreza' :
                       ability === 'Constitution' ? 'Constitución' :
                       ability === 'Intelligence' ? 'Inteligencia' :
                       ability === 'Wisdom' ? 'Sabiduría' :
                       ability === 'Charisma' ? 'Carisma' : ability}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            
            {/* Plus 2 / Plus 1 Selection */}
            {backgroundAsiChoice === 'plus2plus1' && selectedBackground && (
              <div className="space-y-4">
                <div>
                  <Label className="text-sm font-medium mb-2 block">Elige la característica con +2:</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {JSON.parse(selectedBackground.abilityScores).map((ability: string) => {
                      const abilityNames: Record<string, string> = {
                        'Strength': 'Fuerza',
                        'Dexterity': 'Destreza',
                        'Constitution': 'Constitución',
                        'Intelligence': 'Inteligencia',
                        'Wisdom': 'Sabiduría',
                        'Charisma': 'Carisma'
                      }
                      const isSelected = backgroundAsiSelection.plus2Ability === ability
                      const isDisabled = backgroundAsiSelection.plus1Ability === ability
                      
                      return (
                        <Button
                          key={ability}
                          variant={isSelected ? 'default' : 'outline'}
                          disabled={isDisabled}
                          className={`h-auto py-3 flex flex-col ${isSelected ? 'bg-green-600 hover:bg-green-700' : ''}`}
                          onClick={() => setBackgroundAsiSelection(prev => ({ ...prev, plus2Ability: ability }))}
                        >
                          <span className="font-bold">{abilityNames[ability]}</span>
                          <span className="text-xs mt-1">{isSelected ? '+2 seleccionado' : 'Click para +2'}</span>
                        </Button>
                      )
                    })}
                  </div>
                </div>
                
                <div>
                  <Label className="text-sm font-medium mb-2 block">Elige la característica con +1:</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {JSON.parse(selectedBackground.abilityScores).map((ability: string) => {
                      const abilityNames: Record<string, string> = {
                        'Strength': 'Fuerza',
                        'Dexterity': 'Destreza',
                        'Constitution': 'Constitución',
                        'Intelligence': 'Inteligencia',
                        'Wisdom': 'Sabiduría',
                        'Charisma': 'Carisma'
                      }
                      const isSelected = backgroundAsiSelection.plus1Ability === ability
                      const isDisabled = backgroundAsiSelection.plus2Ability === ability
                      
                      return (
                        <Button
                          key={ability}
                          variant={isSelected ? 'default' : 'outline'}
                          disabled={isDisabled}
                          className={`h-auto py-3 flex flex-col ${isSelected ? 'bg-blue-600 hover:bg-blue-700' : ''}`}
                          onClick={() => setBackgroundAsiSelection(prev => ({ ...prev, plus1Ability: ability }))}
                        >
                          <span className="font-bold">{abilityNames[ability]}</span>
                          <span className="text-xs mt-1">{isSelected ? '+1 seleccionado' : 'Click para +1'}</span>
                        </Button>
                      )
                    })}
                  </div>
                </div>
              </div>
            )}
            
            {/* Plus 1 to All Selection */}
            {backgroundAsiChoice === 'plus1all' && selectedBackground && (
              <div className="p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
                <p className="text-sm text-center">
                  <strong>Se aplicará +1 a:</strong>
                </p>
                <div className="flex justify-center gap-2 mt-2 flex-wrap">
                  {JSON.parse(selectedBackground.abilityScores).map((ability: string) => {
                    const abilityNames: Record<string, string> = {
                      'Strength': 'Fuerza',
                      'Dexterity': 'Destreza',
                      'Constitution': 'Constitución',
                      'Intelligence': 'Inteligencia',
                      'Wisdom': 'Sabiduría',
                      'Charisma': 'Carisma'
                    }
                    return (
                      <Badge key={ability} className="bg-green-600">
                        {abilityNames[ability]} +1
                      </Badge>
                    )
                  })}
                </div>
              </div>
            )}
          </div>
          
          <div className="flex justify-between">
            <Button 
              variant="ghost" 
              onClick={autoApplyBackgroundBonuses}
            >
              Omitir (aplicar automáticamente)
            </Button>
            <Button 
              onClick={applyBackgroundAsi}
              disabled={backgroundAsiChoice === 'plus2plus1' && (!backgroundAsiSelection.plus2Ability || !backgroundAsiSelection.plus1Ability)}
            >
              Aplicar y Continuar
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Step 2: Class Selection */}
      {creationStep === 2 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sword className="h-5 w-5" />
              2. Elige tu Clase y Habilidades
            </CardTitle>
            <CardDescription>
              Tu clase determina las capacidades principales de tu personaje
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Class Selection */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {classes.map((cls) => (
                <Card 
                  key={cls.id}
                  className={`cursor-pointer transition-all hover:border-primary ${
                    newCharacter.classId === cls.id ? 'border-2 border-primary bg-primary/5' : ''
                  }`}
                  onClick={() => setNewCharacter({ ...newCharacter, classId: cls.id, subclassId: '', selectedClassSkills: [], classEquipmentChoice: 'A' })}
                >
                  <CardHeader className="pb-2">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{cls.name}</CardTitle>
                      {cls.spellcasting && <Badge variant="secondary" className="gap-1"><Wand2 className="h-3 w-3" /> Lanzador</Badge>}
                    </div>
                    <CardDescription>Habilidad: {cls.primaryAbility}</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <p className="text-sm text-muted-foreground line-clamp-3">{cls.description}</p>
                    <div className="mt-2 flex flex-wrap gap-1">
                      <Badge variant="outline">d{cls.hitDie} PG</Badge>
                    </div>
                  </CardContent>
                  <CardFooter className="pt-0">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation()
                        setInfoDialog({
                          open: true,
                          title: cls.name,
                          content: `
                            <div class="space-y-2">
                              <p><strong>Descripción:</strong> ${cls.description}</p>
                              <p><strong>Habilidad Primaria:</strong> ${cls.primaryAbility}</p>
                              <p><strong>Dados de Golpe:</strong> d${cls.hitDie}</p>
                              <p><strong>Salvaciones:</strong> ${JSON.parse(cls.savingThrows).join(', ')}</p>
                              <p><strong>Habilidades disponibles:</strong> ${JSON.parse(cls.skillProficiencies).join(', ')}</p>
                              <p><strong>Entrenamiento en Armadura:</strong> ${JSON.parse(cls.armorTraining).join(', ')}</p>
                              <p><strong>Entrenamiento en Armas:</strong> ${JSON.parse(cls.weaponProficiencies).join(', ')}</p>
                              <p><strong>Subclases disponibles:</strong> ${cls.subclasses?.map(s => s.name).join(', ') || 'Ninguna'}
                            </div>
                          `
                        })
                      }}
                    >
                      <Info className="h-4 w-4 mr-1" />
                      Ver detalles
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
            
            {/* Skill Selection for Class */}
            {newCharacter.classId && (
              <div className="mt-6 p-4 bg-muted/50 rounded-lg border">
                <h3 className="font-semibold mb-2 flex items-center gap-2">
                  <Brain className="h-4 w-4" />
                  Elige {(() => {
                    const cls = classes.find(c => c.id === newCharacter.classId)
                    return cls?.name === 'Bard' ? '3' : '2'
                  })()} Habilidades de Clase
                </h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Selecciona las habilidades en las que tu personaje será competente
                </p>
                
                {/* Show background skills that are already granted */}
                {selectedBackground && JSON.parse(selectedBackground.skillProficiencies).length > 0 && (
                  <div className="mb-3 p-2 bg-green-500/10 border border-green-500/30 rounded-lg">
                    <p className="text-xs text-green-600 dark:text-green-400 mb-1">
                      <strong>Habilidades de tu trasfondo ({selectedBackground.name}):</strong>
                    </p>
                    <div className="flex flex-wrap gap-1">
                      {JSON.parse(selectedBackground.skillProficiencies).map((skill: string) => (
                        <Badge key={skill} variant="secondary" className="bg-green-600/20 text-green-700 dark:text-green-300 border-green-500/30">
                          <Check className="h-3 w-3 mr-1" />
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
                
                <div className="flex flex-wrap gap-2">
                  {(() => {
                    const cls = classes.find(c => c.id === newCharacter.classId)
                    if (!cls) return null
                    const classSkills = JSON.parse(cls.skillProficiencies)
                    // Get background skills to exclude
                    const backgroundSkills = selectedBackground ? JSON.parse(selectedBackground.skillProficiencies) : []
                    
                    // All possible skills in the game
                    const allSkills = [
                      'Acrobatics', 'Animal Handling', 'Arcana', 'Athletics', 
                      'Deception', 'History', 'Insight', 'Intimidation', 
                      'Investigation', 'Medicine', 'Nature', 'Perception', 
                      'Performance', 'Persuasion', 'Religion', 'Sleight of Hand', 
                      'Stealth', 'Survival'
                    ]
                    
                    // If classSkills contains 'Any', use all skills
                    const availableSkills = classSkills.includes('Any') 
                      ? allSkills.filter((skill: string) => !backgroundSkills.includes(skill))
                      : classSkills.filter((skill: string) => !backgroundSkills.includes(skill))
                    
                    if (availableSkills.length === 0) {
                      return (
                        <p className="text-sm text-muted-foreground italic">
                          Todas las habilidades de clase ya están cubiertas por tu trasfondo.
                        </p>
                      )
                    }
                    
                    // Determine max skills based on class (Bard gets 3, others get 2)
                    const maxSkills = cls.name === 'Bard' ? 3 : 2
                    
                    return availableSkills.map((skill: string) => {
                      const isSelected = newCharacter.selectedClassSkills.includes(skill)
                      return (
                        <Badge 
                          key={skill}
                          variant={isSelected ? 'default' : 'outline'}
                          className={`cursor-pointer transition-all ${isSelected ? 'bg-primary' : 'hover:bg-primary/10'}`}
                          onClick={() => {
                            if (isSelected) {
                              setNewCharacter(prev => ({
                                ...prev,
                                selectedClassSkills: prev.selectedClassSkills.filter(s => s !== skill)
                              }))
                            } else if (newCharacter.selectedClassSkills.length < maxSkills) {
                              setNewCharacter(prev => ({
                                ...prev,
                                selectedClassSkills: [...prev.selectedClassSkills, skill]
                              }))
                            }
                          }}
                        >
                          {isSelected && <Check className="h-3 w-3 mr-1" />}
                          {skill}
                        </Badge>
                      )
                    })
                  })()}
                </div>
                <p className="text-xs text-muted-foreground mt-2">
                  Seleccionadas: {newCharacter.selectedClassSkills.length} / {(() => {
                    const cls = classes.find(c => c.id === newCharacter.classId)
                    return cls?.name === 'Bard' ? 3 : 2
                  })()}
                </p>
              </div>
            )}
            
            {/* Class Equipment Choice Section */}
            {selectedClass && (
              <div className="mt-6 p-4 bg-muted/50 rounded-lg border">
                <h3 className="font-semibold mb-2 flex items-center gap-2">
                  <Package className="h-4 w-4" />
                  Elige tu Equipamiento de Clase
                </h3>
                <p className="text-sm text-muted-foreground mb-3">
                  Tu clase {selectedClass.name} te ofrece dos opciones de equipamiento inicial
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {(() => {
                    const equipment = JSON.parse(selectedClass.startingEquipment)
                    return (
                      <>
                        {/* Option A */}
                        <div 
                          className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                            newCharacter.classEquipmentChoice === 'A' 
                              ? 'border-primary bg-primary/10' 
                              : 'border-border hover:border-primary/50'
                          }`}
                          onClick={() => setNewCharacter(prev => ({ ...prev, classEquipmentChoice: 'A' }))}
                        >
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant={newCharacter.classEquipmentChoice === 'A' ? 'default' : 'outline'}>
                              Opción A
                            </Badge>
                            {newCharacter.classEquipmentChoice === 'A' && (
                              <Check className="h-4 w-4 text-green-500" />
                            )}
                          </div>
                          <div className="space-y-1 text-sm">
                            {equipment.A?.items?.map((item: string, idx: number) => (
                              <div key={idx} className="flex items-center gap-2">
                                <Package className="h-3 w-3 text-muted-foreground" />
                                <span>{item}</span>
                              </div>
                            ))}
                            {equipment.A?.gold > 0 && (
                              <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 font-medium mt-2">
                                <span>💰 {equipment.A.gold} Piezas de Oro</span>
                              </div>
                            )}
                          </div>
                        </div>
                        
                        {/* Option B */}
                        <div 
                          className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                            newCharacter.classEquipmentChoice === 'B' 
                              ? 'border-primary bg-primary/10' 
                              : 'border-border hover:border-primary/50'
                          }`}
                          onClick={() => setNewCharacter(prev => ({ ...prev, classEquipmentChoice: 'B' }))}
                        >
                          <div className="flex items-center gap-2 mb-2">
                            <Badge variant={newCharacter.classEquipmentChoice === 'B' ? 'default' : 'outline'}>
                              Opción B
                            </Badge>
                            {newCharacter.classEquipmentChoice === 'B' && (
                              <Check className="h-4 w-4 text-green-500" />
                            )}
                          </div>
                          <div className="space-y-1 text-sm">
                            {equipment.B?.items?.length > 0 ? (
                              equipment.B.items.map((item: string, idx: number) => (
                                <div key={idx} className="flex items-center gap-2">
                                  <Package className="h-3 w-3 text-muted-foreground" />
                                  <span>{item}</span>
                                </div>
                              ))
                            ) : (
                              <div className="text-muted-foreground italic">
                                Sin objetos adicionales
                              </div>
                            )}
                            {equipment.B?.gold > 0 && (
                              <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 font-medium mt-2">
                                <span>💰 {equipment.B.gold} Piezas de Oro</span>
                              </div>
                            )}
                          </div>
                        </div>
                      </>
                    )
                  })()}
                </div>
              </div>
            )}
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={() => setCreationStep(1)}>
              <ChevronLeft className="h-4 w-4 mr-1" /> Anterior
            </Button>
            <Button 
              disabled={!newCharacter.classId}
              onClick={() => setCreationStep(3)}
            >
              Siguiente <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </CardFooter>
        </Card>
      )}

      {/* Step 3: Species Selection */}
      {creationStep === 3 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              3. Elige tu Especie
            </CardTitle>
            <CardDescription>
              Tu especie determina tus rasgos innatos y capacidades
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {species.map((sp) => {
                const subtypeConfig = getSpeciesSubtypeConfig(sp.name)
                return (
                  <Card 
                    key={sp.id}
                    className={`cursor-pointer transition-all hover:border-primary ${
                      newCharacter.speciesId === sp.id ? 'border-2 border-primary bg-primary/5' : ''
                    }`}
                    onClick={() => {
                      // Reset subtype when species changes
                      setNewCharacter({ 
                        ...newCharacter, 
                        speciesId: sp.id,
                        speciesSubtype: newCharacter.speciesId === sp.id ? newCharacter.speciesSubtype : '',
                        humanFeatId: newCharacter.speciesId === sp.id ? newCharacter.humanFeatId : ''
                      })
                      if (newCharacter.speciesId !== sp.id) {
                        setSelectedSpeciesSubtype(null)
                      }
                    }}
                  >
                    <CardHeader className="pb-2">
                      <div className="flex items-center justify-between">
                        <CardTitle className="text-lg">{sp.name}</CardTitle>
                        {subtypeConfig?.requiresSelection && (
                          <Badge variant="secondary" className="text-xs">
                            Requiere elección
                          </Badge>
                        )}
                      </div>
                      <CardDescription>Tamaño: {sp.size} | Velocidad: {sp.speed} ft</CardDescription>
                    </CardHeader>
                    <CardContent className="pb-2">
                      <p className="text-sm text-muted-foreground line-clamp-3">{sp.description}</p>
                      {subtypeConfig?.requiresSelection && (
                        <p className="text-xs text-amber-600 mt-1">
                          Elige: {subtypeConfig.selectionName}
                        </p>
                      )}
                    </CardContent>
                    <CardFooter className="pt-0">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation()
                          const traits = JSON.parse(sp.traits)
                          setInfoDialog({
                            open: true,
                            title: sp.name,
                            content: `
                              <div class="space-y-2">
                                <p><strong>Descripción:</strong> ${sp.description}</p>
                                <p><strong>Tamaño:</strong> ${sp.size}</p>
                                <p><strong>Velocidad:</strong> ${sp.speed} pies</p>
                                <div><strong>Rasgos:</strong>
                                  <ul class="list-disc pl-5 mt-1">
                                    ${Object.entries(traits).map(([key, value]) => 
                                      `<li><strong>${key}:</strong> ${value}</li>`
                                    ).join('')}
                                  </ul>
                                </div>
                              </div>
                            `
                          })
                        }}
                      >
                        <Info className="h-4 w-4 mr-1" />
                        Ver rasgos
                      </Button>
                    </CardFooter>
                  </Card>
                )
              })}
            </div>
            
            {/* Show selected subtype if applicable */}
            {selectedSpecies && (() => {
              const config = getSpeciesSubtypeConfig(selectedSpecies.name)
              
              // Handle Human feat selection display
              if (selectedSpecies.name === 'Human' && newCharacter.humanFeatId) {
                const selectedFeat = allFeats.find(f => f.id === newCharacter.humanFeatId)
                if (selectedFeat) {
                  return (
                    <Alert className="bg-green-500/10 border-green-500/30 mt-4">
                      <Check className="h-4 w-4 text-green-500" />
                      <AlertDescription>
                        <strong>Dote de Origen (Versátil):</strong> {selectedFeat.name}
                        <div className="text-sm text-muted-foreground mt-1">
                          {selectedFeat.benefit}
                        </div>
                      </AlertDescription>
                    </Alert>
                  )
                }
              }
              
              // Handle other species subtype display
              if (config && newCharacter.speciesSubtype) {
                const option = config.options.find(opt => opt.id === newCharacter.speciesSubtype)
                if (!option) return null
                
                return (
                  <Alert className="bg-green-500/10 border-green-500/30 mt-4">
                    <Check className="h-4 w-4 text-green-500" />
                    <AlertDescription>
                      <strong>{config.selectionName}:</strong> {option.name}
                      <div className="text-sm text-muted-foreground mt-1">
                        {option.benefits.join(' • ')}
                      </div>
                    </AlertDescription>
                  </Alert>
                )
              }
              
              return null
            })()}
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={() => setCreationStep(2)}>
              <ChevronLeft className="h-4 w-4 mr-1" /> Anterior
            </Button>
            <Button 
              disabled={!newCharacter.speciesId}
              onClick={openSpeciesSubtypeDialog}
            >
              Siguiente <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </CardFooter>
        </Card>
      )}
      
      {/* Species Subtype Selection Dialog */}
      <Dialog open={speciesSubtypeDialog} onOpenChange={setSpeciesSubtypeDialog}>
        <DialogContent className="max-w-3xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {getSpeciesIcon(selectedSpecies?.name || '')}
              {selectedSpecies && getSpeciesSubtypeConfig(selectedSpecies.name)?.selectionName}
            </DialogTitle>
            <DialogDescription>
              {selectedSpecies?.name === 'Human' ? (
                <>Tu especie <strong>Humano</strong> tiene el rasgo <strong>Versátil</strong>: ganas un dote de origen de tu elección. <em>Skilled</em> es el recomendado.</>
              ) : (
                <>Tu especie <strong>{selectedSpecies?.name}</strong> requiere que elijas una opción específica. Esta elección determinará tus rasgos y habilidades especiales.</>
              )}
            </DialogDescription>
          </DialogHeader>
          
          <ScrollArea className="max-h-[50vh] pr-4">
            {/* Human Feat Selection */}
            {selectedSpecies?.name === 'Human' ? (
              <div className="py-4">
                <div className="mb-4 flex gap-2">
                  <Input
                    placeholder="Buscar dote..."
                    value={featSearchTerm}
                    onChange={(e) => setFeatSearchTerm(e.target.value)}
                    className="max-w-xs"
                  />
                  <Select value={featCategoryFilter} onValueChange={setFeatCategoryFilter}>
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder="Categoría" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas</SelectItem>
                      <SelectItem value="Origin">Origen</SelectItem>
                      <SelectItem value="General">General</SelectItem>
                      <SelectItem value="Fighting Style">Estilo de Combate</SelectItem>
                      <SelectItem value="Epic Boon">Dote Épica</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="grid grid-cols-1 gap-3">
                  {allFeats
                    .filter(feat => feat.category === 'Origin')
                    .filter(feat => {
                      const matchesSearch = feat.name.toLowerCase().includes(featSearchTerm.toLowerCase()) ||
                        (feat.description && feat.description.toLowerCase().includes(featSearchTerm.toLowerCase()))
                      return matchesSearch
                    })
                    .map((feat) => {
                      const isSelected = newCharacter.humanFeatId === feat.id
                      
                      return (
                        <div
                          key={feat.id}
                          className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                            isSelected 
                              ? 'border-primary bg-primary/10' 
                              : 'border-border hover:border-primary/50 hover:bg-muted/50'
                          }`}
                          onClick={() => setNewCharacter(prev => ({ ...prev, humanFeatId: feat.id }))}
                        >
                          <div className="flex items-start justify-between mb-2">
                            <h4 className="font-bold">{feat.name}</h4>
                            <div className="flex gap-2">
                              <Badge variant="outline" className="text-xs">
                                Origen
                              </Badge>
                              {isSelected && (
                                <Badge className="bg-primary text-xs">Seleccionado</Badge>
                              )}
                            </div>
                          </div>
                          
                          <p className="text-sm text-muted-foreground mb-2">{feat.description}</p>
                          
                          <div className="space-y-1">
                            <div className="flex items-center gap-2 text-xs">
                              <Check className="h-3 w-3 text-green-500 flex-shrink-0" />
                              <span>{feat.benefit}</span>
                            </div>
                          </div>
                        </div>
                      )
                    })}
                </div>
              </div>
            ) : (
              /* Regular Species Subtype Selection */
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 py-4">
                {selectedSpecies && getSpeciesSubtypeConfig(selectedSpecies.name)?.options?.map((option) => {
                  const isSelected = selectedSpeciesSubtype === option.id
                  
                  return (
                    <div
                      key={option.id}
                      className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                        isSelected 
                          ? 'border-primary bg-primary/10' 
                          : 'border-border hover:border-primary/50 hover:bg-muted/50'
                      }`}
                      onClick={() => setSelectedSpeciesSubtype(option.id)}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-bold">{option.name}</h4>
                        {isSelected && (
                          <Badge className="bg-primary text-xs">Seleccionado</Badge>
                        )}
                      </div>
                      
                      <p className="text-sm text-muted-foreground mb-2">{option.description}</p>
                      
                      {/* Benefits */}
                      <div className="space-y-1">
                        {option.benefits.map((benefit, idx) => (
                          <div key={idx} className="flex items-center gap-2 text-xs">
                            <Check className="h-3 w-3 text-green-500 flex-shrink-0" />
                            <span>{benefit}</span>
                          </div>
                        ))}
                      </div>
                      
                      {/* Damage Resistance */}
                      {option.damageResistance && (
                        <Badge variant="outline" className="mt-2 text-xs bg-amber-500/10">
                          <Shield className="h-3 w-3 mr-1" />
                          Resistencia: {option.damageResistance}
                        </Badge>
                      )}
                      
                      {/* Cantrip */}
                      {option.cantrip && (
                        <Badge variant="outline" className="mt-2 ml-1 text-xs bg-purple-500/10">
                          <Wand2 className="h-3 w-3 mr-1" />
                          Truco: {option.cantrip}
                        </Badge>
                      )}
                      
                      {/* Spells */}
                      {option.spells && option.spells.length > 0 && (
                        <div className="mt-2 pt-2 border-t border-border/50">
                          <p className="text-xs text-muted-foreground mb-1">Hechizos al subir de nivel:</p>
                          <div className="flex flex-wrap gap-1">
                            {option.spells.map((spell, idx) => (
                              <Badge key={idx} variant="secondary" className="text-xs">
                                Nv.{spell.level}: {spell.spellName}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )
                })}
              </div>
            )}
          </ScrollArea>
          
          <div className="flex justify-between pt-4 border-t">
            <Button variant="ghost" onClick={() => setSpeciesSubtypeDialog(false)}>
              Cancelar
            </Button>
            <div className="flex gap-2">
              {selectedSpecies?.name === 'Human' && (
                <Button 
                  variant="outline"
                  onClick={() => {
                    // Allow skipping feat selection
                    setSpeciesSubtypeDialog(false)
                    setCreationStep(4)
                  }}
                >
                  Omitir por ahora
                </Button>
              )}
              <Button 
                onClick={() => {
                  if (selectedSpecies?.name === 'Human') {
                    // For Human, just close dialog and proceed
                    setSpeciesSubtypeDialog(false)
                    setCreationStep(4)
                  } else {
                    confirmSpeciesSubtype()
                  }
                }}
                disabled={selectedSpecies?.name !== 'Human' && !selectedSpeciesSubtype}
              >
                {selectedSpecies?.name === 'Human' ? 'Confirmar' : 'Confirmar Elección'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Step 4: Ability Scores */}
      {creationStep === 4 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="h-5 w-5" />
              4. Determina tus Puntuaciones de Característica
            </CardTitle>
            <CardDescription>
              Asigna tus puntuaciones base, luego aplica las bonificaciones de tu trasfondo
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Background Bonus Status - Show button to apply if not applied yet */}
            {selectedBackground && !backgroundBonusesApplied && (
              <Alert className="bg-amber-500/10 border-amber-500/30">
                <AlertTriangle className="h-4 w-4 text-amber-500" />
                <AlertDescription className="flex items-center justify-between">
                  <span>
                    <strong>Bonificaciones de {selectedBackground.name} pendientes:</strong>{' '}
                    Primero determina tus puntuaciones base, luego aplica las bonificaciones del trasfondo.
                  </span>
                  <Button 
                    variant="default"
                    size="sm"
                    onClick={openBackgroundAsiDialog}
                  >
                    Aplicar Bonificaciones
                  </Button>
                </AlertDescription>
              </Alert>
            )}
            
            {/* Background Bonus Applied Notice */}
            {selectedBackground && backgroundBonusesApplied && (
              <Alert className="bg-green-500/10 border-green-500/30">
                <Check className="h-4 w-4 text-green-500" />
                <AlertDescription className="flex items-center justify-between">
                  <span>
                    <strong>Bonificaciones de {selectedBackground.name} aplicadas:</strong>{' '}
                    {backgroundAsiChoice === 'plus2plus1' && backgroundAsiSelection.plus2Ability && backgroundAsiSelection.plus1Ability && (
                      <span>
                        +2 a {backgroundAsiSelection.plus2Ability === 'Strength' ? 'Fuerza' :
                              backgroundAsiSelection.plus2Ability === 'Dexterity' ? 'Destreza' :
                              backgroundAsiSelection.plus2Ability === 'Constitution' ? 'Constitución' :
                              backgroundAsiSelection.plus2Ability === 'Intelligence' ? 'Inteligencia' :
                              backgroundAsiSelection.plus2Ability === 'Wisdom' ? 'Sabiduría' : 'Carisma'},
                        +1 a {backgroundAsiSelection.plus1Ability === 'Strength' ? 'Fuerza' :
                              backgroundAsiSelection.plus1Ability === 'Dexterity' ? 'Destreza' :
                              backgroundAsiSelection.plus1Ability === 'Constitution' ? 'Constitución' :
                              backgroundAsiSelection.plus1Ability === 'Intelligence' ? 'Inteligencia' :
                              backgroundAsiSelection.plus1Ability === 'Wisdom' ? 'Sabiduría' : 'Carisma'}
                      </span>
                    )}
                    {backgroundAsiChoice === 'plus1all' && (
                      <span>
                        +1 a {JSON.parse(selectedBackground.abilityScores).map((a: string) => 
                          a === 'Strength' ? 'Fuerza' :
                          a === 'Dexterity' ? 'Destreza' :
                          a === 'Constitution' ? 'Constitución' :
                          a === 'Intelligence' ? 'Inteligencia' :
                          a === 'Wisdom' ? 'Sabiduría' : 'Carisma'
                        ).join(', ')}
                      </span>
                    )}
                  </span>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => {
                      // Revert background bonuses
                      const allowedAbilities = JSON.parse(selectedBackground.abilityScores)
                      const abilityMap: Record<string, string> = {
                        'Strength': 'strength',
                        'Dexterity': 'dexterity',
                        'Constitution': 'constitution',
                        'Intelligence': 'intelligence',
                        'Wisdom': 'wisdom',
                        'Charisma': 'charisma'
                      }
                      const updates: any = {}
                      
                      if (backgroundAsiChoice === 'plus2plus1' && backgroundAsiSelection.plus2Ability && backgroundAsiSelection.plus1Ability) {
                        const plus2Key = abilityMap[backgroundAsiSelection.plus2Ability]
                        const plus1Key = abilityMap[backgroundAsiSelection.plus1Ability]
                        if (plus2Key) updates[plus2Key] = Math.max(3, (newCharacter as any)[plus2Key] - 2)
                        if (plus1Key) updates[plus1Key] = Math.max(3, (newCharacter as any)[plus1Key] - 1)
                      } else if (backgroundAsiChoice === 'plus1all') {
                        allowedAbilities.forEach((ability: string) => {
                          const key = abilityMap[ability]
                          if (key) updates[key] = Math.max(3, (newCharacter as any)[key] - 1)
                        })
                      }
                      
                      setNewCharacter({ ...newCharacter, ...updates })
                      setBackgroundBonusesApplied(false)
                      setBackgroundAsiSelection({ plus2Ability: null, plus1Ability: null })
                    }}
                  >
                    Revertir
                  </Button>
                </AlertDescription>
              </Alert>
            )}

            <div className="flex flex-wrap gap-2">
              <Button 
                onClick={rollAbilityScores}
                variant={abilityScoreMode === 'rolled' ? 'default' : 'outline'}
              >
                <Dices className="h-4 w-4 mr-1" /> Tirar 4d6
              </Button>
              <Button 
                variant={abilityScoreMode === 'standard' ? 'default' : 'outline'}
                onClick={useStandardArray}
              >
                Array Estándar (15, 14, 13, 12, 10, 8)
              </Button>
              <Button 
                variant={abilityScoreMode === 'pointbuy' ? 'default' : 'outline'}
                onClick={resetToPointBuyDefault}
              >
                Point Buy (27 puntos)
              </Button>
            </div>

            {/* Point Buy Info */}
            {abilityScoreMode === 'pointbuy' && (
              <Alert className="bg-blue-500/10 border-blue-500/30">
                <Info className="h-4 w-4 text-blue-500" />
                <AlertDescription className="flex items-center justify-between">
                  <div>
                    <strong>Sistema Point Buy:</strong> Tienes 27 puntos para distribuir. 
                    Las puntuaciones van de 8 a 15. Coste: 8-9 (0-1), 10-13 (2-5), 14 (7), 15 (9).
                  </div>
                  <Badge className={`text-lg ${calculatePointsSpent() > 27 ? 'bg-red-500' : 'bg-green-600'}`}>
                    Puntos: {27 - calculatePointsSpent()} / 27
                  </Badge>
                </AlertDescription>
              </Alert>
            )}

            <Alert>
              <Info className="h-4 w-4" />
              <AlertDescription>
                {selectedClass && (
                  <span>La habilidad primaria de {selectedClass.name} es <strong>{selectedClass.primaryAbility}</strong>
                  {selectedClass.spellcasting && (
                    <span> | Habilidad de conjuración: <strong>{SPELLCASTING_ABILITY[selectedClass.name]}</strong></span>
                  )}</span>
                )}
              </AlertDescription>
            </Alert>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {[
                { name: 'Fuerza', key: 'strength', icon: <Sword className="h-4 w-4" /> },
                { name: 'Destreza', key: 'dexterity', icon: <Zap className="h-4 w-4" /> },
                { name: 'Constitución', key: 'constitution', icon: <Heart className="h-4 w-4" /> },
                { name: 'Inteligencia', key: 'intelligence', icon: <Brain className="h-4 w-4" /> },
                { name: 'Sabiduría', key: 'wisdom', icon: <Eye className="h-4 w-4" /> },
                { name: 'Carisma', key: 'charisma', icon: <Sparkles className="h-4 w-4" /> }
              ].map((ability) => (
                <Card key={ability.key}>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm flex items-center gap-1">
                      {ability.icon} {ability.name}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {abilityScoreMode === 'pointbuy' ? (
                      <div className="space-y-2">
                        <div className="flex items-center justify-center gap-2">
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8 w-8 p-0"
                            onClick={() => decreaseAbilityScore(ability.key as any)}
                            disabled={newCharacter[ability.key as keyof typeof newCharacter] as number <= 8}
                          >
                            -
                          </Button>
                          <span className="text-2xl font-bold w-8 text-center">
                            {newCharacter[ability.key as keyof typeof newCharacter] as number}
                          </span>
                          <Button
                            variant="outline"
                            size="sm"
                            className="h-8 w-8 p-0"
                            onClick={() => increaseAbilityScore(ability.key as any)}
                            disabled={newCharacter[ability.key as keyof typeof newCharacter] as number >= 15}
                          >
                            +
                          </Button>
                        </div>
                        <div className="text-center text-sm text-muted-foreground">
                          ({getModifierString(newCharacter[ability.key as keyof typeof newCharacter] as number)})
                          <span className="text-xs block">
                            Coste: {POINT_BUY_COST[newCharacter[ability.key as keyof typeof newCharacter] as number] || 0}
                          </span>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <Input
                          type="number"
                          min={3}
                          max={20}
                          value={newCharacter[ability.key as keyof typeof newCharacter] as number}
                          onChange={(e) => setNewCharacter({
                            ...newCharacter,
                            [ability.key]: parseInt(e.target.value) || 10
                          })}
                          className="w-16 text-center text-lg font-bold"
                        />
                        <span className="text-lg font-bold text-muted-foreground">
                          ({getModifierString(newCharacter[ability.key as keyof typeof newCharacter] as number)})
                        </span>
                      </div>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Estadísticas Calculadas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {/* HP Choice Section */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span>Puntos de Golpe:</span>
                      <span className="font-bold text-lg">{calculateHp()}</span>
                    </div>
                    {selectedClass && (
                      <div className="flex gap-2">
                        <Button
                          variant={hpChoice === 'max' ? 'default' : 'outline'}
                          size="sm"
                          className="flex-1"
                          onClick={() => setHpChoice('max')}
                        >
                          <span className="font-bold">{getHpRange().max}</span>
                          <span className="text-xs ml-1">Máximo</span>
                        </Button>
                        <Button
                          variant={hpChoice === 'average' ? 'default' : 'outline'}
                          size="sm"
                          className="flex-1"
                          onClick={() => setHpChoice('average')}
                        >
                          <span className="font-bold">{getHpRange().avg}</span>
                          <span className="text-xs ml-1">Promedio</span>
                        </Button>
                      </div>
                    )}
                    {selectedClass && (
                      <p className="text-xs text-muted-foreground">
                        Dado de Golpe: d{selectedClass.hitDie} | Mod CON: {getModifierString(newCharacter.constitution)}
                      </p>
                    )}
                  </div>
                  <Separator className="my-2" />
                  <div className="flex justify-between">
                    <span>Clase de Armadura:</span>
                    <span className="font-bold">{calculateAC()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Iniciativa:</span>
                    <span className="font-bold">{getModifierString(newCharacter.dexterity)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Velocidad:</span>
                    <span className="font-bold">{selectedSpecies?.speed || 30} ft</span>
                  </div>
                  {selectedClass?.spellcasting && (
                    <>
                      <Separator className="my-2" />
                      <div className="font-semibold text-sm">Conjuración (Nivel 1)</div>
                      <div className="flex justify-between">
                        <span>CD de Hechizos:</span>
                        <span className="font-bold">
                          {8 + 2 + getModifier(
                            SPELLCASTING_ABILITY[selectedClass.name] === 'intelligence' ? newCharacter.intelligence :
                            SPELLCASTING_ABILITY[selectedClass.name] === 'wisdom' ? newCharacter.wisdom :
                            newCharacter.charisma
                          )}
                        </span>
                      </div>
                      <div className="flex justify-between">
                        <span>Bono de Ataque:</span>
                        <span className="font-bold">
                          +{2 + getModifier(
                            SPELLCASTING_ABILITY[selectedClass.name] === 'intelligence' ? newCharacter.intelligence :
                            SPELLCASTING_ABILITY[selectedClass.name] === 'wisdom' ? newCharacter.wisdom :
                            newCharacter.charisma
                          )}
                        </span>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg">Salvaciones</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    {selectedClass && (
                      <>
                        <div>FUE: {getModifierString(newCharacter.strength)} {JSON.parse(selectedClass.savingThrows).includes('Strength') && '( competente )'}</div>
                        <div>DES: {getModifierString(newCharacter.dexterity)} {JSON.parse(selectedClass.savingThrows).includes('Dexterity') && '( competente )'}</div>
                        <div>CON: {getModifierString(newCharacter.constitution)} {JSON.parse(selectedClass.savingThrows).includes('Constitution') && '( competente )'}</div>
                        <div>INT: {getModifierString(newCharacter.intelligence)} {JSON.parse(selectedClass.savingThrows).includes('Intelligence') && '( competente )'}</div>
                        <div>SAB: {getModifierString(newCharacter.wisdom)} {JSON.parse(selectedClass.savingThrows).includes('Wisdom') && '( competente )'}</div>
                        <div>CAR: {getModifierString(newCharacter.charisma)} {JSON.parse(selectedClass.savingThrows).includes('Charisma') && '( competente )'}</div>
                      </>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={() => setCreationStep(3)}>
              <ChevronLeft className="h-4 w-4 mr-1" /> Anterior
            </Button>
            <Button onClick={() => setCreationStep(5)}>
              Siguiente <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </CardFooter>
        </Card>
      )}

      {/* Step 5: Final Details */}
      {creationStep === 5 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5" />
              5. Detalles Finales
            </CardTitle>
            <CardDescription>
              Completa los detalles de tu personaje
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nombre del Personaje *</Label>
                <Input
                  id="name"
                  value={newCharacter.name}
                  onChange={(e) => setNewCharacter({ ...newCharacter, name: e.target.value })}
                  placeholder="Ingresa el nombre de tu personaje"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="level">Nivel Inicial</Label>
                <Select
                  value={creationLevel.toString()}
                  onValueChange={(value) => setCreationLevel(parseInt(value))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Selecciona nivel" />
                  </SelectTrigger>
                  <SelectContent>
                    {[1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20].map(lvl => (
                      <SelectItem key={lvl} value={lvl.toString()}>
                        Nivel {lvl}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                {creationLevel > 1 && (
                  <p className="text-xs text-muted-foreground">
                    Se generarán notas pendientes para las decisiones de niveles superiores
                  </p>
                )}
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="alignment">Alineamiento</Label>
              <Select
                value={newCharacter.alignment}
                onValueChange={(value) => setNewCharacter({ ...newCharacter, alignment: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Selecciona alineamiento" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="LG">Legal Bueno</SelectItem>
                  <SelectItem value="NG">Neutral Bueno</SelectItem>
                  <SelectItem value="CG">Caótico Bueno</SelectItem>
                  <SelectItem value="LN">Legal Neutral</SelectItem>
                  <SelectItem value="N">Neutral</SelectItem>
                  <SelectItem value="CN">Caótico Neutral</SelectItem>
                  <SelectItem value="LE">Legal Malvado</SelectItem>
                  <SelectItem value="NE">Neutral Malvado</SelectItem>
                  <SelectItem value="CE">Caótico Malvado</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Subclass selection at level 3+ */}
            {selectedClass?.subclasses && selectedClass.subclasses.length > 0 && (
              <div className="space-y-2">
                <Label>
                  Subclase {creationLevel >= 3 ? '(obligatorio)' : '(seleccionable al nivel 3)'}
                </Label>
                <Select
                  value={newCharacter.subclassId}
                  onValueChange={(value) => setNewCharacter({ ...newCharacter, subclassId: value })}
                >
                  <SelectTrigger className={creationLevel >= 3 && !newCharacter.subclassId ? 'border-red-500' : ''}>
                    <SelectValue placeholder="Selecciona subclase" />
                  </SelectTrigger>
                  <SelectContent>
                    {selectedClass.subclasses.map((sub) => (
                      <SelectItem key={sub.id} value={sub.id}>
                        {sub.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="appearance">Apariencia</Label>
              <Textarea
                id="appearance"
                value={newCharacter.appearance}
                onChange={(e) => setNewCharacter({ ...newCharacter, appearance: e.target.value })}
                placeholder="Describe la apariencia física de tu personaje"
                rows={3}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="background">Historia</Label>
              <Textarea
                id="background"
                value={newCharacter.backgroundStory}
                onChange={(e) => setNewCharacter({ ...newCharacter, backgroundStory: e.target.value })}
                placeholder="Describe la historia y personalidad de tu personaje"
                rows={4}
              />
            </div>

            {/* Summary */}
            <Card className="bg-muted/50">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">Resumen del Personaje</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <div className="grid grid-cols-2 gap-2">
                  <div><strong>Clase:</strong> {selectedClass?.name}</div>
                  <div><strong>Especie:</strong> {selectedSpecies?.name}</div>
                  <div><strong>Trasfondo:</strong> {selectedBackground?.name}</div>
                  <div><strong>Nivel:</strong> {creationLevel}</div>
                  <div><strong>PG:</strong> {calculateHpForLevel()}</div>
                  <div><strong>CA:</strong> {calculateAC()}</div>
                </div>
                {creationLevel > 1 && (
                  <div className="mt-2 p-2 bg-amber-100 dark:bg-amber-900/30 rounded text-amber-800 dark:text-amber-200 text-xs">
                    <strong>⚠️ Nivel superior a 1:</strong> Se crearán notas pendientes para las decisiones que debas tomar.
                  </div>
                )}
              </CardContent>
            </Card>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button variant="outline" onClick={() => setCreationStep(4)}>
              <ChevronLeft className="h-4 w-4 mr-1" /> Anterior
            </Button>
            <Button 
              disabled={!newCharacter.name || (creationLevel >= 3 && selectedClass?.subclasses && selectedClass?.subclasses.length > 0 && !newCharacter.subclassId)}
              onClick={handleCreateCharacter}
            >
              <Save className="h-4 w-4 mr-1" /> Crear Personaje
            </Button>
          </CardFooter>
        </Card>
      )}
    </div>
  )

  // Render character list
  const renderCharacterList = () => (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Tus Personajes</h2>
      
      {characters.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center">
            <p className="text-muted-foreground">No tienes personajes creados.</p>
            <Button className="mt-4" onClick={() => setActiveTab('create')}>
              <Plus className="h-4 w-4 mr-1" /> Crear Personaje
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {characters.map((char) => (
            <Card key={char.id} className="overflow-hidden">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <CardTitle>{char.name}</CardTitle>
                  <Badge>{getClassDisplayString(char)}</Badge>
                </div>
                <CardDescription>
                  {char.species?.name} | {char.background?.name}
                </CardDescription>
              </CardHeader>
              <CardContent className="pb-2">
                <div className="grid grid-cols-3 gap-2 text-center text-sm">
                  <div>
                    <div className="text-lg font-bold">{char.currentHp}/{char.maxHp}</div>
                    <div className="text-muted-foreground">PG</div>
                  </div>
                  <div>
                    <div className="text-lg font-bold">{char.armorClass}</div>
                    <div className="text-muted-foreground">CA</div>
                  </div>
                  <div>
                    <div className="text-lg font-bold">+{char.proficiencyBonus || 2}</div>
                    <div className="text-muted-foreground">Comp.</div>
                  </div>
                </div>
              </CardContent>
              <CardFooter className="flex gap-2">
                <Button 
                  className="flex-1" 
                  size="sm"
                  onClick={() => {
                    fetchCharacterDetails(char.id)
                    setActiveTab('sheet')
                  }}
                >
                  <Eye className="h-4 w-4 mr-1" /> Ver
                </Button>
                <Button 
                  variant="outline" 
                  size="sm"
                  title="Copiar personaje"
                  onClick={() => setDuplicateDialog({ open: true, character: char, newName: char.name + ' (copia)' })}
                >
                  <Copy className="h-4 w-4" />
                </Button>
                <Button 
                  variant="destructive" 
                  size="sm"
                  onClick={() => handleDeleteCharacter(char.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      )}
    </div>
  )

  // Render spellcasting card
  const renderSpellcastingCard = (char: Character) => {
    const stats = calculateSpellcastingStats(char)
    if (!stats) return null
    
    const spellKnowledge = calculateSpellKnowledge(
      char.characterClass?.name || '',
      char.level,
      stats.abilityScore,
      char.characterSpells || [],
      char.classLevels, // Pass classLevels for multiclass support
      char // Pass character for ability scores in multiclass
    )
    
    const spellcastingTypeLabels: Record<SpellcastingType, string> = {
      'known': 'Hechizos Conocidos',
      'prepared': 'Hechizos Preparados',
      'book': 'Grimorio (Preparados)',
      'pact': 'Magia de Pacto',
      'none': 'Sin Conjuración'
    }
    
    const typeLabel = spellcastingTypeLabels[spellKnowledge.spellcastingType]
    const isKnownCaster = ['known', 'pact'].includes(spellKnowledge.spellcastingType)
    const isPreparedCaster = ['prepared', 'book'].includes(spellKnowledge.spellcastingType)
    
    return (
      <Card className="border-purple-500/30 bg-purple-500/5">
        <CardHeader className="pb-2">
          <CardTitle className="text-lg flex items-center gap-2">
            <Wand2 className="h-5 w-5 text-gray-700" />
            Conjuración
            <Badge variant="outline" className="ml-auto text-xs">{typeLabel}</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Main Spellcasting Stats */}
          <div className="grid grid-cols-3 gap-2 text-center">
            <div className="p-2 bg-muted rounded">
              <div className="text-xs text-muted-foreground">CD Hechizos</div>
              <div className="text-2xl font-bold text-gray-900">{stats.spellSaveDC}</div>
            </div>
            <div className="p-2 bg-muted rounded">
              <div className="text-xs text-muted-foreground">Ataque</div>
              <div className="text-2xl font-bold text-gray-900">+{stats.spellAttackBonus}</div>
            </div>
            <div className="p-2 bg-muted rounded">
              <div className="text-xs text-muted-foreground">Habilidad</div>
              <div className="text-lg font-bold">{stats.abilityName?.substring(0, 3).toUpperCase()}</div>
              <div className="text-xs">({stats.modifier >= 0 ? '+' : ''}{stats.modifier})</div>
            </div>
          </div>
          
          {/* Cantrips Section */}
          {spellKnowledge.cantripsMax > 0 && (
            <div className="p-3 bg-muted/50 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-orange-400" />
                  Trucos
                </span>
                <Badge variant={spellKnowledge.cantripsKnown >= spellKnowledge.cantripsMax ? "default" : "secondary"}>
                  {spellKnowledge.cantripsKnown} / {spellKnowledge.cantripsMax}
                </Badge>
              </div>
              <div className="flex gap-1">
                {Array.from({ length: spellKnowledge.cantripsMax }).map((_, i) => (
                  <div 
                    key={i}
                    className={`flex-1 h-2 rounded-full ${
                      i < spellKnowledge.cantripsKnown 
                        ? 'bg-yellow-500' 
                        : 'bg-muted-foreground/20'
                    }`}
                  />
                ))}
              </div>
              {spellKnowledge.cantripsKnown < spellKnowledge.cantripsMax && (
                <p className="text-xs text-muted-foreground">
                  Puedes aprender {spellKnowledge.cantripsMax - spellKnowledge.cantripsKnown} trucos más
                </p>
              )}
              {/* Multiclass breakdown */}
              {spellKnowledge.isMulticlass && spellKnowledge.classBreakdown.length > 1 && (
                <div className="mt-2 pt-2 border-t border-border/50">
                  <p className="text-xs text-muted-foreground mb-1">Por clase:</p>
                  <div className="flex flex-wrap gap-1">
                    {spellKnowledge.classBreakdown.map((cb) => (
                      cb.cantrips > 0 && (
                        <Badge key={cb.className} variant="outline" className="text-xs">
                          {cb.className}: {cb.cantrips}
                        </Badge>
                      )
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
          
          {/* Spells Known Section (for known casters) */}
          {isKnownCaster && (
            <div className="p-3 bg-muted/50 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold">Hechizos Conocidos</span>
                <Badge variant={spellKnowledge.spellsKnown >= spellKnowledge.spellsMax ? "default" : "secondary"}>
                  {spellKnowledge.spellsKnown} / {spellKnowledge.spellsMax}
                </Badge>
              </div>
              <div className="flex gap-1">
                {Array.from({ length: Math.min(spellKnowledge.spellsMax, 20) }).map((_, i) => (
                  <div 
                    key={i}
                    className={`flex-1 h-2 rounded-full ${
                      i < spellKnowledge.spellsKnown 
                        ? 'bg-purple-500' 
                        : 'bg-muted-foreground/20'
                    }`}
                  />
                ))}
              </div>
              {spellKnowledge.spellsKnown < spellKnowledge.spellsMax && (
                <p className="text-xs text-muted-foreground">
                  Puedes conocer {spellKnowledge.spellsMax - spellKnowledge.spellsKnown} hechizos más
                </p>
              )}
              {/* Multiclass breakdown */}
              {spellKnowledge.isMulticlass && spellKnowledge.classBreakdown.length > 1 && (
                <div className="mt-2 pt-2 border-t border-border/50">
                  <p className="text-xs text-muted-foreground mb-1">Por clase:</p>
                  <div className="flex flex-wrap gap-1">
                    {spellKnowledge.classBreakdown.map((cb) => (
                      cb.spellsKnown > 0 && (
                        <Badge key={cb.className} variant="outline" className="text-xs">
                          {cb.className}: {cb.spellsKnown}
                        </Badge>
                      )
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
          
          {/* Spells Prepared Section (for prepared casters) */}
          {isPreparedCaster && spellKnowledge.spellsPreparedMax > 0 && (
            <div className="p-3 bg-muted/50 rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold">Hechizos Preparados</span>
                <Badge variant={spellKnowledge.spellsPrepared >= spellKnowledge.spellsPreparedMax ? "destructive" : "secondary"}>
                  {spellKnowledge.spellsPrepared} / {spellKnowledge.spellsPreparedMax}
                </Badge>
              </div>
              <div className="flex gap-1 flex-wrap">
                {Array.from({ length: spellKnowledge.spellsPreparedMax }).map((_, i) => (
                  <div 
                    key={i}
                    className={`w-3 h-3 rounded-full ${
                      i < spellKnowledge.spellsPrepared 
                        ? 'bg-purple-500' 
                        : 'bg-muted-foreground/20'
                    }`}
                  />
                ))}
              </div>
              <p className="text-xs text-muted-foreground">
                {spellKnowledge.spellcastingType === 'book' 
                  ? `Preparas ${spellKnowledge.spellsPreparedMax} hechizos de tu grimorio`
                  : `Preparas ${spellKnowledge.spellsPreparedMax} hechizos de tu lista de clase`
                }
              </p>
              {/* Multiclass breakdown */}
              {spellKnowledge.isMulticlass && spellKnowledge.classBreakdown.length > 1 && (
                <div className="mt-2 pt-2 border-t border-border/50">
                  <p className="text-xs text-muted-foreground mb-1">Por clase:</p>
                  <div className="flex flex-wrap gap-1">
                    {spellKnowledge.classBreakdown.map((cb) => (
                      cb.spellsPrepared > 0 && (
                        <Badge key={cb.className} variant="outline" className="text-xs">
                          {cb.className}: {cb.spellsPrepared}
                        </Badge>
                      )
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
          
          {/* Spells by Level Grid */}
          {spellKnowledge.maxSpellLevel > 0 && (
            <div className="space-y-2">
              <span className="text-sm font-semibold">Hechizos por Nivel</span>
              <div className="grid grid-cols-3 gap-1">
                {spellKnowledge.spellsByLevel.map((levelInfo) => {
                  const spellsAtLevel = char.characterSpells?.filter((cs: any) => 
                    cs.spell?.level === levelInfo.level && (cs.known !== false || cs.prepared)
                  ) || []
                  const preparedAtLevel = char.characterSpells?.filter((cs: any) => 
                    cs.spell?.level === levelInfo.level && cs.prepared
                  ) || []
                  
                  return (
                    <div key={levelInfo.level} className="p-2 bg-muted rounded text-center">
                      <div className="text-xs text-muted-foreground mb-1">
                        {levelInfo.level === 1 ? '1er' : levelInfo.level === 2 ? '2do' : levelInfo.level === 3 ? '3er' : `${levelInfo.level}º`} Nivel
                      </div>
                      <div className="text-lg font-bold text-gray-900">
                        {isPreparedCaster ? preparedAtLevel.length : spellsAtLevel.length}
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {isPreparedCaster ? 'preparados' : 'conocidos'}
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )}
          
          {/* Max Spell Level Indicator */}
          {spellKnowledge.maxSpellLevel > 0 && (
            <div className="flex items-center justify-center gap-2 text-sm">
              <span className="text-muted-foreground">Hechizos máximos:</span>
              <Badge variant="outline" className="bg-purple-500/10">
                Nivel {spellKnowledge.maxSpellLevel}
              </Badge>
            </div>
          )}
          
          {/* Spell Slots */}
          {spellSlots && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold">Ranuras de Hechizos</span>
                  {spellSlots.isMulticlass && spellSlots.effectiveCasterLevel !== undefined && (
                    <Badge variant="outline" className="text-[10px] h-5">
                      Nv.Efectivo: {spellSlots.effectiveCasterLevel}
                    </Badge>
                  )}
                </div>
                <Button 
                  variant="outline" 
                  size="sm"
                  className="h-7 text-xs bg-emerald-500/10 border-emerald-500/30 hover:bg-emerald-500/20 text-emerald-700 dark:text-emerald-300"
                  onClick={async () => {
                    try {
                      await fetch(`/api/characters/${char.id}/spell-slots`, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ rest: true })
                      })
                      const res = await fetch(`/api/characters/${char.id}/spell-slots`)
                      const data = await res.json()
                      setSpellSlots(data)
                    } catch (error) {
                      console.error('Error resting spell slots:', error)
                    }
                  }}
                >
                  <Moon className="h-3.5 w-3.5 mr-1.5" /> Descanso Largo
                </Button>
              </div>
              
              {/* Standard Spell Slots */}
              {spellSlots.slots.some(s => s.total > 0) && (
                <div className="grid grid-cols-3 gap-2">
                  {spellSlots.slots.filter(s => s.total > 0).map((slot) => (
                    <div 
                      key={slot.level} 
                      className="text-center p-2.5 bg-gradient-to-b from-muted/80 to-muted rounded-lg border border-muted-foreground/10"
                    >
                      <div className="text-xs text-muted-foreground mb-1.5 font-medium">Nivel {slot.level}</div>
                      <div className="flex justify-center gap-1.5 my-2">
                        {Array.from({ length: slot.total }).map((_, i) => {
                          const isAvailable = i < (slot.total - slot.used)
                          return (
                            <button
                              key={i}
                              onClick={async () => {
                                if (!isAvailable) return
                                try {
                                  const res = await fetch(`/api/characters/${char.id}/spell-slots`, {
                                    method: 'PUT',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify({ useSlot: slot.level })
                                  })
                                  if (res.ok) {
                                    const data = await res.json()
                                    setSpellSlots(data)
                                  }
                                } catch (error) {
                                  console.error('Error using spell slot:', error)
                                }
                              }}
                              disabled={!isAvailable}
                              className={`w-5 h-5 rounded-full border-2 transition-all duration-200
                                ${isAvailable 
                                  ? 'bg-gradient-to-b from-purple-400 to-purple-600 border-purple-300 hover:from-purple-300 hover:to-purple-500 hover:scale-110 hover:shadow-md hover:shadow-purple-500/30 cursor-pointer' 
                                  : 'bg-muted border-muted-foreground/20 cursor-not-allowed opacity-50'
                                }`}
                              title={isAvailable ? `Usar ranura de nivel ${slot.level}` : 'Ranura agotada'}
                            />
                          )
                        })}
                      </div>
                      <div className="text-xs font-medium">
                        <span className={`${slot.total - slot.used > 0 ? 'text-purple-600 dark:text-purple-400' : 'text-muted-foreground'}`}>
                          {slot.total - slot.used}
                        </span>
                        <span className="text-muted-foreground">/{slot.total}</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              {/* Warlock Pact Magic Slots */}
              {spellSlots.pactSlots && spellSlots.pactSlots.total > 0 && (
                <div className="mt-3 pt-3 border-t border-muted-foreground/10">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-semibold text-cyan-600 dark:text-cyan-400">Magia de Pacto</span>
                      <Badge variant="outline" className="text-[10px] h-5 bg-cyan-500/10 border-cyan-500/30 text-cyan-700 dark:text-cyan-300">
                        Nivel {spellSlots.pactSlots.level}
                      </Badge>
                    </div>
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="h-6 text-[10px] bg-cyan-500/10 border-cyan-500/30 hover:bg-cyan-500/20 text-cyan-700 dark:text-cyan-300"
                      onClick={async () => {
                        try {
                          // Short rest restores Pact Magic slots
                          await fetch(`/api/characters/${char.id}/spell-slots`, {
                            method: 'PUT',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ rest: true })
                          })
                          const res = await fetch(`/api/characters/${char.id}/spell-slots`)
                          const data = await res.json()
                          setSpellSlots(data)
                        } catch (error) {
                          console.error('Error resting pact slots:', error)
                        }
                      }}
                    >
                      <Sun className="h-3 w-3 mr-1" /> Descanso Corto
                    </Button>
                  </div>
                  <div className="flex items-center justify-center gap-2 p-3 bg-gradient-to-b from-cyan-500/10 to-cyan-500/5 rounded-lg border border-cyan-500/20">
                    <div className="flex gap-1.5">
                      {Array.from({ length: spellSlots.pactSlots.total }).map((_, i) => {
                        const isAvailable = i < (spellSlots.pactSlots!.total - spellSlots.pactSlots!.used)
                        return (
                          <button
                            key={i}
                            onClick={async () => {
                              if (!isAvailable) return
                              try {
                                const res = await fetch(`/api/characters/${char.id}/spell-slots`, {
                                  method: 'PUT',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({ usePactSlot: true })
                                })
                                if (res.ok) {
                                  const data = await res.json()
                                  setSpellSlots(data)
                                }
                              } catch (error) {
                                console.error('Error using pact slot:', error)
                              }
                            }}
                            disabled={!isAvailable}
                            className={`w-6 h-6 rounded-full border-2 transition-all duration-200
                              ${isAvailable 
                                ? 'bg-gradient-to-b from-cyan-400 to-cyan-600 border-cyan-300 hover:from-cyan-300 hover:to-cyan-500 hover:scale-110 hover:shadow-md hover:shadow-cyan-500/30 cursor-pointer' 
                                : 'bg-muted border-muted-foreground/20 cursor-not-allowed opacity-50'
                              }`}
                            title={isAvailable ? `Usar ranura de pacto (nivel ${spellSlots.pactSlots!.level})` : 'Ranura agotada'}
                          />
                        )
                      })}
                    </div>
                    <div className="text-xs font-medium ml-2">
                      <span className={`${spellSlots.pactSlots.total - spellSlots.pactSlots.used > 0 ? 'text-cyan-600 dark:text-cyan-400' : 'text-muted-foreground'}`}>
                        {spellSlots.pactSlots.total - spellSlots.pactSlots.used}
                      </span>
                      <span className="text-muted-foreground">/{spellSlots.pactSlots.total}</span>
                    </div>
                  </div>
                  <p className="text-[10px] text-cyan-600/70 dark:text-cyan-400/70 text-center mt-1">
                    ⚡ Se recuperan con descanso corto o largo
                  </p>
                </div>
              )}
              
              <p className="text-[10px] text-muted-foreground text-center">
                💡 Haz clic en una ranura para gastarla
              </p>
            </div>
          )}
        </CardContent>
      </Card>
    )
  }

  // Render character sheet
  const renderCharacterSheet = () => {
    if (!selectedCharacter) {
      return (
        <Card>
          <CardContent className="py-8 text-center">
            <p className="text-muted-foreground">Selecciona un personaje para ver su hoja.</p>
            <Button className="mt-4" onClick={() => setActiveTab('characters')}>
              Ver Personajes
            </Button>
          </CardContent>
        </Card>
      )
    }

    const char = selectedCharacter

    return (
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-3">
              <h2 className="text-2xl font-bold">{char.name}</h2>
              <Button
                variant="ghost"
                size="sm"
                className="h-8 w-8 p-0"
                onClick={() => {
                  setEditingName(char.name)
                  setEditNameDialog(true)
                }}
              >
                <Edit className="h-4 w-4" />
              </Button>
              <div className="flex items-center gap-1 px-3 py-1 bg-purple-500/10 border border-purple-500/30 rounded-full">
                <span className="text-sm font-semibold text-purple-700 dark:text-purple-300">XP</span>
                <span className="text-sm font-bold text-gray-900">{(char.xp || 0).toLocaleString()}</span>
                <Button
                  variant="ghost"
                  size="sm"
                  className="h-6 w-6 p-0 ml-1"
                  onClick={() => {
                    setEditingXp(char.xp || 0)
                    setEditXpDialog(true)
                  }}
                >
                  <Edit className="h-3 w-3" />
                </Button>
              </div>
            </div>
            <p className="text-muted-foreground">
              {(() => {
                // Build class display string including multiclass
                const classLevels = (char as any).classLevels
                if (classLevels && classLevels.length > 0) {
                  // Sort: primary first, then by level
                  const sortedLevels = [...classLevels].sort((a, b) => {
                    if (a.isPrimary) return -1
                    if (b.isPrimary) return 1
                    return b.level - a.level
                  })
                  const classString = sortedLevels.map((cl: any) => 
                    `${cl.class?.name || 'Unknown'} ${cl.level}`
                  ).join(' / ')
                  return classString
                }
                // Fallback to single class display
                return `${char.characterClass?.name} ${char.level}`
              })()} | {char.species?.name} | {char.background?.name}
            </p>
          </div>
          <div className="flex gap-2 flex-wrap">
            <Button onClick={openLevelUpDialog}>
              <ArrowUpCircle className="h-4 w-4 mr-1" /> Subir Nivel
            </Button>
            <Button variant="outline" onClick={() => setShopDialog(true)}>
              <ShoppingBag className="h-4 w-4 mr-1" /> Tienda
            </Button>
            {(char.characterClass?.spellcasting || (char.characterSpells && char.characterSpells.length > 0)) && (
              <Button variant="outline" onClick={() => setGrimorioDialog(true)}>
                <BookOpen className="h-4 w-4 mr-1" /> Grimorio
              </Button>
            )}
          </div>
        </div>

        {/* Main Stats */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {/* Ability Scores */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center justify-between">
                Puntuaciones de Característica
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={() => {
                    setEditingAbilities({
                      str: char.strength,
                      dex: char.dexterity,
                      con: char.constitution,
                      int: char.intelligence,
                      wis: char.wisdom,
                      cha: char.charisma
                    })
                    setEditAbilityDialog(true)
                  }}
                >
                  <Edit className="h-4 w-4" />
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-2">
                {[
                  { name: 'FUE', value: char.strength },
                  { name: 'DES', value: char.dexterity },
                  { name: 'CON', value: char.constitution },
                  { name: 'INT', value: char.intelligence },
                  { name: 'SAB', value: char.wisdom },
                  { name: 'CAR', value: char.charisma }
                ].map((ability) => (
                  <div key={ability.name} className="text-center p-2 bg-muted rounded">
                    <div className="text-xs text-muted-foreground">{ability.name}</div>
                    <div className="text-xl font-bold">{ability.value}</div>
                    <div className="text-sm">{getModifierString(ability.value)}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Combat Stats */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Combate</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="grid grid-cols-2 gap-4">
                <div 
                  className="text-center p-3 bg-muted rounded cursor-pointer hover:bg-muted/80"
                  onClick={() => {
                    setEditingHp({
                      current: char.currentHp,
                      max: char.maxHp,
                      temp: char.tempHp
                    })
                    setEditHpDialog(true)
                  }}
                >
                  <div className="text-xs text-muted-foreground flex items-center justify-center gap-1">
                    Puntos de Golpe
                    <Edit className="h-3 w-3" />
                  </div>
                  <div className="text-2xl font-bold">{char.currentHp}/{char.maxHp}</div>
                  {char.tempHp > 0 && <div className="text-xs">+{char.tempHp} temp</div>}
                </div>
                <div className="text-center p-3 bg-muted rounded">
                  <div className="text-xs text-muted-foreground">Clase de Armadura</div>
                  <div className="text-2xl font-bold">{char.armorClass}</div>
                </div>
                <div className="text-center p-3 bg-muted rounded">
                  <div className="text-xs text-muted-foreground">Iniciativa</div>
                  <div className="text-2xl font-bold">{getModifierString(char.dexterity)}</div>
                </div>
                <div className="text-center p-3 bg-muted rounded">
                  <div className="text-xs text-muted-foreground">Velocidad</div>
                  <div className="text-2xl font-bold">{char.speed}</div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div className="text-center p-2 bg-muted rounded">
                  <div className="text-xs text-muted-foreground">Dados de Golpe</div>
                  <div className="text-lg">
                    {(() => {
                      // Handle multiclass hit dice display
                      const classLevels = (char as any).classLevels
                      if (classLevels && classLevels.length > 0) {
                        // Group hit dice by die type
                        const hitDiceByType: Record<number, { current: number; max: number }> = {}
                        classLevels.forEach((cl: any) => {
                          const dieType = cl.hitDieType
                          if (!hitDiceByType[dieType]) {
                            hitDiceByType[dieType] = { current: 0, max: 0 }
                          }
                          hitDiceByType[dieType].current += cl.hitDiceCurrent || 0
                          hitDiceByType[dieType].max += cl.hitDiceMax || 0
                        })
                        // Format display
                        return Object.entries(hitDiceByType)
                          .sort((a, b) => parseInt(b[0]) - parseInt(a[0]))
                          .map(([dieType, data]) => `${data.current}d${dieType}`)
                          .join(' + ')
                      }
                      // Single class fallback
                      return `${char.hitDiceCurrent}d${char.hitDiceType}`
                    })()}
                  </div>
                </div>
                <div className="text-center p-2 bg-muted rounded">
                  <div className="text-xs text-muted-foreground flex items-center justify-center gap-1">
                    <Eye className="h-3 w-3" />
                    Sabiduría Pasiva
                  </div>
                  <div className="text-lg font-bold">
                    {10 + getModifier(char.wisdom) + 
                      (char.expertPerception ? (char.proficiencyBonus || 2) * 2 : 
                       char.skillPerception ? (char.proficiencyBonus || 2) : 0)}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Saving Throws */}
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-lg">Salvaciones</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
                {[
                  { name: 'FUE', fullName: 'Fuerza', proficient: char.saveStr, value: char.strength },
                  { name: 'DES', fullName: 'Destreza', proficient: char.saveDex, value: char.dexterity },
                  { name: 'CON', fullName: 'Constitución', proficient: char.saveCon, value: char.constitution },
                  { name: 'INT', fullName: 'Inteligencia', proficient: char.saveInt, value: char.intelligence },
                  { name: 'SAB', fullName: 'Sabiduría', proficient: char.saveWis, value: char.wisdom },
                  { name: 'CAR', fullName: 'Carisma', proficient: char.saveCha, value: char.charisma }
                ].map((save) => (
                  <div 
                    key={save.name} 
                    className={`text-center p-2 rounded cursor-pointer transition-colors ${
                      save.proficient 
                        ? 'bg-primary/20 border-2 border-primary/50' 
                        : 'bg-muted hover:bg-muted/80'
                    }`}
                    onClick={async () => {
                      const fieldName = `save${save.name}` as keyof Character
                      const newValue = !save.proficient
                      await fetch(`/api/characters/${char.id}`, {
                        method: 'PUT',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ [fieldName]: newValue })
                      })
                      fetchCharacterDetails(char.id)
                    }}
                  >
                    <div className="text-xs text-muted-foreground">{save.name}</div>
                    <div className={`text-xl font-bold ${save.proficient ? 'text-primary' : ''}`}>
                      {getModifierString(save.value + (save.proficient ? (char.proficiencyBonus || 2) : 0))}
                    </div>
                    {save.proficient && <div className="text-xs text-primary">●</div>}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Skills - Interactive - Full Width */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Brain className="h-5 w-5" />
              Habilidades
              <Badge variant="default" className="ml-2 bg-emerald-600 hover:bg-emerald-700">
                +{char.proficiencyBonus || 2} Competencia
              </Badge>
              <Badge variant="outline" className="text-xs">
                Clic para seleccionar nivel de competencia
              </Badge>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-2">
              {[
                { name: 'Acrobacia', skill: 'skillAcrobatics', expert: 'expertAcrobatics', ability: 'DES', value: char.dexterity },
                { name: 'Trato con Animales', skill: 'skillAnimalHandling', expert: 'expertAnimalHandling', ability: 'SAB', value: char.wisdom },
                { name: 'Arcano', skill: 'skillArcana', expert: 'expertArcana', ability: 'INT', value: char.intelligence },
                { name: 'Atletismo', skill: 'skillAthletics', expert: 'expertAthletics', ability: 'FUE', value: char.strength },
                { name: 'Engaño', skill: 'skillDeception', expert: 'expertDeception', ability: 'CAR', value: char.charisma },
                { name: 'Historia', skill: 'skillHistory', expert: 'expertHistory', ability: 'INT', value: char.intelligence },
                { name: 'Perspicacia', skill: 'skillInsight', expert: 'expertInsight', ability: 'SAB', value: char.wisdom },
                { name: 'Intimidación', skill: 'skillIntimidation', expert: 'expertIntimidation', ability: 'CAR', value: char.charisma },
                { name: 'Investigación', skill: 'skillInvestigation', expert: 'expertInvestigation', ability: 'INT', value: char.intelligence },
                { name: 'Medicina', skill: 'skillMedicine', expert: 'expertMedicine', ability: 'SAB', value: char.wisdom },
                { name: 'Naturaleza', skill: 'skillNature', expert: 'expertNature', ability: 'INT', value: char.intelligence },
                { name: 'Percepción', skill: 'skillPerception', expert: 'expertPerception', ability: 'SAB', value: char.wisdom },
                { name: 'Interpretación', skill: 'skillPerformance', expert: 'expertPerformance', ability: 'CAR', value: char.charisma },
                { name: 'Persuasión', skill: 'skillPersuasion', expert: 'expertPersuasion', ability: 'CAR', value: char.charisma },
                { name: 'Religión', skill: 'skillReligion', expert: 'expertReligion', ability: 'INT', value: char.intelligence },
                { name: 'Juego de Manos', skill: 'skillSleightOfHand', expert: 'expertSleightOfHand', ability: 'DES', value: char.dexterity },
                { name: 'Sigilo', skill: 'skillStealth', expert: 'expertStealth', ability: 'DES', value: char.dexterity },
                { name: 'Supervivencia', skill: 'skillSurvival', expert: 'expertSurvival', ability: 'SAB', value: char.wisdom }
              ].map((skill) => {
                const isProficient = char[skill.skill as keyof Character] as boolean
                const isExpert = (char[skill.expert as keyof Character] as boolean) ?? false
                const prof = char.proficiencyBonus || 2
                const abilityModifier = getModifier(skill.value)
                
                // Check for Jack of All Trades (Bard level 2+)
                const hasJackOfAllTrades = char.characterClass?.name === 'Bard' && char.level >= 2
                const jackOfAllTradesBonus = hasJackOfAllTrades && !isProficient && !isExpert ? Math.floor(prof / 2) : 0
                
                const modifier = abilityModifier + (isExpert ? prof * 2 : isProficient ? prof : jackOfAllTradesBonus)
                const modifierString = modifier >= 0 ? `+${modifier}` : `${modifier}`
                
                // Jack of All Trades gives half proficiency to non-proficient skills (Bard level 2+)
                const hasJackOfAllTradesBonus = jackOfAllTradesBonus > 0
                
                // Function to update skill proficiency
                const updateSkillProficiency = async (newStatus: 'none' | 'proficient' | 'expert') => {
                  let updates: Record<string, boolean> = {}
                  
                  if (newStatus === 'none') {
                    updates[skill.expert] = false
                    updates[skill.skill] = false
                  } else if (newStatus === 'proficient') {
                    updates[skill.skill] = true
                    updates[skill.expert] = false
                  } else if (newStatus === 'expert') {
                    updates[skill.skill] = true
                    updates[skill.expert] = true
                  }
                  
                  await fetch(`/api/characters/${char.id}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(updates)
                  })
                  fetchCharacterDetails(char.id)
                }
                
                return (
                  <Popover key={skill.name}>
                    <PopoverTrigger asChild>
                      <div 
                        className={`p-2 rounded cursor-pointer transition-all hover:scale-105 ${
                          isExpert 
                            ? 'bg-yellow-500/20 border-2 border-yellow-500/50' 
                            : isProficient 
                              ? 'bg-primary/20 border-2 border-primary/50' 
                              : hasJackOfAllTradesBonus
                                ? 'bg-purple-500/20 border-2 border-purple-500/50'
                                : 'bg-muted hover:bg-muted/80 border-2 border-transparent'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-1">
                          <span className={`text-xs truncate ${
                            isExpert 
                              ? 'text-orange-500 font-bold' 
                              : isProficient 
                                ? 'text-primary font-semibold' 
                                : hasJackOfAllTradesBonus 
                                  ? 'text-purple-400 font-medium'
                                  : 'text-muted-foreground'
                          }`}>
                            {skill.name}
                          </span>
                          <span className={`text-xs ${
                            isExpert 
                              ? 'text-orange-500' 
                              : isProficient 
                                ? 'text-primary' 
                                : hasJackOfAllTradesBonus 
                                  ? 'text-purple-400'
                                  : 'text-muted-foreground'
                          }`}>
                            {skill.ability}
                          </span>
                        </div>
                        <div className={`text-lg font-bold ${
                          isExpert 
                            ? 'text-orange-500' 
                            : isProficient 
                              ? 'text-primary' 
                              : hasJackOfAllTradesBonus 
                                ? 'text-purple-400'
                                : ''
                        }`}>
                          {modifierString}
                        </div>
                        <div className="flex justify-center gap-1">
                          {isExpert && <span className="text-xs text-orange-500">★ Experto</span>}
                          {isProficient && !isExpert && <span className="text-xs text-primary">● Prof.</span>}
                          {hasJackOfAllTradesBonus && <span className="text-xs text-purple-400">♦ Jack</span>}
                          {!isProficient && !isExpert && !hasJackOfAllTradesBonus && <span className="text-xs text-muted-foreground">—</span>}
                        </div>
                      </div>
                    </PopoverTrigger>
                    <PopoverContent className="w-48 p-2" align="center">
                      <div className="space-y-1">
                        <p className="text-xs text-muted-foreground text-center mb-2">{skill.name}</p>
                        <button
                          onClick={() => updateSkillProficiency('none')}
                          className={`w-full px-3 py-2 text-sm rounded-md flex items-center justify-between transition-colors ${
                            !isProficient && !isExpert 
                              ? 'bg-muted text-foreground' 
                              : 'hover:bg-muted/50'
                          }`}
                        >
                          <span>— No proficiente</span>
                          {!isProficient && !isExpert && <Check className="h-4 w-4" />}
                        </button>
                        <button
                          onClick={() => updateSkillProficiency('proficient')}
                          className={`w-full px-3 py-2 text-sm rounded-md flex items-center justify-between transition-colors ${
                            isProficient && !isExpert 
                              ? 'bg-primary/20 text-primary font-medium' 
                              : 'hover:bg-muted/50'
                          }`}
                        >
                          <span>● Proficiente</span>
                          {isProficient && !isExpert && <Check className="h-4 w-4" />}
                        </button>
                        <button
                          onClick={() => updateSkillProficiency('expert')}
                          className={`w-full px-3 py-2 text-sm rounded-md flex items-center justify-between transition-colors ${
                            isExpert 
                              ? 'bg-yellow-500/20 text-orange-500 font-medium' 
                              : 'hover:bg-muted/50'
                          }`}
                        >
                          <span>★ Experto</span>
                          {isExpert && <Check className="h-4 w-4" />}
                        </button>
                        {hasJackOfAllTradesBonus && (
                          <div className="pt-2 border-t mt-2">
                            <p className="text-xs text-purple-400 text-center">
                              ♦ +{jackOfAllTradesBonus} Jack of All Trades
                            </p>
                          </div>
                        )}
                      </div>
                    </PopoverContent>
                  </Popover>
                )
              })}
            </div>
          </CardContent>
        </Card>

        {/* Spellcasting Card */}
        {(char.characterClass?.spellcasting || (char.characterSpells && char.characterSpells.length > 0)) && (
          <div className="grid grid-cols-1 gap-4">
            {/* Show spellcasting stats only for spellcasting classes */}
            {char.characterClass?.spellcasting && renderSpellcastingCard(char)}
            
            {/* Known Spells Quick View - Show for both spellcasters and non-spellcasters with species spells */}
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    Hechizos Conocidos
                    {!char.characterClass?.spellcasting && char.characterSpells && char.characterSpells.length > 0 && (
                      <Badge variant="secondary" className="text-xs">De Especie/Rasgos</Badge>
                    )}
                  </div>
                  <Button size="sm" variant="outline" onClick={() => setSpellsDialog(true)}>
                    <Plus className="h-4 w-4" />
                  </Button>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {char.characterSpells?.length === 0 ? (
                  <p className="text-muted-foreground text-sm">Sin hechizos conocidos. Haz clic en el botón + para añadir.</p>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {char.characterSpells
                      ?.sort((a: any, b: any) => a.spell?.level - b.spell?.level || a.spell?.name.localeCompare(b.spell?.name))
                      .map((cs: any) => (
                      <div 
                        key={cs.id} 
                        className="flex justify-between items-center text-sm p-2 bg-muted rounded cursor-pointer hover:bg-muted/80"
                        onClick={() => setSpellDetailDialog({ open: true, spell: cs.spell })}
                      >
                        <div className="flex items-center gap-2">
                          <div className={`p-1 rounded ${getSchoolColor(cs.spell?.school)}`}>
                            {getSchoolIcon(cs.spell?.school)}
                          </div>
                          <span className="font-medium">{cs.spell?.name}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Badge variant="outline" className="text-xs">
                            {cs.spell?.level === 0 ? 'T' : cs.spell?.level}
                          </Badge>
                          {cs.source === 'domain' && <Badge variant="secondary" className="text-xs bg-purple-600">⚡ Dominio</Badge>}
                          {cs.source === 'circle' && <Badge variant="secondary" className="text-xs bg-emerald-600">🌿 Círculo</Badge>}
                          {cs.source === 'oath' && <Badge variant="secondary" className="text-xs bg-amber-600">⚔️ Juramento</Badge>}
                          {cs.source === 'ranger' && <Badge variant="secondary" className="text-xs bg-green-600">🏹 Ranger</Badge>}
                          {cs.source === 'sorcerer' && <Badge variant="secondary" className="text-xs bg-red-600">🔥 Sorcerer</Badge>}
                          {cs.source === 'warlock' && <Badge variant="secondary" className="text-xs bg-violet-600">👁️ Warlock</Badge>}
                          {cs.source === 'species' && <Badge variant="secondary" className="text-xs bg-teal-600">🧬 Especie</Badge>}
                          {cs.source === 'feat' && <Badge variant="secondary" className="text-xs bg-orange-600">⭐ Dote</Badge>}
                          {cs.prepared && cs.source === 'class' && <Badge variant="secondary" className="text-xs bg-green-600">Prep.</Badge>}
                          {cs.spell?.concentration && <Badge variant="outline" className="text-xs">C</Badge>}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}

        {/* Inventory & Equipment */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <Card className="lg:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center justify-between">
                <span>Inventario</span>
                <Button size="sm" variant="outline" onClick={() => setInventoryDialog(true)}>
                  <Plus className="h-4 w-4 mr-1" /> Añadir
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-64">
                {char.inventoryItems?.length === 0 ? (
                  <p className="text-muted-foreground text-sm text-center py-8">Sin objetos en el inventario. Haz clic en "Añadir" para agregar equipos.</p>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {char.inventoryItems?.map((invItem: any) => {
                      // Determine item type and get item data
                      const isWeapon = !!invItem.weapon
                      const isArmor = !!invItem.armor
                      const isItem = !!invItem.item
                      const isMagicItem = !!invItem.magicItem
                      
                      const itemData = invItem.weapon || invItem.armor || invItem.item || invItem.magicItem
                      if (!itemData) return null
                      
                      // Calculate weapon attack and damage bonuses
                      let attackBonus = 0
                      let damageBonus = 0
                      let attackMod = ''
                      
                      if (isWeapon && invItem.weapon) {
                        const weapon = invItem.weapon
                        // Determine if finesse weapon or ranged
                        const isFinesse = weapon.properties?.includes('Finesse') || weapon.properties?.includes('Acrobacia')
                        const isRanged = weapon.category?.includes('Ranged')
                        
                        // Use DEX for ranged or finesse (if higher), STR otherwise
                        const strMod = getModifier(char.strength)
                        const dexMod = getModifier(char.dexterity)
                        
                        const profBonus = char.proficiencyBonus || 2
                        if (isRanged) {
                          attackBonus = dexMod + profBonus
                          attackMod = 'DES'
                        } else if (isFinesse && dexMod > strMod) {
                          attackBonus = dexMod + profBonus
                          attackMod = 'DES'
                        } else {
                          attackBonus = strMod + profBonus
                          attackMod = 'FUE'
                        }
                        damageBonus = isRanged ? dexMod : (isFinesse && dexMod > strMod ? dexMod : strMod)
                      }
                      
                      // Get cost
                      const cost = isItem ? `${(itemData.cost / 100).toFixed(2)} GP` : `${itemData.cost || 0} GP`
                      
                      return (
                        <div 
                          key={invItem.id} 
                          className="p-2 bg-muted rounded border border-transparent hover:border-primary/30 cursor-pointer transition-all"
                          onClick={() => setItemDetailDialog({ open: true, item: invItem })}
                        >
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <div className="flex items-center gap-2">
                                {isWeapon && <Sword className="h-4 w-4 text-gray-600" />}
                                {isArmor && <Shield className="h-4 w-4 text-gray-600" />}
                                {isItem && <Package className="h-4 w-4 text-gray-600" />}
                                {isMagicItem && <Sparkles className="h-4 w-4 text-gray-600" />}
                                <span className="font-medium text-sm">{itemData.name}</span>
                                {invItem.quantity > 1 && <Badge variant="outline" className="text-xs">x{invItem.quantity}</Badge>}
                              </div>
                              
                              {/* Weapon stats */}
                              {isWeapon && invItem.weapon && (
                                <div className="flex gap-3 mt-1 text-xs text-muted-foreground">
                                  <span className="text-gray-700 font-medium">
                                    Ataque: {attackBonus >= 0 ? '+' : ''}{attackBonus} ({attackMod})
                                  </span>
                                  <span className="text-gray-700 font-medium">
                                    Daño: {invItem.weapon.damage}{damageBonus >= 0 ? '+' : ''}{damageBonus} {invItem.weapon.damageType}
                                  </span>
                                </div>
                              )}
                              
                              {/* Armor stats */}
                              {isArmor && invItem.armor && (
                                <div className="flex gap-3 mt-1 text-xs text-muted-foreground">
                                  <span className="text-gray-700 font-medium">
                                    CA: {invItem.armor.baseAC}
                                  </span>
                                  <span>{invItem.armor.category}</span>
                                </div>
                              )}
                              
                              {/* Cost */}
                              <div className="flex items-center gap-2 mt-1">
                                <Badge variant="outline" className="text-xs bg-yellow-500/10 border-yellow-500/30">
                                  {cost}
                                </Badge>
                                {invItem.equipped && <Badge variant="secondary" className="text-xs">Equipado</Badge>}
                                {invItem.attuned && <Badge variant="default" className="text-xs">Sintonizado</Badge>}
                              </div>
                            </div>
                            
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive"
                              onClick={(e) => {
                                e.stopPropagation()
                                handleDeleteInventoryItem(invItem.id)
                              }}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                )}
              </ScrollArea>
            </CardContent>
          </Card>
        </div>

        {/* Especie - Full Width */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <User className="h-5 w-5" />
              Especie
            </CardTitle>
          </CardHeader>
          <CardContent>
            {!char.species ? (
              <div className="text-center py-8 text-muted-foreground">
                <User className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p className="text-sm">No hay especie seleccionada</p>
              </div>
            ) : (
              <div className="space-y-3">
                {/* Species Header */}
                <div className={`bg-gradient-to-r ${getSpeciesColor(char.species?.name)} rounded-lg p-3 border`}>
                  <div className="flex items-center gap-3">
                    <div className="p-2 bg-background/50 rounded-full">
                      {getSpeciesIcon(char.species?.name)}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-lg">{char.species?.name}</h3>
                      <p className="text-xs text-muted-foreground line-clamp-1">{char.species?.description}</p>
                    </div>
                  </div>
                  
                  {/* Size and Speed Badges */}
                  <div className="flex gap-2 mt-3">
                    <Badge className={`${getSizeInfo(char.species?.size).color} border`}>
                      {getSizeInfo(char.species?.size).icon}
                      <span className="ml-1">{getSizeInfo(char.species?.size).label}</span>
                    </Badge>
                    <Badge className="bg-green-500/20 text-gray-900 border border-green-500/30">
                      <Footprints className="h-3 w-3 mr-1" />
                      {char.species?.speed || 30} ft
                    </Badge>
                  </div>
                </div>
                
                {/* Species Traits */}
                <ScrollArea className="h-48">
                  {(() => {
                    try {
                      if (!char.speciesTraits) {
                        return (
                          <div className="text-center py-6 text-muted-foreground text-sm">
                            No hay rasgos de especie registrados
                          </div>
                        )
                      }
                      const traits = JSON.parse(char.speciesTraits)
                      if (!traits || Object.keys(traits).length === 0) {
                        return (
                          <div className="text-center py-6 text-muted-foreground text-sm">
                            No hay rasgos de especie registrados
                          </div>
                        )
                      }
                      return (
                        <div className="space-y-2 pr-2">
                          {Object.entries(traits).map(([key, value], index) => (
                            <SpeciesTraitCard 
                              key={key} 
                              traitName={key} 
                              traitValue={value} 
                              index={index}
                            />
                          ))}
                        </div>
                      )
                    } catch {
                      return (
                        <div className="text-center py-6 text-muted-foreground text-sm">
                          No hay rasgos de especie registrados
                        </div>
                      )
                    }
                  })()}
                </ScrollArea>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Clase - Full Width */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Sword className="h-5 w-5" />
              Clase
            </CardTitle>
          </CardHeader>
          <CardContent>
            {(() => {
              const classLevels = (char as any).classLevels
              // Check if multiclass (has classLevels and more than 1)
              if (classLevels && classLevels.length > 1) {
                // Sort: primary first, then by level
                const sortedLevels = [...classLevels].sort((a: any, b: any) => {
                  if (a.isPrimary) return -1
                  if (b.isPrimary) return 1
                  return b.level - a.level
                })
                return (
                  <Tabs defaultValue={sortedLevels[0]?.class?.id || sortedLevels[0]?.classId}>
                    <TabsList className="grid w-full grid-cols-{sortedLevels.length}" style={{ gridTemplateColumns: `repeat(${sortedLevels.length}, 1fr)` }}>
                      {sortedLevels.map((cl: any) => (
                        <TabsTrigger key={cl.id} value={cl.class?.id || cl.classId}>
                          {cl.class?.name || 'Clase'} {cl.level}
                        </TabsTrigger>
                      ))}
                    </TabsList>
                    {sortedLevels.map((cl: any) => (
                      <TabsContent key={cl.id} value={cl.class?.id || cl.classId} className="mt-2">
                        <ClassFeaturesTable className={cl.class?.name || ''} currentLevel={cl.level} />
                      </TabsContent>
                    ))}
                  </Tabs>
                )
              }
              // Single class - show directly
              return (
                <ClassFeaturesTable className={char.characterClass?.name || ''} currentLevel={char.level} />
              )
            })()}
          </CardContent>
        </Card>

        {/* Dotes - Full Width */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Award className="h-5 w-5" />
              Dotes
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {/* Add Feat Button */}
              <Button 
                variant="outline" 
                size="sm" 
                className="w-full"
                onClick={() => setFeatDialog({ open: true, feat: null })}
              >
                <Plus className="h-4 w-4 mr-2" /> Añadir Dote
              </Button>
              
              <ScrollArea className="h-32">
                {char.characterFeats?.length === 0 && (
                  <div className="text-sm text-muted-foreground text-center py-4">
                    No hay dotes. Añade uno para empezar.
                  </div>
                )}
                {char.characterFeats?.map((cf: any) => (
                  <div 
                    key={cf.id} 
                    className="text-sm p-2 bg-muted rounded mb-1 cursor-pointer hover:bg-muted/80 transition-colors"
                    onClick={() => setFeatDetailDialog({ open: true, characterFeat: cf })}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <strong>{cf.feat?.name}</strong>
                        {cf.feat?.category && (
                          <Badge variant="outline" className="text-xs">
                            {cf.feat.category}
                          </Badge>
                        )}
                      </div>
                      {cf.chosenAbilityScore && (
                        <Badge className="text-xs bg-green-600">
                          +1 {cf.chosenAbilityScore.substring(0, 3).toUpperCase()}
                        </Badge>
                      )}
                    </div>
                    <p className="text-muted-foreground text-xs mt-1 line-clamp-1">{cf.feat?.description}</p>
                  </div>
                ))}
              </ScrollArea>
            </div>
          </CardContent>
        </Card>

        {/* Currency */}
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Monedas</CardTitle>
              <Button
                variant="ghost"
                size="sm"
                className="h-7 w-7 p-0"
                onClick={() => {
                  setEditingCurrency({
                    cp: selectedCharacter?.cp || 0,
                    sp: selectedCharacter?.sp || 0,
                    ep: selectedCharacter?.ep || 0,
                    gp: selectedCharacter?.gp || 0,
                    pp: selectedCharacter?.pp || 0
                  })
                  setEditCurrencyDialog(true)
                }}
              >
                <Edit className="h-3.5 w-3.5" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-5 gap-2 text-center">
              <div className="p-2 bg-amber-700/20 rounded">
                <div className="text-xs text-muted-foreground">PP</div>
                <div className="text-lg font-bold">{char.pp}</div>
              </div>
              <div className="p-2 bg-yellow-500/20 rounded">
                <div className="text-xs text-muted-foreground">GP</div>
                <div className="text-lg font-bold">{char.gp}</div>
              </div>
              <div className="p-2 bg-blue-500/20 rounded">
                <div className="text-xs text-muted-foreground">EP</div>
                <div className="text-lg font-bold">{char.ep}</div>
              </div>
              <div className="p-2 bg-gray-400/20 rounded">
                <div className="text-xs text-muted-foreground">SP</div>
                <div className="text-lg font-bold">{char.sp}</div>
              </div>
              <div className="p-2 bg-amber-600/20 rounded">
                <div className="text-xs text-muted-foreground">CP</div>
                <div className="text-lg font-bold">{char.cp}</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Proficiencies */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Proficiencias
            </CardTitle>
            <CardDescription>
              Herramientas, armas y armaduras con las que eres competente
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {/* Tools Proficiency */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-sm flex items-center gap-2">
                    <Package className="h-4 w-4 text-amber-500" />
                    Herramientas
                  </h4>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0"
                    onClick={() => {
                      const currentTools = char.toolProficiencies ? JSON.parse(char.toolProficiencies) : []
                      setEditingProficiencies(currentTools)
                      setNewProficiency('')
                      setProficienciesDialog('tools')
                    }}
                  >
                    <Edit className="h-3 w-3" />
                  </Button>
                </div>
                <div className="min-h-[60px] p-2 bg-muted/50 rounded-lg">
                  {(() => {
                    try {
                      const tools = char.toolProficiencies ? JSON.parse(char.toolProficiencies) : []
                      if (tools.length === 0) {
                        return <span className="text-xs text-muted-foreground italic">Ninguna</span>
                      }
                      return (
                        <div className="flex flex-wrap gap-1">
                          {tools.map((tool: string, idx: number) => (
                            <Badge key={idx} variant="secondary" className="text-xs bg-orange-500/10 text-gray-900 border-orange-500/30">
                              {tool}
                            </Badge>
                          ))}
                        </div>
                      )
                    } catch {
                      return <span className="text-xs text-muted-foreground italic">Ninguna</span>
                    }
                  })()}
                </div>
              </div>

              {/* Weapons Proficiency */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-sm flex items-center gap-2">
                    <Sword className="h-4 w-4 text-red-500" />
                    Armas
                  </h4>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0"
                    onClick={() => {
                      const currentWeapons = char.weaponProficiencies ? JSON.parse(char.weaponProficiencies) : []
                      setEditingProficiencies(currentWeapons)
                      setNewProficiency('')
                      setProficienciesDialog('weapons')
                    }}
                  >
                    <Edit className="h-3 w-3" />
                  </Button>
                </div>
                <div className="min-h-[60px] p-2 bg-muted/50 rounded-lg">
                  {(() => {
                    try {
                      const weapons = char.weaponProficiencies ? JSON.parse(char.weaponProficiencies) : []
                      if (weapons.length === 0) {
                        return <span className="text-xs text-muted-foreground italic">Ninguna</span>
                      }
                      return (
                        <div className="flex flex-wrap gap-1">
                          {weapons.map((weapon: string, idx: number) => (
                            <Badge key={idx} variant="secondary" className="text-xs bg-red-500/10 text-gray-900 border-red-500/30">
                              {weapon}
                            </Badge>
                          ))}
                        </div>
                      )
                    } catch {
                      return <span className="text-xs text-muted-foreground italic">Ninguna</span>
                    }
                  })()}
                </div>
              </div>

              {/* Armor Proficiency */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold text-sm flex items-center gap-2">
                    <Shield className="h-4 w-4 text-blue-500" />
                    Armaduras
                  </h4>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-6 w-6 p-0"
                    onClick={() => {
                      const currentArmor = char.armorProficiencies ? JSON.parse(char.armorProficiencies) : []
                      setEditingProficiencies(currentArmor)
                      setNewProficiency('')
                      setProficienciesDialog('armor')
                    }}
                  >
                    <Edit className="h-3 w-3" />
                  </Button>
                </div>
                <div className="min-h-[60px] p-2 bg-muted/50 rounded-lg">
                  {(() => {
                    try {
                      const armor = char.armorProficiencies ? JSON.parse(char.armorProficiencies) : []
                      if (armor.length === 0) {
                        return <span className="text-xs text-muted-foreground italic">Ninguna</span>
                      }
                      return (
                        <div className="flex flex-wrap gap-1">
                          {armor.map((a: string, idx: number) => (
                            <Badge key={idx} variant="secondary" className="text-xs bg-blue-500/10 text-gray-900 border-blue-500/30">
                              {a}
                            </Badge>
                          ))}
                        </div>
                      )
                    } catch {
                      return <span className="text-xs text-muted-foreground italic">Ninguna</span>
                    }
                  })()}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Background - Always visible and editable */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center justify-between">
              <span>Detalles del Personaje</span>
              <Button 
                variant="ghost" 
                size="sm" 
                className="h-8 w-8 p-0"
                onClick={() => {
                  setEditingDetails({
                    appearance: char.appearance || '',
                    backgroundStory: char.backgroundStory || '',
                    alignment: char.alignment || ''
                  })
                  setEditDetailsDialog(true)
                }}
              >
                <Edit className="h-4 w-4" />
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {char.appearance ? (
              <div>
                <h4 className="font-semibold mb-1 flex items-center gap-2">
                  <User className="h-4 w-4 text-muted-foreground" />
                  Apariencia
                </h4>
                <p className="text-sm text-muted-foreground whitespace-pre-wrap">{char.appearance}</p>
              </div>
            ) : (
              <div 
                className="text-sm text-muted-foreground italic cursor-pointer hover:text-foreground transition-colors p-2 border border-dashed rounded-lg text-center"
                onClick={() => {
                  setEditingDetails({ appearance: '', backgroundStory: char.backgroundStory || '', alignment: char.alignment || '' })
                  setEditDetailsDialog(true)
                }}
              >
                + Añadir apariencia
              </div>
            )}
            {char.backgroundStory ? (
              <div>
                <h4 className="font-semibold mb-1 flex items-center gap-2">
                  <BookOpen className="h-4 w-4 text-muted-foreground" />
                  Historia
                </h4>
                <p className="text-sm text-muted-foreground whitespace-pre-wrap">{char.backgroundStory}</p>
              </div>
            ) : (
              <div 
                className="text-sm text-muted-foreground italic cursor-pointer hover:text-foreground transition-colors p-2 border border-dashed rounded-lg text-center"
                onClick={() => {
                  setEditingDetails({ appearance: char.appearance || '', backgroundStory: '', alignment: char.alignment || '' })
                  setEditDetailsDialog(true)
                }}
              >
                + Añadir historia
              </div>
            )}
            {char.alignment ? (
              <div>
                <h4 className="font-semibold mb-1 flex items-center gap-2">
                  <Star className="h-4 w-4 text-muted-foreground" />
                  Alineamiento
                </h4>
                <Badge variant="outline" className="text-sm">{char.alignment}</Badge>
              </div>
            ) : (
              <div 
                className="text-sm text-muted-foreground italic cursor-pointer hover:text-foreground transition-colors p-2 border border-dashed rounded-lg text-center"
                onClick={() => {
                  setEditingDetails({ appearance: char.appearance || '', backgroundStory: char.backgroundStory || '', alignment: '' })
                  setEditDetailsDialog(true)
                }}
              >
                + Añadir alineamiento
              </div>
            )}
          </CardContent>
        </Card>

        {/* Quick Notes Section */}
        <Card className="bg-orange-50 dark:bg-orange-950/20 border-orange-200 dark:border-orange-800">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg flex items-center justify-between text-gray-900">
              <span className="flex items-center gap-2">
                <Scroll className="h-5 w-5" />
                Notas Rápidas
              </span>
              <div className="flex gap-2">
                {notes.length > 0 && (
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="bg-red-100 hover:bg-red-200 border-red-300 dark:bg-red-900 dark:hover:bg-red-800 text-red-700 dark:text-red-200"
                    onClick={handleDeleteAllNotes}
                  >
                    <Trash2 className="h-4 w-4 mr-1" /> Borrar Todas
                  </Button>
                )}
                <Button 
                  size="sm" 
                  variant="outline" 
                  className="bg-amber-100 hover:bg-amber-200 border-amber-300 dark:bg-amber-900 dark:hover:bg-amber-800"
                  onClick={() => handleCreateNote()}
                >
                  <Plus className="h-4 w-4 mr-1" /> Nueva Nota
                </Button>
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {notes.length === 0 ? (
              <div className="text-center py-8 text-gray-600">
                <Scroll className="h-12 w-12 mx-auto mb-2 opacity-50" />
                <p className="text-sm">No hay notas. Haz clic en "Nueva Nota" para crear una.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {notes.map((note) => (
                  <div 
                    key={note.id}
                    className={`relative p-3 rounded-lg border-2 cursor-pointer transition-all hover:shadow-md ${
                      note.color === 'red' ? 'bg-red-50 border-red-200 dark:bg-red-950/30 dark:border-red-800' :
                      note.color === 'green' ? 'bg-green-50 border-green-200 dark:bg-green-950/30 dark:border-green-800' :
                      note.color === 'blue' ? 'bg-blue-50 border-blue-200 dark:bg-blue-950/30 dark:border-blue-800' :
                      note.color === 'yellow' ? 'bg-yellow-50 border-yellow-200 dark:bg-yellow-950/30 dark:border-yellow-800' :
                      note.color === 'purple' ? 'bg-purple-50 border-purple-200 dark:bg-purple-950/30 dark:border-purple-800' :
                      'bg-amber-50 border-amber-200 dark:bg-amber-950/30 dark:border-amber-800'
                    }`}
                    onClick={() => setNoteDialog({ open: true, note })}
                  >
                    {note.pinned && (
                      <div className="absolute top-2 right-2">
                        <Star className="h-4 w-4 text-amber-500 fill-amber-500" />
                      </div>
                    )}
                    <h4 className="font-medium text-sm mb-1 truncate pr-6">{note.title}</h4>
                    <p className="text-xs text-muted-foreground line-clamp-3 whitespace-pre-wrap">{note.content || 'Sin contenido'}</p>
                    <div className="flex justify-between items-center mt-2 pt-2 border-t border-current/10">
                      <span className="text-xs text-muted-foreground">
                        {new Date(note.updatedAt).toLocaleDateString()}
                      </span>
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 w-6 p-0 hover:bg-destructive/20"
                        onClick={(e) => {
                          e.stopPropagation()
                          handleDeleteNote(note.id)
                        }}
                      >
                        <Trash2 className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    )
  }

  // Level Up Dialog
  const renderLevelUpDialog = () => {
    const totalAsiPoints = Object.values(levelUpChoices.asiPoints).reduce((a, b) => a + b, 0)
    const asiLevels = [4, 8, 12, 16, 19]
    
    // Helper to format multiclass requirements
    const formatMulticlassReq = (className: string) => {
      const req = levelUpOptions?.multiclassRequirements?.[className]
      if (!req) return ''
      
      const abilityNames: Record<string, string> = {
        'strength': 'FUE',
        'dexterity': 'DES',
        'constitution': 'CON',
        'intelligence': 'INT',
        'wisdom': 'SAB',
        'charisma': 'CAR'
      }
      
      if (req.useOr) {
        return `${abilityNames[req.primary]} ${req.primaryValue} o ${abilityNames[req.secondary!]} ${req.secondaryValue}`
      } else if (req.secondary) {
        return `${abilityNames[req.primary]} ${req.primaryValue} y ${abilityNames[req.secondary]} ${req.secondaryValue}`
      } else {
        return `${abilityNames[req.primary]} ${req.primaryValue}`
      }
    }
    
    return (
      <Dialog open={levelUpDialog} onOpenChange={setLevelUpDialog}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ArrowUpCircle className="h-5 w-5" />
              Subir de Nivel
            </DialogTitle>
            <DialogDescription>
              Tu personaje subirá del nivel {levelUpOptions?.currentLevel} al nivel {levelUpOptions?.newLevel}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6">
            {/* Check if character is already multiclass */}
            {levelUpOptions?.currentClassLevels?.length > 1 ? (
              /* Multiclass Character: Choose which class to advance or add new class */
              <Card className="border-2 border-blue-500/50 bg-blue-500/5">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <GitBranch className="h-5 w-5 text-blue-500" />
                    Personaje Multiclase
                  </CardTitle>
                  <CardDescription>
                    Elige en qué clase quieres subir de nivel o añadir una nueva
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {/* Existing classes to advance */}
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-muted-foreground">Tus clases actuales:</p>
                    {levelUpOptions.currentClassLevels.map((classLevel: any) => {
                      const conMod = Math.floor(((selectedCharacter?.constitution || 10) - 10) / 2)
                      const avgHp = Math.floor(classLevel.class.hitDie / 2) + 1 + conMod
                      const isSelected = levelUpChoices.advanceClassId === classLevel.classId
                      
                      return (
                        <div 
                          key={classLevel.id}
                          className={`p-3 rounded-lg border-2 cursor-pointer transition-all ${
                            isSelected && levelUpChoices.levelUpType === 'existingClass'
                              ? 'border-green-500 bg-green-500/10' 
                              : 'border-border hover:border-green-500/50'
                          }`}
                          onClick={() => setLevelUpChoices(prev => ({ 
                            ...prev, 
                            levelUpType: 'existingClass',
                            advanceClassId: classLevel.classId,
                            multiclassClassId: null 
                          }))}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <ArrowUpCircle className="h-4 w-4 text-green-500" />
                              <span className="font-semibold">{classLevel.class.name}</span>
                              <Badge variant="outline" className="text-xs">
                                Nivel {classLevel.level} → {classLevel.level + 1}
                              </Badge>
                              {classLevel.isPrimary && (
                                <Badge variant="secondary" className="text-xs bg-primary/20">Principal</Badge>
                              )}
                            </div>
                            <Badge variant="secondary" className="text-xs bg-green-500/10 text-green-700">
                              +{avgHp} PG | d{classLevel.class.hitDie} DG
                            </Badge>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                  
                  {/* Option to add new class */}
                  {levelUpOptions?.availableMulticlassOptions?.length > 0 && (
                    <div className="pt-2 border-t">
                      <div 
                        className={`p-3 rounded-lg border-2 cursor-pointer transition-all ${
                          levelUpChoices.levelUpType === 'multiclass' 
                            ? 'border-purple-500 bg-purple-500/10' 
                            : 'border-border hover:border-purple-500/50'
                        }`}
                        onClick={() => setLevelUpChoices(prev => ({ 
                          ...prev, 
                          levelUpType: 'multiclass',
                          advanceClassId: null 
                        }))}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <GitBranch className="h-4 w-4 text-purple-500" />
                          <span className="font-semibold">Añadir Nueva Clase</span>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          Tomar un nivel 1 en una nueva clase ({levelUpOptions?.availableMulticlassOptions?.length} disponibles)
                        </p>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ) : (
              /* Single Class Character: Existing advance/multiclass choice */
              <>
                {/* Multiclass or Advance Choice */}
                {levelUpOptions?.canMulticlass && levelUpOptions?.availableMulticlassOptions?.length > 0 && (
                  <Card className="border-2 border-purple-500/50 bg-purple-500/5">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg flex items-center gap-2">
                        <GitBranch className="h-5 w-5 text-purple-500" />
                        Elige tu camino
                      </CardTitle>
                      <CardDescription>
                        Puedes continuar en tu clase actual o comenzar una nueva clase (multiclase)
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                        {/* Advance in current class */}
                        <div 
                          className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                            levelUpChoices.levelUpType === 'advance' 
                              ? 'border-primary bg-primary/10' 
                              : 'border-border hover:border-primary/50'
                          }`}
                          onClick={() => setLevelUpChoices(prev => ({ 
                            ...prev, 
                            levelUpType: 'advance',
                            multiclassClassId: null 
                          }))}
                        >
                          <div className="flex items-center gap-2 mb-2">
                            <ArrowUpCircle className="h-5 w-5 text-green-500" />
                            <span className="font-semibold">Avanzar en tu clase</span>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            Continuar como {selectedCharacter?.characterClass?.name} nivel {levelUpOptions?.newLevel}
                          </p>
                          <p className="text-xs text-green-600 mt-1">
                            +1 Dado de Golpe d{selectedCharacter?.characterClass?.hitDie}
                          </p>
                        </div>
                        
                        {/* Multiclass option */}
                        <div 
                          className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${
                            levelUpChoices.levelUpType === 'multiclass' 
                              ? 'border-purple-500 bg-purple-500/10' 
                              : 'border-border hover:border-purple-500/50'
                          }`}
                          onClick={() => setLevelUpChoices(prev => ({ 
                            ...prev, 
                            levelUpType: 'multiclass'
                          }))}
                        >
                          <div className="flex items-center gap-2 mb-2">
                            <GitBranch className="h-5 w-5 text-purple-500" />
                            <span className="font-semibold">Multiclase</span>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            Tomar un nivel en una nueva clase
                          </p>
                          <p className="text-xs text-purple-600 mt-1">
                            {levelUpOptions?.availableMulticlassOptions?.length} clases disponibles
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </>
            )}
            
            {/* Multiclass Class Selection - for adding new class */}
            {levelUpChoices.levelUpType === 'multiclass' && levelUpOptions?.availableMulticlassOptions?.length > 0 && (
              <Card className="border-2 border-purple-500/50">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Crown className="h-5 w-5 text-purple-500" />
                    Elige tu Nueva Clase
                  </CardTitle>
                  <CardDescription>
                    Selecciona la clase en la que deseas tomar un nivel
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-64">
                    <div className="space-y-2 pr-2">
                      {levelUpOptions.availableMulticlassOptions.map((cls: any) => {
                        // Calculate HP gain for this class
                        const conMod = Math.floor(((selectedCharacter?.constitution || 10) - 10) / 2)
                        const avgHp = Math.floor(cls.hitDie / 2) + 1 + conMod
                        
                        return (
                          <div 
                            key={cls.id}
                            className={`p-3 rounded-lg border-2 cursor-pointer transition-all ${
                              levelUpChoices.multiclassClassId === cls.id 
                                ? 'border-purple-500 bg-purple-500/10' 
                                : 'border-border hover:border-purple-500/50'
                            }`}
                            onClick={() => setLevelUpChoices(prev => ({ 
                              ...prev, 
                              multiclassClassId: cls.id 
                            }))}
                          >
                            <div className="flex items-center justify-between">
                              <div className="font-medium">{cls.name}</div>
                              <div className="flex gap-2">
                                <Badge variant="outline" className="text-xs">
                                  d{cls.hitDie} DG
                                </Badge>
                                <Badge variant="secondary" className="text-xs bg-green-500/10 text-green-700">
                                  +{avgHp} PG
                                </Badge>
                              </div>
                            </div>
                            <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{cls.description}</p>
                            <p className="text-xs text-purple-600 mt-1">
                              Requisito: {formatMulticlassReq(cls.name)}
                            </p>
                          </div>
                        )
                      })}
                    </div>
                  </ScrollArea>
                  
                  <Alert className="mt-3">
                    <Info className="h-4 w-4" />
                    <AlertDescription className="text-xs">
                      <strong>Al multiclasear obtienes:</strong>
                      <ul className="list-disc pl-4 mt-1">
                        <li>Puntos de golpe del dado de la nueva clase</li>
                        <li>Competencias en armas y armaduras de la nueva clase</li>
                        <li>Acceso a características de nivel 1 de la nueva clase</li>
                        <li>NO obtienes las salvaciones de la nueva clase</li>
                      </ul>
                    </AlertDescription>
                  </Alert>
                </CardContent>
              </Card>
            )}
            
            {/* Base benefits - only show if advancing in current class */}
            {(levelUpChoices.levelUpType === 'advance' || levelUpChoices.levelUpType === 'existingClass') && (
              <Alert>
                <AlertCircle className="h-4 w-4" />
                <AlertDescription>
                  <strong>Ganancias automáticas:</strong>
                  <ul className="list-disc pl-5 mt-1">
                    <li>+1 Dado de Golpe adicional</li>
                    <li>Nuevos Puntos de Golpe (promedio del dado + CON mod)</li>
                    {levelUpOptions?.proficiencyBonusChange > 0 && (
                      <li className="text-green-600">+{levelUpOptions.proficiencyBonusChange} Bonificador de Competencia</li>
                    )}
                  </ul>
                </AlertDescription>
              </Alert>
            )}
            
            {/* Subclass Selection (Level 3) - only if advancing */}
            {(levelUpChoices.levelUpType === 'advance' || levelUpChoices.levelUpType === 'existingClass') && levelUpOptions?.availableSubclasses?.length > 0 && (
              <Card className="border-2 border-primary/50">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Crown className="h-5 w-5 text-orange-400" />
                    Elige tu Subclase
                  </CardTitle>
                  <CardDescription>
                    A nivel 3, tu personaje debe elegir una subclase que define su especialización
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {levelUpOptions.availableSubclasses.map((subclass: any) => (
                      <div 
                        key={subclass.id}
                        className={`p-3 rounded-lg border-2 cursor-pointer transition-all ${
                          levelUpChoices.subclassId === subclass.id 
                            ? 'border-primary bg-primary/10' 
                            : 'border-border hover:border-primary/50'
                        }`}
                        onClick={() => setLevelUpChoices(prev => ({ ...prev, subclassId: subclass.id }))}
                      >
                        <div className="font-medium">{subclass.name}</div>
                        <p className="text-sm text-muted-foreground line-clamp-2">{subclass.description}</p>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
            
            {/* ASI or Feat Selection - only if advancing */}
            {(levelUpChoices.levelUpType === 'advance' || levelUpChoices.levelUpType === 'existingClass') && levelUpOptions?.canIncreaseAbilityScores && (
              <Card className="border-2 border-primary/50">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Zap className="h-5 w-5 text-orange-400" />
                    Mejora de Características o Dote
                  </CardTitle>
                  <CardDescription>
                    Elige entre mejorar tus características o adquirir un nuevo dote
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Choice toggle */}
                  <div className="flex gap-2">
                    <Button 
                      variant={levelUpChoices.asiChoice === 'asi' ? 'default' : 'outline'}
                      className="flex-1"
                      onClick={() => setLevelUpChoices(prev => ({ 
                        ...prev, 
                        asiChoice: 'asi', 
                        featId: null 
                      }))}
                    >
                      <ArrowUpCircle className="h-4 w-4 mr-2" />
                      Mejorar Características (+2 puntos)
                    </Button>
                    <Button 
                      variant={levelUpChoices.asiChoice === 'feat' ? 'default' : 'outline'}
                      className="flex-1"
                      onClick={() => setLevelUpChoices(prev => ({ 
                        ...prev, 
                        asiChoice: 'feat',
                        asiPoints: { str: 0, dex: 0, con: 0, int: 0, wis: 0, cha: 0 }
                      }))}
                    >
                      <Sparkles className="h-4 w-4 mr-2" />
                      Elegir Dote
                    </Button>
                  </div>
                  
                  {/* ASI Selection */}
                  {levelUpChoices.asiChoice === 'asi' && (
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Puntos restantes: {2 - totalAsiPoints}</span>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                        {[
                          { key: 'str', label: 'Fuerza', current: selectedCharacter?.strength || 10 },
                          { key: 'dex', label: 'Destreza', current: selectedCharacter?.dexterity || 10 },
                          { key: 'con', label: 'Constitución', current: selectedCharacter?.constitution || 10 },
                          { key: 'int', label: 'Inteligencia', current: selectedCharacter?.intelligence || 10 },
                          { key: 'wis', label: 'Sabiduría', current: selectedCharacter?.wisdom || 10 },
                          { key: 'cha', label: 'Carisma', current: selectedCharacter?.charisma || 10 },
                        ].map(ability => (
                          <div key={ability.key} className="flex items-center justify-between p-2 bg-muted rounded-lg">
                            <span className="text-sm font-medium">{ability.label}</span>
                            <div className="flex items-center gap-2">
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="h-6 w-6 p-0"
                                disabled={levelUpChoices.asiPoints[ability.key as keyof typeof levelUpChoices.asiPoints] <= 0}
                                onClick={() => setLevelUpChoices(prev => ({
                                  ...prev,
                                  asiPoints: {
                                    ...prev.asiPoints,
                                    [ability.key]: prev.asiPoints[ability.key as keyof typeof prev.asiPoints] - 1
                                  }
                                }))}
                              >
                                -
                              </Button>
                              <span className="w-8 text-center">
                                {ability.current + levelUpChoices.asiPoints[ability.key as keyof typeof levelUpChoices.asiPoints]}
                              </span>
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="h-6 w-6 p-0"
                                disabled={
                                  totalAsiPoints >= 2 || 
                                  (ability.current + levelUpChoices.asiPoints[ability.key as keyof typeof levelUpChoices.asiPoints]) >= 20
                                }
                                onClick={() => setLevelUpChoices(prev => ({
                                  ...prev,
                                  asiPoints: {
                                    ...prev.asiPoints,
                                    [ability.key]: prev.asiPoints[ability.key as keyof typeof prev.asiPoints] + 1
                                  }
                                }))}
                              >
                                +
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                  
                  {/* Feat Selection */}
                  {levelUpChoices.asiChoice === 'feat' && (
                    <ScrollArea className="h-64">
                      <div className="space-y-2 pr-2">
                        {levelUpOptions?.availableFeats?.map((feat: any) => (
                          <div 
                            key={feat.id}
                            className={`p-3 rounded-lg border cursor-pointer transition-all ${
                              levelUpChoices.featId === feat.id 
                                ? 'border-primary bg-primary/10' 
                                : 'border-border hover:border-primary/50'
                            }`}
                            onClick={() => setLevelUpChoices(prev => ({ ...prev, featId: feat.id }))}
                          >
                            <div className="flex items-center justify-between">
                              <div className="font-medium">{feat.name}</div>
                              <Badge variant="outline" className="text-xs">{feat.category}</Badge>
                            </div>
                            <p className="text-sm text-muted-foreground line-clamp-2 mt-1">{feat.description}</p>
                          </div>
                        ))}
                      </div>
                    </ScrollArea>
                  )}
                </CardContent>
              </Card>
            )}
            
            {/* New Spell Selection for Spellcasters - only if advancing */}
            {(levelUpChoices.levelUpType === 'advance' || levelUpChoices.levelUpType === 'existingClass') && levelUpOptions?.availableSpells?.length > 0 && (
              <Card className="border-2 border-primary/50">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Wand2 className="h-5 w-5 text-purple-500" />
                    Nuevo Hechizo (Opcional)
                  </CardTitle>
                  <CardDescription>
                    Puedes aprender un nuevo hechizo disponible para tu clase
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-48">
                    <div className="space-y-2 pr-2">
                      {levelUpOptions.availableSpells.map((spell: any) => (
                        <div 
                          key={spell.id}
                          className={`p-3 rounded-lg border cursor-pointer transition-all ${
                            levelUpChoices.spellId === spell.id 
                              ? 'border-primary bg-primary/10' 
                              : 'border-border hover:border-primary/50'
                          }`}
                          onClick={() => setLevelUpChoices(prev => ({ 
                            ...prev, 
                            spellId: prev.spellId === spell.id ? null : spell.id 
                          }))}
                        >
                          <div className="flex items-center justify-between">
                            <div className="font-medium">{spell.name}</div>
                            <div className="flex gap-1">
                              <Badge className={`${getSchoolColor(spell.school)} text-xs`}>
                                {spell.school}
                              </Badge>
                              <Badge variant="outline" className="text-xs">
                                Nivel {spell.level}
                              </Badge>
                            </div>
                          </div>
                          <p className="text-sm text-muted-foreground line-clamp-1 mt-1">{spell.description}</p>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            )}
            
            {/* New Features Info - only if advancing */}
            {(levelUpChoices.levelUpType === 'advance' || levelUpChoices.levelUpType === 'existingClass') && levelUpOptions?.newFeatures?.length > 0 && (
              <Card>
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Star className="h-5 w-5 text-orange-400" />
                    Nuevas Características de Clase
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="list-disc pl-5 space-y-1">
                    {levelUpOptions.newFeatures.map((feature: string, idx: number) => (
                      <li key={idx} className="text-sm">{feature}</li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            )}
          </div>
          
          <div className="flex justify-end gap-2 pt-4">
            <Button variant="outline" onClick={() => setLevelUpDialog(false)}>
              Cancelar
            </Button>
            <Button 
              onClick={handleLevelUp}
              disabled={
                // Multiclass validation (new class)
                (levelUpChoices.levelUpType === 'multiclass' && !levelUpChoices.multiclassClassId) ||
                // Existing class validation (for multiclass characters)
                (levelUpChoices.levelUpType === 'existingClass' && !levelUpChoices.advanceClassId) ||
                // Advance validation (single class)
                ((levelUpChoices.levelUpType === 'advance' || levelUpChoices.levelUpType === 'existingClass') && (
                  (levelUpOptions?.availableSubclasses?.length > 0 && !levelUpChoices.subclassId) ||
                  (levelUpOptions?.canIncreaseAbilityScores && !levelUpChoices.asiChoice) ||
                  (levelUpChoices.asiChoice === 'asi' && totalAsiPoints !== 2)
                ))
              }
            >
              <ArrowUpCircle className="h-4 w-4 mr-2" /> 
              {levelUpChoices.levelUpType === 'multiclass' ? 'Confirmar Multiclase' : 'Confirmar Subida de Nivel'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  // Inventory Dialog
  const renderInventoryDialog = () => {
    // Filter items based on search term
    const filteredWeapons = weapons.filter(w => 
      w.name.toLowerCase().includes(inventorySearchTerm.toLowerCase()) ||
      w.category.toLowerCase().includes(inventorySearchTerm.toLowerCase()) ||
      w.damageType.toLowerCase().includes(inventorySearchTerm.toLowerCase())
    )
    
    const filteredArmor = armor.filter(a => 
      a.name.toLowerCase().includes(inventorySearchTerm.toLowerCase()) ||
      a.category.toLowerCase().includes(inventorySearchTerm.toLowerCase())
    )
    
    const filteredItems = items.filter(i => 
      i.name.toLowerCase().includes(inventorySearchTerm.toLowerCase()) ||
      i.category.toLowerCase().includes(inventorySearchTerm.toLowerCase()) ||
      (i.subcategory && i.subcategory.toLowerCase().includes(inventorySearchTerm.toLowerCase()))
    )
    
    return (
      <Dialog open={inventoryDialog} onOpenChange={(open) => {
        setInventoryDialog(open)
        if (!open) setInventorySearchTerm('')
      }}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Gestionar Inventario</DialogTitle>
            <DialogDescription>
              Añade o quita armas, armaduras y objetos
            </DialogDescription>
          </DialogHeader>
          
          {/* Search Input */}
          <div className="relative">
            <Input
              placeholder="Buscar en inventario..."
              value={inventorySearchTerm}
              onChange={(e) => setInventorySearchTerm(e.target.value)}
              className="w-full"
            />
            {inventorySearchTerm && (
              <Button
                variant="ghost"
                size="sm"
                className="absolute right-1 top-1/2 -translate-y-1/2 h-7 w-7 p-0"
                onClick={() => setInventorySearchTerm('')}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            )}
          </div>
          
          <Tabs defaultValue="weapons" className="mt-4">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="weapons">
                Armas {filteredWeapons.length !== weapons.length && `(${filteredWeapons.length})`}
              </TabsTrigger>
              <TabsTrigger value="armor">
                Armadura {filteredArmor.length !== armor.length && `(${filteredArmor.length})`}
              </TabsTrigger>
              <TabsTrigger value="items">
                Objetos {filteredItems.length !== items.length && `(${filteredItems.length})`}
              </TabsTrigger>
              <TabsTrigger value="magic">Mágicos</TabsTrigger>
            </TabsList>
            <TabsContent value="weapons" className="mt-4">
              <ScrollArea className="h-96">
                {filteredWeapons.length === 0 ? (
                  <div className="text-center text-muted-foreground py-8">
                    No se encontraron armas
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {filteredWeapons.map((weapon) => (
                      <Card key={weapon.id} className="p-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="font-medium">{weapon.name}</div>
                            <div className="text-sm text-muted-foreground">
                              {weapon.damage} {weapon.damageType} | {weapon.category}
                            </div>
                            <div className="text-xs text-muted-foreground mt-1">
                              Coste: {weapon.cost} GP | Peso: {weapon.weight} lb
                            </div>
                          </div>
                          <Button 
                            size="sm"
                            onClick={async () => {
                              await fetch(`/api/characters/${selectedCharacter?.id}/inventory`, {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ weaponId: weapon.id })
                              })
                              fetchCharacterDetails(selectedCharacter?.id || '')
                            }}
                          >
                            <Plus className="h-4 w-4" />
                          </Button>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </TabsContent>
            <TabsContent value="armor" className="mt-4">
              <ScrollArea className="h-96">
                {filteredArmor.length === 0 ? (
                  <div className="text-center text-muted-foreground py-8">
                    No se encontró armadura
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {filteredArmor.map((a) => (
                      <Card key={a.id} className="p-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="font-medium">{a.name}</div>
                            <div className="text-sm text-muted-foreground">
                              CA {a.baseAC} | {a.category}
                            </div>
                            <div className="text-xs text-muted-foreground mt-1">
                              Coste: {a.cost} GP | Peso: {a.weight} lb
                            </div>
                          </div>
                          <Button 
                            size="sm"
                            onClick={async () => {
                              await fetch(`/api/characters/${selectedCharacter?.id}/inventory`, {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ armorId: a.id })
                              })
                              fetchCharacterDetails(selectedCharacter?.id || '')
                            }}
                          >
                            <Plus className="h-4 w-4" />
                          </Button>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </TabsContent>
            <TabsContent value="items" className="mt-4">
              <ScrollArea className="h-96">
                {filteredItems.length === 0 ? (
                  <div className="text-center text-muted-foreground py-8">
                    No se encontraron objetos
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {filteredItems.map((item) => (
                      <Card key={item.id} className="p-3">
                        <div className="flex justify-between items-start">
                          <div>
                            <div className="font-medium">{item.name}</div>
                            <div className="text-sm text-muted-foreground">
                              {item.category}
                            </div>
                            <div className="text-xs text-muted-foreground mt-1">
                              Coste: {item.cost / 100} GP | Peso: {item.weight} lb
                            </div>
                          </div>
                          <Button 
                            size="sm"
                            onClick={async () => {
                              await fetch(`/api/characters/${selectedCharacter?.id}/inventory`, {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ itemId: item.id })
                              })
                              fetchCharacterDetails(selectedCharacter?.id || '')
                            }}
                          >
                            <Plus className="h-4 w-4" />
                          </Button>
                        </div>
                      </Card>
                    ))}
                  </div>
                )}
              </ScrollArea>
            </TabsContent>
            <TabsContent value="magic" className="mt-4">
              <ScrollArea className="h-96">
                <div className="text-center text-muted-foreground py-8">
                  Los objetos mágicos deben encontrarse en aventuras
                </div>
              </ScrollArea>
            </TabsContent>
          </Tabs>
        </DialogContent>
      </Dialog>
    )
  }

  // Enhanced Spells Dialog
  const renderSpellsDialog = () => {
    const className = selectedCharacter?.characterClass?.name || ''
    const classLevels = selectedCharacter?.classLevels || []
    const isMulticlass = classLevels.length > 1
    
    // Get all spellcasting class names from the character
    const spellcastingClasses: string[] = []
    
    // Add primary class if it has spellcasting
    if (selectedCharacter?.characterClass?.spellcasting) {
      spellcastingClasses.push(className)
    }
    
    // Add all multiclass spellcasting classes
    for (const cl of classLevels) {
      const cls = cl.class
      if (cls && cls.spellcasting && !spellcastingClasses.includes(cls.name)) {
        // For Paladin/Ranger, check if they have spellcasting (level 2+)
        if (cls.name === 'Paladin' || cls.name === 'Ranger') {
          if (cl.level >= 2) {
            spellcastingClasses.push(cls.name)
          }
        } else {
          spellcastingClasses.push(cls.name)
        }
      }
    }
    
    const isSpellcaster = spellcastingClasses.length > 0
    
    // For spellcasters, show spells from ALL their classes. For non-spellcasters with species spells, show all spells
    const classSpells = isSpellcaster 
      ? spells.filter(s => {
          const spellClasses = JSON.parse(s.classes)
          return spellClasses.some((sc: string) => spellcastingClasses.includes(sc))
        })
      : spells // Show all spells for non-spellcasters (they might have species/granted spells)
    
    // Calculate max spell level available (highest among all classes)
    let maxSpellLevel = 0
    for (const cl of classLevels) {
      const cls = cl.class
      if (cls) {
        const classMaxSpell = getMaxSpellLevel(cls.name, cl.level)
        if (classMaxSpell > maxSpellLevel) {
          maxSpellLevel = classMaxSpell
        }
      }
    }
    // Also check primary class
    const primaryMaxSpell = getMaxSpellLevel(className, selectedCharacter?.level || 1)
    if (primaryMaxSpell > maxSpellLevel) {
      maxSpellLevel = primaryMaxSpell
    }
    
    // Filter spells
    const filteredSpells = classSpells.filter(s => {
      if (spellLevelFilter !== 'all' && s.level !== parseInt(spellLevelFilter)) return false
      if (spellSchoolFilter !== 'all' && s.school !== spellSchoolFilter) return false
      // For spellcasters, only show spells of levels they can cast
      // For non-spellcasters, show all cantrips and level 1 spells (species can grant these)
      if (isSpellcaster && s.level > maxSpellLevel) return false
      return true
    })
    
    // Get unique schools for filter
    const schools = [...new Set(classSpells.map(s => s.school))].sort()
    
    // Get known spell IDs
    const knownSpellIds = new Set(selectedCharacter?.characterSpells?.map((cs: any) => cs.spellId) || [])
    
    // Calculate spellcasting stats
    const stats = calculateSpellcastingStats(selectedCharacter)
    
    // Calculate total prepared spells for multiclass
    let totalMaxPrepared = 0
    if (stats && isSpellcaster) {
      for (const cl of classLevels) {
        const cls = cl.class
        if (cls && spellcastingClasses.includes(cls.name)) {
          const classAbility = SPELLCASTING_ABILITY[cls.name]
          let abilityScore = 10
          if (selectedCharacter) {
            switch (classAbility) {
              case 'intelligence': abilityScore = selectedCharacter.intelligence; break
              case 'wisdom': abilityScore = selectedCharacter.wisdom; break
              case 'charisma': abilityScore = selectedCharacter.charisma; break
            }
          }
          const classPrepared = getMaxPreparedSpells(cls.name, cl.level, abilityScore)
          totalMaxPrepared += classPrepared
        }
      }
    }
    
    // Exclude non-class spells from prepared count - they don't count toward the limit
    const currentPrepared = selectedCharacter?.characterSpells?.filter((cs: any) => cs.prepared && cs.spell?.level > 0 && cs.source === 'class').length || 0
    
    // Build class display string
    const classDisplayString = isMulticlass 
      ? spellcastingClasses.join(' / ')
      : className
    
    return (
      <Dialog open={spellsDialog} onOpenChange={setSpellsDialog}>
        <DialogContent className="max-w-5xl h-[85vh] flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="flex items-center gap-2">
              <Wand2 className="h-5 w-5" />
              Gestionar Hechizos - {classDisplayString}
              {isMulticlass && spellcastingClasses.length > 1 && (
                <Badge variant="secondary" className="text-xs ml-2">Multiclase</Badge>
              )}
              {!isSpellcaster && (
                <Badge variant="secondary" className="text-xs ml-2">Hechizos de Especie/Rasgos</Badge>
              )}
            </DialogTitle>
            <DialogDescription>
              {isSpellcaster 
                ? `Hechizos disponibles para tus clases (${spellcastingClasses.join(', ')}). Nivel máximo de hechizo: ${maxSpellLevel === 0 ? 'Trucos' : maxSpellLevel}`
                : 'Gestiona los hechizos otorgados por tu especie, dotes u otros rasgos.'
              }
            </DialogDescription>
          </DialogHeader>
          
          {/* Stats Bar - Only for spellcasters */}
          {stats && isSpellcaster && (
            <div className="flex-shrink-0 flex gap-4 p-3 bg-muted rounded-lg text-sm flex-wrap">
              <div><strong>CD:</strong> {stats.spellSaveDC}</div>
              <div><strong>Ataque:</strong> +{stats.spellAttackBonus}</div>
              <div><strong>Habilidad:</strong> {stats.abilityName}</div>
              <div><strong>Preparados:</strong> {currentPrepared}/{totalMaxPrepared}</div>
              <div><strong>Conocidos:</strong> {selectedCharacter?.characterSpells?.length || 0}</div>
            </div>
          )}
          
          {/* Multiclass info */}
          {isMulticlass && spellcastingClasses.length > 1 && (
            <Alert className="flex-shrink-0">
              <Info className="h-4 w-4" />
              <AlertDescription className="text-sm">
                <strong>Clases de conjuración:</strong> {spellcastingClasses.map(c => {
                  const cl = classLevels.find((cl: any) => cl.class?.name === c)
                  return `${c} ${cl?.level || ''}`
                }).join(', ')}
                <br />
                <span className="text-muted-foreground">Puedes elegir hechizos de cualquiera de estas clases.</span>
              </AlertDescription>
            </Alert>
          )}
          
          {/* Non-spellcaster info */}
          {!isSpellcaster && (
            <Alert className="flex-shrink-0">
              <Info className="h-4 w-4" />
              <AlertDescription className="text-sm">
                Tu clase no es lanzadora de hechizos, pero puedes tener hechizos otorgados por tu especie, dotes u otros rasgos. 
                Aquí puedes ver y gestionar esos hechizos.
              </AlertDescription>
            </Alert>
          )}
          
          {/* Filters */}
          <div className="flex-shrink-0 flex gap-4">
            <Select value={spellLevelFilter} onValueChange={setSpellLevelFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Nivel" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los Niveles</SelectItem>
                <SelectItem value="0">Trucos</SelectItem>
                {[1,2,3,4,5,6,7,8,9].filter(l => l <= maxSpellLevel).map(l => (
                  <SelectItem key={l} value={l.toString()}>Nivel {l}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={spellSchoolFilter} onValueChange={setSpellSchoolFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Escuela" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las Escuelas</SelectItem>
                {schools.map(s => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <div className="flex-1 text-right text-muted-foreground">
              {filteredSpells.length} hechizos encontrados
            </div>
          </div>
          
          {/* Spells Grid - Flexible height */}
          <div className="flex-1 min-h-0">
            <ScrollArea className="h-full">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 pr-4">
                {filteredSpells.map((spell) => {
                  const isKnown = knownSpellIds.has(spell.id)
                  const characterSpell = selectedCharacter?.characterSpells?.find((cs: any) => cs.spellId === spell.id)
                  
                  return (
                    <Card 
                      key={spell.id} 
                      className={`p-3 cursor-pointer hover:bg-muted/50 ${isKnown ? 'border-primary/50' : ''}`}
                      onClick={() => setSpellDetailDialog({ open: true, spell })}
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <div className={`p-1 rounded ${getSchoolColor(spell.school)}`}>
                              {getSchoolIcon(spell.school)}
                            </div>
                            <div>
                              <div className="font-medium">{spell.name}</div>
                              <div className="text-xs text-muted-foreground">
                                {spell.level === 0 ? 'Truco' : `Nivel ${spell.level}`} | {spell.school}
                              </div>
                            </div>
                          </div>
                          <div className="text-xs text-muted-foreground mt-1 ml-7">
                            {spell.castingTime} | {spell.range}
                            {spell.concentration && ' | C'} {spell.ritual && ' | R'}
                          </div>
                        </div>
                        
                        <div className="flex flex-col gap-1">
                          {!isKnown ? (
                            <Button 
                              size="sm"
                              onClick={async (e) => {
                                e.stopPropagation()
                                await fetch(`/api/characters/${selectedCharacter?.id}/spells`, {
                                  method: 'POST',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({ spellId: spell.id, prepared: false })
                                })
                                fetchCharacterDetails(selectedCharacter?.id || '')
                              }}
                            >
                              <Plus className="h-4 w-4" />
                            </Button>
                          ) : (
                            <div className="flex gap-1">
                              <Button 
                                size="sm"
                                variant={characterSpell?.prepared ? "default" : "outline"}
                                onClick={async (e) => {
                                  e.stopPropagation()
                                  await fetch(`/api/characters/${selectedCharacter?.id}/spells`, {
                                    method: 'PUT',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify({ spellId: spell.id, prepared: !characterSpell?.prepared })
                                  })
                                  fetchCharacterDetails(selectedCharacter?.id || '')
                                }}
                              >
                                {characterSpell?.prepared ? <Unlock className="h-4 w-4" /> : <Lock className="h-4 w-4" />}
                              </Button>
                              <Button 
                                size="sm"
                                variant="destructive"
                                onClick={async (e) => {
                                  e.stopPropagation()
                                  await fetch(`/api/characters/${selectedCharacter?.id}/spells?spellId=${spell.id}`, {
                                    method: 'DELETE'
                                  })
                                  fetchCharacterDetails(selectedCharacter?.id || '')
                                }}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    </Card>
                  )
                })}
              </div>
            </ScrollArea>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  // Spell Detail Dialog
  const renderSpellDetailDialog = () => {
    const spell = spellDetailDialog.spell
    if (!spell) return null

    // Check if spell is known by character
    const characterSpell = selectedCharacter?.characterSpells?.find((cs: any) => cs.spellId === spell.id)
    const isKnown = !!characterSpell
    const isPrepared = characterSpell?.prepared || false
    const spellSource = characterSpell?.source || 'class'
    // Protected spells (domain, species, feat) don't count toward limits and can't be removed
    const isProtectedSpell = spellSource !== 'class'

    // Check if class uses prepared spells
    const className = selectedCharacter?.characterClass?.name || ''
    const spellcastingType = getSpellcastingType(className)
    const usesPreparedSpells = spellcastingType === 'prepared' || spellcastingType === 'book'

    // Calculate prepared spells stats
    const stats = calculateSpellcastingStats(selectedCharacter)
    const maxPrepared = stats ? getMaxPreparedSpells(className, selectedCharacter?.level || 1, stats.abilityScore) : 0
    // Only class spells count toward prepared limit
    const currentPrepared = selectedCharacter?.characterSpells?.filter((cs: any) => cs.prepared && cs.spell?.level > 0 && cs.source === 'class').length || 0

    // Add spell to known
    const addSpellToKnown = async () => {
      if (!selectedCharacter?.id) return

      try {
        const res = await fetch(`/api/characters/${selectedCharacter.id}/spells`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ spellId: spell.id, prepared: false })
        })

        if (res.ok) {
          fetchCharacterDetails(selectedCharacter.id)
        }
      } catch (error) {
        console.error('Error adding spell:', error)
      }
    }

    // Toggle prepared status
    const togglePrepared = async () => {
      if (!selectedCharacter?.id || !isKnown || isProtectedSpell) return

      try {
        const res = await fetch(`/api/characters/${selectedCharacter.id}/spells`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ spellId: spell.id, prepared: !isPrepared })
        })

        if (res.ok) {
          fetchCharacterDetails(selectedCharacter.id)
        }
      } catch (error) {
        console.error('Error toggling prepared status:', error)
      }
    }

    // Remove spell from known
    const removeSpell = async () => {
      if (!selectedCharacter?.id || !isKnown || isProtectedSpell) return

      try {
        const res = await fetch(`/api/characters/${selectedCharacter.id}/spells?spellId=${spell.id}`, {
          method: 'DELETE'
        })

        if (res.ok) {
          fetchCharacterDetails(selectedCharacter.id)
          setSpellDetailDialog({ open: false, spell: null })
        }
      } catch (error) {
        console.error('Error removing spell:', error)
      }
    }

    return (
      <Dialog open={spellDetailDialog.open} onOpenChange={(open) => setSpellDetailDialog({ open, spell: spellDetailDialog.spell })}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <div className={`p-2 rounded ${getSchoolColor(spell.school)}`}>
                {getSchoolIcon(spell.school)}
              </div>
              {spell.name}
              {isProtectedSpell && spellSource === 'domain' && (
                <Badge variant="default" className="ml-2 bg-purple-600 hover:bg-purple-700">
                  ⚡ Dominio
                </Badge>
              )}
              {isProtectedSpell && spellSource === 'circle' && (
                <Badge variant="default" className="ml-2 bg-emerald-600 hover:bg-emerald-700">
                  🌿 Círculo
                </Badge>
              )}
              {isProtectedSpell && spellSource === 'oath' && (
                <Badge variant="default" className="ml-2 bg-amber-600 hover:bg-amber-700">
                  ⚔️ Juramento
                </Badge>
              )}
              {isProtectedSpell && spellSource === 'ranger' && (
                <Badge variant="default" className="ml-2 bg-green-600 hover:bg-green-700">
                  🏹 Ranger
                </Badge>
              )}
              {isProtectedSpell && spellSource === 'sorcerer' && (
                <Badge variant="default" className="ml-2 bg-red-600 hover:bg-red-700">
                  🔥 Sorcerer
                </Badge>
              )}
              {isProtectedSpell && spellSource === 'warlock' && (
                <Badge variant="default" className="ml-2 bg-violet-600 hover:bg-violet-700">
                  👁️ Warlock
                </Badge>
              )}
              {isProtectedSpell && spellSource === 'species' && (
                <Badge variant="default" className="ml-2 bg-teal-600 hover:bg-teal-700">
                  🧬 Especie
                </Badge>
              )}
              {isProtectedSpell && spellSource === 'feat' && (
                <Badge variant="default" className="ml-2 bg-orange-600 hover:bg-orange-700">
                  ⭐ Dote
                </Badge>
              )}
              {isKnown && !isProtectedSpell && (
                <Badge variant="secondary" className="ml-2">
                  Conocido
                </Badge>
              )}
              {isPrepared && !isProtectedSpell && (
                <Badge variant="default" className="ml-1 bg-green-600">
                  Preparado
                </Badge>
              )}
            </DialogTitle>
            <DialogDescription>
              {spell.level === 0 ? 'Truco' : `Hechizo de Nivel ${spell.level}`} | {spell.school}
              {isProtectedSpell && <span className="text-purple-600 ml-2">| Siempre preparado (no cuenta en el límite)</span>}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
              <div className="p-2 bg-muted rounded">
                <div className="text-xs text-muted-foreground">Tiempo</div>
                <div className="font-medium">{spell.castingTime}</div>
              </div>
              <div className="p-2 bg-muted rounded">
                <div className="text-xs text-muted-foreground">Alcance</div>
                <div className="font-medium">{spell.range}</div>
              </div>
              <div className="p-2 bg-muted rounded">
                <div className="text-xs text-muted-foreground">Duración</div>
                <div className="font-medium">{spell.duration}</div>
              </div>
              <div className="p-2 bg-muted rounded">
                <div className="text-xs text-muted-foreground">Componentes</div>
                <div className="font-medium">{spell.components}</div>
              </div>
            </div>

            {/* Tags */}
            <div className="flex gap-2 flex-wrap">
              {spell.concentration && <Badge variant="secondary">Concentración</Badge>}
              {spell.ritual && <Badge variant="secondary">Ritual</Badge>}
              {spell.damageType && <Badge variant="outline">{spell.damageType}</Badge>}
              {spell.damageDice && <Badge variant="outline">{spell.damageDice}</Badge>}
            </div>

            {/* Description */}
            <div className="text-sm prose prose-sm dark:prose-invert max-w-none">
              <p>{spell.description}</p>
            </div>

            {/* Classes */}
            <div className="text-sm">
              <strong>Clases:</strong> {typeof spell.classes === 'string' ? JSON.parse(spell.classes).join(', ') : spell.classes.join(', ')}
            </div>

            {/* Spell Actions */}
            <div className="pt-4 border-t space-y-3">
              {/* If spell is not known, show add button */}
              {!isKnown && (
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-sm">Añadir a Hechizos Conocidos</h4>
                    <p className="text-xs text-muted-foreground">
                      Este hechizo no está en tu lista de hechizos conocidos
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={addSpellToKnown}
                  >
                    <Plus className="h-4 w-4 mr-1" />
                    Añadir
                  </Button>
                </div>
              )}

              {/* Protected Spell (domain, circle, oath, etc.) - Always Prepared, Cannot Be Removed */}
              {isProtectedSpell && (
                <Alert className="bg-purple-50 dark:bg-purple-950/30 border-purple-200 dark:border-purple-800">
                  <Sparkles className="h-4 w-4 text-purple-600" />
                  <AlertDescription className="text-xs text-purple-800 dark:text-purple-200">
                    {spellSource === 'domain' && (
                      <><strong>Hechizo de Dominio:</strong> Este hechizo está siempre preparado y no cuenta para tu límite de hechizos preparados. No puede ser eliminado ni desmarcado.</>
                    )}
                    {spellSource === 'circle' && (
                      <><strong>Hechizo de Círculo:</strong> Este hechizo es otorgado por tu círculo druídico y no cuenta para tu límite de hechizos preparados. No puede ser eliminado ni desmarcado.</>
                    )}
                    {spellSource === 'oath' && (
                      <><strong>Hechizo de Juramento:</strong> Este hechizo es otorgado por tu juramento sagrado y no cuenta para tu límite de hechizos preparados. No puede ser eliminado ni desmarcado.</>
                    )}
                    {spellSource === 'ranger' && (
                      <><strong>Hechizo de Subclase:</strong> Este hechizo es otorgado por tu arquetipo de ranger y no cuenta para tu límite de hechizos preparados. No puede ser eliminado ni desmarcado.</>
                    )}
                    {spellSource === 'sorcerer' && (
                      <><strong>Hechizo de Linaje:</strong> Este hechizo es otorgado por tu linaje de hechicero y no cuenta para tu límite de hechizos preparados. No puede ser eliminado ni desmarcado.</>
                    )}
                    {spellSource === 'warlock' && (
                      <><strong>Hechizo de Patrón:</strong> Este hechizo es otorgado por tu patrón sobrenatural y no cuenta para tu límite de hechizos preparados. No puede ser eliminado ni desmarcado.</>
                    )}
                    {spellSource === 'species' && (
                      <><strong>Hechizo de Especie:</strong> Este hechizo es otorgado por tu especie y no cuenta para tu límite de hechizos preparados. No puede ser eliminado ni desmarcado.</>
                    )}
                    {spellSource === 'feat' && (
                      <><strong>Hechizo de Dote:</strong> Este hechizo es otorgado por un dote y no cuenta para tu límite de hechizos preparados. No puede ser eliminado ni desmarcado.</>
                    )}
                  </AlertDescription>
                </Alert>
              )}

              {/* Prepared Spell Button - Only for classes that prepare spells and known spells (not protected) */}
              {isKnown && !isProtectedSpell && spell.level > 0 && usesPreparedSpells && (
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium text-sm">Estado de Preparación</h4>
                    <p className="text-xs text-muted-foreground">
                      Hechizos preparados: {currentPrepared} / {maxPrepared}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      type="button"
                      variant={isPrepared ? "default" : "outline"}
                      size="sm"
                      onClick={(e) => {
                        e.preventDefault()
                        e.stopPropagation()
                        togglePrepared()
                      }}
                      className={isPrepared ? "bg-green-600 hover:bg-green-700" : ""}
                    >
                      {isPrepared ? (
                        <>
                          <Check className="h-4 w-4 mr-1" />
                          Preparado
                        </>
                      ) : (
                        <>
                          <Lock className="h-4 w-4 mr-1" />
                          Marcar como Preparado
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              )}

              {/* Alert if max prepared reached */}
              {isKnown && spell.level > 0 && usesPreparedSpells && !isPrepared && currentPrepared >= maxPrepared && (
                <Alert>
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="text-xs">
                    Has alcanzado el máximo de hechizos preparados. Desmarca otro hechizo para preparar este.
                  </AlertDescription>
                </Alert>
              )}

              {/* Info for classes that don't prepare spells */}
              {isKnown && spell.level > 0 && !usesPreparedSpells && spellcastingType !== 'none' && (
                <Alert>
                  <Info className="h-4 w-4" />
                  <AlertDescription className="text-xs">
                    Tu clase ({className}) no necesita preparar hechizos. Los hechizos conocidos siempre están disponibles para lanzar.
                  </AlertDescription>
                </Alert>
              )}

              {/* Remove spell button - Not for protected spells */}
              {isKnown && !isProtectedSpell && (
                <div className="flex justify-end pt-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={removeSpell}
                    className="text-red-500 hover:text-red-600 hover:bg-red-500/10"
                  >
                    <Trash2 className="h-4 w-4 mr-1" />
                    Eliminar de Conocidos
                  </Button>
                </div>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  // Item Detail Dialog
  const renderItemDetailDialog = () => {
    const invItem = itemDetailDialog.item
    if (!invItem) return null
    
    const isWeapon = !!invItem.weapon
    const isArmor = !!invItem.armor
    const isItem = !!invItem.item
    const isMagicItem = !!invItem.magicItem
    const itemData = invItem.weapon || invItem.armor || invItem.item || invItem.magicItem
    
    if (!itemData) return null
    
    // Calculate weapon stats
    let attackBonus = 0
    let damageBonus = 0
    let attackMod = ''
    
    if (isWeapon && invItem.weapon) {
      const weapon = invItem.weapon
      const isFinesse = weapon.properties?.includes('Finesse') || weapon.properties?.includes('Acrobacia')
      const isRanged = weapon.category?.includes('Ranged')
      const strMod = getModifier(selectedCharacter?.strength || 10)
      const dexMod = getModifier(selectedCharacter?.dexterity || 10)
      
      if (isRanged) {
        attackBonus = dexMod + (selectedCharacter?.proficiencyBonus || 2)
        attackMod = 'DES'
      } else if (isFinesse && dexMod > strMod) {
        attackBonus = dexMod + (selectedCharacter?.proficiencyBonus || 2)
        attackMod = 'DES'
      } else {
        attackBonus = strMod + (selectedCharacter?.proficiencyBonus || 2)
        attackMod = 'FUE'
      }
      damageBonus = isRanged ? dexMod : (isFinesse && dexMod > strMod ? dexMod : strMod)
    }
    
    return (
      <Dialog open={itemDetailDialog.open} onOpenChange={(open) => setItemDetailDialog({ open, item: itemDetailDialog.item })}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {isWeapon && <Sword className="h-5 w-5 text-red-400" />}
              {isArmor && <Shield className="h-5 w-5 text-blue-400" />}
              {isItem && <Package className="h-5 w-5 text-gray-400" />}
              {isMagicItem && <Sparkles className="h-5 w-5 text-purple-400" />}
              {itemData.name}
            </DialogTitle>
            <DialogDescription>
              {isWeapon && invItem.weapon && `${invItem.weapon.category} - ${invItem.weapon.damage} ${invItem.weapon.damageType}`}
              {isArmor && invItem.armor && `${invItem.armor.category}`}
              {isItem && invItem.item && `${invItem.item.category}`}
              {isMagicItem && invItem.magicItem && `${invItem.magicItem.rarity} - ${invItem.magicItem.type}`}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Quick Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm">
              <div className="p-2 bg-muted rounded">
                <div className="text-xs text-muted-foreground">Cantidad</div>
                <div className="font-medium">{invItem.quantity}</div>
              </div>
              <div className="p-2 bg-muted rounded">
                <div className="text-xs text-muted-foreground">Peso</div>
                <div className="font-medium">{itemData.weight} lb</div>
              </div>
              <div className="p-2 bg-orange-500/10 rounded border border-orange-500/20">
                <div className="text-xs text-muted-foreground">Coste</div>
                <div className="font-medium text-orange-400">
                  {isItem ? `${(itemData.cost / 100).toFixed(2)} GP` : `${itemData.cost || 0} GP`}
                </div>
              </div>
              <div className="p-2 bg-muted rounded">
                <div className="text-xs text-muted-foreground">Estado</div>
                <div className="font-medium flex gap-1">
                  {invItem.equipped && <Badge variant="secondary" className="text-xs">Equipado</Badge>}
                  {invItem.attuned && <Badge variant="default" className="text-xs">Sintonizado</Badge>}
                </div>
              </div>
            </div>
            
            {/* Weapon Specific Stats */}
            {isWeapon && invItem.weapon && (
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">Estadísticas de Combate</h4>
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-3 bg-green-500/10 rounded border border-green-500/20">
                    <div className="text-xs text-muted-foreground">Bonificador de Ataque</div>
                    <div className="text-xl font-bold text-green-400">
                      {attackBonus >= 0 ? '+' : ''}{attackBonus}
                    </div>
                    <div className="text-xs text-muted-foreground">({attackMod})</div>
                  </div>
                  <div className="p-3 bg-red-500/10 rounded border border-red-500/20">
                    <div className="text-xs text-muted-foreground">Daño</div>
                    <div className="text-xl font-bold text-red-400">
                      {invItem.weapon.damage}{damageBonus >= 0 ? '+' : ''}{damageBonus}
                    </div>
                    <div className="text-xs text-muted-foreground">{invItem.weapon.damageType}</div>
                  </div>
                </div>
                
                {/* Weapon Properties */}
                {invItem.weapon.properties && (
                  <div className="text-sm">
                    <strong>Propiedades:</strong> {invItem.weapon.properties}
                  </div>
                )}
                {invItem.weapon.mastery && (
                  <div className="text-sm">
                    <strong>Maestría:</strong> {invItem.weapon.mastery}
                  </div>
                )}
                {invItem.weapon.range && (
                  <div className="text-sm">
                    <strong>Alcance:</strong> {invItem.weapon.range}
                  </div>
                )}
              </div>
            )}
            
            {/* Armor Specific Stats */}
            {isArmor && invItem.armor && (
              <div className="space-y-2">
                <h4 className="font-semibold text-sm">Estadísticas de Armadura</h4>
                <div className="grid grid-cols-3 gap-2">
                  <div className="p-3 bg-blue-500/10 rounded border border-blue-500/20">
                    <div className="text-xs text-muted-foreground">CA Base</div>
                    <div className="text-xl font-bold text-blue-400">{invItem.armor.baseAC}</div>
                  </div>
                  <div className="p-3 bg-muted rounded">
                    <div className="text-xs text-muted-foreground">Bonif. DES</div>
                    <div className="text-sm font-medium">
                      {invItem.armor.dexBonus ? (invItem.armor.maxDexBonus ? `Máx +${invItem.armor.maxDexBonus}` : 'Sí') : 'No'}
                    </div>
                  </div>
                  <div className="p-3 bg-muted rounded">
                    <div className="text-xs text-muted-foreground">Fuerza Req.</div>
                    <div className="text-sm font-medium">{invItem.armor.strRequired || 'Ninguna'}</div>
                  </div>
                </div>
                
                {invItem.armor.stealthDisadv && (
                  <Badge variant="outline" className="text-orange-400 border-orange-400/30">
                    Desventaja en Sigilo
                  </Badge>
                )}
                
                <div className="text-sm">
                  <strong>Tiempo de colocación:</strong> {invItem.armor.donTime} min | 
                  <strong> Tiempo de retirada:</strong> {invItem.armor.doffTime} min
                </div>
              </div>
            )}
            
            {/* Item Description */}
            {(isItem || isMagicItem) && itemData.description && (
              <div className="text-sm">
                <strong>Descripción:</strong>
                <p className="text-muted-foreground mt-1">{itemData.description}</p>
              </div>
            )}
            
            {/* Magic Item Details */}
            {isMagicItem && invItem.magicItem && (
              <div className="space-y-2">
                {invItem.magicItem.attunement && (
                  <Badge variant="outline" className="text-purple-400 border-purple-400/30">
                    Requiere Sintonización
                  </Badge>
                )}
                {invItem.magicItem.attunementReq && (
                  <div className="text-sm text-muted-foreground">
                    Requisito: {invItem.magicItem.attunementReq}
                  </div>
                )}
                {invItem.magicItem.effects && (
                  <div className="text-sm">
                    <strong>Efectos:</strong> {invItem.magicItem.effects}
                  </div>
                )}
              </div>
            )}
            
            {/* Actions */}
            <div className="flex gap-2 pt-2">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => handleToggleEquip(invItem.id, invItem.equipped, invItem)}
              >
                {invItem.equipped ? 'Desequipar' : 'Equipar'}
              </Button>
              {isMagicItem && invItem.magicItem?.attunement && (
                <Button 
                  variant="outline" 
                  className="flex-1"
                  onClick={async () => {
                    await fetch(`/api/characters/${selectedCharacter?.id}/inventory`, {
                      method: 'PUT',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ itemId: invItem.id, attuned: !invItem.attuned })
                    })
                    fetchCharacterDetails(selectedCharacter?.id || '')
                    setItemDetailDialog({ open: false, item: null })
                  }}
                >
                  {invItem.attuned ? 'Romper Sintonía' : 'Sintonizar'}
                </Button>
              )}
              <Button 
                variant="destructive"
                onClick={() => {
                  handleDeleteInventoryItem(invItem.id)
                  setItemDetailDialog({ open: false, item: null })
                }}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  // Info Dialog
  const renderInfoDialog = () => (
    <Dialog open={infoDialog.open} onOpenChange={(open) => setInfoDialog({ ...infoDialog, open })}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>{infoDialog.title}</DialogTitle>
        </DialogHeader>
        <div 
          className="prose prose-sm dark:prose-invert"
          dangerouslySetInnerHTML={{ __html: infoDialog.content }}
        />
      </DialogContent>
    </Dialog>
  )

  // Note Dialog
  const renderNoteDialog = () => {
    const note = noteDialog.note
    if (!note) return null

    const colorOptions = [
      { value: 'default', label: 'Pergamino', class: 'bg-amber-50 border-amber-300 dark:bg-amber-950/30 dark:border-amber-700' },
      { value: 'red', label: 'Rojo', class: 'bg-red-50 border-red-300 dark:bg-red-950/30 dark:border-red-700' },
      { value: 'green', label: 'Verde', class: 'bg-green-50 border-green-300 dark:bg-green-950/30 dark:border-green-700' },
      { value: 'blue', label: 'Azul', class: 'bg-blue-50 border-blue-300 dark:bg-blue-950/30 dark:border-blue-700' },
      { value: 'yellow', label: 'Amarillo', class: 'bg-yellow-50 border-yellow-300 dark:bg-yellow-950/30 dark:border-yellow-700' },
      { value: 'purple', label: 'Púrpura', class: 'bg-purple-50 border-purple-300 dark:bg-purple-950/30 dark:border-purple-700' },
    ]

    return (
      <Dialog open={noteDialog.open} onOpenChange={(open) => setNoteDialog({ open, note: open ? note : null })}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Scroll className="h-5 w-5" />
              {note.title || 'Nueva Nota'}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            {/* Title */}
            <div>
              <Label htmlFor="note-title">Título</Label>
              <Input
                id="note-title"
                value={note.title}
                onChange={(e) => {
                  const updatedNote = { ...note, title: e.target.value }
                  setNoteDialog({ open: true, note: updatedNote })
                  handleDebouncedUpdateNote(note.id, { title: e.target.value })
                }}
                placeholder="Título de la nota..."
              />
            </div>
            
            {/* Content */}
            <div>
              <Label htmlFor="note-content">Contenido</Label>
              <Textarea
                id="note-content"
                value={note.content}
                onChange={(e) => {
                  const updatedNote = { ...note, content: e.target.value }
                  setNoteDialog({ open: true, note: updatedNote })
                  handleDebouncedUpdateNote(note.id, { content: e.target.value })
                }}
                placeholder="Escribe tu nota aquí..."
                className="min-h-[200px] resize-y"
              />
            </div>
            
            {/* Color Selection */}
            <div>
              <Label>Color</Label>
              <div className="flex gap-2 mt-2">
                {colorOptions.map((color) => (
                  <button
                    key={color.value}
                    className={`w-8 h-8 rounded-full border-2 transition-all ${
                      color.class
                    } ${note.color === color.value ? 'ring-2 ring-offset-2 ring-primary' : 'hover:scale-110'}`}
                    title={color.label}
                    onClick={() => {
                      const updatedNote = { ...note, color: color.value }
                      setNoteDialog({ open: true, note: updatedNote })
                      handleUpdateNote(note.id, { color: color.value })
                    }}
                  />
                ))}
              </div>
            </div>
            
            {/* Pin Toggle */}
            <div className="flex items-center justify-between">
              <Label htmlFor="note-pin" className="flex items-center gap-2">
                <Star className={`h-4 w-4 ${note.pinned ? 'text-amber-500 fill-amber-500' : ''}`} />
                Fijar nota
              </Label>
              <Switch
                id="note-pin"
                checked={note.pinned}
                onCheckedChange={(checked) => {
                  const updatedNote = { ...note, pinned: checked }
                  setNoteDialog({ open: true, note: updatedNote })
                  handleUpdateNote(note.id, { pinned: checked })
                }}
              />
            </div>
            
            {/* Timestamps */}
            <div className="text-xs text-muted-foreground flex justify-between pt-2 border-t">
              <span>Creada: {new Date(note.createdAt).toLocaleString()}</span>
              <span>Actualizada: {new Date(note.updatedAt).toLocaleString()}</span>
            </div>
            
            {/* Actions */}
            <div className="flex gap-2 pt-2">
              <Button 
                variant="destructive" 
                className="flex-1"
                onClick={() => handleDeleteNote(note.id)}
              >
                <Trash2 className="h-4 w-4 mr-1" /> Eliminar
              </Button>
              <Button 
                className="flex-1"
                onClick={() => setNoteDialog({ open: false, note: null })}
              >
                Cerrar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  // Grimorio Dialog - View all spells without restrictions (read-only)
  const renderGrimorioDialog = () => {
    // Get known spell IDs for highlighting
    const knownSpellIds = new Set(selectedCharacter?.characterSpells?.map((cs: any) => cs.spellId) || [])

    // Filter spells (no class restrictions - show ALL spells)
    const filteredSpells = spells.filter(s => {
      // Search filter
      if (grimorioSearchTerm) {
        const searchLower = grimorioSearchTerm.toLowerCase()
        const nameMatch = s.name.toLowerCase().includes(searchLower)
        const schoolMatch = s.school.toLowerCase().includes(searchLower)
        const descMatch = s.description.toLowerCase().includes(searchLower)
        if (!nameMatch && !schoolMatch && !descMatch) return false
      }
      // Level filter
      if (spellLevelFilter !== 'all' && s.level !== parseInt(spellLevelFilter)) return false
      // School filter
      if (spellSchoolFilter !== 'all' && s.school !== spellSchoolFilter) return false
      return true
    })

    // Get unique schools for filter
    const schools = [...new Set(spells.map(s => s.school))].sort()

    return (
      <Dialog open={grimorioDialog} onOpenChange={setGrimorioDialog}>
        <DialogContent className="max-w-5xl h-[85vh] flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5" />
              Grimorio
              <Badge variant="secondary" className="text-xs ml-2">Solo Lectura</Badge>
            </DialogTitle>
            <DialogDescription>
              Catálogo completo de hechizos de D&D 2024. Los hechizos marcados son los que conoces.
            </DialogDescription>
          </DialogHeader>

          {/* Filters */}
          <div className="flex-shrink-0 flex gap-4 flex-wrap">
            {/* Search */}
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar hechizo..."
                value={grimorioSearchTerm}
                onChange={(e) => setGrimorioSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>

            <Select value={spellLevelFilter} onValueChange={setSpellLevelFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Nivel" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los Niveles</SelectItem>
                <SelectItem value="0">Trucos</SelectItem>
                {[1,2,3,4,5,6,7,8,9].map(l => (
                  <SelectItem key={l} value={l.toString()}>Nivel {l}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={spellSchoolFilter} onValueChange={setSpellSchoolFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Escuela" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las Escuelas</SelectItem>
                {schools.map(s => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <div className="flex items-center text-muted-foreground text-sm">
              {filteredSpells.length} hechizos
            </div>
          </div>

          {/* Spells Grid */}
          <div className="flex-1 min-h-0">
            <ScrollArea className="h-full">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2 pr-4">
                {filteredSpells.map((spell) => {
                  const isKnown = knownSpellIds.has(spell.id)
                  const characterSpell = selectedCharacter?.characterSpells?.find((cs: any) => cs.spellId === spell.id)

                  return (
                    <Card
                      key={spell.id}
                      className={`p-3 cursor-pointer hover:bg-muted/50 ${isKnown ? 'border-primary/50 bg-primary/5' : ''}`}
                      onClick={() => setSpellDetailDialog({ open: true, spell })}
                    >
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <div className={`p-1 rounded ${getSchoolColor(spell.school)}`}>
                              {getSchoolIcon(spell.school)}
                            </div>
                            <div>
                              <div className="font-medium flex items-center gap-2">
                                {spell.name}
                                {isKnown && (
                                  <Badge variant="default" className="text-xs">Conocido</Badge>
                                )}
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {spell.level === 0 ? 'Truco' : `Nivel ${spell.level}`} | {spell.school}
                              </div>
                            </div>
                          </div>
                          <div className="text-xs text-muted-foreground mt-1 ml-7">
                            {spell.castingTime} | {spell.range}
                            {spell.concentration && ' | C'} {spell.ritual && ' | R'}
                          </div>
                          <div className="text-xs text-muted-foreground mt-1 ml-7">
                            Clases: {typeof spell.classes === 'string' ? JSON.parse(spell.classes).join(', ') : spell.classes.join(', ')}
                          </div>
                        </div>

                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation()
                            setSpellDetailDialog({ open: true, spell })
                          }}
                        >
                          <Eye className="h-4 w-4" />
                        </Button>
                      </div>
                    </Card>
                  )
                })}
              </div>
            </ScrollArea>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  // Shop Dialog - View all items with prices
  const renderShopDialog = () => {
    // Combine all items from the database with full data for detail view
    const allShopItems = [
      // Weapons
      ...weapons.map(w => ({
        id: `weapon-${w.id}`,
        name: w.name,
        category: 'weapon',
        subcategory: w.category,
        cost: w.cost,
        weight: w.weight,
        description: `${w.damage} ${w.damageType} damage`,
        extra: w.properties,
        // Full weapon data for detail view
        rawData: w,
        damage: w.damage,
        damageType: w.damageType,
        properties: w.properties,
        range: w.range,
        weaponCategory: w.category
      })),
      // Armor
      ...armor.map(a => ({
        id: `armor-${a.id}`,
        name: a.name,
        category: 'armor',
        subcategory: a.category,
        cost: a.cost,
        weight: a.weight,
        description: `AC ${a.baseAC}${a.dexBonus ? ' + Dex' : ''}${a.maxDexBonus ? ` (max ${a.maxDexBonus})` : ''}`,
        extra: a.stealthDisadv ? 'Desventaja en sigilo' : '',
        // Full armor data for detail view
        rawData: a,
        baseAC: a.baseAC,
        dexBonus: a.dexBonus,
        maxDexBonus: a.maxDexBonus,
        stealthDisadv: a.stealthDisadv,
        strengthReq: a.strengthReq,
        armorCategory: a.category
      })),
      // Items
      ...items.map(i => ({
        id: `item-${i.id}`,
        name: i.name,
        category: 'item',
        subcategory: i.subcategory || i.category,
        cost: i.cost,
        weight: i.weight,
        description: i.description || '',
        extra: '',
        // Full item data for detail view
        rawData: i,
        itemCategory: i.category,
        itemSubcategory: i.subcategory
      })),
      // Magic Items
      ...magicItems.map(m => ({
        id: `magic-${m.id}`,
        name: m.name,
        category: 'magic',
        subcategory: m.rarity,
        cost: m.cost || 0,
        weight: m.weight || 0,
        description: m.description,
        extra: m.type,
        // Full magic item data for detail view
        rawData: m,
        rarity: m.rarity,
        type: m.type,
        requiresAttunement: m.requiresAttunement,
        attunementNotes: m.attunementNotes
      }))
    ]

    // Filter by search term and category
    const filteredItems = allShopItems.filter(item => {
      if (shopSearchTerm) {
        const searchLower = shopSearchTerm.toLowerCase()
        if (!item.name.toLowerCase().includes(searchLower) &&
            !item.description.toLowerCase().includes(searchLower) &&
            !item.subcategory.toLowerCase().includes(searchLower)) {
          return false
        }
      }
      if (shopCategoryFilter !== 'all' && item.category !== shopCategoryFilter) return false
      return true
    })

    // Sort by cost (gp)
    const sortedItems = [...filteredItems].sort((a, b) => a.cost - b.cost)

    // Format cost - database stores values in gp (gold pieces)
    // D&D currency: 1 pp = 10 gp, 1 gp = 10 sp, 1 sp = 10 cp (1 gp = 100 cp)
    const formatCost = (costInGp: number): string => {
      if (costInGp === 0) return '0 gp'
      if (costInGp >= 10) {
        // Show in platinum for 10+ gp (1 pp = 10 gp)
        const pp = costInGp / 10
        return `${Number.isInteger(pp) ? pp : pp.toFixed(1)} pp`
      } else if (costInGp >= 1) {
        return `${Number.isInteger(costInGp) ? costInGp : costInGp.toFixed(1)} gp`
      } else if (costInGp >= 0.1) {
        return `${Math.round(costInGp * 10)} sp`
      } else {
        return `${Math.round(costInGp * 100)} cp`
      }
    }

    // Category icons and colors
    const getCategoryIcon = (category: string) => {
      switch (category) {
        case 'weapon': return <Sword className="h-4 w-4" />
        case 'armor': return <Shield className="h-4 w-4" />
        case 'item': return <Package className="h-4 w-4" />
        case 'magic': return <Sparkles className="h-4 w-4" />
        default: return <Package className="h-4 w-4" />
      }
    }

    const getCategoryColor = (category: string) => {
      switch (category) {
        case 'weapon': return 'bg-red-500/20 text-gray-900 border-red-500/30'
        case 'armor': return 'bg-blue-500/20 text-gray-900 border-blue-500/30'
        case 'item': return 'bg-amber-500/20 text-gray-900 border-amber-500/30'
        case 'magic': return 'bg-purple-500/20 text-gray-900 border-purple-500/30'
        default: return 'bg-muted text-gray-900'
      }
    }

    const getRarityColor = (rarity: string) => {
      switch (rarity?.toLowerCase()) {
        case 'common': return 'text-gray-500'
        case 'uncommon': return 'text-green-500'
        case 'rare': return 'text-blue-500'
        case 'very rare': return 'text-purple-500'
        case 'legendary': return 'text-orange-500'
        case 'artifact': return 'text-red-500'
        default: return 'text-gray-500'
      }
    }

    return (
      <Dialog open={shopDialog} onOpenChange={setShopDialog}>
        <DialogContent className="max-w-5xl h-[85vh] flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="flex items-center gap-2">
              <ShoppingBag className="h-5 w-5" />
              Tienda
              <Badge variant="secondary" className="text-xs ml-2">Catálogo</Badge>
            </DialogTitle>
            <DialogDescription>
              Catálogo completo de armas, armaduras, objetos y objetos mágicos de D&D 2024.
            </DialogDescription>
          </DialogHeader>

          {/* Filters */}
          <div className="flex-shrink-0 flex gap-4 flex-wrap">
            {/* Search */}
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar objeto..."
                value={shopSearchTerm}
                onChange={(e) => setShopSearchTerm(e.target.value)}
                className="pl-9"
              />
            </div>

            <Select value={shopCategoryFilter} onValueChange={setShopCategoryFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Categoría" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas</SelectItem>
                <SelectItem value="weapon">Armas</SelectItem>
                <SelectItem value="armor">Armaduras</SelectItem>
                <SelectItem value="item">Objetos</SelectItem>
                <SelectItem value="magic">Objetos Mágicos</SelectItem>
              </SelectContent>
            </Select>

            <div className="flex items-center text-muted-foreground text-sm">
              {filteredItems.length} objetos
            </div>
          </div>

          {/* Items Grid - Single Column */}
          <div className="flex-1 min-h-0">
            <ScrollArea className="h-full">
              <div className="grid grid-cols-1 gap-2 pr-4">
                {sortedItems.map((item) => (
                  <Card
                    key={item.id}
                    className="p-3 cursor-pointer hover:bg-muted/50 transition-colors"
                    onClick={() => setShopItemDetailDialog({ open: true, item })}
                  >
                    <div className="flex justify-between items-start gap-2">
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <div className={`p-1 rounded ${getCategoryColor(item.category)}`}>
                            {getCategoryIcon(item.category)}
                          </div>
                          <div className="flex-1">
                            <div className="font-medium text-sm flex items-center gap-2">
                              {item.name}
                              {item.category === 'magic' && (
                                <span className={`text-xs ${getRarityColor(item.subcategory)}`}>
                                  ({item.subcategory})
                                </span>
                              )}
                            </div>
                            <div className="text-xs text-muted-foreground">
                              {item.subcategory}
                              {item.extra && ` | ${item.extra}`}
                            </div>
                          </div>
                        </div>
                        {item.description && (
                          <p className="text-xs text-muted-foreground mt-1 ml-7 line-clamp-2">
                            {item.description}
                          </p>
                        )}
                        <div className="text-xs text-muted-foreground mt-1 ml-7">
                          Peso: {item.weight} lb
                        </div>
                      </div>

                      {/* Price */}
                      <div className="flex items-center gap-1 bg-yellow-500/10 px-2 py-1 rounded border border-yellow-500/30">
                        <Coins className="h-4 w-4 text-yellow-600" />
                        <span className="font-bold text-sm text-yellow-700">
                          {formatCost(item.cost)}
                        </span>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  // Shop Item Detail Dialog - Show full item information
  const renderShopItemDetailDialog = () => {
    const item = shopItemDetailDialog.item
    if (!item) return null

    // Format cost - database stores values in gp (gold pieces)
    // D&D currency: 1 pp = 10 gp, 1 gp = 10 sp, 1 sp = 10 cp (1 gp = 100 cp)
    const formatCost = (costInGp: number): string => {
      if (costInGp === 0) return '0 gp'
      if (costInGp >= 10) {
        // Show in platinum for 10+ gp (1 pp = 10 gp)
        const pp = costInGp / 10
        return `${Number.isInteger(pp) ? pp : pp.toFixed(1)} pp`
      } else if (costInGp >= 1) {
        return `${Number.isInteger(costInGp) ? costInGp : costInGp.toFixed(1)} gp`
      } else if (costInGp >= 0.1) {
        return `${Math.round(costInGp * 10)} sp`
      } else {
        return `${Math.round(costInGp * 100)} cp`
      }
    }

    // Category icons and colors
    const getCategoryIcon = (category: string) => {
      switch (category) {
        case 'weapon': return <Sword className="h-5 w-5" />
        case 'armor': return <Shield className="h-5 w-5" />
        case 'item': return <Package className="h-5 w-5" />
        case 'magic': return <Sparkles className="h-5 w-5" />
        default: return <Package className="h-5 w-5" />
      }
    }

    const getCategoryColor = (category: string) => {
      switch (category) {
        case 'weapon': return 'bg-red-500/20 text-red-700 border-red-500/30'
        case 'armor': return 'bg-blue-500/20 text-blue-700 border-blue-500/30'
        case 'item': return 'bg-amber-500/20 text-amber-700 border-amber-500/30'
        case 'magic': return 'bg-purple-500/20 text-purple-700 border-purple-500/30'
        default: return 'bg-muted'
      }
    }

    const getRarityColor = (rarity: string) => {
      switch (rarity?.toLowerCase()) {
        case 'common': return 'text-gray-500'
        case 'uncommon': return 'text-green-500'
        case 'rare': return 'text-blue-500'
        case 'very rare': return 'text-purple-500'
        case 'legendary': return 'text-orange-500'
        case 'artifact': return 'text-red-500'
        default: return 'text-gray-500'
      }
    }

    const getRarityBg = (rarity: string) => {
      switch (rarity?.toLowerCase()) {
        case 'common': return 'bg-gray-500/10 border-gray-500/30'
        case 'uncommon': return 'bg-green-500/10 border-green-500/30'
        case 'rare': return 'bg-blue-500/10 border-blue-500/30'
        case 'very rare': return 'bg-purple-500/10 border-purple-500/30'
        case 'legendary': return 'bg-orange-500/10 border-orange-500/30'
        case 'artifact': return 'bg-red-500/10 border-red-500/30'
        default: return 'bg-muted'
      }
    }

    return (
      <Dialog open={shopItemDetailDialog.open} onOpenChange={(open) => setShopItemDetailDialog({ open, item: open ? item : null })}>
        <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <div className={`p-2 rounded ${getCategoryColor(item.category)}`}>
                {getCategoryIcon(item.category)}
              </div>
              {item.name}
              {item.category === 'magic' && (
                <Badge className={`ml-2 ${getRarityBg(item.rarity)} ${getRarityColor(item.rarity)} border`}>
                  {item.rarity}
                </Badge>
              )}
            </DialogTitle>
            <DialogDescription>
              {item.category === 'weapon' && `Arma ${item.weaponCategory || ''}`}
              {item.category === 'armor' && `Armadura - ${item.armorCategory || ''}`}
              {item.category === 'item' && `Objeto${item.itemSubcategory ? ` - ${item.itemSubcategory}` : ''}`}
              {item.category === 'magic' && `Objeto Mágico - ${item.type || ''}`}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            {/* Price and Weight */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-3 bg-yellow-500/10 rounded-lg border border-yellow-500/30">
                <div className="text-xs text-muted-foreground">Precio</div>
                <div className="text-xl font-bold text-yellow-700 flex items-center gap-2">
                  <Coins className="h-5 w-5" />
                  {formatCost(item.cost)}
                </div>
              </div>
              <div className="p-3 bg-muted rounded-lg">
                <div className="text-xs text-muted-foreground">Peso</div>
                <div className="text-xl font-bold">{item.weight} lb</div>
              </div>
            </div>

            {/* Weapon Specific Info */}
            {item.category === 'weapon' && (
              <div className="space-y-3">
                <h4 className="font-semibold flex items-center gap-2">
                  <Sword className="h-4 w-4 text-red-500" />
                  Estadísticas de Arma
                </h4>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  <div className="p-2 bg-muted rounded">
                    <div className="text-xs text-muted-foreground">Categoría</div>
                    <div className="font-medium">{item.weaponCategory || '-'}</div>
                  </div>
                  <div className="p-2 bg-red-500/10 rounded border border-red-500/20">
                    <div className="text-xs text-muted-foreground">Daño</div>
                    <div className="font-bold text-red-600">{item.damage || '-'}</div>
                  </div>
                  <div className="p-2 bg-muted rounded">
                    <div className="text-xs text-muted-foreground">Tipo de Daño</div>
                    <div className="font-medium">{item.damageType || '-'}</div>
                  </div>
                  <div className="p-2 bg-muted rounded">
                    <div className="text-xs text-muted-foreground">Alcance</div>
                    <div className="font-medium">{item.range || '-'}</div>
                  </div>
                  <div className="p-2 bg-muted rounded col-span-2">
                    <div className="text-xs text-muted-foreground">Propiedades</div>
                    <div className="font-medium text-sm">{item.properties || 'Ninguna'}</div>
                  </div>
                </div>
              </div>
            )}

            {/* Armor Specific Info */}
            {item.category === 'armor' && (
              <div className="space-y-3">
                <h4 className="font-semibold flex items-center gap-2">
                  <Shield className="h-4 w-4 text-blue-500" />
                  Estadísticas de Armadura
                </h4>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  <div className="p-2 bg-muted rounded">
                    <div className="text-xs text-muted-foreground">Categoría</div>
                    <div className="font-medium">{item.armorCategory || '-'}</div>
                  </div>
                  <div className="p-2 bg-blue-500/10 rounded border border-blue-500/20">
                    <div className="text-xs text-muted-foreground">CA Base</div>
                    <div className="font-bold text-blue-600">{item.baseAC || '-'}</div>
                  </div>
                  <div className="p-2 bg-muted rounded">
                    <div className="text-xs text-muted-foreground">Bonus DES</div>
                    <div className="font-medium">{item.dexBonus ? 'Sí' : 'No'}</div>
                  </div>
                  <div className="p-2 bg-muted rounded">
                    <div className="text-xs text-muted-foreground">Máx. Bonus DES</div>
                    <div className="font-medium">{item.maxDexBonus || '-'}</div>
                  </div>
                  <div className="p-2 bg-muted rounded">
                    <div className="text-xs text-muted-foreground">Fuerza Req.</div>
                    <div className="font-medium">{item.strengthReq || '-'}</div>
                  </div>
                  <div className="p-2 bg-amber-500/10 rounded border border-amber-500/20">
                    <div className="text-xs text-muted-foreground">Sigilo</div>
                    <div className="font-medium">{item.stealthDisadv ? '⚠️ Desventaja' : 'Normal'}</div>
                  </div>
                </div>
              </div>
            )}

            {/* Item Specific Info */}
            {item.category === 'item' && (
              <div className="space-y-3">
                <h4 className="font-semibold flex items-center gap-2">
                  <Package className="h-4 w-4 text-amber-500" />
                  Detalles del Objeto
                </h4>
                <div className="grid grid-cols-2 gap-2">
                  <div className="p-2 bg-muted rounded">
                    <div className="text-xs text-muted-foreground">Categoría</div>
                    <div className="font-medium">{item.itemCategory || '-'}</div>
                  </div>
                  <div className="p-2 bg-muted rounded">
                    <div className="text-xs text-muted-foreground">Subcategoría</div>
                    <div className="font-medium">{item.itemSubcategory || '-'}</div>
                  </div>
                </div>
              </div>
            )}

            {/* Magic Item Specific Info */}
            {item.category === 'magic' && (
              <div className="space-y-3">
                <h4 className="font-semibold flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-purple-500" />
                  Detalles del Objeto Mágico
                </h4>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  <div className={`p-2 rounded border ${getRarityBg(item.rarity)}`}>
                    <div className="text-xs text-muted-foreground">Rareza</div>
                    <div className={`font-bold ${getRarityColor(item.rarity)}`}>{item.rarity || '-'}</div>
                  </div>
                  <div className="p-2 bg-muted rounded">
                    <div className="text-xs text-muted-foreground">Tipo</div>
                    <div className="font-medium">{item.type || '-'}</div>
                  </div>
                  <div className="p-2 bg-muted rounded">
                    <div className="text-xs text-muted-foreground">Sintonización</div>
                    <div className="font-medium">
                      {item.requiresAttunement ? (
                        <span className="text-purple-600">Requerida</span>
                      ) : (
                        'No requerida'
                      )}
                    </div>
                  </div>
                  {item.attunementNotes && (
                    <div className="p-2 bg-purple-500/10 rounded border border-purple-500/20 col-span-2 md:col-span-3">
                      <div className="text-xs text-muted-foreground">Notas de Sintonización</div>
                      <div className="font-medium text-sm">{item.attunementNotes}</div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Description */}
            {item.description && (
              <div className="space-y-2">
                <h4 className="font-semibold">Descripción</h4>
                <div className="p-3 bg-muted/50 rounded-lg text-sm prose prose-sm dark:prose-invert max-w-none">
                  {item.description}
                </div>
              </div>
            )}

            {/* Close Button */}
            <div className="flex justify-end pt-2">
              <Button onClick={() => setShopItemDetailDialog({ open: false, item: null })}>
                Cerrar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  // Encyclopedia Dialog - View all game data (classes, species, backgrounds, feats)
  const renderEncyclopediaDialog = () => {
    // Get icons for each category
    const getCategoryIcon = (category: string) => {
      switch (category) {
        case 'classes': return <Sword className="h-5 w-5" />
        case 'species': return <Users className="h-5 w-5" />
        case 'backgrounds': return <Scroll className="h-5 w-5" />
        case 'feats': return <Award className="h-5 w-5" />
        default: return <BookOpen className="h-5 w-5" />
      }
    }

    const getCategoryColor = (category: string) => {
      switch (category) {
        case 'classes': return 'from-red-500/20 to-red-600/10 border-red-500/30'
        case 'species': return 'from-emerald-500/20 to-emerald-600/10 border-emerald-500/30'
        case 'backgrounds': return 'from-amber-500/20 to-amber-600/10 border-amber-500/30'
        case 'feats': return 'from-purple-500/20 to-purple-600/10 border-purple-500/30'
        default: return 'from-muted to-muted/50'
      }
    }

    // Filter items based on search
    const filterItems = (items: any[], searchTerm: string) => {
      if (!searchTerm) return items
      const term = searchTerm.toLowerCase()
      return items.filter(item =>
        item.name?.toLowerCase().includes(term) ||
        item.description?.toLowerCase().includes(term)
      )
    }

    // Get items for current category
    const getCurrentItems = () => {
      switch (encyclopediaCategory) {
        case 'classes':
          return filterItems(classes, encyclopediaSearchTerm)
        case 'species':
          return filterItems(species, encyclopediaSearchTerm)
        case 'backgrounds':
          return filterItems(backgrounds, encyclopediaSearchTerm)
        case 'feats':
          return filterItems(allFeats, encyclopediaSearchTerm)
        default:
          return []
      }
    }

    const currentItems = getCurrentItems()

    return (
      <Dialog open={encyclopediaDialog} onOpenChange={setEncyclopediaDialog}>
        <DialogContent className="max-w-5xl h-[90vh] flex flex-col">
          <DialogHeader className="flex-shrink-0">
            <DialogTitle className="flex items-center gap-3 text-2xl">
              <div className="p-2 rounded-lg bg-gradient-to-br from-primary/20 to-primary/10">
                <Library className="h-6 w-6" />
              </div>
              Enciclopedia D&D 2024
            </DialogTitle>
            <DialogDescription className="text-base">
              Consulta toda la información de clases, especies, trasfondos y dotes.
            </DialogDescription>
          </DialogHeader>

          {/* Category Tabs */}
          <div className="flex-shrink-0 flex gap-3 flex-wrap items-center">
            <div className="flex gap-2 bg-muted p-1.5 rounded-xl">
              {(['classes', 'species', 'backgrounds', 'feats'] as const).map((cat) => (
                <Button
                  key={cat}
                  variant={encyclopediaCategory === cat ? 'default' : 'ghost'}
                  size="sm"
                  onClick={() => {
                    setEncyclopediaCategory(cat)
                    setEncyclopediaSearchTerm('')
                  }}
                  className={`gap-2 px-4 ${encyclopediaCategory === cat ? 'shadow-md' : ''}`}
                >
                  {getCategoryIcon(cat)}
                  <span className="hidden sm:inline">
                    {cat === 'classes' && 'Clases'}
                    {cat === 'species' && 'Especies'}
                    {cat === 'backgrounds' && 'Trasfondos'}
                    {cat === 'feats' && 'Dotes'}
                  </span>
                </Button>
              ))}
            </div>

            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar en la enciclopedia..."
                value={encyclopediaSearchTerm}
                onChange={(e) => setEncyclopediaSearchTerm(e.target.value)}
                className="pl-10 h-10"
              />
            </div>

            <Badge variant="secondary" className="text-sm px-3 py-1">
              {currentItems.length} elementos
            </Badge>
          </div>

          {/* Items List */}
          <div className="flex-1 min-h-0">
            <ScrollArea className="h-full">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pr-4 pb-2">
                {currentItems.map((item: any) => (
                  <Card
                    key={item.id}
                    className={`p-4 cursor-pointer hover:shadow-lg transition-all duration-200 border bg-gradient-to-br ${getCategoryColor(encyclopediaCategory)} hover:scale-[1.01]`}
                    onClick={() => setEncyclopediaDetailItem({ open: true, item, type: encyclopediaCategory })}
                  >
                    <div className="flex justify-between items-start gap-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-3">
                          <div className="p-2 rounded-lg bg-white/50 dark:bg-black/20">
                            {getCategoryIcon(encyclopediaCategory)}
                          </div>
                          <div className="flex-1">
                            <div className="font-bold text-lg">{item.name}</div>
                            <div className="text-sm text-muted-foreground mt-0.5">
                              {encyclopediaCategory === 'classes' && (
                                <span className="flex items-center gap-2">
                                  <Badge variant="outline" className="text-xs">d{item.hitDie} PG</Badge>
                                  <span className="text-xs">{item.primaryAbility}</span>
                                </span>
                              )}
                              {encyclopediaCategory === 'species' && (
                                <span className="flex items-center gap-2">
                                  <Badge variant="outline" className="text-xs">{item.size}</Badge>
                                  <span className="text-xs">{item.speed} ft</span>
                                </span>
                              )}
                              {encyclopediaCategory === 'backgrounds' && (
                                <span className="text-xs">Dote: {item.feat || 'N/A'}</span>
                              )}
                              {encyclopediaCategory === 'feats' && (
                                <span className="flex items-center gap-2">
                                  <Badge variant="outline" className="text-xs">{item.category || 'General'}</Badge>
                                  {item.repeatable && <Badge variant="secondary" className="text-xs">Repetible</Badge>}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                        {item.description && (
                          <p className="text-xs text-muted-foreground mt-2 line-clamp-2 ml-11">
                            {item.description}
                          </p>
                        )}
                      </div>
                      <div className="p-2 rounded-full bg-white/30 dark:bg-black/20">
                        <Eye className="h-4 w-4 text-muted-foreground" />
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </ScrollArea>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  // Encyclopedia Detail Dialog - Show full information for selected item
  const renderEncyclopediaDetailDialog = () => {
    const item = encyclopediaDetailItem.item
    const type = encyclopediaDetailItem.type
    if (!item) return null

    // Helper to parse JSON fields
    const parseJson = (jsonStr: string | null | undefined) => {
      if (!jsonStr) return null
      try {
        return JSON.parse(jsonStr)
      } catch {
        return null
      }
    }

    const getTypeIcon = () => {
      switch (type) {
        case 'classes': return <Sword className="h-6 w-6" />
        case 'species': return <Users className="h-6 w-6" />
        case 'backgrounds': return <Scroll className="h-6 w-6" />
        case 'feats': return <Award className="h-6 w-6" />
        default: return <BookOpen className="h-6 w-6" />
      }
    }

    const getTypeColor = () => {
      switch (type) {
        case 'classes': return 'bg-gradient-to-r from-red-500/20 to-red-600/10 border-red-500/30'
        case 'species': return 'bg-gradient-to-r from-emerald-500/20 to-emerald-600/10 border-emerald-500/30'
        case 'backgrounds': return 'bg-gradient-to-r from-amber-500/20 to-amber-600/10 border-amber-500/30'
        case 'feats': return 'bg-gradient-to-r from-purple-500/20 to-purple-600/10 border-purple-500/30'
        default: return 'bg-muted'
      }
    }

    return (
      <Dialog open={encyclopediaDetailItem.open} onOpenChange={(open) => setEncyclopediaDetailItem({ open, item: open ? item : null, type })}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <div className={`inline-flex items-center gap-3 p-3 rounded-xl mb-2 ${getTypeColor()} border`}>
              {getTypeIcon()}
              <div>
                <DialogTitle className="text-2xl">{item.name}</DialogTitle>
                <DialogDescription className="text-sm mt-1">
                  {type === 'classes' && `Clase • Dado de Golpe d${item.hitDie}`}
                  {type === 'species' && `Especie • ${item.size} • ${item.speed} ft velocidad`}
                  {type === 'backgrounds' && 'Trasfondo'}
                  {type === 'feats' && `Dote • ${item.category || 'General'}`}
                </DialogDescription>
              </div>
            </div>
          </DialogHeader>

          <div className="space-y-6 mt-4">
            {/* Description */}
            {item.description && (
              <div className="p-4 bg-muted/30 rounded-xl border text-sm leading-relaxed">
                {item.description}
              </div>
            )}

            {/* CLASS SPECIFIC INFO */}
            {type === 'classes' && (
              <>
                {/* Primary Stats Grid */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="p-4 bg-gradient-to-br from-red-500/10 to-red-600/5 rounded-xl border border-red-500/20 text-center">
                    <Heart className="h-5 w-5 mx-auto text-red-500 mb-1" />
                    <div className="text-xs text-muted-foreground">Dado de Golpe</div>
                    <div className="text-2xl font-bold text-red-600">d{item.hitDie}</div>
                  </div>
                  <div className="p-4 bg-gradient-to-br from-blue-500/10 to-blue-600/5 rounded-xl border border-blue-500/20 text-center">
                    <Brain className="h-5 w-5 mx-auto text-blue-500 mb-1" />
                    <div className="text-xs text-muted-foreground">Habilidad Primaria</div>
                    <div className="text-lg font-bold">{item.primaryAbility || '-'}</div>
                  </div>
                  <div className="p-4 bg-gradient-to-br from-amber-500/10 to-amber-600/5 rounded-xl border border-amber-500/20 text-center">
                    <Shield className="h-5 w-5 mx-auto text-amber-500 mb-1" />
                    <div className="text-xs text-muted-foreground mb-1">Salvaciones</div>
                    <div className="text-sm font-medium">
                      {(() => {
                        const saves = parseJson(item.savingThrows)
                        return saves ? saves.join(', ') : item.savingThrows || '-'
                      })()}
                    </div>
                  </div>
                  <div className="p-4 bg-gradient-to-br from-emerald-500/10 to-emerald-600/5 rounded-xl border border-emerald-500/20 text-center">
                    <Award className="h-5 w-5 mx-auto text-emerald-500 mb-1" />
                    <div className="text-xs text-muted-foreground mb-1">Habilidades</div>
                    <div className="text-xs font-medium">
                      {(() => {
                        const skills = parseJson(item.skillProficiencies)
                        return skills ? skills.join(', ') : item.skillProficiencies || '-'
                      })()}
                    </div>
                  </div>
                </div>

                {/* Proficiencies Section */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-muted/30 rounded-xl border">
                    <div className="flex items-center gap-2 font-semibold mb-2">
                      <Shield className="h-4 w-4 text-blue-500" />
                      Armaduras
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {(() => {
                        const armor = parseJson(item.armorTraining)
                        return armor && armor.length > 0 ? armor.join(', ') : 'Sin competencia'
                      })()}
                    </p>
                  </div>
                  <div className="p-4 bg-muted/30 rounded-xl border">
                    <div className="flex items-center gap-2 font-semibold mb-2">
                      <Sword className="h-4 w-4 text-red-500" />
                      Armas
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {(() => {
                        const weapons = parseJson(item.weaponProficiencies)
                        return weapons && weapons.length > 0 ? weapons.join(', ') : 'Sin competencia'
                      })()}
                    </p>
                  </div>
                </div>

                {/* Starting Equipment */}
                {item.startingEquipment && (
                  <div className="space-y-3">
                    <h4 className="font-bold text-lg flex items-center gap-2">
                      <Package className="h-5 w-5 text-amber-500" />
                      Equipamiento Inicial
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {(() => {
                        const equipment = parseJson(item.startingEquipment)
                        if (!equipment) return <div className="text-muted-foreground">No disponible</div>
                        return (
                          <>
                            <div className="p-4 bg-gradient-to-br from-amber-500/10 to-amber-600/5 rounded-xl border border-amber-500/20">
                              <Badge className="mb-3 bg-amber-500/20 text-amber-700 dark:text-amber-300 border-amber-500/30">Opción A</Badge>
                              <ul className="text-sm space-y-1.5">
                                {equipment.A?.items?.map((i: string, idx: number) => (
                                  <li key={idx} className="flex items-start gap-2">
                                    <span className="text-amber-500 mt-0.5">•</span>
                                    {i}
                                  </li>
                                ))}
                              </ul>
                              {equipment.A?.gold > 0 && (
                                <div className="mt-3 pt-2 border-t border-amber-500/20 text-amber-600 font-medium flex items-center gap-1">
                                  <Coins className="h-4 w-4" /> {equipment.A.gold} gp
                                </div>
                              )}
                            </div>
                            <div className="p-4 bg-gradient-to-br from-emerald-500/10 to-emerald-600/5 rounded-xl border border-emerald-500/20">
                              <Badge className="mb-3 bg-emerald-500/20 text-emerald-700 dark:text-emerald-300 border-emerald-500/30">Opción B</Badge>
                              <ul className="text-sm space-y-1.5">
                                {equipment.B?.items?.map((i: string, idx: number) => (
                                  <li key={idx} className="flex items-start gap-2">
                                    <span className="text-emerald-500 mt-0.5">•</span>
                                    {i}
                                  </li>
                                ))}
                              </ul>
                              {equipment.B?.gold > 0 && (
                                <div className="mt-3 pt-2 border-t border-emerald-500/20 text-emerald-600 font-medium flex items-center gap-1">
                                  <Coins className="h-4 w-4" /> {equipment.B.gold} gp
                                </div>
                              )}
                            </div>
                          </>
                        )
                      })()}
                    </div>
                  </div>
                )}

                {/* Class Features */}
                {item.features && (
                  <div className="space-y-3">
                    <h4 className="font-bold text-lg flex items-center gap-2">
                      <Zap className="h-5 w-5 text-yellow-500" />
                      Rasgos de Clase por Nivel
                    </h4>
                    <div className="grid gap-2">
                      {(() => {
                        const features = typeof item.features === 'string' ? parseJson(item.features) : item.features
                        if (!features) return <div className="text-muted-foreground">No disponible</div>
                        
                        return Object.entries(features).map(([level, featureList]: [string, any]) => {
                          if (!featureList || (Array.isArray(featureList) && featureList.length === 0)) return null
                          
                          return (
                            <div key={level} className="p-3 bg-gradient-to-r from-yellow-500/5 to-amber-500/5 rounded-lg border border-yellow-500/10">
                              <div className="flex items-center gap-2 mb-1">
                                <Badge variant="outline" className="bg-yellow-500/10 text-yellow-700 dark:text-yellow-300 border-yellow-500/30">
                                  Nivel {level}
                                </Badge>
                              </div>
                              <div className="flex flex-wrap gap-2">
                                {Array.isArray(featureList) ? featureList.map((feat: string, idx: number) => (
                                  <span key={idx} className="text-sm px-2 py-0.5 bg-muted/50 rounded">
                                    {feat}
                                  </span>
                                )) : <span className="text-sm">{String(featureList)}</span>}
                              </div>
                            </div>
                          )
                        })
                      })()}
                    </div>
                  </div>
                )}

                {/* Spellcasting Badge */}
                {item.spellcasting && (
                  <div className="p-4 bg-gradient-to-r from-purple-500/10 to-violet-500/10 rounded-xl border border-purple-500/20 flex items-center gap-3">
                    <div className="p-2 rounded-lg bg-purple-500/20">
                      <Wand2 className="h-5 w-5 text-purple-500" />
                    </div>
                    <div>
                      <div className="font-semibold text-purple-700 dark:text-purple-300">Lanzador de Conjuros</div>
                      <p className="text-xs text-muted-foreground">Esta clase tiene capacidades de lanzamiento de hechizos.</p>
                    </div>
                  </div>
                )}

                {/* Subclasses */}
                {(() => {
                  const classSubclasses = item.subclasses || []
                  if (classSubclasses.length === 0) return null
                  return (
                    <div className="space-y-3">
                      <h4 className="font-bold text-lg flex items-center gap-2">
                        <GitBranch className="h-5 w-5 text-cyan-500" />
                        Subclases Disponibles
                      </h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {classSubclasses.map((sub: any) => (
                          <div 
                            key={sub.id} 
                            className="p-4 bg-gradient-to-br from-cyan-500/10 to-cyan-600/5 rounded-xl border border-cyan-500/20 cursor-pointer hover:shadow-lg hover:scale-[1.02] transition-all"
                            onClick={() => setSubclassDetailDialog({ open: true, subclass: sub, parentClass: item })}
                          >
                            <div className="flex items-center justify-between">
                              <div className="font-semibold text-cyan-700 dark:text-cyan-300">{sub.name}</div>
                              <Eye className="h-4 w-4 text-cyan-500" />
                            </div>
                            <div className="text-xs text-muted-foreground mt-1">{sub.description}</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )
                })()}
              </>
            )}

            {/* SPECIES SPECIFIC INFO */}
            {type === 'species' && (
              <>
                {/* Basic Stats */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-5 bg-gradient-to-br from-emerald-500/10 to-emerald-600/5 rounded-xl border border-emerald-500/20 text-center">
                    <div className="text-xs text-muted-foreground mb-1">Tamaño</div>
                    <div className="text-3xl font-bold">{item.size}</div>
                  </div>
                  <div className="p-5 bg-gradient-to-br from-blue-500/10 to-blue-600/5 rounded-xl border border-blue-500/20 text-center">
                    <Footprints className="h-5 w-5 mx-auto text-blue-500 mb-1" />
                    <div className="text-xs text-muted-foreground mb-1">Velocidad</div>
                    <div className="text-3xl font-bold">{item.speed} <span className="text-lg">ft</span></div>
                  </div>
                </div>

                {/* Traits */}
                {item.traits && (
                  <div className="space-y-3">
                    <h4 className="font-bold text-lg flex items-center gap-2">
                      <Sparkles className="h-5 w-5 text-yellow-500" />
                      Rasgos de Especie
                    </h4>
                    <div className="grid gap-2">
                      {(() => {
                        const traits = parseJson(item.traits)
                        if (!traits) return <div className="text-muted-foreground">No disponible</div>
                        return Object.entries(traits).map(([key, value]: [string, any]) => (
                          <div key={key} className="p-3 bg-muted/30 rounded-lg border flex justify-between items-start">
                            <span className="font-medium text-primary">{formatTraitName(key)}</span>
                            <span className="text-sm text-right max-w-[60%]">
                              {typeof value === 'object' ? JSON.stringify(value) : String(value)}
                            </span>
                          </div>
                        ))
                      })()}
                    </div>
                  </div>
                )}
              </>
            )}

            {/* BACKGROUND SPECIFIC INFO */}
            {type === 'backgrounds' && (
              <>
                {/* Ability Scores */}
                {item.abilityScores && (
                  <div className="p-5 bg-gradient-to-br from-blue-500/10 to-blue-600/5 rounded-xl border border-blue-500/20">
                    <div className="flex items-center gap-2 font-bold mb-2">
                      <Brain className="h-5 w-5 text-blue-500" />
                      Bonus de Puntuaciones de Característica
                    </div>
                    <p className="text-lg">{item.abilityScores}</p>
                  </div>
                )}

                {/* Feat */}
                {item.feat && (
                  <div className="p-5 bg-gradient-to-br from-amber-500/10 to-amber-600/5 rounded-xl border border-amber-500/20">
                    <div className="flex items-center gap-2 font-bold text-amber-700 dark:text-amber-300 mb-2">
                      <Award className="h-5 w-5" />
                      Dote Otorgado
                    </div>
                    <p className="text-lg">{item.feat}</p>
                  </div>
                )}

                {/* Skill and Tool Proficiencies */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {item.skillProficiencies && (
                    <div className="p-4 bg-muted/30 rounded-xl border">
                      <div className="font-semibold mb-2">Competencias en Habilidades</div>
                      <p className="text-sm text-muted-foreground">{item.skillProficiencies}</p>
                    </div>
                  )}
                  {item.toolProficiency && (
                    <div className="p-4 bg-muted/30 rounded-xl border">
                      <div className="font-semibold mb-2">Competencia en Herramientas</div>
                      <p className="text-sm text-muted-foreground">{item.toolProficiency}</p>
                    </div>
                  )}
                </div>

                {/* Equipment */}
                {item.equipment && (
                  <div className="space-y-3">
                    <h4 className="font-bold text-lg flex items-center gap-2">
                      <Package className="h-5 w-5 text-amber-500" />
                      Equipamiento
                    </h4>
                    <div className="p-4 bg-muted/30 rounded-xl border text-sm prose prose-sm dark:prose-invert max-w-none">
                      {typeof item.equipment === 'string' ? item.equipment : JSON.stringify(item.equipment, null, 2)}
                    </div>
                  </div>
                )}
              </>
            )}

            {/* FEAT SPECIFIC INFO */}
            {type === 'feats' && (
              <>
                {/* Category and Prerequisite */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-5 bg-gradient-to-br from-purple-500/10 to-purple-600/5 rounded-xl border border-purple-500/20 text-center">
                    <div className="text-xs text-muted-foreground mb-1">Categoría</div>
                    <div className="text-xl font-bold text-purple-700 dark:text-purple-300">{item.category || 'General'}</div>
                  </div>
                  <div className="p-5 bg-gradient-to-br from-gray-500/10 to-gray-600/5 rounded-xl border border-gray-500/20 text-center">
                    <div className="text-xs text-muted-foreground mb-1">Prerrequisito</div>
                    <div className="text-xl font-bold">{item.prerequisite || 'Ninguno'}</div>
                  </div>
                </div>

                {/* Repeatable Badge */}
                <div className="flex items-center gap-3">
                  <Badge variant={item.repeatable ? 'default' : 'secondary'} className="text-sm px-4 py-1">
                    {item.repeatable ? '🔄 Repetible' : '📌 No Repetible'}
                  </Badge>
                </div>

                {/* Benefit */}
                {item.benefit && (
                  <div className="space-y-3">
                    <h4 className="font-bold text-lg flex items-center gap-2">
                      <Zap className="h-5 w-5 text-yellow-500" />
                      Beneficio
                    </h4>
                    <div className="p-4 bg-gradient-to-br from-yellow-500/10 to-amber-500/5 rounded-xl border border-yellow-500/20 text-sm">
                      {item.benefit}
                    </div>
                  </div>
                )}

                {/* Additional Info Grid */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                  {item.abilityScoreOptions && (
                    <div className="p-4 bg-gradient-to-br from-blue-500/10 to-blue-600/5 rounded-xl border border-blue-500/20">
                      <div className="text-xs text-muted-foreground mb-1">Mejora de Característica</div>
                      <div className="font-semibold text-blue-700 dark:text-blue-300">
                        {(() => {
                          const options = parseJson(item.abilityScoreOptions)
                          return options ? options.join(', ') : item.abilityScoreOptions
                        })()}
                      </div>
                    </div>
                  )}
                  {item.skillProficienciesGranted && item.skillProficienciesGranted > 0 && (
                    <div className="p-4 bg-gradient-to-br from-green-500/10 to-green-600/5 rounded-xl border border-green-500/20">
                      <div className="text-xs text-muted-foreground mb-1">Habilidades Otorgadas</div>
                      <div className="text-2xl font-bold text-green-600">{item.skillProficienciesGranted}</div>
                    </div>
                  )}
                  {item.expertiseGranted && (
                    <div className="p-4 bg-gradient-to-br from-amber-500/10 to-amber-600/5 rounded-xl border border-amber-500/20">
                      <div className="text-xs text-muted-foreground mb-1">Experiencia</div>
                      <div className="font-semibold text-amber-600">Incluye experiencia</div>
                    </div>
                  )}
                </div>

                {/* Spells Granted */}
                {item.spellsGranted && (
                  <div className="p-4 bg-gradient-to-r from-purple-500/10 to-violet-500/10 rounded-xl border border-purple-500/20">
                    <div className="flex items-center gap-2 font-bold text-purple-700 dark:text-purple-300 mb-2">
                      <Wand2 className="h-5 w-5" />
                      Hechizos Otorgados
                    </div>
                    <p className="text-sm">{item.spellsGranted}</p>
                  </div>
                )}
              </>
            )}

            {/* Close Button */}
            <div className="flex justify-end pt-4 border-t">
              <Button onClick={() => setEncyclopediaDetailItem({ open: false, item: null, type: '' })} className="px-6">
                Cerrar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  // Subclass Detail Dialog - Show full information for selected subclass
  const renderSubclassDetailDialog = () => {
    const subclass = subclassDetailDialog.subclass
    const parentClass = subclassDetailDialog.parentClass
    if (!subclass || !parentClass) return null

    // Helper to parse JSON fields
    const parseJson = (jsonStr: string | null | undefined) => {
      if (!jsonStr) return null
      try {
        return JSON.parse(jsonStr)
      } catch {
        return null
      }
    }

    return (
      <Dialog open={subclassDetailDialog.open} onOpenChange={(open) => setSubclassDetailDialog({ open, subclass: open ? subclass : null, parentClass: open ? parentClass : null })}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <div className="inline-flex items-center gap-3 p-3 rounded-xl mb-2 bg-gradient-to-r from-cyan-500/20 to-cyan-600/10 border border-cyan-500/30">
              <GitBranch className="h-6 w-6 text-cyan-500" />
              <div>
                <DialogTitle className="text-2xl">{subclass.name}</DialogTitle>
                <DialogDescription className="text-sm mt-1">
                  Subclase de {parentClass.name} • {subclass.description}
                </DialogDescription>
              </div>
            </div>
          </DialogHeader>

          <div className="space-y-6 mt-4">
            {/* Description */}
            {subclass.description && (
              <div className="p-4 bg-muted/30 rounded-xl border text-sm leading-relaxed">
                {subclass.description}
              </div>
            )}

            {/* Subclass Features by Level */}
            {subclass.features && (
              <div className="space-y-3">
                <h4 className="font-bold text-lg flex items-center gap-2">
                  <Zap className="h-5 w-5 text-cyan-500" />
                  Rasgos de Subclase por Nivel
                </h4>
                <div className="grid gap-2">
                  {(() => {
                    const features = typeof subclass.features === 'string' ? parseJson(subclass.features) : subclass.features
                    if (!features) return <div className="text-muted-foreground">No disponible</div>
                    
                    return Object.entries(features).map(([level, featureList]: [string, any]) => {
                      if (!featureList || (Array.isArray(featureList) && featureList.length === 0)) return null
                      
                      return (
                        <div key={level} className="p-3 bg-gradient-to-r from-cyan-500/5 to-teal-500/5 rounded-lg border border-cyan-500/10">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge variant="outline" className="bg-cyan-500/10 text-cyan-700 dark:text-cyan-300 border-cyan-500/30">
                              Nivel {level}
                            </Badge>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {Array.isArray(featureList) ? featureList.map((feat: string, idx: number) => (
                              <span key={idx} className="text-sm px-2 py-0.5 bg-muted/50 rounded">
                                {feat}
                              </span>
                            )) : <span className="text-sm">{String(featureList)}</span>}
                          </div>
                        </div>
                      )
                    })
                  })()}
                </div>
              </div>
            )}

            {/* Subclass Spells */}
            {subclass.subclassSpells && (
              <div className="space-y-3">
                <h4 className="font-bold text-lg flex items-center gap-2">
                  <Wand2 className="h-5 w-5 text-purple-500" />
                  Hechizos de Subclase
                </h4>
                <div className="space-y-3">
                  {(() => {
                    const spells = typeof subclass.subclassSpells === 'string' ? parseJson(subclass.subclassSpells) : subclass.subclassSpells
                    if (!spells) return <div className="text-muted-foreground">No disponible</div>
                    
                    return Object.entries(spells).map(([level, spellList]: [string, any]) => {
                      if (!spellList || spellList.length === 0) return null
                      
                      return (
                        <div key={level} className="p-4 bg-gradient-to-r from-purple-500/10 to-violet-500/5 rounded-xl border border-purple-500/20">
                          <div className="flex items-center gap-2 mb-2">
                            <Badge className="bg-purple-500/20 text-purple-700 dark:text-purple-300 border-purple-500/30">
                              Nivel {level}
                            </Badge>
                          </div>
                          <div className="flex flex-wrap gap-2">
                            {spellList.map((spell: string, idx: number) => (
                              <span key={idx} className="text-sm px-3 py-1 bg-purple-500/10 rounded-lg border border-purple-500/20">
                                {spell}
                              </span>
                            ))}
                          </div>
                        </div>
                      )
                    })
                  })()}
                </div>
              </div>
            )}

            {/* Close Button */}
            <div className="flex justify-end pt-4 border-t">
              <Button onClick={() => setSubclassDetailDialog({ open: false, subclass: null, parentClass: null })} className="px-6">
                Cerrar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    )
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <Dices className="h-12 w-12 mx-auto animate-spin" />
          <p className="mt-4 text-muted-foreground">Cargando D&D 2024...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold flex items-center gap-2">
              <Dices className="h-8 w-8" />
              D&D 2024 - Creador de Personajes
            </h1>
            <p className="text-muted-foreground">
              Crea y gestiona tus personajes de Dungeons & Dragons 2024
            </p>
          </div>
          <Button variant="outline" onClick={() => setEncyclopediaDialog(true)}>
            <Library className="h-4 w-4 mr-2" /> Enciclopedia
          </Button>
        </div>

        {/* Main Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
          <TabsList className="grid w-full grid-cols-3 lg:w-auto lg:inline-grid">
            <TabsTrigger value="create">
              <Plus className="h-4 w-4 mr-1" /> Crear
            </TabsTrigger>
            <TabsTrigger value="characters">
              <Users className="h-4 w-4 mr-1" /> Personajes
            </TabsTrigger>
            <TabsTrigger value="sheet" disabled={!selectedCharacter}>
              <Scroll className="h-4 w-4 mr-1" /> Hoja
            </TabsTrigger>
          </TabsList>

          <TabsContent value="create">
            {renderCreationWizard()}
          </TabsContent>

          <TabsContent value="characters">
            {renderCharacterList()}
          </TabsContent>

          <TabsContent value="sheet">
            {renderCharacterSheet()}
          </TabsContent>
        </Tabs>
      </div>

      {/* Dialogs */}
      {renderInfoDialog()}
      {renderLevelUpDialog()}
      {renderInventoryDialog()}
      {renderSpellsDialog()}
      {renderSpellDetailDialog()}
      {renderGrimorioDialog()}
      {renderShopDialog()}
      {renderShopItemDetailDialog()}
      {renderEncyclopediaDialog()}
      {renderEncyclopediaDetailDialog()}
      {renderSubclassDetailDialog()}
      {renderItemDetailDialog()}
      {renderNoteDialog()}
      
      {/* Duplicate Character Dialog */}
      <Dialog open={duplicateDialog.open} onOpenChange={(open) => setDuplicateDialog({ ...duplicateDialog, open })}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Copy className="h-5 w-5" />
              Copiar Personaje
            </DialogTitle>
            <DialogDescription>
              Crea una copia de <strong>{duplicateDialog.character?.name}</strong> con un nuevo nombre.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Nombre del nuevo personaje</Label>
              <Input
                value={duplicateDialog.newName}
                onChange={(e) => setDuplicateDialog({ ...duplicateDialog, newName: e.target.value })}
                placeholder="Nombre del personaje"
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    handleDuplicateCharacter()
                  }
                }}
              />
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setDuplicateDialog({ open: false, character: null, newName: '' })}>
                Cancelar
              </Button>
              <Button 
                onClick={handleDuplicateCharacter}
                disabled={!duplicateDialog.newName.trim()}
              >
                <Copy className="h-4 w-4 mr-1" />
                Crear Copia
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Name Dialog */}
      <Dialog open={editNameDialog} onOpenChange={setEditNameDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Editar Nombre del Personaje</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Nombre</Label>
              <Input
                value={editingName}
                onChange={(e) => setEditingName(e.target.value)}
                placeholder="Nombre del personaje"
              />
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setEditNameDialog(false)}>
                Cancelar
              </Button>
              <Button onClick={() => {
                handleUpdateCharacterName(editingName)
                setEditNameDialog(false)
              }}>
                Guardar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit XP Dialog */}
      <Dialog open={editXpDialog} onOpenChange={setEditXpDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Editar Puntos de Experiencia</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Experiencia (XP)</Label>
              <Input
                type="number"
                min={0}
                value={editingXp}
                onChange={(e) => setEditingXp(Math.max(0, parseInt(e.target.value) || 0))}
                placeholder="0"
              />
              <p className="text-xs text-muted-foreground mt-1">
                Los puntos de experiencia determinan cuándo tu personaje sube de nivel.
              </p>
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setEditXpDialog(false)}>
                Cancelar
              </Button>
              <Button onClick={() => {
                handleUpdateCharacterXp(editingXp)
                setEditXpDialog(false)
              }}>
                Guardar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit Ability Scores Dialog */}
      <Dialog open={editAbilityDialog} onOpenChange={setEditAbilityDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Editar Puntuaciones de Característica</DialogTitle>
            <DialogDescription>
              Modifica las puntuaciones de característica de tu personaje (máximo 20)
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              {[
                { key: 'str', label: 'Fuerza' },
                { key: 'dex', label: 'Destreza' },
                { key: 'con', label: 'Constitución' },
                { key: 'int', label: 'Inteligencia' },
                { key: 'wis', label: 'Sabiduría' },
                { key: 'cha', label: 'Carisma' }
              ].map((ability) => (
                <div key={ability.key}>
                  <Label className="text-xs">{ability.label}</Label>
                  <div className="flex items-center gap-2">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="h-8 w-8 p-0"
                      onClick={() => setEditingAbilities(prev => ({
                        ...prev,
                        [ability.key]: Math.max(1, prev[ability.key as keyof typeof prev] - 1)
                      }))}
                    >
                      -
                    </Button>
                    <Input 
                      type="number"
                      min={1}
                      max={20}
                      value={editingAbilities[ability.key as keyof typeof editingAbilities]}
                      onChange={(e) => setEditingAbilities(prev => ({
                        ...prev,
                        [ability.key]: Math.min(20, Math.max(1, parseInt(e.target.value) || 10))
                      }))}
                      className="w-16 text-center"
                    />
                    <Button 
                      variant="outline" 
                      size="sm" 
                      className="h-8 w-8 p-0"
                      onClick={() => setEditingAbilities(prev => ({
                        ...prev,
                        [ability.key]: Math.min(20, prev[ability.key as keyof typeof prev] + 1)
                      }))}
                    >
                      +
                    </Button>
                    <span className="text-xs text-muted-foreground w-8">
                      {getModifierString(editingAbilities[ability.key as keyof typeof editingAbilities])}
                    </span>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setEditAbilityDialog(false)}>
                Cancelar
              </Button>
              <Button onClick={() => {
                handleUpdateAbilityScores(editingAbilities)
                setEditAbilityDialog(false)
              }}>
                Guardar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Edit HP Dialog */}
      <Dialog open={editHpDialog} onOpenChange={setEditHpDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Editar Puntos de Golpe</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div>
                <Label>PG Actuales</Label>
                <Input 
                  type="number"
                  min={0}
                  value={editingHp.current}
                  onChange={(e) => setEditingHp(prev => ({ ...prev, current: parseInt(e.target.value) || 0 }))}
                />
              </div>
              <div>
                <Label>PG Máximos</Label>
                <Input 
                  type="number"
                  min={1}
                  value={editingHp.max}
                  onChange={(e) => setEditingHp(prev => ({ ...prev, max: parseInt(e.target.value) || 1 }))}
                />
              </div>
              <div>
                <Label>PG Temporales</Label>
                <Input 
                  type="number"
                  min={0}
                  value={editingHp.temp}
                  onChange={(e) => setEditingHp(prev => ({ ...prev, temp: parseInt(e.target.value) || 0 }))}
                />
              </div>
            </div>
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setEditHpDialog(false)}>
                Cancelar
              </Button>
              <Button onClick={() => {
                handleUpdateHp(editingHp)
                setEditHpDialog(false)
              }}>
                Guardar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Edit Character Details Dialog */}
      <Dialog open={editDetailsDialog} onOpenChange={setEditDetailsDialog}>
        <DialogContent className="max-w-2xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>Editar Detalles del Personaje</DialogTitle>
            <DialogDescription>
              Modifica la apariencia, historia y alineamiento de tu personaje
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label className="flex items-center gap-2">
                <User className="h-4 w-4" />
                Apariencia
              </Label>
              <Textarea 
                value={editingDetails.appearance}
                onChange={(e) => setEditingDetails(prev => ({ ...prev, appearance: e.target.value }))}
                placeholder="Describe la apariencia física de tu personaje..."
                className="mt-1 min-h-[100px]"
              />
            </div>
            <div>
              <Label className="flex items-center gap-2">
                <BookOpen className="h-4 w-4" />
                Historia / Trasfondo
              </Label>
              <Textarea 
                value={editingDetails.backgroundStory}
                onChange={(e) => setEditingDetails(prev => ({ ...prev, backgroundStory: e.target.value }))}
                placeholder="Cuéntanos la historia de tu personaje..."
                className="mt-1 min-h-[150px]"
              />
            </div>
            <div>
              <Label className="flex items-center gap-2">
                <Star className="h-4 w-4" />
                Alineamiento
              </Label>
              <Select 
                value={editingDetails.alignment} 
                onValueChange={(value) => setEditingDetails(prev => ({ ...prev, alignment: value }))}
              >
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="Selecciona un alineamiento" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Legal Bueno">Legal Bueno</SelectItem>
                  <SelectItem value="Legal Neutral">Legal Neutral</SelectItem>
                  <SelectItem value="Legal Malvado">Legal Malvado</SelectItem>
                  <SelectItem value="Neutral Bueno">Neutral Bueno</SelectItem>
                  <SelectItem value="Neutral Verdadero">Neutral Verdadero</SelectItem>
                  <SelectItem value="Neutral Malvado">Neutral Malvado</SelectItem>
                  <SelectItem value="Caótico Bueno">Caótico Bueno</SelectItem>
                  <SelectItem value="Caótico Neutral">Caótico Neutral</SelectItem>
                  <SelectItem value="Caótico Malvado">Caótico Malvado</SelectItem>
                  <SelectItem value="Sin alineamiento">Sin alineamiento</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex gap-2 justify-end pt-2">
              <Button variant="outline" onClick={() => setEditDetailsDialog(false)}>
                Cancelar
              </Button>
              <Button onClick={() => {
                handleUpdateDetails(editingDetails)
                setEditDetailsDialog(false)
              }}>
                <Save className="h-4 w-4 mr-2" />
                Guardar Cambios
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Edit Currency Dialog */}
      <Dialog open={editCurrencyDialog} onOpenChange={setEditCurrencyDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              💰 Editar Monedas
            </DialogTitle>
            <DialogDescription>
              Modifica la cantidad de monedas de tu personaje
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-5 gap-3">
              <div>
                <Label className="text-center block mb-1 text-xs">PP</Label>
                <div className="p-2 bg-amber-700/20 rounded text-center">
                  <Input
                    type="number"
                    min="0"
                    value={editingCurrency.pp}
                    onChange={(e) => setEditingCurrency(prev => ({ ...prev, pp: parseInt(e.target.value) || 0 }))}
                    className="w-full text-center text-lg font-bold h-10"
                  />
                </div>
                <p className="text-[10px] text-muted-foreground text-center mt-1">Platino</p>
              </div>
              <div>
                <Label className="text-center block mb-1 text-xs">GP</Label>
                <div className="p-2 bg-yellow-500/20 rounded text-center">
                  <Input
                    type="number"
                    min="0"
                    value={editingCurrency.gp}
                    onChange={(e) => setEditingCurrency(prev => ({ ...prev, gp: parseInt(e.target.value) || 0 }))}
                    className="w-full text-center text-lg font-bold h-10"
                  />
                </div>
                <p className="text-[10px] text-muted-foreground text-center mt-1">Oro</p>
              </div>
              <div>
                <Label className="text-center block mb-1 text-xs">EP</Label>
                <div className="p-2 bg-blue-500/20 rounded text-center">
                  <Input
                    type="number"
                    min="0"
                    value={editingCurrency.ep}
                    onChange={(e) => setEditingCurrency(prev => ({ ...prev, ep: parseInt(e.target.value) || 0 }))}
                    className="w-full text-center text-lg font-bold h-10"
                  />
                </div>
                <p className="text-[10px] text-muted-foreground text-center mt-1">Electrum</p>
              </div>
              <div>
                <Label className="text-center block mb-1 text-xs">SP</Label>
                <div className="p-2 bg-gray-400/20 rounded text-center">
                  <Input
                    type="number"
                    min="0"
                    value={editingCurrency.sp}
                    onChange={(e) => setEditingCurrency(prev => ({ ...prev, sp: parseInt(e.target.value) || 0 }))}
                    className="w-full text-center text-lg font-bold h-10"
                  />
                </div>
                <p className="text-[10px] text-muted-foreground text-center mt-1">Plata</p>
              </div>
              <div>
                <Label className="text-center block mb-1 text-xs">CP</Label>
                <div className="p-2 bg-amber-600/20 rounded text-center">
                  <Input
                    type="number"
                    min="0"
                    value={editingCurrency.cp}
                    onChange={(e) => setEditingCurrency(prev => ({ ...prev, cp: parseInt(e.target.value) || 0 }))}
                    className="w-full text-center text-lg font-bold h-10"
                  />
                </div>
                <p className="text-[10px] text-muted-foreground text-center mt-1">Cobre</p>
              </div>
            </div>
            
            <div className="text-center text-sm text-muted-foreground bg-muted/50 p-2 rounded">
              <p className="font-medium">Conversión:</p>
              <p>1 PP = 10 GP = 100 EP = 1,000 SP = 10,000 CP</p>
            </div>
            
            <div className="flex gap-2 justify-end">
              <Button variant="outline" onClick={() => setEditCurrencyDialog(false)}>
                Cancelar
              </Button>
              <Button onClick={async () => {
                if (selectedCharacter) {
                  await fetch(`/api/characters/${selectedCharacter.id}`, {
                    method: 'PUT',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(editingCurrency)
                  })
                  fetchCharacterDetails(selectedCharacter.id)
                }
                setEditCurrencyDialog(false)
              }}>
                <Save className="h-4 w-4 mr-2" />
                Guardar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Proficiencies Edit Dialog */}
      <Dialog open={!!proficienciesDialog} onOpenChange={(open) => !open && setProficienciesDialog(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {proficienciesDialog === 'tools' && <><Package className="h-5 w-5 text-amber-500" /> Editar Herramientas</>}
              {proficienciesDialog === 'weapons' && <><Sword className="h-5 w-5 text-red-500" /> Editar Armas</>}
              {proficienciesDialog === 'armor' && <><Shield className="h-5 w-5 text-blue-500" /> Editar Armaduras</>}
            </DialogTitle>
            <DialogDescription>
              Añade o elimina proficiencias de tu personaje
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {/* Current proficiencies */}
            <div>
              <Label className="text-sm font-medium mb-2 block">Proficiencias actuales</Label>
              <div className="min-h-[60px] p-3 bg-muted/50 rounded-lg">
                {editingProficiencies.length === 0 ? (
                  <span className="text-sm text-muted-foreground italic">Ninguna proficiencia</span>
                ) : (
                  <div className="flex flex-wrap gap-2">
                    {editingProficiencies.map((prof, idx) => (
                      <Badge 
                        key={idx} 
                        variant="secondary"
                        className={`cursor-pointer transition-all hover:opacity-70 ${
                          proficienciesDialog === 'tools' ? 'bg-orange-500/20 text-orange-400' :
                          proficienciesDialog === 'weapons' ? 'bg-red-500/20 text-red-300' :
                          'bg-blue-500/20 text-blue-300'
                        }`}
                      >
                        {prof}
                        <button
                          className="ml-1 hover:text-destructive"
                          onClick={() => setEditingProficiencies(prev => prev.filter((_, i) => i !== idx))}
                        >
                          ×
                        </button>
                      </Badge>
                    ))}
                  </div>
                )}
              </div>
            </div>
            
            {/* Add new proficiency */}
            <div>
              <Label className="text-sm font-medium mb-2 block">Añadir nueva proficiencia</Label>
              <div className="flex gap-2">
                <Input 
                  value={newProficiency}
                  onChange={(e) => setNewProficiency(e.target.value)}
                  placeholder={proficienciesDialog === 'tools' ? 'ej: Herramientas de ladrón' :
                               proficienciesDialog === 'weapons' ? 'ej: Espadas largas' :
                               'ej: Armadura de placas'}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && newProficiency.trim()) {
                      if (!editingProficiencies.includes(newProficiency.trim())) {
                        setEditingProficiencies(prev => [...prev, newProficiency.trim()])
                      }
                      setNewProficiency('')
                    }
                  }}
                  className="flex-1"
                />
                <Button 
                  variant="outline"
                  disabled={!newProficiency.trim()}
                  onClick={() => {
                    if (newProficiency.trim() && !editingProficiencies.includes(newProficiency.trim())) {
                      setEditingProficiencies(prev => [...prev, newProficiency.trim()])
                    }
                    setNewProficiency('')
                  }}
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </div>
            
            {/* Common suggestions */}
            <div>
              <Label className="text-sm font-medium mb-2 block">Sugerencias comunes</Label>
              <div className="flex flex-wrap gap-1">
                {(proficienciesDialog === 'tools' ? [
                  'Herramientas de ladrón', 'Herramientas de artesano', 'Kit de disfraz', 
                  'Kit de falsificación', 'Kit de herbolarismo', 'Instrumento musical', 
                  'Herramientas de navegación', 'Kit de envenenador', 'Herramientas de alquimista'
                ] : proficienciesDialog === 'weapons' ? [
                  'Armas simples', 'Armas marciales', 'Espadas largas', 'Arcos largos',
                  'Ballestas de mano', 'Hachas de batalla', 'Martillos de guerra', 'Cuchillos'
                ] : [
                  'Armadura ligera', 'Armadura mediana', 'Armadura pesada', 'Escudos',
                  'Armadura de cuero', 'Armadura de mallas', 'Armadura de placas', 'Cota de mallas'
                ]).filter(s => !editingProficiencies.includes(s)).slice(0, 6).map((suggestion) => (
                  <Badge 
                    key={suggestion}
                    variant="outline"
                    className="cursor-pointer hover:bg-primary/10"
                    onClick={() => setEditingProficiencies(prev => [...prev, suggestion])}
                  >
                    + {suggestion}
                  </Badge>
                ))}
              </div>
            </div>
            
            <div className="flex gap-2 justify-end pt-2">
              <Button variant="outline" onClick={() => setProficienciesDialog(null)}>
                Cancelar
              </Button>
              <Button onClick={() => {
                if (proficienciesDialog) {
                  handleUpdateProficiencies(proficienciesDialog, editingProficiencies)
                  setProficienciesDialog(null)
                }
              }}>
                <Save className="h-4 w-4 mr-2" />
                Guardar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Feat Selection Dialog */}
      <Dialog open={featDialog.open} onOpenChange={(open) => {
        setFeatDialog({ open, feat: null })
        if (!open) {
          setFeatSearchTerm('')
          setFeatCategoryFilter('all')
        }
      }}>
        <DialogContent className="max-w-2xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>Seleccionar Dote</DialogTitle>
            <DialogDescription>
              Elige un dote para añadir a tu personaje
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-2">
            <div className="flex gap-2">
              <Input 
                placeholder="Buscar dote..." 
                className="flex-1"
                value={featSearchTerm}
                onChange={(e) => setFeatSearchTerm(e.target.value)}
              />
              <select 
                className="px-3 py-2 border rounded-md"
                value={featCategoryFilter}
                onChange={(e) => setFeatCategoryFilter(e.target.value)}
              >
                <option value="all">Todas las categorías</option>
                <option value="Origin">Origen</option>
                <option value="General">General</option>
                <option value="Fighting Style">Estilo de Combate</option>
                <option value="Epic Boon">Dones Épicos</option>
              </select>
            </div>
            
            <ScrollArea className="h-[400px]">
              {(() => {
                const filteredFeats = allFeats.filter(feat => {
                  const matchesSearch = feat.name.toLowerCase().includes(featSearchTerm.toLowerCase()) ||
                    (feat.description && feat.description.toLowerCase().includes(featSearchTerm.toLowerCase()))
                  const matchesCategory = featCategoryFilter === 'all' || feat.category === featCategoryFilter
                  return matchesSearch && matchesCategory
                })
                
                if (filteredFeats.length === 0) {
                  return (
                    <div className="text-center py-8 text-muted-foreground">
                      {featSearchTerm || featCategoryFilter !== 'all' 
                        ? 'No se encontraron dotes con esos filtros.' 
                        : 'No hay dotes disponibles.'}
                    </div>
                  )
                }
                
                return filteredFeats.map((feat) => {
                  const hasFeat = selectedCharacter?.characterFeats?.some(
                    (cf: any) => cf.featId === feat.id
                  )
                  const isRepeatable = feat.repeatable
                  
                  return (
                    <div 
                      key={feat.id}
                      className={`p-3 border rounded-lg mb-2 cursor-pointer transition-all ${
                        hasFeat && !isRepeatable 
                          ? 'opacity-50 cursor-not-allowed' 
                          : 'hover:border-primary hover:bg-muted/50'
                      }`}
                      onClick={() => {
                        if (!hasFeat || isRepeatable) {
                          handleAddFeat(feat)
                        }
                      }}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <strong>{feat.name}</strong>
                          <Badge variant="outline" className="text-xs">{feat.category}</Badge>
                          {isRepeatable && <Badge className="text-xs bg-blue-600">Repetible</Badge>}
                        </div>
                        {hasFeat && !isRepeatable && (
                          <Badge className="bg-muted text-muted-foreground">Adquirido</Badge>
                        )}
                      </div>
                      {feat.prerequisite && (
                        <p className="text-xs text-amber-600 mt-1">Prerrequisito: {feat.prerequisite}</p>
                      )}
                      <p className="text-sm text-muted-foreground mt-1">{feat.description}</p>
                      {feat.abilityScoreOptions && (
                        <div className="flex gap-1 mt-2">
                          <span className="text-xs text-muted-foreground">Bonificación:</span>
                          {JSON.parse(feat.abilityScoreOptions).map((ab: string) => (
                            <Badge key={ab} variant="secondary" className="text-xs">+1 {ab.substring(0,3).toUpperCase()}</Badge>
                          ))}
                        </div>
                      )}
                      {feat.spellsGranted && (
                        <div className="flex gap-1 mt-2">
                          <span className="text-xs text-muted-foreground">Hechizos:</span>
                          {JSON.parse(feat.spellsGranted).map((sp: string) => (
                            <Badge key={sp} variant="secondary" className="text-xs">{sp}</Badge>
                          ))}
                        </div>
                      )}
                    </div>
                  )
                })
              })()}
            </ScrollArea>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Ability Score Selection Dialog */}
      <Dialog open={featAbilityDialog.open} onOpenChange={(open) => setFeatAbilityDialog({ open, feat: null, abilityOptions: [] })}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Seleccionar Característica</DialogTitle>
            <DialogDescription>
              El dote "{featAbilityDialog.feat?.name}" permite aumentar una característica. Elige cuál:
            </DialogDescription>
          </DialogHeader>
          
          <div className="grid grid-cols-2 gap-2 py-4">
            {featAbilityDialog.abilityOptions.map((ability) => {
              const abilityKey = ability.toLowerCase() as keyof typeof selectedCharacter
              const currentValue = selectedCharacter?.[abilityKey] as number || 10
              const abilityNames: Record<string, string> = {
                strength: 'Fuerza',
                dexterity: 'Destreza',
                constitution: 'Constitución',
                intelligence: 'Inteligencia',
                wisdom: 'Sabiduría',
                charisma: 'Carisma'
              }
              
              return (
                <Button
                  key={ability}
                  variant="outline"
                  className="h-auto py-3 flex flex-col items-center gap-1"
                  onClick={() => handleSelectAbilityForFeat(ability)}
                >
                  <span className="font-bold">{abilityNames[ability]}</span>
                  <span className="text-lg">{currentValue}</span>
                  <span className="text-xs text-green-600">→ {Math.min(currentValue + 1, 20)}</span>
                </Button>
              )
            })}
          </div>
          
          <div className="flex justify-end">
            <Button variant="ghost" onClick={handleSkipAbilitySelection}>
              Omitir por ahora
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Spell Selection Dialog */}
      <Dialog open={featSpellDialog.open} onOpenChange={(open) => setFeatSpellDialog({ open, feat: null, spellOptions: [] })}>
        <DialogContent className="max-w-2xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>Seleccionar Hechizo</DialogTitle>
            <DialogDescription>
              El dote "{featSpellDialog.feat?.name}" permite añadir un hechizo. Elige cuál:
            </DialogDescription>
          </DialogHeader>
          
          <ScrollArea className="h-[400px]">
            <div className="grid grid-cols-1 gap-2 py-2">
              {featSpellDialog.spellOptions.map((spell: Spell) => (
                <div
                  key={spell.id}
                  className="p-3 border rounded-lg cursor-pointer hover:border-primary hover:bg-muted/50 transition-all"
                  onClick={() => handleSelectSpellForFeat(spell.id)}
                >
                  <div className="flex items-center justify-between">
                    <strong>{spell.name}</strong>
                    <div className="flex gap-1">
                      <Badge variant="outline" className="text-xs">{spell.school}</Badge>
                      <Badge variant="secondary" className="text-xs">
                        {spell.level === 0 ? 'Truco' : `Nivel ${spell.level}`}
                      </Badge>
                    </div>
                  </div>
                  <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{spell.description}</p>
                </div>
              ))}
              {featSpellDialog.spellOptions.length === 0 && (
                <div className="text-center py-8 text-muted-foreground">
                  No hay hechizos disponibles con los criterios del dote.
                </div>
              )}
            </div>
          </ScrollArea>
          
          <div className="flex justify-end">
            <Button variant="ghost" onClick={handleSkipSpellSelection}>
              Omitir por ahora
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Skill Selection Dialog */}
      <Dialog open={featSkillDialog.open} onOpenChange={(open) => {
        if (!open) handleSkipSkillSelection()
      }}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Seleccionar Habilidades</DialogTitle>
            <DialogDescription>
              El dote "{featSkillDialog.feat?.name}" permite ganar proficiencia en {featSkillDialog.skillCount} habilidad{featSkillDialog.skillCount > 1 ? 'es' : ''}.
              {featSkillDialog.grantsExpertise && ' También otorga experticia en una habilidad.'}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="text-sm text-muted-foreground">
              Seleccionadas: {featSkillDialog.selectedSkills.length} / {featSkillDialog.skillCount}
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {[
                { name: 'Acrobacia', skill: 'skillAcrobatics' },
                { name: 'Trato con Animales', skill: 'skillAnimalHandling' },
                { name: 'Arcano', skill: 'skillArcana' },
                { name: 'Atletismo', skill: 'skillAthletics' },
                { name: 'Engaño', skill: 'skillDeception' },
                { name: 'Historia', skill: 'skillHistory' },
                { name: 'Perspicacia', skill: 'skillInsight' },
                { name: 'Intimidación', skill: 'skillIntimidation' },
                { name: 'Investigación', skill: 'skillInvestigation' },
                { name: 'Medicina', skill: 'skillMedicine' },
                { name: 'Naturaleza', skill: 'skillNature' },
                { name: 'Percepción', skill: 'skillPerception' },
                { name: 'Interpretación', skill: 'skillPerformance' },
                { name: 'Persuasión', skill: 'skillPersuasion' },
                { name: 'Religión', skill: 'skillReligion' },
                { name: 'Juego de Manos', skill: 'skillSleightOfHand' },
                { name: 'Sigilo', skill: 'skillStealth' },
                { name: 'Supervivencia', skill: 'skillSurvival' }
              ].map((skill) => {
                const isSelected = featSkillDialog.selectedSkills.includes(skill.name)
                const isAlreadyProficient = selectedCharacter ? (selectedCharacter as any)[skill.skill] : false
                
                return (
                  <div
                    key={skill.skill}
                    className={`p-3 border rounded-lg cursor-pointer transition-all ${
                      isSelected 
                        ? 'border-primary bg-primary/20' 
                        : isAlreadyProficient
                          ? 'border-yellow-500/50 bg-yellow-500/10 opacity-60'
                          : 'hover:border-primary hover:bg-muted/50'
                    }`}
                    onClick={() => {
                      if (!isAlreadyProficient || isSelected) {
                        handleToggleSkillForFeat(skill.name)
                      }
                    }}
                  >
                    <div className="flex items-center justify-between">
                      <span className={isSelected ? 'font-bold' : ''}>{skill.name}</span>
                      {isAlreadyProficient && !isSelected && (
                        <Badge variant="outline" className="text-xs text-orange-500">Ya proficiente</Badge>
                      )}
                      {isSelected && (
                        <Badge className="bg-primary text-xs">Seleccionada</Badge>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
          
          <div className="flex justify-between">
            <Button variant="ghost" onClick={handleSkipSkillSelection}>
              Omitir por ahora
            </Button>
            <Button 
              onClick={handleConfirmSkillSelection}
              disabled={featSkillDialog.selectedSkills.length !== featSkillDialog.skillCount}
            >
              Confirmar selección
            </Button>
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Feat Detail Dialog */}
      <Dialog open={featDetailDialog.open} onOpenChange={(open) => setFeatDetailDialog({ open, characterFeat: null })}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>{featDetailDialog.characterFeat?.feat?.name}</DialogTitle>
            <div className="flex gap-2 mt-2">
              <Badge variant="outline">{featDetailDialog.characterFeat?.feat?.category}</Badge>
              {featDetailDialog.characterFeat?.feat?.repeatable && (
                <Badge className="bg-blue-600">Repetible</Badge>
              )}
            </div>
          </DialogHeader>
          
          <div className="space-y-4">
            {featDetailDialog.characterFeat?.feat?.prerequisite && (
              <div>
                <Label className="text-muted-foreground">Prerrequisito</Label>
                <p className="text-sm">{featDetailDialog.characterFeat?.feat?.prerequisite}</p>
              </div>
            )}
            
            <div>
              <Label className="text-muted-foreground">Descripción</Label>
              <p className="text-sm">{featDetailDialog.characterFeat?.feat?.description}</p>
            </div>
            
            <div>
              <Label className="text-muted-foreground">Beneficio</Label>
              <p className="text-sm">{featDetailDialog.characterFeat?.feat?.benefit}</p>
            </div>
            
            {featDetailDialog.characterFeat?.chosenAbilityScore && (
              <div className="p-3 bg-green-100 dark:bg-green-900/30 rounded-lg">
                <Label className="text-green-700 dark:text-green-400">Característica Aumentada</Label>
                <p className="text-sm font-bold text-green-700 dark:text-green-400">
                  +1 {featDetailDialog.characterFeat?.chosenAbilityScore}
                </p>
              </div>
            )}
            
            {featDetailDialog.characterFeat?.chosenSpellId && (
              <div className="p-3 bg-blue-100 dark:bg-blue-900/30 rounded-lg">
                <Label className="text-blue-700 dark:text-blue-400">Hechizo Añadido</Label>
                <p className="text-sm font-bold text-blue-700 dark:text-blue-400">
                  {spells.find((s: Spell) => s.id === featDetailDialog.characterFeat?.chosenSpellId)?.name || 'Hechizo seleccionado'}
                </p>
              </div>
            )}
            
            {featDetailDialog.characterFeat?.feat?.spellsGranted && (
              <div>
                <Label className="text-muted-foreground">Hechizos Concedidos</Label>
                <div className="flex flex-wrap gap-1 mt-1">
                  {JSON.parse(featDetailDialog.characterFeat?.feat?.spellsGranted).map((sp: string) => (
                    <Badge key={sp} variant="secondary">{sp}</Badge>
                  ))}
                </div>
              </div>
            )}
            
            <div>
              <Label className="text-muted-foreground">Origen</Label>
              <p className="text-sm">{featDetailDialog.characterFeat?.source}</p>
            </div>
            
            <div className="flex justify-between pt-4 border-t">
              <Button 
                variant="destructive" 
                onClick={() => handleDeleteFeat(
                  featDetailDialog.characterFeat?.id,
                  featDetailDialog.characterFeat?.feat?.name
                )}
              >
                <Trash2 className="h-4 w-4 mr-2" /> Eliminar Dote
              </Button>
              <Button variant="outline" onClick={() => setFeatDetailDialog({ open: false, characterFeat: null })}>
                Cerrar
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
// rebuild trigger
