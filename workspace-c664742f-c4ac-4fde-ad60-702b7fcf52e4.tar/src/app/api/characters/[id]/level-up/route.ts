import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Multiclass ability score requirements (D&D 2024 rules)
const MULTICLASS_REQUIREMENTS: Record<string, { primary: string; primaryValue: number; secondary?: string; secondaryValue?: number; useOr?: boolean }> = {
  'Barbarian': { primary: 'strength', primaryValue: 13 },
  'Bard': { primary: 'charisma', primaryValue: 13 },
  'Cleric': { primary: 'wisdom', primaryValue: 13 },
  'Druid': { primary: 'wisdom', primaryValue: 13 },
  'Fighter': { primary: 'strength', primaryValue: 13, secondary: 'dexterity', secondaryValue: 13, useOr: true },
  'Monk': { primary: 'dexterity', primaryValue: 13, secondary: 'wisdom', secondaryValue: 13 },
  'Paladin': { primary: 'strength', primaryValue: 13, secondary: 'charisma', secondaryValue: 13 },
  'Ranger': { primary: 'dexterity', primaryValue: 13, secondary: 'wisdom', secondaryValue: 13 },
  'Rogue': { primary: 'dexterity', primaryValue: 13 },
  'Sorcerer': { primary: 'charisma', primaryValue: 13 },
  'Warlock': { primary: 'charisma', primaryValue: 13 },
  'Wizard': { primary: 'intelligence', primaryValue: 13 }
};

// Sources for subclass spells
const SPELL_SOURCES: Record<string, string> = {
  'Cleric': 'domain',
  'Druid': 'circle',
  'Paladin': 'oath',
  'Ranger': 'ranger',
  'Sorcerer': 'sorcerer',
  'Warlock': 'warlock',
};

// Sync subclass spells helper
async function syncSubclassSpells(
  characterId: string, 
  subclassId: string, 
  characterLevel: number, 
  className: string
): Promise<number> {
  try {
    const subclass = await db.subclass.findUnique({
      where: { id: subclassId }
    });
    
    if (!subclass || !subclass.subclassSpells || subclass.subclassSpells === 'null') {
      return 0;
    }
    
    let subclassSpellsByLevel: Record<number, string[]> = {};
    try {
      subclassSpellsByLevel = JSON.parse(subclass.subclassSpells);
    } catch {
      return 0;
    }
    
    const spellSource = SPELL_SOURCES[className] || 'subclass';
    const unlockLevels = Object.keys(subclassSpellsByLevel)
      .map(Number)
      .filter(n => !isNaN(n));
    
    let spellsAdded = 0;
    
    for (const unlockLevel of unlockLevels) {
      if (characterLevel >= unlockLevel && Array.isArray(subclassSpellsByLevel[unlockLevel])) {
        for (const spellName of subclassSpellsByLevel[unlockLevel]) {
          if (!spellName) continue;
          
          try {
            const spell = await db.spell.findFirst({
              where: { name: { equals: spellName } }
            });
            
            if (spell) {
              const existing = await db.characterSpell.findFirst({
                where: { characterId, spellId: spell.id }
              });
              
              if (!existing) {
                await db.characterSpell.create({
                  data: {
                    characterId,
                    spellId: spell.id,
                    prepared: true,
                    known: true,
                    source: spellSource
                  }
                });
                spellsAdded++;
              }
            }
          } catch {
            // Continue on error
          }
        }
      }
    }
    
    return spellsAdded;
  } catch (error) {
    console.error('Error syncing subclass spells:', error);
    return 0;
  }
}

// Check if character meets multiclass requirements for a class
function meetsMulticlassRequirements(character: any, className: string): boolean {
  const requirements = MULTICLASS_REQUIREMENTS[className];
  if (!requirements) return false;

  const abilityMap: Record<string, number> = {
    'strength': character.strength,
    'dexterity': character.dexterity,
    'constitution': character.constitution,
    'intelligence': character.intelligence,
    'wisdom': character.wisdom,
    'charisma': character.charisma
  };

  const primaryValue = abilityMap[requirements.primary] || 0;
  
  if (requirements.useOr) {
    // Fighter: Strength 13 OR Dexterity 13
    const secondaryValue = abilityMap[requirements.secondary!] || 0;
    return primaryValue >= requirements.primaryValue || secondaryValue >= requirements.secondaryValue!;
  } else if (requirements.secondary) {
    // Both required (Monk, Paladin, Ranger)
    const secondaryValue = abilityMap[requirements.secondary] || 0;
    return primaryValue >= requirements.primaryValue && secondaryValue >= requirements.secondaryValue!;
  } else {
    return primaryValue >= requirements.primaryValue;
  }
}

// POST level up character
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    
    const character = await db.character.findUnique({
      where: { id },
      include: {
        characterClass: true
      }
    });
    
    if (!character) {
      return NextResponse.json({ error: 'Character not found' }, { status: 404 });
    }
    
    // Fetch class levels separately
    const classLevels = await db.characterClassLevel.findMany({
      where: { characterId: id },
      include: { class: true }
    });
    
    const newLevel = character.level + 1;
    
    // Check if multiclassing
    const isMulticlass = body.multiclassClassId && body.multiclassClassId !== character.classId;
    
    let hpGain: number;
    let hitDieType: number;
    let classLevelUpdates: any = {};
    
    if (isMulticlass) {
      // Multiclass: Get new class info
      const newClass = await db.characterClass.findUnique({
        where: { id: body.multiclassClassId }
      });
      
      if (!newClass) {
        return NextResponse.json({ error: 'New class not found' }, { status: 404 });
      }
      
      // Check multiclass requirements
      if (!meetsMulticlassRequirements(character, newClass.name)) {
        return NextResponse.json({ 
          error: `No cumples los requisitos para multiclasear como ${newClass.name}. Requiere ${MULTICLASS_REQUIREMENTS[newClass.name] ? formatRequirements(MULTICLASS_REQUIREMENTS[newClass.name]) : 'desconocido'}.`
        }, { status: 400 });
      }
      
      hitDieType = newClass.hitDie;
      const constitutionModifier = Math.floor((character.constitution - 10) / 2);
      hpGain = Math.floor(newClass.hitDie / 2) + 1 + constitutionModifier; // Average + CON
      
      // Create new class level entry for multiclass
      await db.characterClassLevel.create({
        data: {
          characterId: id,
          classId: body.multiclassClassId,
          level: 1,
          hitDieType: newClass.hitDie,
          hitDiceCurrent: 1,
          hitDiceMax: 1,
          isPrimary: false
        }
      });
      
      // Add new class proficiencies
      const currentWeapons = character.weaponProficiencies ? JSON.parse(character.weaponProficiencies) : [];
      const currentArmor = character.armorProficiencies ? JSON.parse(character.armorProficiencies) : [];
      
      const newWeapons = newClass.weaponProficiencies ? JSON.parse(newClass.weaponProficiencies) : [];
      const newArmor = newClass.armorTraining ? JSON.parse(newClass.armorTraining) : [];
      
      // Merge proficiencies (don't add duplicates)
      const mergedWeapons = [...new Set([...currentWeapons, ...newWeapons])];
      const mergedArmor = [...new Set([...currentArmor, ...newArmor])];
      
      classLevelUpdates = {
        weaponProficiencies: JSON.stringify(mergedWeapons),
        armorProficiencies: JSON.stringify(mergedArmor)
      };
      
    } else {
      // Normal level up in existing class
      const hitDie = character.characterClass?.hitDie || 8;
      hitDieType = character.hitDiceType;
      const constitutionModifier = Math.floor((character.constitution - 10) / 2);
      hpGain = Math.floor(hitDie / 2) + 1 + constitutionModifier;
      
      // Update existing class level
      const primaryClassLevel = await db.characterClassLevel.findFirst({
        where: { characterId: id, isPrimary: true }
      });
      
      if (primaryClassLevel) {
        await db.characterClassLevel.update({
          where: { id: primaryClassLevel.id },
          data: {
            level: primaryClassLevel.level + 1,
            hitDiceCurrent: primaryClassLevel.hitDiceCurrent + 1,
            hitDiceMax: primaryClassLevel.hitDiceMax + 1
          }
        });
      } else {
        // Create primary class level if it doesn't exist
        await db.characterClassLevel.create({
          data: {
            characterId: id,
            classId: character.classId!,
            level: newLevel,
            hitDieType: character.hitDiceType,
            hitDiceCurrent: character.hitDiceMax + 1,
            hitDiceMax: character.hitDiceMax + 1,
            isPrimary: true,
            subclassId: body.subclassId || character.subclassId
          }
        });
      }
    }
    
    // Calculate new proficiency bonus
    const proficiencyBonus = Math.ceil(newLevel / 4) + 1;
    
    // Update character
    const updateData: any = {
      level: newLevel,
      maxHp: character.maxHp + hpGain,
      currentHp: character.currentHp + hpGain,
      hitDiceMax: character.hitDiceMax + 1,
      hitDiceCurrent: character.hitDiceCurrent + 1,
      proficiencyBonus: Math.max(2, Math.min(6, proficiencyBonus)),
      
      // Update ability scores if chosen
      ...(body.abilityScores && {
        strength: body.abilityScores.strength || character.strength,
        dexterity: body.abilityScores.dexterity || character.dexterity,
        constitution: body.abilityScores.constitution || character.constitution,
        intelligence: body.abilityScores.intelligence || character.intelligence,
        wisdom: body.abilityScores.wisdom || character.wisdom,
        charisma: body.abilityScores.charisma || character.charisma
      }),
      
      // Update subclass if chosen at level 3
      ...(!isMulticlass && newLevel === 3 && body.subclassId && {
        subclassId: body.subclassId
      }),
      
      // Update XP
      xp: body.xp || character.xp,
      
      // Multiclass updates
      ...(isMulticlass && classLevelUpdates)
    };
    
    const updatedCharacter = await db.character.update({
      where: { id },
      data: updateData,
      include: {
        characterClass: true,
        classLevels: {
          include: { class: true, subclass: true }
        }
      }
    });
    
    // Add feat if chosen
    if (body.featId) {
      const existingFeat = await db.characterFeat.findFirst({
        where: { characterId: id, featId: body.featId }
      });
      
      if (!existingFeat) {
        await db.characterFeat.create({
          data: {
            characterId: id,
            featId: body.featId,
            source: `Level ${newLevel}`
          }
        });
      }
    }
    
    // Add spell if spellcaster chose one
    if (body.spellId) {
      const existingSpell = await db.characterSpell.findFirst({
        where: { characterId: id, spellId: body.spellId }
      });
      
      if (!existingSpell) {
        await db.characterSpell.create({
          data: {
            characterId: id,
            spellId: body.spellId,
            prepared: false,
            known: true
          }
        });
      }
    }
    
    // Sync subclass spells if character has a subclass
    const effectiveSubclassId = body.subclassId || updatedCharacter.subclassId || character.subclassId;
    if (effectiveSubclassId && updatedCharacter.characterClass?.name) {
      await syncSubclassSpells(
        id, 
        effectiveSubclassId, 
        newLevel, 
        updatedCharacter.characterClass.name
      );
    }
    
    return NextResponse.json(updatedCharacter);
  } catch (error) {
    console.error('Error leveling up character:', error);
    return NextResponse.json({ error: 'Failed to level up character' }, { status: 500 });
  }
}

// Helper function to format requirements for display
function formatRequirements(req: { primary: string; primaryValue: number; secondary?: string; secondaryValue?: number; useOr?: boolean }): string {
  const formatAbility = (ability: string) => {
    const names: Record<string, string> = {
      'strength': 'Fuerza',
      'dexterity': 'Destreza',
      'constitution': 'Constitución',
      'intelligence': 'Inteligencia',
      'wisdom': 'Sabiduría',
      'charisma': 'Carisma'
    };
    return `${names[ability] || ability} ${req.primaryValue}`;
  };
  
  if (req.useOr) {
    return `${formatAbility(req.primary)} O ${formatAbility(req.secondary!)} ${req.secondaryValue}`;
  } else if (req.secondary) {
    return `${formatAbility(req.primary)} Y ${formatAbility(req.secondary)} ${req.secondaryValue}`;
  } else {
    return formatAbility(req.primary);
  }
}

// GET level up options
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    const character = await db.character.findUnique({
      where: { id },
      include: {
        characterClass: true,
        subclass: true,
        characterFeats: {
          include: { feat: true }
        },
        characterSpells: {
          include: { spell: true }
        }
      }
    });
    
    if (!character) {
      return NextResponse.json({ error: 'Character not found' }, { status: 404 });
    }
    
    // Fetch class levels separately
    const classLevels = await db.characterClassLevel.findMany({
      where: { characterId: id },
      include: { class: true }
    });
    
    const newLevel = character.level + 1;
    
    // Get all classes for multiclass options
    const allClasses = await db.characterClass.findMany({
      orderBy: { name: 'asc' }
    });
    
    // Filter available multiclass options based on requirements
    const currentClassIds = new Set(classLevels?.map(cl => cl.classId) || []);
    if (character.classId) currentClassIds.add(character.classId);
    
    const availableMulticlassOptions = allClasses.filter(cls => {
      // Can't multiclass into a class you already have
      if (currentClassIds.has(cls.id)) return false;
      // Must meet ability score requirements
      return meetsMulticlassRequirements(character, cls.name);
    });
    
    // Get available feats
    const allFeats = await db.feat.findMany({
      orderBy: { name: 'asc' }
    });
    
    // Get available spells for spellcasters
    let availableSpells: any[] = [];
    if (character.characterClass?.spellcasting) {
      const knownSpellIds = character.characterSpells.map(cs => cs.spellId);
      availableSpells = await db.spell.findMany({
        where: {
          level: { lte: Math.ceil(newLevel / 2) }, // Max spell level
          id: { notIn: knownSpellIds },
          classes: { contains: character.characterClass.name }
        },
        orderBy: [{ level: 'asc' }, { name: 'asc' }]
      });
    }
    
    // Get available subclasses at level 3
    let availableSubclasses: any[] = [];
    if (newLevel === 3 && character.classId && !character.subclassId) {
      availableSubclasses = await db.subclass.findMany({
        where: { classId: character.classId }
      });
    }
    
    // Get class features for new level
    let newFeatures: string[] = [];
    if (character.characterClass?.features) {
      const features = JSON.parse(character.characterClass.features);
      newFeatures = features[newLevel] || [];
    }
    
    // Check if ASI/feat at this level
    const asiLevels = [4, 8, 12, 16, 19];
    const canIncreaseAbilityScores = asiLevels.includes(newLevel);
    
    return NextResponse.json({
      currentLevel: character.level,
      newLevel,
      canIncreaseAbilityScores,
      availableFeats: allFeats,
      availableSpells,
      availableSubclasses,
      newFeatures,
      proficiencyBonusChange: getProficiencyBonusChange(character.level, newLevel),
      // Multiclass options
      canMulticlass: character.level >= 1,
      currentClassLevels: classLevels || [],
      availableMulticlassOptions,
      multiclassRequirements: MULTICLASS_REQUIREMENTS
    });
  } catch (error) {
    console.error('Error getting level up options:', error);
    return NextResponse.json({ error: 'Failed to get level up options' }, { status: 500 });
  }
}

function getProficiencyBonusChange(oldLevel: number, newLevel: number): number {
  const oldBonus = Math.ceil(oldLevel / 4) + 1;
  const newBonus = Math.ceil(newLevel / 4) + 1;
  return Math.max(0, Math.min(4, newBonus - oldBonus));
}
