import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Sources that don't count toward spell limits and can't be removed
const SPELL_SOURCES: Record<string, string> = {
  'Cleric': 'domain',
  'Druid': 'circle',
  'Paladin': 'oath',
  'Ranger': 'ranger',
  'Sorcerer': 'sorcerer',
  'Warlock': 'warlock',
};

// POST - Sync subclass spells for a character
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    
    const { subclassId, characterLevel, className } = body;
    
    // Validate inputs
    if (!subclassId || !className || !characterLevel || characterLevel < 1) {
      return NextResponse.json({ 
        success: false, 
        message: 'Invalid parameters' 
      }, { status: 400 });
    }
    
    // Get subclass with its spells
    const subclass = await db.subclass.findUnique({
      where: { id: subclassId }
    });
    
    if (!subclass) {
      return NextResponse.json({ 
        success: false, 
        message: 'Subclass not found' 
      }, { status: 404 });
    }
    
    // Check if subclass has spells
    if (!subclass.subclassSpells || subclass.subclassSpells === 'null' || subclass.subclassSpells === '{}') {
      return NextResponse.json({ 
        success: true, 
        message: 'No subclass spells to sync',
        spellsAdded: 0
      });
    }
    
    // Parse subclass spells
    let subclassSpellsByLevel: Record<number, string[]> = {};
    try {
      subclassSpellsByLevel = JSON.parse(subclass.subclassSpells);
      if (!subclassSpellsByLevel || typeof subclassSpellsByLevel !== 'object') {
        return NextResponse.json({ 
          success: true, 
          message: 'Invalid subclass spells format',
          spellsAdded: 0
        });
      }
    } catch {
      return NextResponse.json({ 
        success: true, 
        message: 'Could not parse subclass spells',
        spellsAdded: 0
      });
    }
    
    // Determine spell source
    const spellSource = SPELL_SOURCES[className] || 'subclass';
    
    // Get unlock levels
    const unlockLevels = Object.keys(subclassSpellsByLevel)
      .map(Number)
      .filter(n => !isNaN(n))
      .sort((a, b) => a - b);
    
    if (unlockLevels.length === 0) {
      return NextResponse.json({ 
        success: true, 
        message: 'No unlock levels found',
        spellsAdded: 0
      });
    }
    
    let spellsAdded = 0;
    
    // Process each unlock level
    for (const unlockLevel of unlockLevels) {
      if (characterLevel >= unlockLevel && subclassSpellsByLevel[unlockLevel]) {
        const spellsToAdd = subclassSpellsByLevel[unlockLevel];
        
        if (!Array.isArray(spellsToAdd) || spellsToAdd.length === 0) continue;
        
        for (const spellName of spellsToAdd) {
          if (!spellName || typeof spellName !== 'string') continue;
          
          try {
            // Find the spell by name (case-insensitive)
            const spell = await db.spell.findFirst({
              where: {
                name: {
                  equals: spellName
                }
              }
            });
            
            if (spell) {
              // Check if already known
              const existing = await db.characterSpell.findFirst({
                where: {
                  characterId: id,
                  spellId: spell.id
                }
              });
              
              if (!existing) {
                // Add as subclass spell
                await db.characterSpell.create({
                  data: {
                    characterId: id,
                    spellId: spell.id,
                    prepared: true,
                    known: true,
                    source: spellSource
                  }
                });
                spellsAdded++;
              } else if (existing.source === 'class') {
                // Upgrade to protected source
                await db.characterSpell.update({
                  where: { id: existing.id },
                  data: {
                    source: spellSource,
                    prepared: true
                  }
                });
                spellsAdded++;
              }
            }
          } catch (spellError) {
            console.error('Error processing spell:', spellName, spellError);
            // Continue with next spell
          }
        }
      }
    }
    
    return NextResponse.json({ 
      success: true, 
      message: `Synced ${spellsAdded} subclass spells`,
      spellsAdded
    });
  } catch (error) {
    console.error('Error syncing subclass spells:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Failed to sync subclass spells' 
    }, { status: 500 });
  }
}
