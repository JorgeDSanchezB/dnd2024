import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// Sources that don't count toward spell limits and can't be removed
const SPELL_SOURCES: Record<string, string> = {
  'Cleric': 'domain',
  'Druid': 'circle',
  'Paladin': 'oath',
  'Ranger': 'ranger',
  'Sorcerer': 'sorcerer',
  'Warlock': 'warlock',
};

// POST - Sync ALL subclass spells for a character (for multiclass)
export async function POST(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    // Get character with all class levels and their subclasses
    const character = await db.character.findUnique({
      where: { id },
      include: {
        classLevels: {
          include: {
            class: true,
            subclass: true
          }
        }
      }
    });
    
    if (!character) {
      return NextResponse.json({ 
        success: false, 
        message: 'Character not found' 
      }, { status: 404 });
    }
    
    let totalSpellsAdded = 0;
    const results: { className: string; subclassName: string; level: number; spellsAdded: number }[] = [];
    
    // Iterate through all class levels
    for (const classLevel of character.classLevels) {
      // Skip if no subclass
      if (!classLevel.subclassId || !classLevel.subclass) continue;
      
      // Skip if level is less than 3 (subclass chosen at level 3)
      if (classLevel.level < 3) continue;
      
      const subclass = classLevel.subclass;
      const className = classLevel.class.name;
      
      // Check if subclass has spells
      if (!subclass.subclassSpells || subclass.subclassSpells === 'null' || subclass.subclassSpells === '{}') {
        continue;
      }
      
      // Parse subclass spells
      let subclassSpellsByLevel: Record<number, string[]> = {};
      try {
        subclassSpellsByLevel = JSON.parse(subclass.subclassSpells);
        if (!subclassSpellsByLevel || typeof subclassSpellsByLevel !== 'object') {
          continue;
        }
      } catch {
        continue;
      }
      
      // Determine spell source
      const spellSource = SPELL_SOURCES[className] || 'subclass';
      
      // Get unlock levels
      const unlockLevels = Object.keys(subclassSpellsByLevel)
        .map(Number)
        .filter(n => !isNaN(n))
        .sort((a, b) => a - b);
      
      if (unlockLevels.length === 0) continue;
      
      let spellsAddedForClass = 0;
      
      // Process each unlock level
      for (const unlockLevel of unlockLevels) {
        // Check if character's CLASS level (not total level) meets the requirement
        if (classLevel.level >= unlockLevel && subclassSpellsByLevel[unlockLevel]) {
          const spellsToAdd = subclassSpellsByLevel[unlockLevel];
          
          if (!Array.isArray(spellsToAdd) || spellsToAdd.length === 0) continue;
          
          for (const spellName of spellsToAdd) {
            if (!spellName || typeof spellName !== 'string') continue;
            
            try {
              // Find the spell by name
              const spell = await db.spell.findFirst({
                where: {
                  name: {
                    equals: spellName
                  }
                }
              });
              
              if (spell) {
                // Check if already known
                const existing = await db.characterSpell.findFirst({
                  where: {
                    characterId: id,
                    spellId: spell.id
                  }
                });
                
                if (!existing) {
                  // Add as subclass spell with classId for multiclass tracking
                  await db.characterSpell.create({
                    data: {
                      characterId: id,
                      spellId: spell.id,
                      prepared: true,
                      known: true,
                      source: spellSource,
                      classId: classLevel.classId // Track which class this spell belongs to
                    }
                  });
                  spellsAddedForClass++;
                } else if (existing.source === 'class') {
                  // Upgrade to protected source
                  await db.characterSpell.update({
                    where: { id: existing.id },
                    data: {
                      source: spellSource,
                      prepared: true,
                      classId: classLevel.classId
                    }
                  });
                  spellsAddedForClass++;
                }
              }
            } catch (spellError) {
              console.error('Error processing spell:', spellName, spellError);
              // Continue with next spell
            }
          }
        }
      }
      
      if (spellsAddedForClass > 0) {
        results.push({
          className,
          subclassName: subclass.name,
          level: classLevel.level,
          spellsAdded: spellsAddedForClass
        });
        totalSpellsAdded += spellsAddedForClass;
      }
    }
    
    return NextResponse.json({ 
      success: true, 
      message: `Synced ${totalSpellsAdded} subclass spells across ${results.length} classes`,
      totalSpellsAdded,
      details: results
    });
  } catch (error) {
    console.error('Error syncing all subclass spells:', error);
    return NextResponse.json({ 
      success: false, 
      error: 'Failed to sync subclass spells' 
    }, { status: 500 });
  }
}
