import { NextResponse } from 'next/server';
import { db } from '@/lib/db';

// GET single character
export async function GET(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    const character = await db.character.findUnique({
      where: { id },
      include: {
        species: true,
        characterClass: true,
        subclass: true,
        background: true,
        inventoryItems: {
          include: {
            weapon: true,
            armor: true,
            item: true,
            magicItem: true
          }
        },
        characterSpells: {
          include: {
            spell: true
          }
        },
        characterFeats: {
          include: {
            feat: true
          }
        }
      }
    });
    
    if (!character) {
      return NextResponse.json({ error: 'Character not found' }, { status: 404 });
    }
    
    // Fetch class levels separately
    const classLevels = await db.characterClassLevel.findMany({
      where: { characterId: id },
      include: {
        class: true,
        subclass: true
      }
    });
    
    return NextResponse.json({ ...character, classLevels });
  } catch (error) {
    console.error('Error fetching character:', error);
    return NextResponse.json({ error: 'Failed to fetch character' }, { status: 500 });
  }
}

// PUT update character
export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await request.json();
    
    const character = await db.character.update({
      where: { id },
      data: body
    });
    
    return NextResponse.json(character);
  } catch (error) {
    console.error('Error updating character:', error);
    return NextResponse.json({ error: 'Failed to update character' }, { status: 500 });
  }
}

// DELETE character
export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    
    await db.character.delete({
      where: { id }
    });
    
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Error deleting character:', error);
    return NextResponse.json({ error: 'Failed to delete character' }, { status: 500 });
  }
}
