import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// GET - Get all feats for a character
export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    
    const characterFeats = await db.characterFeat.findMany({
      where: { characterId: id },
      include: {
        feat: true
      },
      orderBy: { createdAt: 'desc' }
    })
    
    return NextResponse.json(characterFeats)
  } catch (error) {
    console.error('Error fetching character feats:', error)
    return NextResponse.json({ error: 'Error fetching character feats' }, { status: 500 })
  }
}

// POST - Add a feat to a character
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    
    const { featId, source, chosenAbilityScore, chosenSpellId, chosenSkills } = body
    
    // Check if character already has this feat (and it's not repeatable)
    const feat = await db.feat.findUnique({ where: { id: featId } })
    if (!feat) {
      return NextResponse.json({ error: 'Feat not found' }, { status: 404 })
    }
    
    const existingFeat = await db.characterFeat.findFirst({
      where: { characterId: id, featId }
    })
    
    if (existingFeat && !feat.repeatable) {
      return NextResponse.json({ error: 'Character already has this feat and it is not repeatable' }, { status: 400 })
    }
    
    // Get character current stats
    const character = await db.character.findUnique({ where: { id } })
    if (!character) {
      return NextResponse.json({ error: 'Character not found' }, { status: 404 })
    }
    
    // Skill name to field mapping
    const skillFieldMap: Record<string, string> = {
      'Acrobacia': 'skillAcrobatics',
      'Trato con Animales': 'skillAnimalHandling',
      'Arcano': 'skillArcana',
      'Atletismo': 'skillAthletics',
      'Engaño': 'skillDeception',
      'Historia': 'skillHistory',
      'Perspicacia': 'skillInsight',
      'Intimidación': 'skillIntimidation',
      'Investigación': 'skillInvestigation',
      'Medicina': 'skillMedicine',
      'Naturaleza': 'skillNature',
      'Percepción': 'skillPerception',
      'Interpretación': 'skillPerformance',
      'Persuasión': 'skillPersuasion',
      'Religión': 'skillReligion',
      'Juego de Manos': 'skillSleightOfHand',
      'Sigilo': 'skillStealth',
      'Supervivencia': 'skillSurvival'
    }
    
    // Start a transaction to update everything
    const result = await db.$transaction(async (tx) => {
      // Add the feat to the character
      const characterFeat = await tx.characterFeat.create({
        data: {
          characterId: id,
          featId,
          source: source || 'Level',
          chosenAbilityScore,
          chosenSpellId,
          chosenSkills: chosenSkills ? JSON.stringify(chosenSkills) : null
        },
        include: { feat: true }
      })
      
      // If feat gives ability score bonus and one was chosen, update the character
      if (feat.abilityScoreOptions && chosenAbilityScore) {
        const updateData: Record<string, number> = {}
        const abilityMap: Record<string, string> = {
          strength: 'strength',
          dexterity: 'dexterity',
          constitution: 'constitution',
          intelligence: 'intelligence',
          wisdom: 'wisdom',
          charisma: 'charisma'
        }
        
        const abilityKey = abilityMap[chosenAbilityScore.toLowerCase()]
        if (abilityKey) {
          const currentValue = character[abilityKey as keyof typeof character] as number
          const bonus = feat.abilityScoreBonus || 1
          updateData[abilityKey] = Math.min(currentValue + bonus, 20)
          
          await tx.character.update({
            where: { id },
            data: updateData
          })
        }
      }
      
      // If feat gives skill proficiencies and they were chosen, update the character
      if (chosenSkills && Array.isArray(chosenSkills)) {
        const skillUpdates: Record<string, boolean> = {}
        
        for (const skillName of chosenSkills) {
          const field = skillFieldMap[skillName]
          if (field) {
            skillUpdates[field] = true
          }
        }
        
        if (Object.keys(skillUpdates).length > 0) {
          await tx.character.update({
            where: { id },
            data: skillUpdates
          })
        }
      }
      
      // If feat gives a spell and one was chosen, add it to character spells
      if (chosenSpellId) {
        await tx.characterSpell.create({
          data: {
            characterId: id,
            spellId: chosenSpellId,
            known: true,
            prepared: false
          }
        }).catch(() => {
          // Spell might already exist, ignore error
        })
      }
      
      // If feat has granted spells, add them
      if (feat.spellsGranted) {
        const grantedSpells = JSON.parse(feat.spellsGranted) as string[]
        for (const spellName of grantedSpells) {
          const spell = await tx.spell.findFirst({
            where: { name: { equals: spellName, mode: 'insensitive' } }
          })
          if (spell) {
            await tx.characterSpell.create({
              data: {
                characterId: id,
                spellId: spell.id,
                known: true,
                prepared: false
              }
            }).catch(() => {})
          }
        }
      }
      
      return characterFeat
    })
    
    return NextResponse.json(result)
  } catch (error) {
    console.error('Error adding feat:', error)
    return NextResponse.json({ error: 'Error adding feat' }, { status: 500 })
  }
}

// DELETE - Remove a feat from a character
export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const characterFeatId = request.nextUrl.searchParams.get('characterFeatId')
    
    if (!characterFeatId) {
      return NextResponse.json({ error: 'Character feat ID is required' }, { status: 400 })
    }
    
    // Get the character feat details
    const characterFeat = await db.characterFeat.findUnique({
      where: { id: characterFeatId },
      include: { feat: true }
    })
    
    if (!characterFeat) {
      return NextResponse.json({ error: 'Character feat not found' }, { status: 404 })
    }
    
    // Get character current stats
    const character = await db.character.findUnique({ where: { id } })
    if (!character) {
      return NextResponse.json({ error: 'Character not found' }, { status: 404 })
    }
    
    // Skill name to field mapping
    const skillFieldMap: Record<string, string> = {
      'Acrobacia': 'skillAcrobatics',
      'Trato con Animales': 'skillAnimalHandling',
      'Arcano': 'skillArcana',
      'Atletismo': 'skillAthletics',
      'Engaño': 'skillDeception',
      'Historia': 'skillHistory',
      'Perspicacia': 'skillInsight',
      'Intimidación': 'skillIntimidation',
      'Investigación': 'skillInvestigation',
      'Medicina': 'skillMedicine',
      'Naturaleza': 'skillNature',
      'Percepción': 'skillPerception',
      'Interpretación': 'skillPerformance',
      'Persuasión': 'skillPersuasion',
      'Religión': 'skillReligion',
      'Juego de Manos': 'skillSleightOfHand',
      'Sigilo': 'skillStealth',
      'Supervivencia': 'skillSurvival'
    }
    
    // Start transaction to revert changes
    await db.$transaction(async (tx) => {
      // If feat gave ability score bonus, revert it
      if (characterFeat.feat.abilityScoreOptions && characterFeat.chosenAbilityScore) {
        const updateData: Record<string, number> = {}
        const abilityMap: Record<string, string> = {
          strength: 'strength',
          dexterity: 'dexterity',
          constitution: 'constitution',
          intelligence: 'intelligence',
          wisdom: 'wisdom',
          charisma: 'charisma'
        }
        
        const abilityKey = abilityMap[characterFeat.chosenAbilityScore.toLowerCase()]
        if (abilityKey) {
          const currentValue = character[abilityKey as keyof typeof character] as number
          const bonus = characterFeat.feat.abilityScoreBonus || 1
          updateData[abilityKey] = Math.max(currentValue - bonus, 1)
          
          await tx.character.update({
            where: { id },
            data: updateData
          })
        }
      }
      
      // If feat gave skill proficiencies, revert them
      if (characterFeat.chosenSkills) {
        const chosenSkills = JSON.parse(characterFeat.chosenSkills) as string[]
        const skillUpdates: Record<string, boolean> = {}
        
        for (const skillName of chosenSkills) {
          const field = skillFieldMap[skillName]
          if (field) {
            skillUpdates[field] = false
          }
        }
        
        if (Object.keys(skillUpdates).length > 0) {
          await tx.character.update({
            where: { id },
            data: skillUpdates
          })
        }
      }
      
      // If feat gave a spell, remove it
      if (characterFeat.chosenSpellId) {
        await tx.characterSpell.deleteMany({
          where: {
            characterId: id,
            spellId: characterFeat.chosenSpellId
          }
        }).catch(() => {})
      }
      
      // If feat had granted spells, remove them
      if (characterFeat.feat.spellsGranted) {
        const grantedSpells = JSON.parse(characterFeat.feat.spellsGranted) as string[]
        for (const spellName of grantedSpells) {
          const spell = await tx.spell.findFirst({
            where: { name: { equals: spellName, mode: 'insensitive' } }
          })
          if (spell) {
            await tx.characterSpell.deleteMany({
              where: {
                characterId: id,
                spellId: spell.id
              }
            }).catch(() => {})
          }
        }
      }
      
      // Delete the character feat
      await tx.characterFeat.delete({
        where: { id: characterFeatId }
      })
    })
    
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error removing feat:', error)
    return NextResponse.json({ error: 'Error removing feat' }, { status: 500 })
  }
}
